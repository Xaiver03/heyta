// src/db.types.ts
var assertIterateLimit = (limit) => {
  if (limit === void 0) return;
  if (!Number.isInteger(limit) || limit <= 0) {
    throw new Error(`iterate limit \u5FC5\u987B\u662F\u6B63\u6574\u6570\uFF0C\u6536\u5230\uFF1A${String(limit)}`);
  }
};
var DEFAULT_ITERATE_LIMIT = 1e4;

// src/errors.ts
var StorageError = class extends Error {
  failure;
  constructor(message, failure, cause) {
    super(message);
    this.name = "StorageError";
    this.failure = failure;
    this.cause = cause;
  }
};
function storageError(cause, fallbackMessage, failure) {
  if (cause instanceof Error) return new StorageError(cause.message, failure, cause);
  if (cause === void 0 || cause === null) return new StorageError(fallbackMessage, failure);
  return new StorageError(String(cause), failure, cause);
}
function asStorageError(cause, fallbackMessage, failure) {
  if (cause instanceof StorageError) return cause;
  return storageError(cause, fallbackMessage, failure);
}
var AdapterDestroyedError = class extends StorageError {
  constructor(target) {
    super(
      `\u8FD9\u4EFD\u5B58\u50A8\u5DF2\u88AB\u9500\u6BC1\uFF08${target}\uFF09\u3002\u9500\u6BC1\u540E\u7684\u5B9E\u4F8B\u4E0D\u53EF\u518D\u7528 \u2014\u2014 \u5B83\u4F1A\u62D2\u7EDD\u8BFB\u5199\uFF0C\u800C\u4E0D\u662F\u628A\u521A\u5220\u6389\u7684\u5BB9\u5668\u91CD\u65B0\u5EFA\u6210\u7A7A\u58F3\u3002\u8BF7\u6539\u7528\u4E00\u4E2A\u65B0\u7684\u9002\u914D\u5668\u5B9E\u4F8B\u3002`,
      { kind: "programming-error" }
    );
    this.name = "AdapterDestroyedError";
  }
};

// src/stores.ts
var STORES = {
  /**
   * 操作日志本体。同步系统的唯一事实来源。
   *
   * 主键是自增的 `seq`（本地单调递增），**不是** op 的业务 id ——
   * 因为同步游标、崩溃恢复都要依赖"单调且无空洞"的本地序号。
   */
  OPS: "ops",
  /** 物化后的实体状态（把 ops 重放出来的结果）。可从 OPS 完整重建。 */
  STATE: "state",
  /** 键值型簿记：客户端 id、服务端游标、加密配置等。 */
  META: "meta",
  /** 已归档/压缩的操作（保留用于恢复点与审计）。 */
  ARCHIVE: "archive"
};
var ALL_STORES = [
  STORES.OPS,
  STORES.STATE,
  STORES.META,
  STORES.ARCHIVE
];
var OP_FIELDS = {
  /**
   * ⚠️ **本地**自增序号。
   *
   * 注意与 `Operation.seq`（**服务端**序号）区分：两者名字一样但含义不同。
   * 本常量指顶层 `StoredOperation.seq`（存储记录的主键），
   * 不是嵌套的 `op.seq`。索引 keyPath 因此写顶层 `'seq'`。
   */
  SEQ: "seq",
  /** 操作业务 id（客户端生成的 UUID v7），**唯一索引** —— 用于去重。 */
  OP_ID: "id",
  ENTITY_TYPE: "entityType",
  ENTITY_ID: "entityId",
  /** 多实体批次操作涉及的全部实体 id，**multiEntry 索引**。 */
  ENTITY_IDS: "entityIds",
  PAYLOAD: "payload",
  VECTOR_CLOCK: "vectorClock",
  CLIENT_ID: "clientId",
  CLIENT_TIMESTAMP: "timestamp",
  SCHEMA_VERSION: "schemaVersion",
  /**
   * 上传状态，**字符串不是布尔**。
   *
   * 同一个理由再踩一次就太蠢了：IndexedDB 不能索引布尔值 ——
   * `true` 不是合法的 IDB key，索引里不会产生条目，查询恒返回空**且不报错**。
   */
  UPLOAD_STATUS: "uploadStatus",
  /**
   * 🔴 应用状态。**必须用字符串，不能用布尔。**
   *
   * 为什么：**IndexedDB 不允许布尔值作为键** —— `true` 不是合法的 IDB key，
   * 所以对布尔字段建索引时，索引条目会被**静默跳过**（不报错，只是查不到）。
   * 我第一版就是用 `pendingApply: true` 建索引，结果 `findPendingApply()`
   * 永远返回空数组 —— 崩溃恢复完全失效，而且没有任何错误提示。
   *
   * 取值见 {@link ApplyStatus}。
   */
  APPLY_STATUS: "applyStatus"
};
var UPLOAD_STATUSES = ["pending", "uploaded", "rejected"];
var _opFieldShape = {
  OP_ID: OP_FIELDS.OP_ID,
  ENTITY_TYPE: OP_FIELDS.ENTITY_TYPE,
  ENTITY_ID: OP_FIELDS.ENTITY_ID,
  ENTITY_IDS: OP_FIELDS.ENTITY_IDS,
  PAYLOAD: OP_FIELDS.PAYLOAD,
  VECTOR_CLOCK: OP_FIELDS.VECTOR_CLOCK,
  CLIENT_ID: OP_FIELDS.CLIENT_ID,
  CLIENT_TIMESTAMP: OP_FIELDS.CLIENT_TIMESTAMP,
  SCHEMA_VERSION: OP_FIELDS.SCHEMA_VERSION
};
var OP_INDEXES = {
  /** 唯一：同一 op 不得写入两次。 */
  OP_ID: "by_opId",
  /** 按实体查询：['entityType','entityId'] 复合索引。 */
  ENTITY: "by_entity",
  /** 多实体批次：multiEntry，用于 GIN 式查询的对等物。 */
  ENTITY_IDS: "by_entityIds",
  /** 崩溃恢复扫描：找出所有 applyStatus='pending' 的记录。 */
  PENDING_APPLY: "by_applyStatus",
  /** 按上传状态查待同步的 op（离线队列）。 */
  PENDING_UPLOAD: "by_uploadStatus"
};
var STATE_FIELDS = {
  ENTITY_TYPE: "entityType",
  ENTITY_ID: "entityId",
  DATA: "data",
  /** 最后作用于该实体的 op 的本地 seq，用于快速判断新鲜度。 */
  LAST_SEQ: "lastSeq"
};
var STATE_KEY_PATH = [STATE_FIELDS.ENTITY_TYPE, STATE_FIELDS.ENTITY_ID];
var META_FIELDS = {
  KEY: "key",
  VALUE: "value"
};
var META_KEYS = {
  /** 本设备的稳定 id。LWW 冲突决胜依据，**一经生成不可更改**。 */
  CLIENT_ID: "clientId",
  /** 已从服务端拉取到的最大 serverSeq（同步游标）。 */
  LAST_SERVER_SEQ: "lastServerSeq",
  /** 本地最大的 seq。 */
  LAST_LOCAL_SEQ: "lastLocalSeq",
  /** 加密是否启用。 */
  ENCRYPTION_ENABLED: "encryptionEnabled",
  /** 最后成功同步的时间。 */
  LAST_SYNCED_AT: "lastSyncedAt",
  /**
   * 服务端已确认的因果前沿。
   *
   * 这是同步恢复所需的独立簿记，不能复用 materialized checkpoint：
   * checkpoint 是可删除的本地加速缓存，而这个前沿是服务端确认过的事实。
   */
  OBSERVED_CLOCK: "observedClock",
  /** 历史曾经不完整（例如存在无法解密的远程 op），只能置 true。 */
  HISTORY_INCOMPLETE: "historyIncomplete",
  /** Opaque wrapped vault key package; never contains a plaintext root key. */
  VAULT_KEY_PACKAGE: "vaultKeyPackageV1",
  /** Account/server scope paired atomically with the opaque vault package. */
  VAULT_KEY_SCOPE: "vaultKeyScopeV1",
  /** Ciphertext-only durable key-migration journal; no root/plaintext/password. */
  VAULT_MIGRATION_JOURNAL: "vaultMigrationJournalV1",
  /** 上一次成功拉到的公共事实响应体（`HolidayAdjustmentsResponse` 的 JSON）。 */
  PUBLIC_FACTS_JSON: "publicFactsJson",
  /** 它对应的版本令牌（服务端 ETag 的候选值），条件请求时原样回传。 */
  PUBLIC_FACTS_ETAG: "publicFactsEtag",
  /** 那次拉取的本地毫秒时间戳（只用于"缓存多旧"，不参与任何裁决）。 */
  PUBLIC_FACTS_FETCHED_AT: "publicFactsFetchedAt",
  /** Active encrypted-payload generation paired with the local key package. */
  VAULT_PAYLOAD_KEY_VERSION: "vaultPayloadKeyVersionV1",
  /** Encrypted pending root-rotation target; never stores a plaintext root. */
  VAULT_PENDING_ROOT_ROTATION: "vaultPendingRootRotationV1",
  /** Account-scoped inbound automation recipient private key wrapped by the vault root. */
  INBOUND_RECIPIENT_KEY: "inboundRecipientKeyV1",
  /** Worker token envelope; the plaintext token never enters the op-log. */
  INBOUND_WORKER_CREDENTIAL: "inboundWorkerCredentialV1",
  /** Event → opaque commit proof journal used by the upload fence. */
  INBOUND_COMMIT_JOURNAL: "inboundCommitJournalV1"
};

// src/op-log-store.ts
var OpLogStoreErrorCode = /* @__PURE__ */ ((OpLogStoreErrorCode2) => {
  OpLogStoreErrorCode2["DUPLICATE_OP_ID"] = "DUPLICATE_OP_ID";
  OpLogStoreErrorCode2["SEQ_GAP"] = "SEQ_GAP";
  OpLogStoreErrorCode2["NESTED_TRANSACTION"] = "NESTED_TRANSACTION";
  OpLogStoreErrorCode2["STORAGE_UNAVAILABLE"] = "STORAGE_UNAVAILABLE";
  OpLogStoreErrorCode2["ARCHIVE_REQUIRES_CHECKPOINT"] = "ARCHIVE_REQUIRES_CHECKPOINT";
  return OpLogStoreErrorCode2;
})(OpLogStoreErrorCode || {});
var OpLogStoreError = class extends Error {
  constructor(code, message) {
    super(message);
    this.code = code;
    this.name = "OpLogStoreError";
  }
  code;
};

// src/checkpoint.ts
function checkpointChecksum(checkpoint) {
  const input = JSON.stringify(checkpoint);
  let hash = 2166136261;
  for (let index = 0; index < input.length; index += 1) {
    hash ^= input.charCodeAt(index);
    hash = Math.imul(hash, 16777619);
  }
  return (hash >>> 0).toString(16).padStart(8, "0");
}
function isValidCheckpoint(checkpoint, lastLocalSeq) {
  if (!checkpoint || typeof checkpoint !== "object" || Array.isArray(checkpoint)) return false;
  const candidate = checkpoint;
  if (candidate.formatVersion !== 1) return false;
  if (!Number.isInteger(candidate.coveredSeq) || candidate.coveredSeq < 0) return false;
  if (candidate.coveredSeq > lastLocalSeq) return false;
  if (candidate.state === void 0 || candidate.state === null) return false;
  if (candidate.clock === null || typeof candidate.clock !== "object") return false;
  if (Array.isArray(candidate.clock) || Object.values(candidate.clock).some(
    (counter) => !Number.isSafeInteger(counter) || counter < 0
  )) return false;
  if (!Array.isArray(candidate.appliedOpIds) || candidate.appliedOpIds.some((id) => typeof id !== "string")) return false;
  if (typeof candidate.checksum !== "string" || candidate.checksum.length === 0) return false;
  const { checksum, ...base } = candidate;
  return checksum === checkpointChecksum(base);
}

// src/indexeddb/indexeddb-adapter.ts
var DB_SCHEMA_VERSION = 2;
var INDEXEDDB_SCHEMA = [
  {
    name: STORES.OPS,
    keyPath: OP_FIELDS.SEQ,
    autoIncrement: true,
    indexes: [
      // ⚠️ keyPath 必须指向 `op.*`。存进去的记录形状是 { op, source, applyStatus }，
      // op 的业务字段是**嵌套**的。我第一版把 keyPath 写成顶层 `entityType`，
      // 于是索引全部命中不到任何记录 —— 不报错，只是查询恒返回空。
      { name: OP_INDEXES.OP_ID, keyPath: `op.${OP_FIELDS.OP_ID}`, unique: true },
      { name: OP_INDEXES.PENDING_UPLOAD, keyPath: OP_FIELDS.UPLOAD_STATUS },
      {
        name: OP_INDEXES.ENTITY,
        keyPath: [`op.${OP_FIELDS.ENTITY_TYPE}`, `op.${OP_FIELDS.ENTITY_ID}`]
      },
      {
        name: OP_INDEXES.ENTITY_IDS,
        keyPath: `op.${OP_FIELDS.ENTITY_IDS}`,
        multiEntry: true
      },
      // applyStatus 是**字符串**（不是布尔）—— 布尔不能作为 IDB 键
      { name: OP_INDEXES.PENDING_APPLY, keyPath: OP_FIELDS.APPLY_STATUS }
    ]
  },
  {
    name: STORES.STATE,
    keyPath: ["entityType", "entityId"]
  },
  {
    name: STORES.META,
    keyPath: "key"
  },
  {
    name: STORES.ARCHIVE,
    keyPath: OP_FIELDS.SEQ,
    indexes: [
      { name: OP_INDEXES.OP_ID, keyPath: `op.${OP_FIELDS.OP_ID}`, unique: true }
    ]
  }
];
function toIdbQuery(query) {
  if (query === void 0) return void 0;
  if (Array.isArray(query)) return query;
  if (typeof query === "string" || typeof query === "number") return query;
  return buildRange(query);
}
function buildRange(range) {
  if (range === void 0) return void 0;
  const { lower, upper, lowerOpen, upperOpen } = range;
  if (lower !== void 0 && upper !== void 0) {
    return IDBKeyRange.bound(lower, upper, lowerOpen ?? false, upperOpen ?? false);
  }
  if (lower !== void 0) return IDBKeyRange.lowerBound(lower, lowerOpen ?? false);
  if (upper !== void 0) return IDBKeyRange.upperBound(upper, upperOpen ?? false);
  return void 0;
}
function applyCursorAction(cursor, action) {
  switch (action) {
    case "continue":
      cursor.continue();
      return true;
    case "stop":
      return false;
    case "delete":
      cursor.delete();
      cursor.continue();
      return true;
    case "delete-stop":
      cursor.delete();
      return false;
  }
}
function req(request, suppressError = false) {
  return new Promise((resolve, reject) => {
    request.onsuccess = () => resolve(request.result);
    request.onerror = (event) => {
      if (suppressError) {
        event.preventDefault();
        event.stopPropagation();
      }
      reject(storageError(request.error, "IndexedDB \u8BF7\u6C42\u5931\u8D25", { kind: "request-failed" }));
    };
  });
}
var IndexedDbAdapter = class {
  constructor(dbName = "heyta") {
    this.dbName = dbName;
  }
  dbName;
  db;
  opening;
  /** 销毁即死路 —— 理由与 `sqlite-adapter.ts` 的 `destroyed` 那段相同（E2 口径 B）。 */
  destroyed = false;
  /** 第二次 `destroy()` 用这份缓存，不再跑一遍 `deleteDatabase`。 */
  destroying;
  init() {
    return this.open().then(() => void 0);
  }
  /**
   * 打开数据库。
   *
   * **并发安全**：用 `opening` 缓存 in-flight 的 Promise ——
   * 否则并发 init 会开多个连接，而 upgrade 事务在多个连接间会互相阻塞。
   */
  open() {
    if (this.destroyed) return Promise.reject(new AdapterDestroyedError(this.dbName));
    if (this.db !== void 0) return Promise.resolve(this.db);
    if (this.opening !== void 0) return this.opening;
    this.opening = new Promise((resolve, reject) => {
      const request = indexedDB.open(this.dbName, DB_SCHEMA_VERSION);
      request.onupgradeneeded = () => {
        const db = request.result;
        for (const store of INDEXEDDB_SCHEMA) {
          const objectStore = db.objectStoreNames.contains(store.name) ? request.transaction.objectStore(store.name) : db.createObjectStore(store.name, {
            keyPath: store.keyPath,
            autoIncrement: store.autoIncrement ?? false
          });
          for (const index of store.indexes ?? []) {
            if (objectStore.indexNames.contains(index.name)) continue;
            objectStore.createIndex(index.name, index.keyPath, {
              unique: index.unique ?? false,
              multiEntry: index.multiEntry ?? false
            });
          }
        }
      };
      request.onsuccess = () => {
        this.db = request.result;
        request.result.onclose = () => {
          this.db = void 0;
          this.opening = void 0;
        };
        request.result.onversionchange = () => {
          request.result.close();
          this.db = void 0;
          this.opening = void 0;
        };
        resolve(request.result);
      };
      request.onerror = () => reject(storageError(request.error, "\u65E0\u6CD5\u6253\u5F00 IndexedDB", { kind: "open-failed" }));
      request.onblocked = () => reject(
        new StorageError(
          "IndexedDB \u5347\u7EA7\u88AB\u5176\u5B83\u6807\u7B7E\u9875\u963B\u585E \u2014\u2014 \u8BF7\u5173\u95ED\u8BE5\u5E94\u7528\u7684\u5176\u5B83\u7A97\u53E3\u540E\u91CD\u8BD5",
          { kind: "upgrade-blocked" }
        )
      );
    });
    return this.opening;
  }
  close() {
    this.db?.close();
    this.db = void 0;
    this.opening = void 0;
  }
  // ── 事务 ────────────────────────────────────────────────
  /**
   * 执行一个原子事务。
   *
   * ⚠️ 返回的 Promise **在 oncomplete 才决议**（见文件头陷阱 2）。
   */
  async transaction(stores, mode, fn) {
    const db = await this.open();
    return new Promise((resolve, reject) => {
      let idbTx;
      try {
        idbTx = db.transaction(stores, mode);
      } catch (error) {
        reject(asStorageError(error, "\u65E0\u6CD5\u5F00\u59CB\u4E8B\u52A1", { kind: "programming-error" }));
        return;
      }
      let result;
      let settled = false;
      idbTx.oncomplete = () => {
        settled = true;
        resolve(result);
      };
      idbTx.onabort = () => {
        if (settled) return;
        settled = true;
        reject(storageError(idbTx.error, "IndexedDB \u4E8B\u52A1\u88AB\u4E2D\u6B62", { kind: "transaction-failed" }));
      };
      idbTx.onerror = () => {
        if (settled) return;
        settled = true;
        reject(storageError(idbTx.error, "IndexedDB \u4E8B\u52A1\u5931\u8D25", { kind: "transaction-failed" }));
      };
      const tx = this.makeTx(idbTx, stores);
      fn(tx).then(
        (value) => {
          result = value;
          try {
            idbTx.commit?.();
          } catch {
          }
        },
        (error) => {
          settled = true;
          try {
            idbTx.abort();
          } catch {
          }
          reject(asStorageError(error, "\u4E8B\u52A1\u5185\u7684\u64CD\u4F5C\u5931\u8D25", { kind: "request-failed" }));
        }
      );
    });
  }
  makeTx(idbTx, allowed) {
    const storeNames = new Set(allowed);
    const assert = (store2) => {
      if (!storeNames.has(store2)) {
        throw new StorageError(
          `\u4E8B\u52A1\u672A\u5305\u542B store\u300C${store2}\u300D\u3002\u8BF7\u628A\u5B83\u52A0\u8FDB transaction([...]) \u7684\u5217\u8868\uFF1A${allowed.join(", ")}`,
          { kind: "programming-error" }
        );
      }
    };
    const store = (name) => {
      assert(name);
      return idbTx.objectStore(name);
    };
    const api = {
      add: (s, value) => req(store(s).add(value)),
      /**
       * 冲突可容忍的 add。
       *
       * 用在 op-log 写入上：同一个 opId 被重复投递是**正常路径**
       * （同步会重放、客户端会重试），不是异常。
       */
      addToleratingDuplicate: async (storeName, value) => {
        try {
          const key = await req(store(storeName).add(value), true);
          return { ok: true, key: typeof key === "number" ? key : Number(key) };
        } catch (error) {
          const driverError = error instanceof StorageError ? error.cause : error;
          if (typeof driverError === "object" && driverError !== null && "name" in driverError && driverError.name === "ConstraintError") {
            return { ok: false, reason: "duplicate" };
          }
          throw error;
        }
      },
      put: (s, value, key) => key === void 0 ? req(store(s).put(value)).then(() => void 0) : req(store(s).put(value, key)).then(() => void 0),
      get: (s, key) => req(store(s).get(key)),
      getAll: (s, range, limit) => {
        assertIterateLimit(limit);
        return req(store(s).getAll(buildRange(range), limit));
      },
      delete: (s, key) => req(store(s).delete(key)).then(() => void 0),
      clear: (s) => req(store(s).clear()).then(() => void 0),
      count: (s, range) => req(store(s).count(buildRange(range))),
      getFromIndex: (s, index, key) => req(store(s).index(index).get(key)),
      // IDBValidKey 比我们的 DbKey 宽（还包含 Date / ArrayBuffer），
      // 但本项目所有主键都是 string | number。在边界处收窄并注明，
      // 而不是把 DbKey 放宽到 IDBValidKey —— 那会让上层也得处理 Date。
      getKeyFromIndex: (s, index, key) => req(store(s).index(index).getKey(key)),
      getAllFromIndex: (s, index, query) => {
        return req(store(s).index(index).getAll(toIdbQuery(query)));
      },
      countFromIndex: (s, index, query) => {
        return req(store(s).index(index).count(toIdbQuery(query)));
      },
      iterate: (s, options, visit) => this.iterateIn(store(s), options, visit)
    };
    return api;
  }
  /** 游标遍历。抽出来是因为顶层方法和事务方法共用它。 */
  iterateIn(source, options, visit) {
    assertIterateLimit(options.limit);
    return new Promise((resolve, reject) => {
      let visited = 0;
      const limit = options.limit;
      const range = buildRange({ lower: options.lower, upper: options.upper });
      const direction = options.direction ?? "next";
      const request = source.openCursor(range, direction);
      request.onsuccess = () => {
        const cursor = request.result;
        if (cursor === null) {
          resolve();
          return;
        }
        if (limit !== void 0 && visited >= limit) {
          resolve();
          return;
        }
        visited += 1;
        const action = visit(cursor.value, cursor.key);
        if (!applyCursorAction(cursor, action)) {
          resolve();
        }
      };
      request.onerror = () => reject(storageError(request.error, "IndexedDB \u6E38\u6807\u5931\u8D25", { kind: "request-failed" }));
    });
  }
  // ── 顶层便捷方法：包一个单 store 事务 ────────────────────
  async add(store, value) {
    return this.transaction([store], "readwrite", (tx) => tx.add(store, value));
  }
  async put(store, value, key) {
    return this.transaction([store], "readwrite", (tx) => tx.put(store, value, key));
  }
  async get(store, key) {
    return this.transaction([store], "readonly", (tx) => tx.get(store, key));
  }
  async getAll(store, range, limit) {
    return this.transaction([store], "readonly", (tx) => tx.getAll(store, range, limit));
  }
  async delete(store, key) {
    return this.transaction([store], "readwrite", (tx) => tx.delete(store, key));
  }
  async clear(store) {
    return this.transaction([store], "readwrite", (tx) => tx.clear(store));
  }
  async count(store, range) {
    return this.transaction([store], "readonly", (tx) => tx.count(store, range));
  }
  async getFromIndex(store, index, key) {
    return this.transaction(
      [store],
      "readonly",
      (tx) => tx.getFromIndex(store, index, key)
    );
  }
  async getKeyFromIndex(store, index, key) {
    return this.transaction(
      [store],
      "readonly",
      (tx) => tx.getKeyFromIndex(store, index, key)
    );
  }
  async getAllFromIndex(store, index, query) {
    return this.transaction(
      [store],
      "readonly",
      (tx) => tx.getAllFromIndex(store, index, query)
    );
  }
  async countFromIndex(store, index, query) {
    return this.transaction(
      [store],
      "readonly",
      (tx) => tx.countFromIndex(store, index, query)
    );
  }
  async iterate(store, options, visit) {
    return this.transaction([store], "readwrite", async (tx) => {
      await tx.iterate(store, options, visit);
    });
  }
  /**
   * 删除整个数据库（`indexedDB.deleteDatabase`）。
   *
   * 🔴 `onblocked` **以前是 `resolve()` 的，那是假凭据**：blocked 的含义是
   * "还有别的标签页/窗口持有连接，删除请求排在它后面"，此刻数据库**还在**。
   * 当场 resolve 会让销毁报告在"什么都没删掉"的情况下说"删了"，
   * 而调用方拿到的正是那句用来对用户承诺的话。
   * 现在 blocked 只是**等待**：决议只来自 onsuccess / onerror。
   *
   * ⚠️ 代价要想清楚：另一个标签页永不关闭时，这个 Promise 会一直挂着。
   * 这是**诚实的**挂起（"我还没做到"），而不是虚假的完成（"我做到了"）。
   * 宿主如果要给用户一个期限，应该在**调用这一层的界面**上做超时并说
   * "另有一个窗口开着，关掉它才能清干净" —— 那不是这一层能替用户决定的事。
   */
  async destroy() {
    if (this.destroying !== void 0) return this.destroying;
    this.destroyed = true;
    const pending = (async () => {
      this.close();
      await new Promise((resolve, reject) => {
        const request = indexedDB.deleteDatabase(this.dbName);
        request.onsuccess = () => resolve();
        request.onerror = () => reject(storageError(request.error, "\u5220\u9664\u6570\u636E\u5E93\u5931\u8D25", { kind: "request-failed" }));
        request.onblocked = () => {
        };
      });
      return { target: this.dbName, containerRemoved: true, storesCleared: ALL_STORES.length };
    })();
    this.destroying = pending.catch((error) => {
      this.destroyed = false;
      this.destroying = void 0;
      throw error;
    });
    return this.destroying;
  }
};
var ALL_STORE_NAMES = ALL_STORES;

// src/sqlite/sqlite-adapter.ts
var q = (identifier) => `"${identifier.replace(/"/g, '""')}"`;
var SEQ_TABLE = "__heyta_seq";
function keyRank(k) {
  if (typeof k === "number") return 0;
  if (typeof k === "string") return 2;
  if (Array.isArray(k)) return 4;
  return 3;
}
function compareKeys(a, b) {
  if (Array.isArray(a) || Array.isArray(b)) {
    if (Array.isArray(a) !== Array.isArray(b)) return keyRank(a) - keyRank(b);
    const arrA = a;
    const arrB = b;
    const len = Math.min(arrA.length, arrB.length);
    for (let i = 0; i < len; i++) {
      const diff = compareKeys(arrA[i], arrB[i]);
      if (diff !== 0) return diff;
    }
    return arrA.length - arrB.length;
  }
  const rankDiff = keyRank(a) - keyRank(b);
  if (rankDiff !== 0) return rankDiff;
  if (typeof a === "number" && typeof b === "number") return a - b;
  const sa = String(a);
  const sb = String(b);
  return sa < sb ? -1 : sa > sb ? 1 : 0;
}
function keyInRange(key, range) {
  if (range === void 0) return true;
  const { lower, upper, lowerOpen, upperOpen } = range;
  if (lower !== void 0) {
    const diff = compareKeys(key, lower);
    if (diff < 0 || diff === 0 && lowerOpen === true) return false;
  }
  if (upper !== void 0) {
    const diff = compareKeys(key, upper);
    if (diff > 0 || diff === 0 && upperOpen === true) return false;
  }
  return true;
}
function valueAtPath(value, path) {
  let current = value;
  for (const segment of path.split(".")) {
    if (current === null || typeof current !== "object") return void 0;
    current = current[segment];
  }
  return current;
}
function setAtPath(target, path, value) {
  const segments = path.split(".");
  let current = target;
  for (let i = 0; i < segments.length - 1; i++) {
    const segment = segments[i];
    const next = current[segment];
    if (next === null || typeof next !== "object") current[segment] = {};
    current = current[segment];
  }
  current[segments[segments.length - 1]] = value;
}
function isKeyValue(v) {
  return typeof v === "string" || typeof v === "number";
}
function buildStorePlan(schema) {
  const table = schema.name;
  const pkPaths = typeof schema.keyPath === "string" ? [schema.keyPath] : [...schema.keyPath];
  const pkColumns = pkPaths.map((_p, i) => `pk${i}`);
  const indexes = [];
  const byName = /* @__PURE__ */ new Map();
  (schema.indexes ?? []).forEach((index, ordinal) => {
    const paths = typeof index.keyPath === "string" ? [index.keyPath] : [...index.keyPath];
    if (index.multiEntry === true && paths.length !== 1) {
      throw new Error(
        `\u7D22\u5F15\u300C${index.name}\u300D\uFF1AmultiEntry \u53EA\u652F\u6301\u5355\u4E2A keyPath\uFF0C\u6536\u5230 ${JSON.stringify(index.keyPath)}`
      );
    }
    const plan = {
      name: index.name,
      multiEntry: index.multiEntry === true,
      unique: index.unique === true,
      paths,
      columns: index.multiEntry === true ? [] : paths.map((_p, i) => `ix${ordinal}_${i}`),
      childTable: index.multiEntry === true ? `${table}__mt${ordinal}` : void 0,
      childIndex: index.multiEntry === true ? `${table}__mt${ordinal}_elem` : void 0
    };
    indexes.push(plan);
    byName.set(plan.name, plan);
  });
  return { schema, table, pkColumns, pkPaths, dataColumn: "data", indexes, byName };
}
var SqliteAdapter = class {
  plans = [];
  planByName = /* @__PURE__ */ new Map();
  driver;
  opening;
  /**
   * 销毁即死路（批次 E2 口径 B）。
   *
   * 🔴 挡的是这一条：`destroy()` 把连接关掉并把文件删了，而此后**任何一次普通读**
   * 都会走 `ensureOpen()` 的重开路径 —— 于是刚删掉的容器被重新建成一张空壳
   * （实测 73728 字节 / 6 张空表，字节数与 iOS 设备级那枚残留逐字相同，见计划 §10.146）。
   * 那一趟里"销毁成功"的报告和"盘上又有库了"是**同一秒**打印的，而读出来的内容
   * 确实是空的 ⇒ 每一层都觉得自己没说谎。
   */
  destroyed = false;
  /** 第二次 `destroy()` 走这份缓存，而不是把"删一遍"再跑一次（那需要先重开）。 */
  destroying;
  /**
   * FIFO 队列。单连接 SQLite 不能并发跑事务，所以适配器自己排队 ——
   * 这正是 `DbAdapter` 契约"调用方不需要加锁"的落地方式。
   */
  queue = Promise.resolve();
  /**
   * 嵌套检测只覆盖**同步前缀**，取舍与理由同 `memory-adapter.ts`：
   * 用一个全局布尔会把**并发**也当成嵌套拦下来，而并发是契约明确要求的合法用法。
   */
  syncDepth = 0;
  /**
   * ⚠️ 注入的是驱动**工厂**而不是驱动实例。原因：`DbAdapter.close()` 要求
   * "后续操作透明重开"，而一个已 `close()` 的驱动实例无法复活。
   * 工厂让 close → 重开成立（原生端每次重开注入新的句柄）。
   */
  driverFactory;
  constructor(options) {
    this.driverFactory = options.driverFactory;
    for (const schema of options.schema) {
      const plan = buildStorePlan(schema);
      this.plans.push(plan);
      this.planByName.set(plan.table, plan);
    }
  }
  // ── 生命周期 ──────────────────────────────────────────────
  init() {
    return this.ensureOpen().then(() => void 0);
  }
  close() {
    this.driver?.close();
    this.driver = void 0;
    this.opening = void 0;
  }
  /**
   * 销毁这份库：**排空在途事务 → DROP 全部表 → VACUUM → close → 让驱动删文件**。
   *
   * 🔴 为什么不"逐行 `DELETE FROM` 就够了"（这一版之前的做法是根本没有这一步）：
   *  `DELETE FROM` 只把页标成空闲，**内容还在文件里**，而 SQLite 默认还会
   *  继续把 WAL 写到 `-wal`。`VACUUM` 重写整个库文件，把空闲页丢回去；
   *  真正的收尾是**删文件**（`driver.removeDatabase`）—— 删不掉时
   *  报告里必须写清"容器还在"，调用方才知道自己承诺了多少。
   *
   * 🔴 **走队列**（与 `transaction` 同一条 `this.queue`）：销毁与写入并发时，
   *  不入队会让"写完又落回来"的 op 在 DROP 之后重新建表 ——
   *  那时报告已经说了"销毁成功"，而数据还在。这是本条契约唯一真正要防的竞态。
   */
  async destroy() {
    if (this.destroying !== void 0) return this.destroying;
    const run = async () => {
      const driver = await this.ensureOpen();
      let storesCleared = 0;
      for (const plan of this.plans) {
        driver.exec(`DROP TABLE IF EXISTS ${q(plan.table)}`);
        storesCleared += 1;
        for (const index of plan.indexes) {
          if (index.multiEntry !== true) continue;
          driver.exec(`DROP TABLE IF EXISTS ${q(index.childTable)}`);
          storesCleared += 1;
        }
      }
      driver.exec(`DROP TABLE IF EXISTS ${q(SEQ_TABLE)}`);
      storesCleared += 1;
      driver.exec("VACUUM");
      this.close();
      this.destroyed = true;
      if (driver.removeDatabase === void 0) {
        return {
          target: "sqlite",
          containerRemoved: false,
          reason: "\u8FD9\u4E2A\u9A71\u52A8\u6CA1\u6709 removeDatabase\uFF08\u539F\u751F\u6865\u5C1A\u672A\u5B9E\u73B0\uFF0C\u89C1\u6279\u6B21 E\uFF09\uFF1A\u5185\u5BB9\u5DF2\u6E05\u7A7A\uFF0C\u6587\u4EF6\u4ECD\u5728",
          storesCleared
        };
      }
      const removal = await driver.removeDatabase();
      return { ...removal, storesCleared };
    };
    const result = this.queue.then(run, run);
    this.destroying = result.catch((error) => {
      this.destroying = void 0;
      this.destroyed = false;
      throw error;
    });
    this.queue = result.then(
      () => void 0,
      () => void 0
    );
    return this.destroying;
  }
  /** 打开连接并建 schema。幂等（`CREATE ... IF NOT EXISTS`），可并发调用。 */
  ensureOpen() {
    if (this.destroyed) return Promise.reject(new AdapterDestroyedError("sqlite"));
    if (this.driver !== void 0) return Promise.resolve(this.driver);
    if (this.opening !== void 0) return this.opening;
    this.opening = Promise.resolve().then(() => {
      const driver = this.driverFactory();
      try {
        this.createSchema(driver);
      } catch (error) {
        driver.close();
        this.opening = void 0;
        throw error;
      }
      this.driver = driver;
      return driver;
    });
    return this.opening;
  }
  createSchema(driver) {
    for (const plan of this.plans) {
      const definitions = [
        // 键列/索引列故意**不声明类型** → BLOB 亲和性 → 不做数值转换。
        ...plan.pkColumns.map((c) => q(c)),
        ...plan.indexes.filter((i) => !i.multiEntry).flatMap((i) => i.columns.map((c) => q(c))),
        `${q(plan.dataColumn)} TEXT NOT NULL`,
        `PRIMARY KEY (${plan.pkColumns.map(q).join(", ")})`
      ];
      driver.exec(
        `CREATE TABLE IF NOT EXISTS ${q(plan.table)} (${definitions.join(", ")})`
      );
      for (const index of plan.indexes) {
        if (index.multiEntry) {
          driver.exec(
            `CREATE TABLE IF NOT EXISTS ${q(index.childTable)} (${[
              ...plan.pkColumns.map((c) => q(c)),
              '"elem"'
            ].join(", ")})`
          );
          driver.exec(
            `CREATE INDEX IF NOT EXISTS ${q(index.childIndex)} ON ${q(index.childTable)} ("elem")`
          );
          continue;
        }
        const unique = index.unique ? "UNIQUE " : "";
        driver.exec(
          `CREATE ${unique}INDEX IF NOT EXISTS ${q(`${plan.table}__i${index.columns[0]}`)} ON ${q(plan.table)} (${index.columns.map(q).join(", ")})`
        );
      }
    }
    driver.exec(
      `CREATE TABLE IF NOT EXISTS ${q(SEQ_TABLE)} ("store" TEXT PRIMARY KEY, "next" INTEGER NOT NULL)`
    );
  }
  // ── 事务 ─────────────────────────────────────────────────
  transaction(stores, _mode, fn) {
    if (this.syncDepth > 0) {
      throw new Error("\u4E0D\u652F\u6301\u5D4C\u5957\u4E8B\u52A1\uFF1A\u5728\u4E8B\u52A1\u91CC\u53C8\u8C03\u7528\u4E86 transaction()");
    }
    for (const name of stores) {
      if (!this.planByName.has(name)) {
        throw new Error(
          `\u4E8B\u52A1\u8BBF\u95EE\u4E86\u672A\u5B9A\u4E49\u7684 store\uFF1A\u300C${name}\u300D\u3002\u5DF2\u5B9A\u4E49\uFF1A${[...this.planByName.keys()].join(", ")}`
        );
      }
    }
    const run = async () => {
      const driver = await this.ensureOpen();
      driver.exec("BEGIN IMMEDIATE");
      let pending;
      this.syncDepth++;
      try {
        pending = fn(this.makeTx(stores, driver));
      } catch (error) {
        this.syncDepth--;
        try {
          driver.exec("ROLLBACK");
        } catch {
        }
        throw error;
      }
      this.syncDepth--;
      try {
        const result2 = await pending;
        driver.exec("COMMIT");
        return result2;
      } catch (error) {
        try {
          driver.exec("ROLLBACK");
        } catch {
        }
        throw error;
      }
    };
    const result = this.queue.then(run, run);
    this.queue = result.then(
      () => void 0,
      () => void 0
    );
    return result;
  }
  // ── 顶层便捷方法：各自包一个单 store 事务 ────────────────
  add(store, value) {
    return this.transaction([store], "readwrite", (tx) => tx.add(store, value));
  }
  put(store, value, key) {
    return this.transaction([store], "readwrite", (tx) => tx.put(store, value, key));
  }
  get(store, key) {
    return this.transaction([store], "readonly", (tx) => tx.get(store, key));
  }
  getAll(store, range, limit) {
    return this.transaction([store], "readonly", (tx) => tx.getAll(store, range, limit));
  }
  delete(store, key) {
    return this.transaction([store], "readwrite", (tx) => tx.delete(store, key));
  }
  clear(store) {
    return this.transaction([store], "readwrite", (tx) => tx.clear(store));
  }
  count(store, range) {
    return this.transaction([store], "readonly", (tx) => tx.count(store, range));
  }
  getFromIndex(store, index, key) {
    return this.transaction([store], "readonly", (tx) => tx.getFromIndex(store, index, key));
  }
  getKeyFromIndex(store, index, key) {
    return this.transaction([store], "readonly", (tx) => tx.getKeyFromIndex(store, index, key));
  }
  getAllFromIndex(store, index, query) {
    return this.transaction(
      [store],
      "readonly",
      (tx) => tx.getAllFromIndex(store, index, query)
    );
  }
  countFromIndex(store, index, query) {
    return this.transaction([store], "readonly", (tx) => tx.countFromIndex(store, index, query));
  }
  iterate(store, options, visit) {
    return this.transaction([store], "readwrite", (tx) => tx.iterate(store, options, visit));
  }
  makeTx(allowed, driver) {
    const assert = (store) => {
      if (!allowed.includes(store)) {
        throw new Error(
          `store\u300C${store}\u300D\u4E0D\u5728\u672C\u6B21\u4E8B\u52A1\u7684\u8303\u56F4\u5185\uFF1A${allowed.join(", ")}`
        );
      }
      const plan = this.planByName.get(store);
      if (plan === void 0) throw new Error(`\u672A\u5B9A\u4E49\u7684 store\uFF1A\u300C${store}\u300D`);
      return plan;
    };
    const findIndex = (plan, indexName) => {
      const index = plan.byName.get(indexName);
      if (index === void 0) {
        throw new Error(`store\u300C${plan.table}\u300D\u4E0A\u6CA1\u6709\u7D22\u5F15\u300C${indexName}\u300D`);
      }
      return index;
    };
    const insertRecord = (storeName, value) => {
      const plan = assert(storeName);
      const record = value;
      const recordKey = this.readRecordKey(plan, record);
      let pk;
      let allocated;
      if (recordKey === void 0) {
        if (plan.schema.autoIncrement !== true) {
          throw new Error(
            `store\u300C${storeName}\u300D\u7684\u8BB0\u5F55\u7F3A\u5C11\u4E3B\u952E\u5B57\u6BB5\u300C${plan.pkPaths.join(", ")}\u300D`
          );
        }
        allocated = this.peekAutoIncrement(driver, plan);
        pk = [allocated];
        setAtPath(record, plan.pkPaths[0], allocated);
      } else {
        pk = recordKey;
      }
      this.insertRow(driver, plan, pk, record);
      if (allocated !== void 0) {
        this.writeSeq(driver, plan, allocated);
      } else if (plan.schema.autoIncrement === true && typeof pk[0] === "number") {
        this.bumpAutoIncrement(driver, plan, pk[0]);
      }
      return { key: typeof pk[0] === "number" ? pk[0] : 0, pk };
    };
    return {
      add: async (storeName, value) => insertRecord(storeName, value).key,
      /**
       * 容忍唯一冲突的插入（`DbTx` 接口要求，op-log 幂等去重的核心）。
       *
       * SQLite 里单条约束冲突**不会**中止整个事务（这点与 IndexedDB 相反 ——
       * IndexedDB 必须 `preventDefault()` 才不中止事务），所以直接捕获即可，
       * 后续语句与 COMMIT 仍能正常执行。
       */
      addToleratingDuplicate: async (storeName, value) => {
        try {
          const { key } = insertRecord(storeName, value);
          return { ok: true, key };
        } catch (error) {
          if (this.isUniqueViolation(driver, error)) {
            return { ok: false, reason: "duplicate" };
          }
          throw error;
        }
      },
      put: async (storeName, value, explicitKey) => {
        const plan = assert(storeName);
        const record = value;
        const pk = this.normalizeExplicitKey(plan, explicitKey) ?? this.readRecordKey(plan, record);
        if (pk === void 0) {
          throw new Error(`store\u300C${storeName}\u300D\u7684 put \u7F3A\u5C11\u4E3B\u952E`);
        }
        this.deleteRow(driver, plan, pk);
        this.insertRow(driver, plan, pk, record);
      },
      get: async (storeName, key) => {
        const plan = assert(storeName);
        const pk = this.normalizeExplicitKey(plan, key);
        if (pk === void 0) return void 0;
        const rows = driver.all(
          `SELECT ${q(plan.dataColumn)} FROM ${q(plan.table)} WHERE ${pkWhere(plan)}`,
          pk
        );
        return rows.length === 0 ? void 0 : JSON.parse(String(rows[0][plan.dataColumn]));
      },
      getAll: async (storeName, range, limit) => {
        assertIterateLimit(limit);
        const plan = assert(storeName);
        return this.fetchRecords(driver, plan, range, limit).map((r) => r.data);
      },
      delete: async (storeName, key) => {
        const plan = assert(storeName);
        const pk = this.normalizeExplicitKey(plan, key);
        if (pk === void 0) return;
        this.deleteRow(driver, plan, pk);
      },
      clear: async (storeName) => {
        const plan = assert(storeName);
        driver.run(`DELETE FROM ${q(plan.table)}`);
        for (const index of plan.indexes) {
          if (index.multiEntry) driver.run(`DELETE FROM ${q(index.childTable)}`);
        }
      },
      count: async (storeName, range) => {
        const plan = assert(storeName);
        if (plan.pkColumns.length === 1 && range !== void 0) {
          const params = [];
          const where = rangeConditions(q(plan.pkColumns[0]), range, params);
          const rows = driver.all(
            `SELECT COUNT(*) AS n FROM ${q(plan.table)}${where.length ? ` WHERE ${where.join(" AND ")}` : ""}`,
            params
          );
          return Number(rows[0]?.["n"] ?? 0);
        }
        return this.fetchRecords(driver, plan, range).length;
      },
      getFromIndex: async (storeName, indexName, key) => {
        const plan = assert(storeName);
        const index = findIndex(plan, indexName);
        const records = this.fetchIndexRecords(driver, plan, index, key);
        return records.length === 0 ? void 0 : records[0].data;
      },
      getKeyFromIndex: async (storeName, indexName, key) => {
        const plan = assert(storeName);
        const index = findIndex(plan, indexName);
        const records = this.fetchIndexRecords(driver, plan, index, key);
        return records.length === 0 ? void 0 : toDbKey(plan, records[0].pk);
      },
      getAllFromIndex: async (storeName, indexName, query) => {
        const plan = assert(storeName);
        const index = findIndex(plan, indexName);
        return this.fetchIndexRecords(driver, plan, index, query).map((r) => r.data);
      },
      countFromIndex: async (storeName, indexName, query) => {
        const plan = assert(storeName);
        const index = findIndex(plan, indexName);
        return this.fetchIndexRecords(driver, plan, index, query).length;
      },
      iterate: async (storeName, options, visit) => {
        const plan = assert(storeName);
        assertIterateLimit(options.limit);
        const { direction = "next", lower, upper, limit, index } = options;
        let records;
        if (index === void 0) {
          records = this.fetchRecords(driver, plan, { lower, upper });
        } else {
          const indexPlan = findIndex(plan, index);
          records = this.fetchIndexRecords(driver, plan, indexPlan, { lower, upper });
        }
        if (direction === "prev") records.reverse();
        const cap = limit ?? DEFAULT_ITERATE_LIMIT;
        let visited = 0;
        for (const record of records) {
          if (visited >= cap) break;
          visited++;
          const action = visit(record.data, toDbKey(plan, record.pk));
          if (action === "delete" || action === "delete-stop") {
            this.deleteRow(driver, plan, record.pk);
          }
          if (action === "stop" || action === "delete-stop") break;
        }
      }
    };
  }
  // ── 物理操作 ─────────────────────────────────────────────
  readRecordKey(plan, record) {
    const out = [];
    for (const path of plan.pkPaths) {
      const v = valueAtPath(record, path);
      if (!isKeyValue(v)) return void 0;
      out.push(v);
    }
    return out;
  }
  normalizeExplicitKey(plan, key) {
    if (key === void 0) return void 0;
    const parts = Array.isArray(key) ? key : [key];
    if (parts.length !== plan.pkColumns.length) return void 0;
    if (!parts.every(isKeyValue)) return void 0;
    return parts;
  }
  /**
   * 计算下一个自增键，但**不落盘**（插入成功后才由调用方写回计数器）。
   * 同时参考计数器与表内 MAX，避免计数器表丢失后回退复用旧键。
   */
  peekAutoIncrement(driver, plan) {
    const seqRow = driver.all(
      `SELECT "next" FROM ${q(SEQ_TABLE)} WHERE "store" = ?`,
      [plan.table]
    )[0];
    const stored = seqRow === void 0 ? 0 : Number(seqRow["next"]);
    const maxRow = driver.all(
      `SELECT MAX(${q(plan.pkColumns[0])}) AS "m" FROM ${q(plan.table)}`
    )[0];
    const maxPk = maxRow !== void 0 && typeof maxRow["m"] === "number" ? maxRow["m"] : 0;
    return Math.max(stored, maxPk) + 1;
  }
  /** 判定异常是否为唯一约束冲突；驱动可选择精确实现。 */
  isUniqueViolation(driver, error) {
    if (driver.isUniqueViolation !== void 0) return driver.isUniqueViolation(error);
    return defaultIsUniqueViolation(error);
  }
  bumpAutoIncrement(driver, plan, key) {
    const seqRow = driver.all(
      `SELECT "next" FROM ${q(SEQ_TABLE)} WHERE "store" = ?`,
      [plan.table]
    )[0];
    const stored = seqRow === void 0 ? 0 : Number(seqRow["next"]);
    if (key > stored) this.writeSeq(driver, plan, key);
  }
  writeSeq(driver, plan, next) {
    driver.run(
      `INSERT OR REPLACE INTO ${q(SEQ_TABLE)} ("store", "next") VALUES (?, ?)`,
      [plan.table, next]
    );
  }
  insertRow(driver, plan, pk, record) {
    const columns = [...plan.pkColumns];
    const values = [...pk];
    for (const index of plan.indexes) {
      if (index.multiEntry) continue;
      const entry = inlineIndexValues(index, record);
      for (let i = 0; i < index.columns.length; i++) {
        columns.push(index.columns[i]);
        values.push(entry === void 0 ? null : entry[i]);
      }
    }
    columns.push(plan.dataColumn);
    values.push(JSON.stringify(record));
    driver.run(
      `INSERT INTO ${q(plan.table)} (${columns.map(q).join(", ")}) VALUES (${columns.map(() => "?").join(", ")})`,
      values
    );
    for (const index of plan.indexes) {
      if (!index.multiEntry) continue;
      for (const element of multiEntryValues(index, record)) {
        driver.run(
          `INSERT INTO ${q(index.childTable)} (${[
            ...plan.pkColumns.map(q),
            '"elem"'
          ].join(", ")}) VALUES (${[...plan.pkColumns.map(() => "?"), "?"].join(", ")})`,
          [...pk, element]
        );
      }
    }
  }
  deleteRow(driver, plan, pk) {
    driver.run(`DELETE FROM ${q(plan.table)} WHERE ${pkWhere(plan)}`, pk);
    for (const index of plan.indexes) {
      if (index.multiEntry) {
        driver.run(`DELETE FROM ${q(index.childTable)} WHERE ${pkWhere(plan)}`, pk);
      }
    }
  }
  fetchRecords(driver, plan, range, limit) {
    const params = [];
    let where = "";
    const pushDown = plan.pkColumns.length === 1 && range !== void 0;
    if (pushDown) {
      const conditions = rangeConditions(q(plan.pkColumns[0]), range, params);
      if (conditions.length > 0) where = ` WHERE ${conditions.join(" AND ")}`;
    }
    const sqlLimit = limit !== void 0 && (pushDown || range === void 0);
    if (sqlLimit) params.push(limit);
    const rows = driver.all(
      `SELECT * FROM ${q(plan.table)}${where} ORDER BY ${orderByPk(plan)}${sqlLimit ? " LIMIT ?" : ""}`,
      params
    );
    const projected = rows.map((row) => this.toPhysicalRecord(plan, row));
    return (pushDown ? projected : projected.filter((r) => keyInRange(r.pk, range))).slice(0, limit);
  }
  fetchIndexRecords(driver, plan, index, query) {
    if (index.multiEntry) {
      const params2 = [];
      const conditions2 = [];
      if (query !== void 0) {
        if (isKeyValue(query)) {
          conditions2.push('c."elem" = ?');
          params2.push(query);
        } else if (Array.isArray(query)) {
          return [];
        } else {
          conditions2.push(...rangeConditions('c."elem"', query, params2));
        }
      }
      const extra = conditions2.length > 0 ? ` AND ${conditions2.join(" AND ")}` : "";
      const rows2 = driver.all(
        `SELECT s.* FROM ${q(plan.table)} s WHERE EXISTS (SELECT 1 FROM ${q(index.childTable)} c WHERE ${joinOnPk("c", "s", plan)}${extra}) ORDER BY ${orderByPk(plan, "s")}`,
        params2
      );
      return rows2.map((row) => this.toPhysicalRecord(plan, row));
    }
    const params = [];
    const conditions = [];
    if (query === void 0) {
      for (const column of index.columns) conditions.push(`${q(column)} IS NOT NULL`);
    } else if (isKeyValue(query)) {
      if (index.columns.length !== 1) return [];
      conditions.push(`${q(index.columns[0])} = ?`);
      params.push(query);
    } else if (Array.isArray(query)) {
      if (query.length !== index.columns.length) return [];
      index.columns.forEach((column, i) => {
        conditions.push(`${q(column)} = ?`);
        params.push(query[i]);
      });
    } else if (index.columns.length === 1) {
      conditions.push(...rangeConditions(q(index.columns[0]), query, params));
    } else {
      for (const column of index.columns) conditions.push(`${q(column)} IS NOT NULL`);
    }
    const where = conditions.length > 0 ? ` WHERE ${conditions.join(" AND ")}` : "";
    const rows = driver.all(
      `SELECT * FROM ${q(plan.table)}${where} ORDER BY ${orderByPk(plan)}`,
      params
    );
    let projected = rows.map((row) => this.toPhysicalRecord(plan, row));
    if (query !== void 0 && !isKeyValue(query) && !Array.isArray(query) && index.columns.length > 1) {
      projected = projected.filter(
        (r) => keyInRange(
          index.columns.map((c) => r.row[c]),
          query
        )
      );
    }
    return projected;
  }
  toPhysicalRecord(plan, row) {
    return {
      data: JSON.parse(String(row[plan.dataColumn])),
      pk: plan.pkColumns.map((c) => row[c]),
      row
    };
  }
};
function defaultIsUniqueViolation(error) {
  if (typeof error !== "object" || error === null) return false;
  const candidate = error;
  for (const code of [candidate.errcode, candidate.code]) {
    if (typeof code === "number" && (code === 1555 || code === 2067)) return true;
  }
  return typeof candidate.message === "string" && /UNIQUE constraint failed/i.test(candidate.message);
}
function pkWhere(plan, alias) {
  const prefix = alias === void 0 ? "" : `${alias}.`;
  return plan.pkColumns.map((c) => `${prefix}${q(c)} = ?`).join(" AND ");
}
function joinOnPk(left, right, plan) {
  return plan.pkColumns.map((c) => `${left}.${q(c)} = ${right}.${q(c)}`).join(" AND ");
}
function orderByPk(plan, alias) {
  const prefix = alias === void 0 ? "" : `${alias}.`;
  return plan.pkColumns.map((c) => `${prefix}${q(c)}`).join(", ");
}
function rangeConditions(column, range, params) {
  const conditions = [];
  if (range.lower !== void 0) {
    conditions.push(`${column} ${range.lowerOpen === true ? ">" : ">="} ?`);
    params.push(range.lower);
  }
  if (range.upper !== void 0) {
    conditions.push(`${column} ${range.upperOpen === true ? "<" : "<="} ?`);
    params.push(range.upper);
  }
  return conditions;
}
function inlineIndexValues(index, record) {
  const out = [];
  for (const path of index.paths) {
    const v = valueAtPath(record, path);
    if (!isKeyValue(v)) return void 0;
    out.push(v);
  }
  return out;
}
function multiEntryValues(index, record) {
  const raw = valueAtPath(record, index.paths[0]);
  if (!Array.isArray(raw)) return [];
  const out = [];
  for (const v of raw) {
    if (isKeyValue(v) && !out.some((existing) => compareKeys(existing, v) === 0)) out.push(v);
  }
  return out;
}
function toDbKey(plan, pk) {
  return plan.pkColumns.length === 1 ? pk[0] : pk;
}

// src/sqlite/oplog-worker-bridge.ts
function serializeError(error) {
  if (error instanceof Error) {
    return {
      name: error.name,
      message: error.message,
      // `stack` 只在存在时带上 —— 某些引擎/包装下它可能没有。
      ...error.stack === void 0 ? {} : { stack: error.stack }
    };
  }
  return { name: "Error", message: String(error) };
}
function deserializeError(error) {
  const rebuilt = new Error(error.message);
  rebuilt.name = error.name;
  if (error.stack !== void 0) rebuilt.stack = error.stack;
  return rebuilt;
}
async function handleOpLogWorkerRequest(store, request) {
  const fn = store[request.method];
  if (typeof fn !== "function") {
    return {
      id: request.id,
      ok: false,
      error: {
        name: "TypeError",
        message: `OpLogStore \u4E0A\u6CA1\u6709\u65B9\u6CD5 "${request.method}"\u3002\u8BF7\u6838\u5BF9 OpLogStore \u662F\u5426\u6539\u540D\u3001\u4EE5\u53CA\u6865\u4E0A\u7684\u8F6C\u53D1\u5217\u8868\u662F\u5426\u8DDF\u4E0A\u3002`
      }
    };
  }
  try {
    const value = await fn.apply(store, request.args);
    return { id: request.id, ok: true, value };
  } catch (error) {
    return { id: request.id, ok: false, error: serializeError(error) };
  }
}
function serveOpLogWorker(port, ready) {
  const backlog = [];
  let store = null;
  const dispatch = async (request) => {
    if (store === null) {
      backlog.push(request);
      return;
    }
    const response = await handleOpLogWorkerRequest(store, request);
    port.postMessage(response);
  };
  port.onmessage = (event) => {
    void dispatch(event.data);
  };
  ready.then(
    (opened) => {
      store = opened.store;
      port.postMessage({ type: "ready", clientId: opened.clientId });
      const pendingRequests = backlog.splice(0, backlog.length);
      void (async () => {
        for (const request of pendingRequests) {
          const response = await handleOpLogWorkerRequest(opened.store, request);
          port.postMessage(response);
        }
      })();
    },
    (error) => {
      port.postMessage({ type: "ready", error: serializeError(error) });
      const failure = serializeError(error);
      const pendingRequests = backlog.splice(0, backlog.length);
      for (const request of pendingRequests) {
        port.postMessage({ id: request.id, ok: false, error: failure });
      }
    }
  );
}
function createWorkerOpLogSession(worker) {
  let nextId = 0;
  const pending = /* @__PURE__ */ new Map();
  let resolveReady = () => void 0;
  let rejectReady = () => void 0;
  const ready = new Promise((resolve, reject) => {
    resolveReady = resolve;
    rejectReady = reject;
  });
  ready.catch(() => void 0);
  const receiver = worker;
  const onMessage = (event) => {
    const data = event.data;
    if ("type" in data && data.type === "ready") {
      if ("clientId" in data) resolveReady({ clientId: data.clientId });
      else rejectReady(deserializeError(data.error));
      return;
    }
    const response = data;
    const waiter = pending.get(response.id);
    if (waiter === void 0) return;
    pending.delete(response.id);
    if (response.ok) waiter.resolve(response.value);
    else waiter.reject(deserializeError(response.error));
  };
  if (typeof receiver.addEventListener === "function") {
    receiver.addEventListener("message", onMessage);
  } else {
    receiver.onmessage = onMessage;
  }
  const call = (method, args) => {
    const id = ++nextId;
    return new Promise((resolve, reject) => {
      pending.set(id, { resolve, reject });
      worker.postMessage({ id, method, args });
    });
  };
  const store = {
    appendLocal: (ops) => call("appendLocal", [ops]),
    appendImported: (ops) => call("appendImported", [ops]),
    getOpsSince: (sinceSeq, limit, excludeClient) => call("getOpsSince", [sinceSeq, limit, excludeClient]),
    getOpById: (opId) => call("getOpById", [opId]),
    getOpsForEntity: (entityType, entityId) => call("getOpsForEntity", [entityType, entityId]),
    getLastLocalSeq: () => call("getLastLocalSeq", []),
    getAllOps: (range, limit) => call("getAllOps", [range, limit]),
    countAllOps: () => call("countAllOps", []),
    findPendingApply: () => call("findPendingApply", []),
    countPendingApply: () => call("countPendingApply", []),
    findPendingUpload: () => call("findPendingUpload", []),
    countPendingUpload: () => call("countPendingUpload", []),
    markUploaded: (serverSeqsByOpId) => call("markUploaded", [serverSeqsByOpId]),
    discardPendingUpload: (opIds) => call("discardPendingUpload", [opIds]),
    markRejected: (opIds) => call("markRejected", [opIds]),
    archiveUpTo: (upToSeq) => call("archiveUpTo", [upToSeq]),
    readCheckpoint: () => call("readCheckpoint", []),
    writeCheckpoint: (checkpoint) => call("writeCheckpoint", [checkpoint]),
    readObservedClock: () => call("readObservedClock", []),
    mergeObservedClock: (clock) => call("mergeObservedClock", [clock]),
    hasIncompleteHistory: () => call("hasIncompleteHistory", []),
    markHistoryIncomplete: () => call("markHistoryIncomplete", []),
    // ── 簿记（同步游标）──
    getLastServerSeq: () => call("getLastServerSeq", []),
    setLastServerSeq: (seq) => call("setLastServerSeq", [seq]),
    // ── META 通用读写（公共事实缓存走这里，ADR-0052 §2.5）──
    // 🔴 页侧**没有** `DbAdapter`（库在 Worker / 壳里），所以这条是三条后端路径
    // 唯一都能到达 `STORES.META` 的口子。漏转发不会静默返回空值：
    // `handleOpLogWorkerRequest` 找不到方法名时会响亮报错。
    getMetaValue: (key) => call("getMetaValue", [key]),
    setMetaValue: (key, value) => call("setMetaValue", [key, value]),
    // ── 继承自 `RemoteOperationApplyStorePort` ──
    appendBatchSkipDuplicates: (ops, source, options) => call("appendBatchSkipDuplicates", [ops, source, options]),
    mergeRemoteOpClocks: (ops) => call("mergeRemoteOpClocks", [ops]),
    markReducersCommittedAndMergeClocks: (seqs, ops, rejectedOpIds) => call("markReducersCommittedAndMergeClocks", [seqs, ops, rejectedOpIds]),
    markApplied: (seqs) => call("markApplied", [seqs]),
    markFailed: (opIds) => call("markFailed", [opIds]),
    clearFullStateOpsExcept: (excludeIds) => call("clearFullStateOpsExcept", [excludeIds])
  };
  return { store, ready };
}
function createWorkerOpLogStore(worker) {
  return createWorkerOpLogSession(worker).store;
}

// src/sqlite/oplog-wire-codec.ts
var TAG = "__heytaWire";
function isBox(value) {
  if (typeof value !== "object" || value === null || Array.isArray(value)) return false;
  const keys = Object.keys(value);
  return keys.length === 2 && keys.includes(TAG);
}
function encodeOpLogWire(value) {
  if (value === void 0) return { [TAG]: "undefined", v: null };
  if (value === null) return null;
  if (value instanceof Map) {
    return { [TAG]: "Map", v: [...value.entries()].map(([k, v]) => [encodeOpLogWire(k), encodeOpLogWire(v)]) };
  }
  if (value instanceof Set) {
    return { [TAG]: "Set", v: [...value.values()].map(encodeOpLogWire) };
  }
  if (Array.isArray(value)) return value.map(encodeOpLogWire);
  if (typeof value === "object") {
    const out = {};
    for (const [k, v] of Object.entries(value)) out[k] = encodeOpLogWire(v);
    return out;
  }
  if (typeof value === "function" || typeof value === "symbol" || typeof value === "bigint") {
    throw new Error(
      `op-log \u7EBF\u7801\uFF1A${typeof value} \u8FC7\u4E0D\u4E86\u5BBF\u4E3B\u8FB9\u754C\uFF08JSON \u4F1A\u4E22/\u53D8\u5F62\u72B6\uFF09\u3002\u82E5\u786E\u5B9E\u9700\u8981\uFF0C\u8BF7\u5728 encodeOpLogWire/decodeOpLogWire \u91CC\u6210\u5BF9\u5730\u52A0\u7F16\u7801 \u2014\u2014 \u4E0D\u8981\u5728\u53D1\u9001\u4FA7\u5355\u65B9\u9762"\u8F6C\u6210\u5B57\u7B26\u4E32"\uFF0C\u90A3\u4F1A\u8BA9\u63A5\u6536\u4FA7\u62FF\u5230\u9519\u7684\u6570\u636E\u3002`
    );
  }
  return value;
}
function decodeOpLogWire(value) {
  if (value === null || typeof value !== "object") return value;
  if (isBox(value)) {
    const kind = value[TAG];
    const payload = value["v"];
    if (kind === "undefined") return void 0;
    if (kind === "Map") {
      const entries = payload;
      return new Map(entries.map(([k, v]) => [decodeOpLogWire(k), decodeOpLogWire(v)]));
    }
    if (kind === "Set") {
      const values = payload;
      return new Set(values.map(decodeOpLogWire));
    }
    throw new Error(`op-log \u7EBF\u7801\uFF1A\u4E0D\u8BA4\u8BC6\u7684\u6807\u8BB0 ${String(kind)} \u2014\u2014 \u4E24\u4FA7\u7684\u7801\u7248\u672C\u4E0D\u4E00\u81F4\uFF1F`);
  }
  if (Array.isArray(value)) return value.map(decodeOpLogWire);
  const out = {};
  for (const [k, v] of Object.entries(value)) out[k] = decodeOpLogWire(v);
  return out;
}
function createOpLogWirePort(port) {
  const decodeEvent = (event) => ({
    data: decodeOpLogWire(event.data)
  });
  const wrapper = {
    postMessage(message) {
      port.postMessage(encodeOpLogWire(message));
    }
  };
  if (typeof port.addEventListener === "function") {
    wrapper.addEventListener = (type, listener) => {
      port.addEventListener?.(type, (event) => {
        listener(decodeEvent(event));
      });
    };
  } else {
    Object.defineProperty(wrapper, "onmessage", {
      get: () => port.onmessage ?? null,
      set: (listener) => {
        port.onmessage = listener === null ? null : (event) => {
          listener(decodeEvent(event));
        };
      }
    });
  }
  return wrapper;
}

// src/memory/memory-adapter.ts
function compareKeys2(a, b) {
  const rank = (k) => {
    if (typeof k === "number") return 0;
    if (k instanceof Date) return 1;
    if (typeof k === "string") return 2;
    if (Array.isArray(k)) return 4;
    return 3;
  };
  if (Array.isArray(a) || Array.isArray(b)) {
    const arrA = Array.isArray(a) ? a : [a];
    const arrB = Array.isArray(b) ? b : [b];
    if (Array.isArray(a) !== Array.isArray(b)) {
      return rank(a) - rank(b);
    }
    const len = Math.min(arrA.length, arrB.length);
    for (let i = 0; i < len; i++) {
      const diff = compareKeys2(arrA[i], arrB[i]);
      if (diff !== 0) return diff;
    }
    return arrA.length - arrB.length;
  }
  const rankDiff = rank(a) - rank(b);
  if (rankDiff !== 0) return rankDiff;
  if (typeof a === "number" && typeof b === "number") return a - b;
  return String(a) < String(b) ? -1 : String(a) > String(b) ? 1 : 0;
}
var DuplicateKeyError = class extends Error {
  constructor(what) {
    super(`\u552F\u4E00\u952E\u51B2\u7A81\uFF1A${what}`);
    this.name = "DuplicateKeyError";
  }
};
function serializeKey(key) {
  return JSON.stringify(key);
}
function valueAtPath2(value, path) {
  let current = value;
  for (const segment of path.split(".")) {
    if (current === null || typeof current !== "object") return void 0;
    current = current[segment];
  }
  return current;
}
function keyFromPath(value, keyPath) {
  if (typeof keyPath === "string") {
    const v = valueAtPath2(value, keyPath);
    return typeof v === "string" || typeof v === "number" ? v : void 0;
  }
  const parts = [];
  for (const p of keyPath) {
    const v = valueAtPath2(value, p);
    if (typeof v !== "string" && typeof v !== "number") return void 0;
    parts.push(v);
  }
  return parts;
}
function inRange(key, range) {
  if (range === void 0) return true;
  const { lower, upper, lowerOpen, upperOpen } = range;
  if (lower !== void 0) {
    const diff = compareKeys2(key, lower);
    if (diff < 0 || diff === 0 && lowerOpen === true) return false;
  }
  if (upper !== void 0) {
    const diff = compareKeys2(key, upper);
    if (diff > 0 || diff === 0 && upperOpen === true) return false;
  }
  return true;
}
function matchesIndexQuery(entryKey, query) {
  if (query === void 0) return true;
  if (typeof query === "string" || typeof query === "number") {
    return compareKeys2(entryKey, query) === 0;
  }
  if (Array.isArray(query)) {
    return serializeKey(entryKey) === serializeKey(query);
  }
  return inRange(entryKey, query);
}
var MemoryDbAdapter = class {
  stores = /* @__PURE__ */ new Map();
  closing = false;
  /** 销毁即死路（E2 口径 B，与两份持久实现同一条契约）。 */
  destroyed = false;
  /** 第二次 `destroy()` 复用这份报告，不再"清空一遍"（清空需要先让实例可用）。 */
  destroying;
  syncDepth = 0;
  txQueue = Promise.resolve();
  constructor(schema = []) {
    for (const s of schema) {
      this.stores.set(s.name, {
        schema: s,
        records: /* @__PURE__ */ new Map(),
        autoIncrement: 0
      });
    }
  }
  async init() {
    if (this.destroyed) throw new AdapterDestroyedError("memory");
    this.closing = false;
  }
  close() {
    this.closing = true;
  }
  /**
   * 清空全部 store 的记录与自增计数器，并把这个实例**作废**。
   *
   * ⚠️ **保留 store 的 schema**：把 `stores` 整张 Map 清空会让之后任何一次读
   * 变成"没有这个 store"的异常，而那会被读成"销毁失败"。作废走的是另一条路：
   * 每次操作在**进门时**就被 `AdapterDestroyedError` 拒掉（口径 B，见下）。
   *
   * 🔴 这一版之前它是"清空后仍可继续用"，而那条口径站在契约的对立面：
   * `DbAdapter.destroy` 之后实例还能写，意味着**明文可以重新进这块内存**，
   * 而四份实现里唯一能区分"销毁"与"清空"的判据就是共享契约那一条腿。
   * 内存实现没有持久容器可删，所以 `containerRemoved` 报 true 的理由是
   * **进程内没有任何东西留下来**（不是"文件删了"）—— `target` 与 `reason` 写明它。
   */
  async destroy() {
    if (this.destroying !== void 0) return this.destroying;
    this.closing = false;
    let storesCleared = 0;
    for (const store of this.stores.values()) {
      store.records.clear();
      store.autoIncrement = 0;
      storesCleared += 1;
    }
    this.destroyed = true;
    this.destroying = Promise.resolve({
      target: "memory",
      containerRemoved: true,
      reason: "\u5185\u5B58\u5B9E\u73B0\uFF1A\u6CA1\u6709\u6301\u4E45\u5BB9\u5668\uFF0C\u6E05\u7A7A\u5373\u4E0D\u7559\u4EFB\u4F55\u4E1C\u897F",
      storesCleared
    });
    return this.destroying;
  }
  /** 建表。可重复调用（幂等），用于测试里动态加 store。 */
  defineStore(schema) {
    if (this.stores.has(schema.name)) return;
    this.stores.set(schema.name, { schema, records: /* @__PURE__ */ new Map(), autoIncrement: 0 });
  }
  // ── 公开 API：每条都开一个单 store 事务 ──────────────────────
  add(store, value) {
    return this.transaction([store], "readwrite", async (tx) => tx.add(store, value));
  }
  put(store, value, key) {
    return this.transaction([store], "readwrite", async (tx) => tx.put(store, value, key));
  }
  get(store, key) {
    return this.transaction([store], "readonly", async (tx) => tx.get(store, key));
  }
  getAll(store, range, limit) {
    return this.transaction([store], "readonly", async (tx) => tx.getAll(store, range, limit));
  }
  delete(store, key) {
    return this.transaction([store], "readwrite", async (tx) => tx.delete(store, key));
  }
  clear(store) {
    return this.transaction([store], "readwrite", async (tx) => tx.clear(store));
  }
  count(store, range) {
    return this.transaction([store], "readonly", async (tx) => tx.count(store, range));
  }
  getFromIndex(store, index, key) {
    return this.transaction([store], "readonly", async (tx) => tx.getFromIndex(store, index, key));
  }
  getKeyFromIndex(store, index, key) {
    return this.transaction([store], "readonly", async (tx) => tx.getKeyFromIndex(store, index, key));
  }
  getAllFromIndex(store, index, query) {
    return this.transaction([store], "readonly", async (tx) => tx.getAllFromIndex(store, index, query));
  }
  countFromIndex(store, index, query) {
    return this.transaction([store], "readonly", async (tx) => tx.countFromIndex(store, index, query));
  }
  iterate(store, options, visit) {
    return this.transaction([store], "readwrite", async (tx) => tx.iterate(store, options, visit));
  }
  /**
   * 单事务。**失败时整体回滚**。
   *
   * 回滚是真的要实现的：上层（例如 `appendLocal`）依赖"要么全落盘要么全不落"，
   * 一个假的事务会让崩溃恢复逻辑建立在不存在的保证上。
   */
  async transaction(stores, _mode, fn) {
    if (this.syncDepth > 0) {
      throw new Error("\u4E0D\u652F\u6301\u5D4C\u5957\u4E8B\u52A1\uFF1A\u5728\u4E8B\u52A1\u91CC\u53C8\u8C03\u7528\u4E86 transaction()");
    }
    if (this.destroyed) throw new AdapterDestroyedError("memory");
    for (const name of stores) {
      if (!this.stores.has(name)) {
        throw new Error(
          `\u4E8B\u52A1\u8BBF\u95EE\u4E86\u672A\u5B9A\u4E49\u7684 store\uFF1A\u300C${name}\u300D\u3002\u5DF2\u5B9A\u4E49\uFF1A${[...this.stores.keys()].join(", ")}`
        );
      }
    }
    const snapshot = /* @__PURE__ */ new Map();
    for (const name of stores) {
      const s = this.stores.get(name);
      snapshot.set(name, { records: new Map(s.records), autoIncrement: s.autoIncrement });
    }
    const run = async () => {
      this.syncDepth++;
      let pending;
      try {
        pending = fn(this.makeTx(stores));
      } finally {
        this.syncDepth--;
      }
      try {
        return await pending;
      } catch (error) {
        for (const [name, snap] of snapshot) {
          const s = this.stores.get(name);
          s.records = snap.records;
          s.autoIncrement = snap.autoIncrement;
        }
        throw error;
      }
    };
    const result = this.txQueue.then(run, run);
    this.txQueue = result.then(
      () => void 0,
      () => void 0
    );
    return result;
  }
  /** 构造事务句柄。`allowed` 里的 store 才可访问 —— 访问别的直接报错，不静默降级。 */
  makeTx(allowed) {
    const assert = (store) => {
      if (!allowed.includes(store)) {
        throw new Error(`store\u300C${store}\u300D\u4E0D\u5728\u672C\u6B21\u4E8B\u52A1\u7684\u8303\u56F4\u5185\uFF1A${allowed.join(", ")}`);
      }
      const s = this.stores.get(store);
      if (!s) {
        throw new Error(`\u672A\u5B9A\u4E49\u7684 store\uFF1A\u300C${store}\u300D`);
      }
      return s;
    };
    const findIndex = (store, indexName) => {
      const idx = store.schema.indexes?.find((i) => i.name === indexName);
      if (!idx) {
        throw new Error(`store\u300C${store.schema.name}\u300D\u4E0A\u6CA1\u6709\u7D22\u5F15\u300C${indexName}\u300D`);
      }
      return idx;
    };
    const indexEntries = (store, idx, value) => {
      if (typeof idx.keyPath === "string") {
        const raw = valueAtPath2(value, idx.keyPath);
        if (raw === void 0) return [];
        if (idx.multiEntry === true) {
          if (!Array.isArray(raw)) return [];
          return raw.filter((v) => typeof v === "string" || typeof v === "number");
        }
        if (typeof raw !== "string" && typeof raw !== "number") return [];
        return [raw];
      }
      const composite = keyFromPath(value, idx.keyPath);
      if (composite === void 0) return [];
      if (idx.multiEntry === true && Array.isArray(composite)) {
        return composite.map((v) => v);
      }
      return [composite];
    };
    const applyAction = (action, record, store) => {
      switch (action) {
        case "continue":
          return "continue";
        case "stop":
          return "stop";
        case "delete":
          store.records.delete(serializeKey(record.key));
          return "continue";
        case "delete-stop":
          store.records.delete(serializeKey(record.key));
          return "stop";
      }
    };
    const sortedRecords = (store) => [...store.records.values()].sort((a, b) => compareKeys2(a.key, b.key));
    const insert = (storeName, value) => {
      const store = assert(storeName);
      const record = value;
      const keyPath = store.schema.keyPath;
      let key = keyPath === void 0 ? void 0 : keyFromPath(record, keyPath);
      if (key === void 0) {
        if (keyPath !== void 0 && store.schema.autoIncrement !== true) {
          throw new Error(`store\u300C${storeName}\u300D\u7684\u8BB0\u5F55\u7F3A\u5C11\u4E3B\u952E\u5B57\u6BB5\u300C${String(keyPath)}\u300D`);
        }
        key = ++store.autoIncrement;
        if (keyPath !== void 0) {
          const path = typeof keyPath === "string" ? keyPath : keyPath[0];
          if (path !== void 0) record[path] = key;
        }
      } else if (typeof key === "number" && key > store.autoIncrement) {
        store.autoIncrement = key;
      }
      for (const idx of store.schema.indexes ?? []) {
        if (idx.unique !== true) continue;
        for (const entry of indexEntries(store, idx, record)) {
          for (const existing of store.records.values()) {
            if (existing.key === key) continue;
            for (const otherEntry of indexEntries(store, idx, existing.value)) {
              if (compareKeys2(entry, otherEntry) === 0) {
                throw new DuplicateKeyError(idx.name);
              }
            }
          }
        }
      }
      if (store.records.has(serializeKey(key))) {
        throw new DuplicateKeyError(String(keyPath ?? "\u4E3B\u952E"));
      }
      store.records.set(serializeKey(key), { key, value: record });
      return { key: typeof key === "number" ? key : 0 };
    };
    return {
      add: async (storeName, value) => {
        const { key } = insert(storeName, value);
        return key;
      },
      /**
       * 容忍唯一冲突的插入。
       *
       * 语义与 IndexedDB 实现一致：冲突时**不抛错**，而是报告 `duplicate`，
       * 且**记录不入库**、事务继续。op-log 的幂等去重完全靠这个行为 ——
       * 同一个 opId 被重复投递是正常路径（同步会重放），不是异常。
       */
      addToleratingDuplicate: async (storeName, value) => {
        try {
          const { key } = insert(storeName, value);
          return { ok: true, key };
        } catch (error) {
          if (error instanceof DuplicateKeyError) {
            return { ok: false, reason: "duplicate" };
          }
          throw error;
        }
      },
      put: async (storeName, value, explicitKey) => {
        const store = assert(storeName);
        const record = value;
        const keyPath = store.schema.keyPath;
        const key = explicitKey ?? (keyPath === void 0 ? void 0 : keyFromPath(record, keyPath));
        if (key === void 0) {
          throw new Error(`store\u300C${storeName}\u300D\u7684 put \u7F3A\u5C11\u4E3B\u952E`);
        }
        store.records.set(serializeKey(key), { key, value: record });
      },
      get: async (storeName, key) => {
        const store = assert(storeName);
        return store.records.get(serializeKey(key))?.value;
      },
      getAll: async (storeName, range, limit) => {
        assertIterateLimit(limit);
        const store = assert(storeName);
        return sortedRecords(store).filter((r) => inRange(r.key, range)).slice(0, limit).map((r) => r.value);
      },
      delete: async (storeName, key) => {
        const store = assert(storeName);
        store.records.delete(serializeKey(key));
      },
      clear: async (storeName) => {
        const store = assert(storeName);
        store.records.clear();
      },
      count: async (storeName, range) => {
        const store = assert(storeName);
        return [...store.records.values()].filter((r) => inRange(r.key, range)).length;
      },
      getFromIndex: async (storeName, indexName, key) => {
        const store = assert(storeName);
        const idx = findIndex(store, indexName);
        for (const r of sortedRecords(store)) {
          for (const entry of indexEntries(store, idx, r.value)) {
            if (compareKeys2(entry, key) === 0) return r.value;
          }
        }
        return void 0;
      },
      getKeyFromIndex: async (storeName, indexName, key) => {
        const store = assert(storeName);
        const idx = findIndex(store, indexName);
        for (const r of sortedRecords(store)) {
          for (const entry of indexEntries(store, idx, r.value)) {
            if (compareKeys2(entry, key) === 0) {
              return r.key;
            }
          }
        }
        return void 0;
      },
      getAllFromIndex: async (storeName, indexName, query) => {
        const store = assert(storeName);
        const idx = findIndex(store, indexName);
        const out = [];
        for (const r of sortedRecords(store)) {
          for (const entry of indexEntries(store, idx, r.value)) {
            if (matchesIndexQuery(entry, query)) {
              out.push(r.value);
              break;
            }
          }
        }
        return out;
      },
      countFromIndex: async (storeName, indexName, query) => {
        const store = assert(storeName);
        const idx = findIndex(store, indexName);
        let n = 0;
        for (const r of sortedRecords(store)) {
          for (const entry of indexEntries(store, idx, r.value)) {
            if (matchesIndexQuery(entry, query)) {
              n++;
              break;
            }
          }
        }
        return n;
      },
      iterate: async (storeName, options, visit) => {
        const store = assert(storeName);
        assertIterateLimit(options.limit);
        const { direction = "next", lower, upper, limit, index } = options;
        let candidates;
        if (index === void 0) {
          candidates = sortedRecords(store).filter((r) => inRange(r.key, { lower, upper }));
        } else {
          const idx = findIndex(store, index);
          candidates = sortedRecords(store).filter(
            (r) => indexEntries(store, idx, r.value).some((entry) => inRange(entry, { lower, upper }))
          );
        }
        if (direction === "prev") candidates.reverse();
        const cap = limit ?? DEFAULT_ITERATE_LIMIT;
        let visited = 0;
        for (const record of candidates) {
          if (visited >= cap) break;
          visited++;
          const action = visit(record.value, record.key);
          if (applyAction(action, record, store) === "stop") break;
        }
      }
    };
  }
};

// src/db-op-log-store.ts
var MATERIALIZED_CHECKPOINT_KEY = "materializedCheckpoint";
var DbOpLogStore = class {
  constructor(db, archiveKeepRecent = 500) {
    this.db = db;
    this.archiveKeepRecent = archiveKeepRecent;
  }
  db;
  archiveKeepRecent;
  // ── 写入 ────────────────────────────────────────────────
  async appendLocal(ops) {
    const result = await this.appendBatch(ops, "local", {});
    return result.seqs;
  }
  /**
   * 追加导入的 op。
   *
   * `appendBatch` 里 `uploadStatus` 的规则是 `source === 'local' ? 'pending' : 'uploaded'`，
   * 所以这里天然得到"不进上传队列"——**这正是想要的**，理由见接口注释
   * （导入的 op 带着别的设备的 `clientId`，上传会被服务端逐条 `INVALID_CLIENT_ID` 拒绝）。
   * 不要为了"让它也能上传"把 source 改成 'local'。
   */
  async appendImported(ops) {
    const result = await this.appendBatch(ops, "import", {});
    return { appended: result.appended, skipped: result.skipped, seqs: result.seqs };
  }
  async appendBatchSkipDuplicates(ops, source, options) {
    const result = await this.appendBatch(ops, source, {
      pendingApply: options.pendingApply
    });
    return {
      writtenOps: result.appended,
      skippedCount: result.skipped.length,
      seqs: result.seqs
    };
  }
  /**
   * 统一写入路径。
   *
   * ⚠️ 整批在**一个事务**里完成：要么全写，要么全不写。
   * 分批写会在中途失败时留下"只写了一半"的状态，而崩溃恢复无法区分
   * "这批本来就只有这些"还是"写到一半炸了"。
   */
  async appendBatch(ops, source, flags) {
    if (ops.length === 0) return { appended: [], skipped: [], seqs: [] };
    return this.db.transaction(
      [STORES.OPS, STORES.ARCHIVE, STORES.META],
      "readwrite",
      async (tx) => {
        const appended = [];
        const skipped = [];
        const seqs = [];
        const seenInBatch = /* @__PURE__ */ new Set();
        for (const op of ops) {
          if (seenInBatch.has(op.id)) {
            skipped.push(op);
            continue;
          }
          seenInBatch.add(op.id);
          if (await tx.getKeyFromIndex(STORES.ARCHIVE, OP_INDEXES.OP_ID, op.id) !== void 0) {
            skipped.push(op);
            continue;
          }
          const record = {
            op,
            source,
            // 字符串而不是布尔 —— IndexedDB 不能索引布尔（见 stores.ts）
            applyStatus: flags.pendingApply === true ? "pending" : "applied",
            // 本地 op 等待上传；远程 op 我们本来就收到了，无需上传。
            // 导入的 op 同理不进队列 —— 它的 clientId 属于别的设备，上传必被拒（见 appendImported）。
            uploadStatus: source === "local" ? "pending" : "uploaded"
          };
          const outcome = await tx.addToleratingDuplicate(STORES.OPS, record);
          if (!outcome.ok) {
            skipped.push(op);
            continue;
          }
          appended.push(op);
          seqs.push(outcome.key);
        }
        if (seqs.length > 0) {
          const maxSeq = Math.max(...seqs);
          const current = await readMetaNumber(tx, META_KEYS.LAST_LOCAL_SEQ);
          if (maxSeq > current) {
            await writeMeta(tx, META_KEYS.LAST_LOCAL_SEQ, maxSeq);
          }
        }
        return { appended, skipped, seqs };
      }
    );
  }
  /** 把本地 op 标记成"已应用"（本地 op 写入时就直接标了，这里用于重试）。 */
  async markApplied(seqs) {
    if (seqs.length === 0) return;
    await this.db.transaction([STORES.OPS], "readwrite", async (tx) => {
      for (const seq of seqs) {
        const rec = await tx.get(STORES.OPS, seq);
        if (rec === void 0) continue;
        await tx.put(STORES.OPS, { ...rec, applyStatus: "applied" });
      }
    });
  }
  async markFailed(opIds) {
    if (opIds.length === 0) return;
    await this.db.transaction([STORES.OPS], "readwrite", async (tx) => {
      for (const opId of opIds) {
        const rec = await tx.getFromIndex(
          STORES.OPS,
          OP_INDEXES.OP_ID,
          opId
        );
        if (rec === void 0) continue;
        await tx.put(STORES.OPS, { ...rec, applyStatus: "failed" });
      }
    });
  }
  /**
   * 合并远程 op 的向量时钟。
   *
   * ⚠️ 这里**不做冲突判定** —— 那是 sync-core 的职责。
   * 存储层只负责把时钟持久化，保证"收到但还没应用"的 op 的时钟
   * 在崩溃后仍然存在（否则重启后会误判并发而丢更新）。
   */
  async mergeRemoteOpClocks(ops) {
    if (ops.length === 0) return;
    await this.db.transaction([STORES.META], "readwrite", async (tx) => {
      await writeMeta(
        tx,
        "pendingRemoteClocks",
        ops.map((op) => op.vectorClock ?? {})
      );
    });
  }
  async markReducersCommittedAndMergeClocks(seqs, _ops, rejectedOpIds) {
    await this.markApplied(seqs);
    if (rejectedOpIds !== void 0 && rejectedOpIds.length > 0) {
      await this.markFailed(rejectedOpIds);
    }
  }
  /** 清理"全量状态"操作，只保留最新的。返回被清除的条数。 */
  async clearFullStateOpsExcept(excludeIds) {
    const exclude = new Set(excludeIds);
    let cleared = 0;
    await this.db.transaction([STORES.OPS, STORES.ARCHIVE, STORES.META], "readwrite", async (tx) => {
      for (const store of [STORES.OPS, STORES.ARCHIVE]) {
        const all = await tx.getAll(store);
        for (const rec of all) {
          if (isFullStateOp(rec.op) && !exclude.has(rec.op.id)) {
            await tx.delete(store, rec.seq);
            cleared += 1;
          }
        }
      }
      if (cleared > 0) await tx.delete(STORES.META, MATERIALIZED_CHECKPOINT_KEY);
    });
    return cleared;
  }
  // ── 读取 ────────────────────────────────────────────────
  async getOpsSince(sinceSeq, limit, excludeClient) {
    const all = await this.getAllOps({ lower: sinceSeq, lowerOpen: true }, excludeClient === void 0 ? limit : void 0);
    const filtered = excludeClient === void 0 ? all : all.filter((r) => r.op.clientId !== excludeClient);
    return limit === void 0 ? filtered : filtered.slice(0, limit);
  }
  async getOpsForEntity(entityType, entityId) {
    return this.db.transaction([STORES.OPS, STORES.ARCHIVE], "readonly", async (tx) => {
      const scalar = await tx.getAllFromIndex(
        STORES.OPS,
        OP_INDEXES.ENTITY,
        [entityType, entityId]
      );
      const batch = await tx.getAllFromIndex(
        STORES.OPS,
        OP_INDEXES.ENTITY_IDS,
        entityId
      );
      const archived = await tx.getAll(STORES.ARCHIVE);
      return [...new Map([...scalar, ...batch, ...archived].filter((r) => r.op.entityType === entityType && (r.op.entityId === entityId || r.op.entityIds?.includes(entityId))).map((r) => [r.seq, r])).values()].sort((a, b) => a.seq - b.seq);
    });
  }
  async getOpById(opId) {
    return this.db.transaction([STORES.OPS, STORES.ARCHIVE], "readonly", async (tx) => {
      for (const name of [STORES.OPS, STORES.ARCHIVE]) {
        const key = await tx.getKeyFromIndex(name, OP_INDEXES.OP_ID, opId);
        if (key !== void 0) return tx.get(name, key);
      }
      return void 0;
    });
  }
  async getLastLocalSeq() {
    const value = await this.db.get(
      STORES.META,
      META_KEYS.LAST_LOCAL_SEQ
    );
    return value?.value ?? 0;
  }
  async getAllOps(range, limit) {
    return this.db.transaction([STORES.OPS, STORES.ARCHIVE], "readonly", async (tx) => {
      const hot = await tx.getAll(STORES.OPS, range, limit);
      const archived = await tx.getAll(STORES.ARCHIVE, range, limit);
      const sorted = [...hot, ...archived].sort((a, b) => a.seq - b.seq);
      return limit === void 0 ? sorted : sorted.slice(0, limit);
    });
  }
  async countAllOps() {
    return this.db.transaction([STORES.OPS, STORES.ARCHIVE], "readonly", async (tx) => await tx.count(STORES.OPS) + await tx.count(STORES.ARCHIVE));
  }
  // ── 崩溃恢复 ────────────────────────────────────────────
  /**
   * 找出所有"已落盘但未应用"的 op。
   *
   * 启动时必须先重放它们，**再**接受新的同步。
   * 否则那个 op 的状态永远不会生效，而它已占用了 seq —— 等于静默丢数据。
   */
  async findPendingApply() {
    const rows = await this.db.getAllFromIndex(
      STORES.OPS,
      OP_INDEXES.PENDING_APPLY,
      // 查字符串 'pending'。**不能查布尔 true** —— IndexedDB 不索引布尔值，
      // 索引条目会被静默跳过，查询恒为空（踩过的坑）。
      "pending"
    );
    return rows.sort((a, b) => a.seq - b.seq);
  }
  /**
   * 「队列空不空」的便宜版本：走索引计数，不把整条队列（含密文正文）搬进内存。
   *
   * ⚠️ 查询条件与 {@link findPendingApply} 逐字相同（查字符串 `'pending'`，
   * **不能查布尔 `true`** —— IndexedDB 不索引布尔值，索引条目会被静默跳过）。
   */
  async countPendingApply() {
    return this.db.countFromIndex(STORES.OPS, OP_INDEXES.PENDING_APPLY, "pending");
  }
  // ── 压缩 / 归档 ──────────────────────────────────────────
  /**
   * 把 `upToSeq` 之前的 op 移入归档。
   *
   * 检查 checkpoint 校验和与实际归档上界（exclusive cutoff - 1）。
   * 未上传/未应用/被拒绝的记录仍留在热区；归档历史仍属于日志。
   */
  async archiveUpTo(upToSeq) {
    const cutoff = upToSeq - this.archiveKeepRecent;
    if (cutoff <= 0) return 0;
    return this.db.transaction(
      [STORES.OPS, STORES.ARCHIVE, STORES.META],
      "readwrite",
      async (tx) => {
        const checkpointRecord = await tx.get(STORES.META, MATERIALIZED_CHECKPOINT_KEY);
        const lastLocalSeq = await readMetaNumber(tx, META_KEYS.LAST_LOCAL_SEQ);
        if (!isValidCheckpoint(checkpointRecord?.value, lastLocalSeq) || checkpointRecord.value.coveredSeq < cutoff - 1) {
          throw new OpLogStoreError(
            "ARCHIVE_REQUIRES_CHECKPOINT" /* ARCHIVE_REQUIRES_CHECKPOINT */,
            `\u5F52\u6863 seq < ${cutoff} \u9700\u8981\u4E00\u4E2A\u8986\u76D6\u81F3\u5C11 ${cutoff - 1} \u7684\u6709\u6548 checkpoint`
          );
        }
        const rows = await tx.getAll(STORES.OPS, {
          upper: cutoff,
          upperOpen: true
        });
        const eligible = rows.filter((rec) => rec.applyStatus === "applied" && rec.uploadStatus === "uploaded");
        for (const rec of eligible) {
          await tx.put(STORES.ARCHIVE, rec);
          await tx.delete(STORES.OPS, rec.seq);
        }
        return eligible.length;
      }
    );
  }
  // ── 簿记 ────────────────────────────────────────────────
  /**
   * 待上传的本地 op（离线队列）。
   *
   * 按 seq 升序 —— 上传顺序必须与本地产出顺序一致，
   * 否则服务端的因果校验会看到"后发生的先到"。
   */
  async findPendingUpload() {
    const rows = await this.db.getAllFromIndex(
      STORES.OPS,
      OP_INDEXES.PENDING_UPLOAD,
      "pending"
    );
    return rows.sort((a, b) => a.seq - b.seq);
  }
  /**
   * 待上传队列的条数，不物化行（查询条件与 {@link findPendingUpload} 逐字相同）。
   *
   * 🔴 它**没有**再按 `source === 'local'` 收窄，而调用方（引擎的
   * `getPendingUpload()`）收窄了。两者等价的前提是那条写入不变量：
   * `uploadStatus = source === 'local' ? 'pending' : 'uploaded'` ——
   * 只有本地写入会进 pending。它由 `op-log-store` 契约测试钉住，
   * 不是靠这段注释自称成立。
   */
  async countPendingUpload() {
    return this.db.countFromIndex(STORES.OPS, OP_INDEXES.PENDING_UPLOAD, "pending");
  }
  /**
   * 标记 op 已上传，并记录服务端分配的 seq。
   *
   * ⚠️ 必须同时把 `op.seq` 写成服务端序号：下次上传时
   * `lastKnownServerSeq` 与冲突判定都依赖它。
   */
  async markUploaded(serverSeqsByOpId) {
    if (serverSeqsByOpId.size === 0) return 0;
    return this.db.transaction(
      [STORES.OPS],
      "readwrite",
      async (tx) => {
        let updated = 0;
        for (const [opId, serverSeq] of serverSeqsByOpId) {
          const key = await tx.getKeyFromIndex(STORES.OPS, OP_INDEXES.OP_ID, opId);
          if (key === void 0) continue;
          const record = await tx.get(STORES.OPS, key);
          if (record === void 0) continue;
          await tx.put(STORES.OPS, {
            ...record,
            uploadStatus: "uploaded",
            serverSeq
          });
          updated += 1;
        }
        return updated;
      }
    );
  }
  async discardPendingUpload(opIds) {
    if (opIds.length === 0) return 0;
    return this.db.transaction([STORES.OPS], "readwrite", async (tx) => {
      let updated = 0;
      for (const opId of opIds) {
        const key = await tx.getKeyFromIndex(STORES.OPS, OP_INDEXES.OP_ID, opId);
        if (key === void 0) continue;
        const record = await tx.get(STORES.OPS, key);
        if (record === void 0) continue;
        await tx.put(STORES.OPS, { ...record, uploadStatus: "uploaded" });
        updated += 1;
      }
      return updated;
    });
  }
  async markRejected(opIds) {
    if (opIds.length === 0) return 0;
    return this.db.transaction([STORES.OPS], "readwrite", async (tx) => {
      let updated = 0;
      for (const opId of opIds) {
        const key = await tx.getKeyFromIndex(STORES.OPS, OP_INDEXES.OP_ID, opId);
        if (key === void 0) continue;
        const record = await tx.get(STORES.OPS, key);
        if (record === void 0) continue;
        await tx.put(STORES.OPS, { ...record, uploadStatus: "rejected" });
        updated += 1;
      }
      return updated;
    });
  }
  async getLastServerSeq() {
    return readMetaNumber(this.db, META_KEYS.LAST_SERVER_SEQ);
  }
  async setLastServerSeq(seq) {
    await this.db.transaction([STORES.META], "readwrite", async (tx) => {
      await writeMeta(tx, META_KEYS.LAST_SERVER_SEQ, seq);
    });
  }
  async readCheckpoint() {
    const record = await this.db.get(
      STORES.META,
      MATERIALIZED_CHECKPOINT_KEY
    );
    return record?.value;
  }
  async writeCheckpoint(checkpoint) {
    if (!isValidCheckpoint(checkpoint, await this.getLastLocalSeq())) {
      throw new OpLogStoreError(
        "STORAGE_UNAVAILABLE" /* STORAGE_UNAVAILABLE */,
        "\u62D2\u7EDD\u5199\u5165\u65E0\u6548 materialized checkpoint"
      );
    }
    await this.db.transaction([STORES.META], "readwrite", async (tx) => {
      await tx.put(STORES.META, { key: MATERIALIZED_CHECKPOINT_KEY, value: checkpoint });
    });
  }
  /** Read the durable server-observed causal frontier, independent of checkpoints. */
  async readObservedClock() {
    return this.db.transaction([STORES.META], "readonly", async (tx) => {
      const record = await tx.get(
        STORES.META,
        META_KEYS.OBSERVED_CLOCK
      );
      if (record === void 0) return {};
      return validateObservedClock(record.value);
    });
  }
  /**
   * Persist a component-wise max merge in one META transaction.
   *
   * The read and write intentionally share the same transaction: concurrent
   * callers must never lose a dimension because both read the same old value.
   */
  async mergeObservedClock(clock) {
    const incoming = validateObservedClock(clock);
    await this.db.transaction([STORES.META], "readwrite", async (tx) => {
      const record = await tx.get(
        STORES.META,
        META_KEYS.OBSERVED_CLOCK
      );
      const current = record === void 0 ? {} : validateObservedClock(record.value);
      const merged = { ...current };
      for (const [clientId, counter] of Object.entries(incoming)) {
        if ((merged[clientId] ?? 0) < counter) {
          Object.defineProperty(merged, clientId, {
            value: counter,
            enumerable: true,
            configurable: true,
            writable: true
          });
        }
      }
      await tx.put(STORES.META, {
        [META_FIELDS.KEY]: META_KEYS.OBSERVED_CLOCK,
        [META_FIELDS.VALUE]: merged
      });
    });
  }
  /** Read the one-way history-integrity marker; absent means complete. */
  async hasIncompleteHistory() {
    return this.db.transaction([STORES.META], "readonly", async (tx) => {
      const record = await tx.get(
        STORES.META,
        META_KEYS.HISTORY_INCOMPLETE
      );
      return record?.value === true;
    });
  }
  /** Set the history-integrity marker. Deliberately no clearing operation exists. */
  async markHistoryIncomplete() {
    await this.db.transaction([STORES.META], "readwrite", async (tx) => {
      await tx.put(STORES.META, {
        [META_FIELDS.KEY]: META_KEYS.HISTORY_INCOMPLETE,
        [META_FIELDS.VALUE]: true
      });
    });
  }
  async getMetaValue(key) {
    const rec = await this.db.get(STORES.META, key);
    return rec?.value;
  }
  async setMetaValue(key, value) {
    await this.db.transaction([STORES.META], "readwrite", async (tx) => {
      await writeMeta(tx, key, value);
    });
  }
};
function isFullStateOp(op) {
  const payload = op.payload;
  return typeof payload === "object" && payload !== null && "isFullState" in payload && payload.isFullState === true;
}
async function readMetaNumber(db, key) {
  const rec = await db.get(STORES.META, key);
  return rec?.value ?? 0;
}
async function writeMeta(tx, key, value) {
  await tx.put(STORES.META, { [META_FIELDS.KEY]: key, [META_FIELDS.VALUE]: value });
}
function validateObservedClock(value) {
  if (value === null || typeof value !== "object" || Array.isArray(value)) {
    throw new TypeError("observed clock \u5FC5\u987B\u662F\u5BF9\u8C61");
  }
  const prototype = Object.getPrototypeOf(value);
  if (prototype !== Object.prototype && prototype !== null) {
    throw new TypeError("observed clock \u5FC5\u987B\u662F\u666E\u901A\u5BF9\u8C61");
  }
  if (Reflect.ownKeys(value).some((key) => typeof key !== "string")) {
    throw new TypeError("observed clock \u7684\u952E\u5FC5\u987B\u662F\u5B57\u7B26\u4E32");
  }
  const clock = {};
  for (const [clientId, counter] of Object.entries(value)) {
    if (!Number.isSafeInteger(counter) || counter < 0) {
      throw new RangeError(
        `observed clock\u300C${clientId}\u300D\u5FC5\u987B\u662F\u975E\u8D1F\u5B89\u5168\u6574\u6570\uFF0C\u6536\u5230\uFF1A${String(counter)}`
      );
    }
    Object.defineProperty(clock, clientId, {
      value: counter,
      enumerable: true,
      configurable: true,
      writable: true
    });
  }
  return clock;
}
export {
  ALL_STORES,
  ALL_STORE_NAMES,
  AdapterDestroyedError,
  DB_SCHEMA_VERSION,
  DEFAULT_ITERATE_LIMIT,
  DbOpLogStore,
  INDEXEDDB_SCHEMA,
  IndexedDbAdapter,
  DbOpLogStore as IndexedDbOpLogStore,
  META_FIELDS,
  META_KEYS,
  MemoryDbAdapter,
  OP_FIELDS,
  OP_INDEXES,
  OpLogStoreError,
  OpLogStoreErrorCode,
  STATE_FIELDS,
  STATE_KEY_PATH,
  STORES,
  SqliteAdapter,
  StorageError,
  UPLOAD_STATUSES,
  asStorageError,
  assertIterateLimit,
  checkpointChecksum,
  createOpLogWirePort,
  createWorkerOpLogSession,
  createWorkerOpLogStore,
  decodeOpLogWire,
  encodeOpLogWire,
  handleOpLogWorkerRequest,
  isValidCheckpoint,
  serializeError,
  serveOpLogWorker,
  storageError
};
                                 
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uL3NyYy9kYi50eXBlcy50cyIsIi4uL3NyYy9lcnJvcnMudHMiLCIuLi9zcmMvc3RvcmVzLnRzIiwiLi4vc3JjL29wLWxvZy1zdG9yZS50cyIsIi4uL3NyYy9jaGVja3BvaW50LnRzIiwiLi4vc3JjL2luZGV4ZWRkYi9pbmRleGVkZGItYWRhcHRlci50cyIsIi4uL3NyYy9zcWxpdGUvc3FsaXRlLWFkYXB0ZXIudHMiLCIuLi9zcmMvc3FsaXRlL29wbG9nLXdvcmtlci1icmlkZ2UudHMiLCIuLi9zcmMvc3FsaXRlL29wbG9nLXdpcmUtY29kZWMudHMiLCIuLi9zcmMvbWVtb3J5L21lbW9yeS1hZGFwdGVyLnRzIiwiLi4vc3JjL2RiLW9wLWxvZy1zdG9yZS50cyJdLCJzb3VyY2VzQ29udGVudCI6WyIvKipcbiAqIOW6leWxguaVsOaNruW6k+aKveixoeOAglxuICpcbiAqIOiuvuiuoeWPguiAg+S6hiBTdXBlciBQcm9kdWN0aXZpdHkg55qEIGBzcmMvYXBwL29wLWxvZy9wZXJzaXN0ZW5jZS9vcC1sb2ctZGItYWRhcHRlci50c2DvvIhNSVTvvIlcbiAqIOKAlOKAlCDkvYbov5nmmK8gaGV5dGEg6Ieq5bex55qE5a6e546w77yM5LiN5piv5pCs6L+Q44CC5Y+C6ICD55qE5qC45b+D5pivKirkuKTmnaHmnrbmnoTliKTmlq0qKu+8mlxuICpcbiAqIDEuICoq6YCC6YWN5Zmo6Ieq5bex6LSf6LSj5bm25Y+R5Liy6KGM5YyW77yM6LCD55So5pa55rC46L+c5LiN6ZyA6KaB5Yqg6ZSB44CCKipcbiAqICAgIEluZGV4ZWREQiDljp/nlJ/lsLHkvJrmiorkvZznlKjln5/ph43lj6DnmoTkuovliqHkuLLooYzljJbvvIzkvZznlKjln5/kuI3nm7jkuqTnmoTlj6/ku6Xlubblj5HvvJtcbiAqICAgIOiAjOWNlei/nuaOpeeahCBTUUxpdGUg5b+F6aG75YaF6YOo5Liy6KGM5YyW44CC5oqK6L+Z5Liq5beu5byCKirlhbPlnKjpgILphY3lmajlhoXpg6gqKu+8jFxuICogICAg5LiK5bGC5Luj56CB5omN6IO95a+5XCLnlKjlk6rkuKrlrZjlgqhcIuWujOWFqOaXoOaEn+OAglxuICpcbiAqIDIuICoq5o6l5Y+j5Y+q5pq06Zyy5pyA5bCP5b+F6KaB5pON5L2cKirvvIzkuI3lgZogT1JN44CCXG4gKiAgICDlvoXlip7lupTnlKjnmoTmlbDmja7orr/pl67mqKHlvI/lvojpm4bkuK3vvIzkuIDkuKrplK7lgLwgKyDntKLlvJXnmoTmir3osaHlsLHlpJ/vvJtcbiAqICAgIOi/h+aXqeW8leWFpSBPUk0g5Lya5oqK5a2Y5YKo6YCJ5oup6ZSB5q2744CCXG4gKlxuICog55uu5qCH77yaKirmjaLlrZjlgqjlrp7njrDml7bvvIzkuIrlsYLkuIDooYzpg73kuI3nlKjmlLnjgIIqKlxuICovXG5cbi8qKlxuICogc3RvcmUgLyDntKLlvJXnmoQqKuWjsOaYjuW9oueKtioq44CC5omA5pyJ5a6e546w5YWx55So5ZCM5LiA5Lu9IOKAlOKAlCDkuI3mmK/lkITlrp7njrDlkITlhpnkuIDku73jgIJcbiAqXG4gKiDwn5S0IOaKveWHuuWug+eahOeQhueUse+8muWmguaenCBJbmRleGVkREIg5LiOIFNRTGl0ZSDlkIToh6rlrprkuYnoh6rlt7HnmoQgc2NoZW1hIOexu+Wei++8jFxuICogXCLlkIzkuIDlpZflpZHnuqbmtYvor5Xot5HpgY3miYDmnInlrp7njrBcIuWwseaXoOS7juiwiOi1tyDigJTigJQg6L+eXCLmnInlk6rkupsgc3RvcmXjgIHlk6rkupvntKLlvJVcIlxuICog6YO95Lya5ryC56e777yM6ICM6YKj5q2j5piv5oyB5LmF5YyW57uT5p6E55qE5LiA6YOo5YiG44CCXG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgU3RvcmVJbmRleFNjaGVtYSB7XG4gIG5hbWU6IHN0cmluZztcbiAgLyoqIOaUr+aMgeeCueWIhui3r+W+hO+8iGBvcC5pZGDvvInvvJvmlbDnu4TooajnpLrlpI3lkIjntKLlvJXjgIIgKi9cbiAga2V5UGF0aDogc3RyaW5nIHwgc3RyaW5nW107XG4gIHVuaXF1ZT86IGJvb2xlYW47XG4gIC8qKiDmlbDnu4TlrZfmrrXlsZXlvIDmiJDlpJrkuKrntKLlvJXmnaHnm67vvIjnur/kuIogYGVudGl0eUlkc2Ag5bCx5piv77yJ44CCICovXG4gIG11bHRpRW50cnk/OiBib29sZWFuO1xufVxuXG5leHBvcnQgaW50ZXJmYWNlIFN0b3JlU2NoZW1hIHtcbiAgbmFtZTogc3RyaW5nO1xuICAvKiog5pWw57uE6KGo56S65aSN5ZCI5Li76ZSu44CCICovXG4gIGtleVBhdGg6IHN0cmluZyB8IHN0cmluZ1tdO1xuICBhdXRvSW5jcmVtZW50PzogYm9vbGVhbjtcbiAgaW5kZXhlcz86IFN0b3JlSW5kZXhTY2hlbWFbXTtcbn1cblxuLyoqIOS4u+mUruexu+Wei+OAgkluZGV4ZWREQiDlhYHorrggc3RyaW5nIHwgbnVtYmVy77yMU1FMaXRlIOS6pueEtuOAgiAqL1xuZXhwb3J0IHR5cGUgRGJLZXkgPSBzdHJpbmcgfCBudW1iZXI7XG5cbi8qKiDkuLvplK7ljLrpl7TvvIjpl63lvIDljLrpl7TvvIzkuI4gSW5kZXhlZERCIOeahCBJREJLZXlSYW5nZSDor63kuYnkuIDoh7TvvInjgIIgKi9cbmV4cG9ydCBpbnRlcmZhY2UgRGJLZXlSYW5nZSB7XG4gIGxvd2VyPzogRGJLZXk7XG4gIHVwcGVyPzogRGJLZXk7XG4gIGxvd2VyT3Blbj86IGJvb2xlYW47XG4gIHVwcGVyT3Blbj86IGJvb2xlYW47XG59XG5cbi8qKlxuICog57Si5byV5p+l6K+i77ya5Yy66Ze044CB5qCH6YeP6ZSu44CB5oiW5aSN5ZCI57Si5byV55qE6ZSu5pWw57uE44CCXG4gKlxuICog4pqg77iPICoq5qCH6YeP5b+F6aG75YyF5ZCr5Zyo5YaF44CCKiog5oiR56ys5LiA54mI5YaZ5oiQIGBEYktleVJhbmdlIHwgRGJLZXlbXWDvvIxcbiAqIOS6juaYryBgZ2V0QWxsRnJvbUluZGV4KHN0b3JlLCBpZHgsICdwZW5kaW5nJylgIOi/meexu+WNlemUruafpeivoioq6YCa5LiN6L+H57G75Z6L5qOA5p+lKirvvIxcbiAqIOiAjOWug+aBsOaBsOaYr+acgOW4uOeUqOeahOW9ouW8j++8iOafpeafkOS4queKtuaAgeOAgeafkOS4quWklumUru+8ieOAglxuICog5bCR5LqG5a6D77yM5a6e546w6YeM5Y+q6IO96Z2gIGBhcyBhbnlgIOe7lei/hyDigJTigJQg6YKj5bCx5oqK57G75Z6L5a6J5YWo5Lii5LqG44CCXG4gKi9cbmV4cG9ydCB0eXBlIERiSW5kZXhRdWVyeSA9IERiS2V5UmFuZ2UgfCBEYktleSB8IERiS2V5W107XG5cbmV4cG9ydCB0eXBlIERiVHhNb2RlID0gJ3JlYWRvbmx5JyB8ICdyZWFkd3JpdGUnO1xuXG5leHBvcnQgdHlwZSBEYkN1cnNvckRpcmVjdGlvbiA9ICduZXh0JyB8ICdwcmV2JztcblxuLyoqIOa4uOagh+iuv+mXruiAheeahOi/lOWbnuWAvO+8jOWGs+WumuS4i+S4gOatpeWKqOS9nOOAgiAqL1xuZXhwb3J0IHR5cGUgRGJDdXJzb3JBY3Rpb24gPSAnY29udGludWUnIHwgJ3N0b3AnIHwgJ2RlbGV0ZScgfCAnZGVsZXRlLXN0b3AnO1xuXG5leHBvcnQgdHlwZSBEYkN1cnNvclZpc2l0b3I8VD4gPSAodmFsdWU6IFQsIGtleTogRGJLZXkpID0+IERiQ3Vyc29yQWN0aW9uO1xuXG4vKipcbiAqIGBhZGRUb2xlcmF0aW5nRHVwbGljYXRlYCDnmoTnu5PmnpzjgIJcbiAqXG4gKiDliKTliKvogZTlkIjogIzkuI3mmK8gYHsgb2s6IGJvb2xlYW47IGtleT86IG51bWJlciB9YO+8muWQjuiAheiuqeiwg+eUqOaWueW/hemhu+WvuVxuICogYGtleWAg5YGa6Z2e56m65pat6KiA77yM6ICMXCLmiJDlip/ljbTmsqHmnIkga2V5XCLlrp7pmYXkuIrmmK8qKuS4jeWPr+iDvSoq55qE54q25oCB44CCXG4gKi9cbmV4cG9ydCB0eXBlIERiVG9sZXJhbnRBZGRSZXN1bHQgPVxuICB8IHsgb2s6IHRydWU7IGtleTogbnVtYmVyIH1cbiAgfCB7IG9rOiBmYWxzZTsgcmVhc29uOiAnZHVwbGljYXRlJyB9O1xuXG5leHBvcnQgaW50ZXJmYWNlIERiSXRlcmF0ZU9wdGlvbnMge1xuICBkaXJlY3Rpb24/OiBEYkN1cnNvckRpcmVjdGlvbjtcbiAgLyoqIOS7juivpemUruW8gOWni++8iOWQq++8ieOAgiAqL1xuICBsb3dlcj86IERiS2V5O1xuICAvKiog5Yiw6K+l6ZSu57uT5p2f77yI5ZCr77yJ44CCICovXG4gIHVwcGVyPzogRGJLZXk7XG4gIC8qKiDmnIDlpJrorr/pl67lpJrlsJHmnaHjgIIgKi9cbiAgbGltaXQ/OiBudW1iZXI7XG4gIC8qKiDotbDlk6rkuKrntKLlvJXvvJvkuI3kvKDliJnotbDkuLvplK7jgIIgKi9cbiAgaW5kZXg/OiBzdHJpbmc7XG59XG5cbi8qKlxuICoge0BsaW5rIERiQWRhcHRlci5kZXN0cm95fSDnmoTov5Tlm57lgLwg4oCU4oCUICoq5LiA5qyh6ZSA5q+B55qE5Lmm6Z2i5Yet5o2u77yM5LiN5piv5oiQ5Yqf5qCH5b+X5L2NKirjgIJcbiAqXG4gKiDwn5S0IOS4uuS7gOS5iOimgeaciei/meS4quW9oueKtu+8muazqOmUgOi0puWPt+aJv+ivuueahOaYr1wi6L+Z5Y+w6K6+5aSH5LiK55qE5oiR5LiN6KeB5LqGXCLvvIxcbiAqIOiAjFwi5oqK5q+P5byg6KGo55qE6KGM5Yig5bmy5YeAXCLkuI5cIumCo+S4quaWh+S7ti/pgqPkuKrlupPnnJ/nmoTkuI3lrZjlnKjkuoZcIuaYryoq5Lik5Lu25LqLKirjgIJcbiAqIOWPquWbniBgUHJvbWlzZTx2b2lkPmAg55qEIGRlc3Ryb3kg5Lya6K6p56ys5LiA5Lu26K+76LW35p2l5YOP56ys5LqM5Lu2IOKAlOKAlFxuICog6YKj5piv5pS/562W6YeM5pyA6LS155qE5LiA57G75YGH6K+d77yI6KeBIEFEUi0wMDQ4IOS4jumakOengeaUv+etlumCo+WPpeWIhuWxguWunuivne+8ieOAglxuICpcbiAqIOKaoO+4jyDosIPnlKjmlrkqKuW/hemhu+aKiiBgY29udGFpbmVyUmVtb3ZlZCA9PT0gZmFsc2VgIOivtOWHuuWOuyoq77yI55WM6Z2i5oiW5pel5b+X77yJ77yMXG4gKiDkuI3orrjmiorlroPmipjlj6DmiJBcIuW3sumUgOavgVwi44CCXG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgRGJEZXN0cm95UmVwb3J0IHtcbiAgLyoqIOmUgOavgeWvueixoeeahOagh+ivhu+8iOW6k+WQjSAvIOaWh+S7tuWQjSAvIGA6bWVtb3J5OmDvvInvvIznlKjkuo7miorlh63mja7lr7nkuIrlj7fjgIIgKi9cbiAgcmVhZG9ubHkgdGFyZ2V0OiBzdHJpbmc7XG4gIC8qKlxuICAgKiB0cnVlID0g5oyB5LmF5a655Zmo5pys6Lqr77yI5bqT5paH5Lu244CBSW5kZXhlZERCIOaVsOaNruW6k++8ieW3sue7j+S4jeWcqOS6huOAglxuICAgKiBmYWxzZSA9IOWPqua4heepuuS6huWGheWuue+8jOWuueWZqOi/mOWcqO+8iOaui+eVmemhteeQhuiuuuS4iuWPr+iiq+WPluivgeaBouWkje+8ieOAglxuICAgKi9cbiAgcmVhZG9ubHkgY29udGFpbmVyUmVtb3ZlZDogYm9vbGVhbjtcbiAgLyoqIGBjb250YWluZXJSZW1vdmVkID09PSBmYWxzZWAg5pe2Kirlv4XpobsqKue7meWHuuWOn+WboO+8iOe8uuS6huWwseivtOS4jea4heWug+S4uuS7gOS5iOayoeaIkO+8ieOAgiAqL1xuICByZWFkb25seSByZWFzb24/OiBzdHJpbmc7XG4gIC8qKiDooqvmuIXmjonnmoQgc3RvcmUg5pWw6YePIOKAlOKAlCDliKTmja7nlKjlroPpkolcIua4heepuui/meS7tuS6i+ehruWunuaJq+i/h+S6huWFqOmDqOihqFwi44CCICovXG4gIHJlYWRvbmx5IHN0b3Jlc0NsZWFyZWQ6IG51bWJlcjtcbn1cblxuLyoqXG4gKiDkuovliqHlj6Xmn4TjgILlj6rmnInpgJrov4cge0BsaW5rIERiQWRhcHRlci50cmFuc2FjdGlvbn0g5YiX5Ye655qEIHN0b3JlIOaJjeiDveiiq+iuv+mXruOAglxuICpcbiAqIOKaoO+4jyDmnKzmjqXlj6MqKuS4jeaPkOS+m+W1jOWll+S6i+WKoSoq44CC5bWM5aWXIGB0cmFuc2FjdGlvbmAg6LCD55So5piv6LCD55So5pa555qEIGJ1Z++8jFxuICog6YCC6YWN5Zmo5bqU5oqb6ZSZ6ICM5LiN5piv6Z2Z6buY6ZmN57qn44CCXG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgRGJUeCB7XG4gIGFkZChzdG9yZTogc3RyaW5nLCB2YWx1ZTogdW5rbm93bik6IFByb21pc2U8bnVtYmVyPjtcblxuICAvKipcbiAgICog5o+S5YWl77yb6Iul6Kem5Y+RKirllK/kuIDntKLlvJXlhrLnqoEqKuWImeaKpeWRilwi5bey5a2Y5ZyoXCLogIwqKuS4jeS9v+S6i+WKoeWksei0pSoq44CCXG4gICAqXG4gICAqIPCflLQg6L+Z5Liq5pa55rOV5b+F6aG75Zyo5o6l5Y+j6YeM77yM5Zug5Li65a6D5om/6L295LqGIG9wLWxvZyDnmoTkuIDmnaHlhbPplK7or63kuYnvvJpcbiAgICog5ZCM5LiA5LiqIG9wSWQg6KKr6YeN5aSN5oqV6YCS5pivKirmraPluLjot6/lvoQqKu+8iOWQjOatpeS8mumHjeaUvuOAgeWuouaIt+err+S8mumHjeivle+8ie+8jFxuICAgKiDkuI3mmK/lvILluLjjgIJcbiAgICpcbiAgICog5a6D5pu+57uPKirlj6rlrZjlnKjkuo4gYEluZGV4ZWREYkFkYXB0ZXJgIOS4iuiAjOS4jeWcqOaOpeWPo+mHjCoqIOKAlOKAlFxuICAgKiBgRGJPcExvZ1N0b3JlYCDkuo7mmK/lj6rog73pnaAgYGFzIERiVHggJiB7Li4ufWAg5by66L2s5Y676LCD55So5a6D44CCXG4gICAqIOW8uui9rOacrOi6q+WwseaYr+S/oeWPt++8muaOpeWPo+ayoeacieihqOi+vuS9v+eUqOiAheeahOecn+WunumcgOaxguOAguWQjuaenOaYr+S7u+S9leaWsOmAgumFjeWZqFxuICAgKiDvvIjmr5TlpoIgU1FMaXRl44CB5YaF5a2Y5a6e546w77yJ5Y+q6KaB5oyJ5o6l5Y+j6ICB5a6e5a6e546w77yM5bCx5Lya5Zyo6L+Q6KGM5pe25oqlXG4gICAqIFwiYWRkVG9sZXJhdGluZ0R1cGxpY2F0ZSBpcyBub3QgYSBmdW5jdGlvblwi44CC5YWx5Lqr5aWR57qm5LiA6LeR5bCx5oqT5Yiw5LqG44CCXG4gICAqXG4gICAqIPCflLQg5a6e546w6KaB54K577ya5Yay56qB5b+F6aG76KKrKirpgILphY3lmajlhoXpg6gqKuWQuOaUtu+8iEluZGV4ZWREQiDph4zmmK9cbiAgICogYHByZXZlbnREZWZhdWx0KClg77yJ77yM5ZCm5YiZ6ZSZ6K+v5YaS5rOh5Lya5Lit5q2i5pW05Liq5LqL5Yqh77yM5oqK5pW05om55YaZ5YWl5Zue5rua5o6JIOKAlOKAlFxuICAgKiDpgqPkvJrorqlcIui3s+i/h+mHjeWkjemhueOAgee7p+e7reWGmeWFtuS9meeahFwi5Y+Y5oiQXCLmlbTmibnpg73kuI3lhplcIuOAglxuICAgKi9cbiAgYWRkVG9sZXJhdGluZ0R1cGxpY2F0ZShzdG9yZTogc3RyaW5nLCB2YWx1ZTogdW5rbm93bik6IFByb21pc2U8RGJUb2xlcmFudEFkZFJlc3VsdD47XG4gIHB1dChzdG9yZTogc3RyaW5nLCB2YWx1ZTogdW5rbm93biwga2V5PzogRGJLZXkpOiBQcm9taXNlPHZvaWQ+O1xuICBnZXQ8VD4oc3RvcmU6IHN0cmluZywga2V5OiBEYktleSk6IFByb21pc2U8VCB8IHVuZGVmaW5lZD47XG4gIGdldEFsbDxUPihzdG9yZTogc3RyaW5nLCByYW5nZT86IERiS2V5UmFuZ2UsIGxpbWl0PzogbnVtYmVyKTogUHJvbWlzZTxUW10+O1xuICBkZWxldGUoc3RvcmU6IHN0cmluZywga2V5OiBEYktleSk6IFByb21pc2U8dm9pZD47XG4gIGNsZWFyKHN0b3JlOiBzdHJpbmcpOiBQcm9taXNlPHZvaWQ+O1xuICBjb3VudChzdG9yZTogc3RyaW5nLCByYW5nZT86IERiS2V5UmFuZ2UpOiBQcm9taXNlPG51bWJlcj47XG5cbiAgZ2V0RnJvbUluZGV4PFQ+KHN0b3JlOiBzdHJpbmcsIGluZGV4OiBzdHJpbmcsIGtleTogRGJLZXkgfCBEYktleVtdKTogUHJvbWlzZTxUIHwgdW5kZWZpbmVkPjtcbiAgZ2V0S2V5RnJvbUluZGV4KHN0b3JlOiBzdHJpbmcsIGluZGV4OiBzdHJpbmcsIGtleTogRGJLZXkgfCBEYktleVtdKTogUHJvbWlzZTxEYktleSB8IHVuZGVmaW5lZD47XG5cbiAgLyoqXG4gICAqIOaMiee0ouW8leafpeivou+8jOi/lOWbnioq5YWo6YOoKirlkb3kuK3orrDlvZXjgIJcbiAgICpcbiAgICog8J+UtCAqKui/lOWbnumhuuW6j+acquWumuS5ieOAgioqXG4gICAqXG4gICAqIOWunua1i+WQhOWunueOsOW5tuS4jeS4gOiHtO+8mkluZGV4ZWREQiDljp/nlJ/nmoQgYGdldEFsbEZyb21JbmRleGAg5oyJKirntKLlvJXplK4qKuaOkuW6j++8jFxuICAgKiDogIzlhoXlrZjlrp7njrDkuI4gU1FMaXRlIOWunueOsOaMiSoq5Li76ZSuKirmjpLluo/jgILkuInogIXpg73og73mu6HotrNcIui/lOWbnuWTquS6m+iusOW9lVwi77yMXG4gICAqIOS9humhuuW6j+S4jeWQjOOAglxuICAgKlxuICAgKiDov5nkuI3mmK/nvLrpmbfvvIzmmK8qKuW/hemhu+iiq+WGmeS4i+adpeeahOS6i+WunioqIOKAlOKAlCDlkKbliJnlsIbmnaXmnInkurrlkIjnkIblnLDlgYforr5cbiAgICog5a6D5oyJ57Si5byV6ZSu5pyJ5bqP77yI5Zug5Li6IEluZGV4ZWREQiDlsLHmmK/ov5nmoLfvvInvvIzlnKggU1FMaXRlIOS4iuS8mumdmem7mOaLv+WIsFxuICAgKiDlj6bkuIDkuKrpobrluo/jgIIqKuS+nei1lumhuuW6j+eahOiwg+eUqOaWueW/hemhu+iHquW3sSBzb3J044CCKipcbiAgICpcbiAgICogYERiT3BMb2dTdG9yZWAg6YeM5q+P5Liq6ZyA6KaB6aG65bqP55qE5Zyw5pa577yIYGZpbmRQZW5kaW5nVXBsb2FkYCAvXG4gICAqIGBmaW5kUGVuZGluZ0FwcGx5YCAvIGBnZXRPcHNGb3JFbnRpdHlg77yJ6YO95bey5pi+5byP5oyJIGBzZXFgIOaOkuW6j++8jFxuICAgKiDlubbnlLEgT3BMb2dTdG9yZSDlpZHnuqbplIHkvY/vvIzmiYDku6XkuIrkvKDpobrluo/mmK/lronlhajnmoTjgIJcbiAgICovXG4gIGdldEFsbEZyb21JbmRleDxUPihzdG9yZTogc3RyaW5nLCBpbmRleDogc3RyaW5nLCBxdWVyeT86IERiSW5kZXhRdWVyeSk6IFByb21pc2U8VFtdPjtcblxuICAvKiog5oyJ57Si5byV6K6h5pWw44CC5LiOIHtAbGluayBnZXRBbGxGcm9tSW5kZXh9IOS4jeWQjO+8jOiuoeaVsOS4jumhuuW6j+aXoOWFs+OAgiAqL1xuICBjb3VudEZyb21JbmRleChzdG9yZTogc3RyaW5nLCBpbmRleDogc3RyaW5nLCBxdWVyeT86IERiSW5kZXhRdWVyeSk6IFByb21pc2U8bnVtYmVyPjtcblxuICBpdGVyYXRlPFQ+KHN0b3JlOiBzdHJpbmcsIG9wdGlvbnM6IERiSXRlcmF0ZU9wdGlvbnMsIHZpc2l0OiBEYkN1cnNvclZpc2l0b3I8VD4pOiBQcm9taXNlPHZvaWQ+O1xufVxuXG4vKipcbiAqIOWtmOWCqOmAgumFjeWZqOOAgkluZGV4ZWREQuOAgVNRTGl0ZSDnrYnlrp7njrDmraTmjqXlj6PjgIJcbiAqXG4gKiDlubblj5HlpZHnuqbvvIgqKumHjeimgSoq77yJ77ya5omA5pyJ5pa55rOV6YO95b+F6aG7Kirlj6/lronlhajlubblj5HosIPnlKgqKuOAglxuICog5a6e546w5pa56KaB5LmI5L6d6LWWIEluZGV4ZWREQiDnmoTljp/nlJ/kuovliqHor63kuYnvvIzopoHkuYjlnKjlhoXpg6jnlKggRklGTyDpmJ/liJfkuLLooYzljJZcbiAqIO+8iOWNlei/nuaOpSBTUUxpdGXvvInjgIIqKuiwg+eUqOaWueS4jemcgOimgeWcqOiHquW3sei/meS4gOWxguWKoOmUgeOAgioqXG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgRGJBZGFwdGVyIHtcbiAgLyoqIOaJk+W8gC/liJvlu7rmlbDmja7lupPjgILluYLnrYnvvIzkuJTlj6/lronlhajlubblj5HosIPnlKjjgIIgKi9cbiAgaW5pdCgpOiBQcm9taXNlPHZvaWQ+O1xuXG4gIC8qKiDlhbPpl63ov57mjqXjgILlkI7nu63mk43kvZzkvJrpgI/mmI7lnLDph43mlrDmiZPlvIDjgIIgKi9cbiAgY2xvc2UoKTogdm9pZDtcblxuICAvLyDilIDilIAg5Z+656GA6ZSu5YC85pON5L2cIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuICBhZGQoc3RvcmU6IHN0cmluZywgdmFsdWU6IHVua25vd24pOiBQcm9taXNlPG51bWJlcj47XG4gIHB1dChzdG9yZTogc3RyaW5nLCB2YWx1ZTogdW5rbm93biwga2V5PzogRGJLZXkpOiBQcm9taXNlPHZvaWQ+O1xuICBnZXQ8VD4oc3RvcmU6IHN0cmluZywga2V5OiBEYktleSk6IFByb21pc2U8VCB8IHVuZGVmaW5lZD47XG4gIGdldEFsbDxUPihzdG9yZTogc3RyaW5nLCByYW5nZT86IERiS2V5UmFuZ2UsIGxpbWl0PzogbnVtYmVyKTogUHJvbWlzZTxUW10+O1xuICBkZWxldGUoc3RvcmU6IHN0cmluZywga2V5OiBEYktleSk6IFByb21pc2U8dm9pZD47XG4gIGNsZWFyKHN0b3JlOiBzdHJpbmcpOiBQcm9taXNlPHZvaWQ+O1xuICBjb3VudChzdG9yZTogc3RyaW5nLCByYW5nZT86IERiS2V5UmFuZ2UpOiBQcm9taXNlPG51bWJlcj47XG5cbiAgLy8g4pSA4pSAIOe0ouW8leaTjeS9nCDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcbiAgZ2V0RnJvbUluZGV4PFQ+KHN0b3JlOiBzdHJpbmcsIGluZGV4OiBzdHJpbmcsIGtleTogRGJLZXkgfCBEYktleVtdKTogUHJvbWlzZTxUIHwgdW5kZWZpbmVkPjtcbiAgZ2V0S2V5RnJvbUluZGV4KHN0b3JlOiBzdHJpbmcsIGluZGV4OiBzdHJpbmcsIGtleTogRGJLZXkgfCBEYktleVtdKTogUHJvbWlzZTxEYktleSB8IHVuZGVmaW5lZD47XG5cbiAgLyoqXG4gICAqIOaMiee0ouW8leafpeivou+8jOi/lOWbnioq5YWo6YOoKirlkb3kuK3orrDlvZXjgIJcbiAgICpcbiAgICog8J+UtCAqKui/lOWbnumhuuW6j+acquWumuS5ieOAgioqXG4gICAqXG4gICAqIOWunua1i+WQhOWunueOsOW5tuS4jeS4gOiHtO+8mkluZGV4ZWREQiDljp/nlJ/nmoQgYGdldEFsbEZyb21JbmRleGAg5oyJKirntKLlvJXplK4qKuaOkuW6j++8jFxuICAgKiDogIzlhoXlrZjlrp7njrDkuI4gU1FMaXRlIOWunueOsOaMiSoq5Li76ZSuKirmjpLluo/jgILkuInogIXpg73og73mu6HotrNcIui/lOWbnuWTquS6m+iusOW9lVwi77yMXG4gICAqIOS9humhuuW6j+S4jeWQjOOAglxuICAgKlxuICAgKiDov5nkuI3mmK/nvLrpmbfvvIzmmK8qKuW/hemhu+iiq+WGmeS4i+adpeeahOS6i+WunioqIOKAlOKAlCDlkKbliJnlsIbmnaXmnInkurrlkIjnkIblnLDlgYforr5cbiAgICog5a6D5oyJ57Si5byV6ZSu5pyJ5bqP77yI5Zug5Li6IEluZGV4ZWREQiDlsLHmmK/ov5nmoLfvvInvvIzlnKggU1FMaXRlIOS4iuS8mumdmem7mOaLv+WIsFxuICAgKiDlj6bkuIDkuKrpobrluo/jgIIqKuS+nei1lumhuuW6j+eahOiwg+eUqOaWueW/hemhu+iHquW3sSBzb3J044CCKipcbiAgICpcbiAgICogYERiT3BMb2dTdG9yZWAg6YeM5q+P5Liq6ZyA6KaB6aG65bqP55qE5Zyw5pa577yIYGZpbmRQZW5kaW5nVXBsb2FkYCAvXG4gICAqIGBmaW5kUGVuZGluZ0FwcGx5YCAvIGBnZXRPcHNGb3JFbnRpdHlg77yJ6YO95bey5pi+5byP5oyJIGBzZXFgIOaOkuW6j++8jFxuICAgKiDlubbnlLEgT3BMb2dTdG9yZSDlpZHnuqbplIHkvY/vvIzmiYDku6XkuIrkvKDpobrluo/mmK/lronlhajnmoTjgIJcbiAgICovXG4gIGdldEFsbEZyb21JbmRleDxUPihzdG9yZTogc3RyaW5nLCBpbmRleDogc3RyaW5nLCBxdWVyeT86IERiSW5kZXhRdWVyeSk6IFByb21pc2U8VFtdPjtcblxuICAvKiog5oyJ57Si5byV6K6h5pWw44CC5LiOIHtAbGluayBnZXRBbGxGcm9tSW5kZXh9IOS4jeWQjO+8jOiuoeaVsOS4jumhuuW6j+aXoOWFs+OAgiAqL1xuICBjb3VudEZyb21JbmRleChzdG9yZTogc3RyaW5nLCBpbmRleDogc3RyaW5nLCBxdWVyeT86IERiSW5kZXhRdWVyeSk6IFByb21pc2U8bnVtYmVyPjtcblxuICAvLyDilIDilIAg5ri45qCHIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuICBpdGVyYXRlPFQ+KHN0b3JlOiBzdHJpbmcsIG9wdGlvbnM6IERiSXRlcmF0ZU9wdGlvbnMsIHZpc2l0OiBEYkN1cnNvclZpc2l0b3I8VD4pOiBQcm9taXNlPHZvaWQ+O1xuXG4gIC8vIOKUgOKUgCDkuovliqEg4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG4gIC8qKlxuICAgKiDlnKggYHN0b3Jlc2Ag5LiK5omn6KGM5Y2V5Liq5Y6f5a2Q5LqL5Yqh44CCXG4gICAqIOi/lOWbnueahCBQcm9taXNlIOWGs+iuruaXtuaPkOS6pO+8jOaLkue7neaXtuWbnua7muOAglxuICAgKi9cbiAgdHJhbnNhY3Rpb248VD4oc3RvcmVzOiBzdHJpbmdbXSwgbW9kZTogRGJUeE1vZGUsIGZuOiAodHg6IERiVHgpID0+IFByb21pc2U8VD4pOiBQcm9taXNlPFQ+O1xuXG4gIC8qKlxuICAgKiAqKumUgOavgeacrOacuui/meS7veaYjuaWh+W6kyoq77ya5riF56m65YWo6YOoIHN0b3Jl77yM5bm25Zyo5bmz5Y+w5YWB6K645pe256e76Zmk5oyB5LmF5a655Zmo5pys6Lqr44CCXG4gICAqXG4gICAqIPCflLQg5a6DKirlv4XpobvlnKjmjqXlj6PkuIrvvIzogIzkuJTmmK/lv4XloavpobkqKuOAgui/meS4jeaYr+mjjuagvOmXrumimO+8jOaYr+i/meS4gOadoeaJv+ivuueahOW9oueKtu+8mlxuICAgKiDjgIzms6jplIDotKblj7cgPSDov5nlj7Dorr7lpIfkuIrnmoTmiJHmsqHkuobjgI3jgILmnKzku5PlupPlr7lcIuivpeWcqOaOpeWPo+S4iuWNtOayoeWcqOaOpeWPo+S4ilwiXG4gICAqIOW3sue7j+S7mOi/h+S4gOasoeWtpui0uSDigJTigJQgYGFkZFRvbGVyYXRpbmdEdXBsaWNhdGVgIOW9k+aXtuWPquWcqCBJbmRleGVkREIg5a6e546w5LiK44CBXG4gICAqIOS4jeWcqOaOpeWPo+mHjO+8jOS6juaYr+aWsOmAgumFjeWZqFwi5oyJ5o6l5Y+j6ICB5a6e5a6e546wXCLlsLHkvJrlnKjov5DooYzml7bmiqVcbiAgICogYGlzIG5vdCBhIGZ1bmN0aW9uYO+8iOingSB7QGxpbmsgRGJUeC5hZGRUb2xlcmF0aW5nRHVwbGljYXRlfe+8ieOAglxuICAgKiBgZGVzdHJveWAg55qE5aSx6LSl5qih5byP5pu057Of77yaKirmvI/mjonlroPnmoTkuIDnq6/kuI3kvJrmiqXplJnvvIzlj6rkvJrnu6fnu63nlZnnnYDnlKjmiLfnmoTmmI7mlocqKu+8jFxuICAgKiDogIzpgqPmraPmmK/ov5nmnaHmib/or7rllK/kuIDopoHpmLLnmoTkuovjgILmiYDku6XlroPmmK/lv4XloavnmoQg4oCU4oCUIOWwkeWunueOsOS4gOS4quWwseaYr+e8luivkemUmeivr+OAglxuICAgKlxuICAgKiDor63kuYnvvIjlpZHnuqbmtYvor5XpgJDmnaHpkonkvY/vvIzop4EgYHRlc3RzL2NvbnRyYWN0L2FkYXB0ZXIuY29udHJhY3QudHNg77yJ77yaXG4gICAqICAxLiAqKuW5guetiSoq77ya6ZSA5q+B5LiA5Lu95bey57uP5rKh5LqG55qE5bqT5LiN5piv6ZSZ6K+v44CCXG4gICAqICAyLiAqKuWFiOaOkuepuuWcqOmAlOS6i+WKoeWGjeWKqOaJiyoq77ya6ZSA5q+B5LiO5YaZ5YWl5bm25Y+R5pe277yMXCLlhpnlrozlj4jokL3lm57mnaVcIuS8muiuqVxuICAgKiAgICAg6ZSA5q+B5oql5ZGK6K+06LCO44CCXG4gICAqICAzLiAqKuS4jSBgY2xvc2UoKWAg5ZCO5bCx5a6M5LqLKirvvJpgY2xvc2UoKWAg55qE5aWR57qm5pivXCLlkI7nu63mk43kvZzpgI/mmI7ph43lvIBcIu+8jFxuICAgKiAgICAg5a6DKirkuI3liKDku7vkvZXkuJzopb8qKu+8m+aKiiBjbG9zZSDlvZMgZGVzdHJveSDmmK/mnKzmnaHlrZjlnKjnmoTljoblj7Lljp/lm6DjgIJcbiAgICogIDQuIOi/lOWbniB7QGxpbmsgRGJEZXN0cm95UmVwb3J0fe+8muiwg+eUqOaWueimgeaLv+WIsFwi5a655Zmo5Yiw5bqV5rKh5LqG5rKh5pyJXCLnmoTkuabpnaLlh63mja7jgIJcbiAgICogIDUuICoq6ZSA5q+B5Y2z5q276LevKirvvJrkuYvlkI7ov5nkuKrlrp7kvovkuIrnmoTku7vkvZXor7vlhpnku6UgYEFkYXB0ZXJEZXN0cm95ZWRFcnJvcmAg5aSx6LSl44CCXG4gICAqICAgICDwn5S0IOi/meS4gOadoeaYr+iiq+Wunua1i+mAvOWHuuadpeeahO+8jOS4jeaYr+mjjuagvO+8muatpOWJjSBgZGVzdHJveSgpYCDlj6rlgZrkuoYgYGNsb3NlKClg77yMXG4gICAqICAgICDogIwgYGNsb3NlKClgIOeahOWlkee6puaBsOaBsOaYr1wi5ZCO57ut5pON5L2c6YCP5piO6YeN5byAXCIg4oCU4oCUIOS6juaYr+mUgOavgeWQjueahCoq56ys5LiA5qyh5pmu6YCa6K+7KipcbiAgICogICAgIOWwseaKiuWImuWIoOaOieeahOWuueWZqOmHjeaWsOW7uuaIkOepuuWjs++8iFNRTGl0ZSDkvqcgNzM3Mjgg5a2X6IqCIC8gNiDlvKDnqbrooajvvIzorqHliJIgwqcxMC4xNDbvvInjgIJcbiAgICogICAgIOmCo+asoei/kOihjOWQjOaXtuaJk+WNsOS6hlwi6ZSA5q+B5oiQ5YqfXCLlkoxcIuW6k+aWh+S7tuWbnuadpeS6hlwi77yM6ICM6K+75Ye65p2l5pivIDAg5p2h77yMXG4gICAqICAgICDmiYDku6Xpk77kuIrmr4/kuIDlsYLpg73mnInnkIbnlLHorqTkuLroh6rlt7HmsqHor7TosI7jgIJcbiAgICogICAgIOesrOS6jOasoSBgZGVzdHJveSgpYCDkvovlpJbvvJrlroPov5Tlm57nrKzkuIDmrKHnmoTlkIzkuIDku73miqXlkYrvvIjluYLnrYnmiJDnq4vvvIzkuJTkuI3pnIDopoHph43lvIDvvInjgIJcbiAgICogICAgIOimgeaOpeedgOeUqOi/meS7veWtmOWCqOeahCoq5ZSv5LiAKirmraPlvZPmlrnlvI/mmK/mlrDlu7rkuIDkuKrlrp7kvosg4oCU4oCUIOavj+S4quecn+WunuWuv+S4u+WcqOazqOmUgOS5i+WQjlxuICAgKiAgICAg6YO95piv6L+Z5Liq5b2i54q277yI6YeN5paw5Yqg6L296aG16Z2iIC8g5Ya35ZCv5YqoIC8g6YeN5paw5rOo5YaM77yJ44CCXG4gICAqXG4gICAqIOKaoO+4jyAqKuWIoOW5suWHgOS4jeetieS6juayoeacieaui+eVmSoq77yaU1FMaXRlIOeahOmhteWcqOejgeebmOS4iuWPr+iDveiiq+aBouWkje+8jFNTRCDml6Dms5XnnJ/mraNcbiAgICog5pOm6Zmk77yM5aSH5Lu95LiO5pel5b+X5LiN5Zyo6L+Z5qyh5pON5L2c55qE5L2c55So5Z+f6YeM44CC5pS/562W5b+F6aG75oyJ6L+Z5Liq6L6555WM5YaZXG4gICAqIO+8iEFEUi0wMDQ4IOS4jumakOengeaUv+etlueahOWIhuWxguWunuivne+8ie+8jOS7o+eggeS4jeiuuOaKiiByZXBvcnQg6K+05b6X5q+U5a6D5YGa5Yiw55qE5pu05aW944CCXG4gICAqL1xuICBkZXN0cm95KCk6IFByb21pc2U8RGJEZXN0cm95UmVwb3J0Pjtcbn1cblxuLyoqXG4gKiDmlq3oqIAgYGl0ZXJhdGVgIOeahCBsaW1pdCDlkIjms5XjgIJcbiAqXG4gKiDlrZjlnKjnmoTnkIbnlLHvvJrml6DkuIrpmZDnmoTmuLjmoIfpgY3ljobmmK/np7vliqjnq6/ljaHmrbvnmoTluLjop4Hljp/lm6DvvIxcbiAqIOiuqeWugyoq5Zyo5byA5Y+R5pyf5bCx54K4KirvvIzogIzkuI3mmK/nrYnnur/kuIrnlKjmiLfmiqVcIuW6lOeUqOaJk+W8gOWwseWNoeS9j1wi44CCXG4gKi9cbmV4cG9ydCBjb25zdCBhc3NlcnRJdGVyYXRlTGltaXQgPSAobGltaXQ/OiBudW1iZXIpOiB2b2lkID0+IHtcbiAgaWYgKGxpbWl0ID09PSB1bmRlZmluZWQpIHJldHVybjtcbiAgaWYgKCFOdW1iZXIuaXNJbnRlZ2VyKGxpbWl0KSB8fCBsaW1pdCA8PSAwKSB7XG4gICAgdGhyb3cgbmV3IEVycm9yKGBpdGVyYXRlIGxpbWl0IOW/hemhu+aYr+ato+aVtOaVsO+8jOaUtuWIsO+8miR7U3RyaW5nKGxpbWl0KX1gKTtcbiAgfVxufTtcblxuLyoqIOm7mOiupOmBjeWOhuS4iumZkOOAgumYsuatoua8j+S8oCBsaW1pdCDml7bmiavlhajooajjgIIgKi9cbmV4cG9ydCBjb25zdCBERUZBVUxUX0lURVJBVEVfTElNSVQgPSAxMF8wMDA7XG4iLCIvKipcbiAqIOWtmOWCqOWksei0peeahCoq57uT5p6E5YyW5Y6f5ZugKipcbiAqID09PT09PT09PT09PT09PT09PT09PT09PT09XG4gKlxuICog5Li65LuA5LmI6ZyA6KaB5a6D77ya6ZSZ6K+v5bGP77yIYGFwcHMvd2ViL3NyYy9tYWluLnRzeGAg4oaSIGBFcnJvclNjcmVlbi50c3hg77yJ5riy5p+T55qE5pivXG4gKiBgZXJyb3IubWVzc2FnZWAg55qEKirljp/mlocqKuOAguiAjOi/meadoei3r+W+hOS4iuacieS4gOadoeS4reaWh+aYryoq5peg5p2h5Lu2KirmipvnmoTvvJpcbiAqXG4gKiBgYGBcbiAqIEluZGV4ZWREQiDljYfnuqfooqvlhbblroPmoIfnrb7pobXpmLvloZ4g4oCU4oCUIOivt+WFs+mXreivpeW6lOeUqOeahOWFtuWug+eql+WPo+WQjumHjeivlVxuICogYGBgXG4gKlxuICog6Kem5Y+R5p2h5Lu25piv55yf5a6e55So5oi35Zy65pmv77yI5ZCM5LiA5Liq56uZ54K55byA5LqG5Lik5Liq5qCH562+6aG177yM5YW25Lit5LiA5Liq5piv5pen54mI5pys77yJ44CCXG4gKiDkuo7mmK8qKueUqOiLseaWh+eVjOmdoueahOeUqOaIt+S8muWcqOW6lOeUqOWQr+WKqOWksei0peaXtuivu+WIsOS4gOWPpeS4reaWhyoq44CCXG4gKlxuICog5YGa5rOV5LiOIGBwYWNrYWdlcy9haWAg55qEIGBBaUZhaWx1cmUucmVhc29uYOOAgWBzeW5jLWNsaWVudGAg55qE5ZCM5q2l54q25oCB5a6M5YWo5LiA6Ie077yaXG4gKiAqKuadpea6kOWPque7mee7k+aehOWMlueahOWOn+WboO+8jOaOqui+nuW9kuWQhOWjsyoq44CCXG4gKlxuICog8J+UtCBgbWVzc2FnZWAg5L+d5oyB5Y6f5qC35LiN5Yqo77yM6L+Z5piv5Yi75oSP55qE77yaXG4gKiAgIDEuIOWug+acieiviuaWreS7t+WAvO+8iOmUmeivr+Wxj+aKiuWug+mZjee6p+aIkFwi6K+m5oOFXCLvvIzlrrnlmajph4znnIvkuI3liLDnnJ/plJnor6/ml7bpnaDlroPvvInvvJtcbiAqICAgMi4g546w5pyJ5rWL6K+V5oyJIGBtZXNzYWdlYCDmlq3oqIDvvIhgcmVqZWN0cy50b1Rocm93KCfmlYXmhI/lpLHotKUnKWDvvInvvIxcbiAqICAgICAg5pS5IGBtZXNzYWdlYCDnrYnkuo7miorkuIDloIbkuI7mnKzmrKHmlLnliqjml6DlhbPnmoTmtYvor5XkuIDotbfmlLnmjonjgIJcbiAqXG4gKiDimqDvuI8gKirlt7Lnn6XmnKropobnm5YqKu+8mmBtZW1vcnktYWRhcHRlci50c2Ag5LiOIGBzcWxpdGUtYWRhcHRlci50c2Ag5LuN54S25oqb6KO4IGBFcnJvcmDjgIJcbiAqIOWug+S7rOeahOS4reaWh+WFqOaYryoq57yW56iL6ZSZ6K+vKirvvIjmnKrlrprkuYnnmoQgc3RvcmXjgIHltYzlpZfkuovliqHjgIHnvLrntKLlvJXigKbvvInmiJbpqbHliqjnmoTljp/lp4vmiqXplJnvvIxcbiAqIOS4jeaYr+eUqOaIt+S8muivu+WIsOeahOeVjOmdouaWh+ahiCDigJTigJQg5omA5Lul6L+Z5LiA6L2u5Y+q6L2sIEluZGV4ZWREQu+8iFdlYiDnmoTlkK/liqjot6/lvoTvvInjgIJcbiAqIOimgeaUtuWPo+aXtuaMieWQjOagt+aWueW8j+WKoCBga2luZGDvvIzlubblnKjmtYvor5Xph4zpkonkvY9cIm1lc3NhZ2Ug6YCQ5a2X5pyq5Y+YXCLjgIJcbiAqL1xuXG4vKipcbiAqIOWtmOWCqOWksei0peeahOWOn+WboOOAglxuICpcbiAqIOWJjeWbm+enjeaYryoq55So5oi35Lya6YGH5Yiw55qEKirvvIznrKzkupTnp43mmK8qKuW8gOWPkeiAheaQnumUmeS6hioq77yaXG4gKiDkuKTogIXnmoTlpITnva7mlrnlvI/kuI3lkIwg4oCU4oCUIOWJjeiAheimgee/u+ivkeaIkOeUqOaIt+iDveivu+aHgueahOWPpeWtkO+8jOWQjuiAheivpeW4puedgOaKgOacr+e7huiKglxuICog5Ye6546w5ZyoXCLor6bmg4VcIumHjO+8jOiAjOS4jeaYr+iiq+acrOWcsOWMluaIkOS4gOWPpeS6suWIh+eahOaPkOekuuOAglxuICovXG5leHBvcnQgdHlwZSBTdG9yYWdlRmFpbHVyZSA9XG4gIC8qKiDmlbDmja7lupPmiZPkuI3lvIDvvJrpmpDnp4HmqKHlvI/jgIHphY3pop3kuI3otrPjgIHooqvkuK3mraLigKbigKYgKi9cbiAgfCB7IGtpbmQ6ICdvcGVuLWZhaWxlZCcgfVxuICAvKipcbiAgICog8J+UtCDljYfnuqfooqsqKuWFtuWug+agh+etvumhtSoq6Zi75aGe44CCXG4gICAqXG4gICAqIOi/meaYr+WUr+S4gOS4gOenjVwi55So5oi355yL5LiA55y85bCx55+l6YGT5oCO5LmI5YqeXCLnmoTlpLHotKXvvIjlhbPmjonliKvnmoTnqpflj6PljbPlj6/vvInvvIxcbiAgICog5Lmf5piv5ZSv5LiA5LiA56eNKirml6DmnaHku7YqKuaKm+WHuueahO+8iGBvbmJsb2NrZWRgIOS6i+S7tuayoeaciSBgZXJyb3JgIOWvueixoeWPr+S7peWAn++8ieOAglxuICAgKi9cbiAgfCB7IGtpbmQ6ICd1cGdyYWRlLWJsb2NrZWQnIH1cbiAgLyoqIOS4gOasoeivu+WGmeivt+axguWksei0pe+8iOmpseWKqOaKpeS6humUme+8jOaIlumpseWKqOayoee7memUmeivr+Wvueixoe+8ieOAgiAqL1xuICB8IHsga2luZDogJ3JlcXVlc3QtZmFpbGVkJyB9XG4gIC8qKiDkuovliqHlpLHotKXmiJbooqvkuK3mraLjgIIgKi9cbiAgfCB7IGtpbmQ6ICd0cmFuc2FjdGlvbi1mYWlsZWQnIH1cbiAgLyoqIOe8lueoi+mUmeivr++8muiwg+eUqOaWueeUqOmUmeS6humAgumFjeWZqOOAgueUqOaIt+WvueWug+aXoOS7juS4i+aJi+OAgiAqL1xuICB8IHsga2luZDogJ3Byb2dyYW1taW5nLWVycm9yJyB9O1xuXG4vKipcbiAqIOW4pue7k+aehOWMluWOn+WboOeahOWtmOWCqOmUmeivr+OAgmBtZXNzYWdlYCDkuI7mlLnpgKDliY3pgJDlrZfnm7jlkIzjgIJcbiAqXG4gKiDwn5S0IGBjYXVzZWAg5L+d55WZKirpqbHliqgv5rWP6KeI5Zmo57uZ55qE5Y6f5aeL6ZSZ6K+vKirvvIhgcmVxdWVzdC5lcnJvcmAgLyBgaWRiVHguZXJyb3Jg4oCm77yJ77yMXG4gKiDov5nkuIDngrnmmK/lv4XpobvnmoTvvJrljIXkuIDlsYLkuYvlkI4gYGVycm9yLm5hbWVgIOWwseWPmOaIkCBgJ1N0b3JhZ2VFcnJvcidgIOS6hu+8jFxuICog6ICM5ZSv5LiA57Si5byV5Yay56qB55qE5Yik5a6aKirlj6rog73nnIvpqbHliqjoh6rlt7HnmoTlkI3lrZcqKu+8iGBDb25zdHJhaW50RXJyb3Jg77yJ44CCXG4gKlxuICog6L+Z5LiN5piv5YGH5oOzIOKAlOKAlCDmlLnov5nkuIDniYjml7bmiJHmioogYGVycm9yLm5hbWVgIOW8hOS4ouS6hu+8jFxuICogYERiT3BMb2dTdG9yZWAg55qEXCLlkIzkuIAgb3BJZCDlhpnkuKTmrKHlj6rnlZnkuIDmnaFcIuW9k+Wcuue6ouS6hiA0IOS4quaXouacieeUqOS+i+OAglxuICogKirml6LmnInmtYvor5XmipPliLDkuoblroPvvIzov5nkuZ/mraPmmK9cIuWFiOacieWfuue6v+WGjeaUuVwi55qE5Lu35YC844CCKipcbiAqL1xuZXhwb3J0IGNsYXNzIFN0b3JhZ2VFcnJvciBleHRlbmRzIEVycm9yIHtcbiAgcmVhZG9ubHkgZmFpbHVyZTogU3RvcmFnZUZhaWx1cmU7XG5cbiAgY29uc3RydWN0b3IobWVzc2FnZTogc3RyaW5nLCBmYWlsdXJlOiBTdG9yYWdlRmFpbHVyZSwgY2F1c2U/OiB1bmtub3duKSB7XG4gICAgc3VwZXIobWVzc2FnZSk7XG4gICAgdGhpcy5uYW1lID0gJ1N0b3JhZ2VFcnJvcic7XG4gICAgdGhpcy5mYWlsdXJlID0gZmFpbHVyZTtcbiAgICB0aGlzLmNhdXNlID0gY2F1c2U7XG4gIH1cbn1cblxuLyoqXG4gKiDmiorpqbHliqjnu5nnmoTkuJzopb/ljIXmiJAgYFN0b3JhZ2VFcnJvcmDvvIwqKmBtZXNzYWdlYCDkuI4gYHJlcXVlc3QuZXJyb3IgPz8gbmV3IEVycm9yKOWFnOW6lSlgIOmAkOWtl+ebuOWQjCoq77yaXG4gKlxuICogLSBgY2F1c2VgIOaYryBgRXJyb3JgIOKGkiDnlKgqKuWug+iHquW3seeahCoqIGBtZXNzYWdlYO+8iOa1j+iniOWZqC/pqbHliqjnu5nnmoTnu4boioLkvJjlhYjvvIzkuI7mlLnpgKDliY3kuIDoh7TvvIlcbiAqIC0gYGNhdXNlYCDnvLrluK3vvIhgdW5kZWZpbmVkYC9gbnVsbGDvvInihpIg55SoIGBmYWxsYmFja01lc3NhZ2VgXG4gKiAtIOWFtuWug++8iOeQhuiuuuS4iuS4jeS8muWPkeeUn++8ieKGkiBgU3RyaW5nKGNhdXNlKWBcbiAqXG4gKiDimqDvuI8g5ZSv5LiA55qE6KGM5Li65beu5byC77ya5pS56YCg5YmN6Z2eIGBFcnJvcmAg55qEIGBjYXVzZWAg5Lya6KKrKirljp/moLcqKuW9k+S9nCByZWplY3Rpb24g5YC85oqb5Ye65Y6777yMXG4gKiDnjrDlnKjkuIDlvovljIXmiJAgYFN0b3JhZ2VFcnJvcmDjgILosIPnlKjmlrnmi7/liLDnmoTlp4vnu4jmmK8gYEVycm9yYO+8jOi/meaYr+abtOS4peeahOW9oueKtuOAglxuICovXG5leHBvcnQgZnVuY3Rpb24gc3RvcmFnZUVycm9yKFxuICBjYXVzZTogdW5rbm93bixcbiAgZmFsbGJhY2tNZXNzYWdlOiBzdHJpbmcsXG4gIGZhaWx1cmU6IFN0b3JhZ2VGYWlsdXJlLFxuKTogU3RvcmFnZUVycm9yIHtcbiAgaWYgKGNhdXNlIGluc3RhbmNlb2YgRXJyb3IpIHJldHVybiBuZXcgU3RvcmFnZUVycm9yKGNhdXNlLm1lc3NhZ2UsIGZhaWx1cmUsIGNhdXNlKTtcbiAgaWYgKGNhdXNlID09PSB1bmRlZmluZWQgfHwgY2F1c2UgPT09IG51bGwpIHJldHVybiBuZXcgU3RvcmFnZUVycm9yKGZhbGxiYWNrTWVzc2FnZSwgZmFpbHVyZSk7XG4gIHJldHVybiBuZXcgU3RvcmFnZUVycm9yKFN0cmluZyhjYXVzZSksIGZhaWx1cmUsIGNhdXNlKTtcbn1cbi8qKlxuICog5bey57uP5pivIGBTdG9yYWdlRXJyb3JgIOWwsSoq5Y6f5qC36L+U5ZueKirvvIzlkKbliJnljIXkuIDlsYLjgIJcbiAqXG4gKiDwn5S0IOi/meadoVwi5LiA5omL57uT5p6E5LyY5YWIXCLnmoTop4TliJnmmK/lv4XpobvnmoTvvJrpgILphY3lmajlhoXpg6jmnInkuIDlsYIqKue7n+S4gCBjYXRjaCoqXG4gKiDvvIjkuovliqHkvZPnmoQgYGNhdGNoYO+8ie+8jOWug+S8muaKiumHjOmdouaKm+WHuuadpeeahOS4gOWIh+mHjeaWsOWMheS4gOmBjeOAglxuICog6ICM6YeM6Z2i5oqb5Ye65p2l55qE5Y+v6IO95bey57uP5piv5pu05YW35L2T55qE5Y6f5ZugIOKAlOKAlCDmr5TlpoIgYG1ha2VUeGAg55qEIGBwcm9ncmFtbWluZy1lcnJvcmDjgIJcbiAqIOeUqCBgc3RvcmFnZUVycm9yKClgIOebtOaOpeWMheS8muaKiuWugyoq6ZmN57qnKirmiJDnrLznu5/nmoQgYHJlcXVlc3QtZmFpbGVkYO+8jFxuICog5LqO5pivXCLnlKjmiLfml6Dku47kuIvmiYtcIuWSjFwi6YeN6K+V5LiA5LiLXCLooqvmt7fmiJDlkIzkuIDnsbvjgIJcbiAqXG4gKiDmtYvor5XpkonkvY/kuobov5nkuIDngrnvvIhgdGVzdHMvc3RvcmFnZS1lcnJvci5zcGVjLnRzYO+8ieOAglxuICovXG5leHBvcnQgZnVuY3Rpb24gYXNTdG9yYWdlRXJyb3IoXG4gIGNhdXNlOiB1bmtub3duLFxuICBmYWxsYmFja01lc3NhZ2U6IHN0cmluZyxcbiAgZmFpbHVyZTogU3RvcmFnZUZhaWx1cmUsXG4pOiBTdG9yYWdlRXJyb3Ige1xuICBpZiAoY2F1c2UgaW5zdGFuY2VvZiBTdG9yYWdlRXJyb3IpIHJldHVybiBjYXVzZTtcbiAgcmV0dXJuIHN0b3JhZ2VFcnJvcihjYXVzZSwgZmFsbGJhY2tNZXNzYWdlLCBmYWlsdXJlKTtcbn1cblxuLyoqXG4gKiDlnKgqKuW3sue7jyBgZGVzdHJveSgpYCDov4fnmoTpgILphY3lmajlrp7kvosqKuS4iue7p+e7reivu+WGmeOAglxuICpcbiAqIPCflLQg5Li65LuA5LmI6KaB5pyJ6L+Z5Liq57G75Z6L77yM6ICM5LiN5piv6K6p5a6D6Z2Z6buY5oiQ5Yqf77yaXG4gKiBgZGVzdHJveSgpYCDkvJrmiorov57mjqXlhbPmjonjgILmraTliY3nmoTlrp7njrDph4zvvIzkuYvlkI7ku7vkvZXkuIDmrKHmma7pgJror7vpg73kvJrotbBcbiAqIGBvcGVuKClgL2BlbnN1cmVPcGVuKClgIOmCo+adoemHjeW8gOi3r+W+hO+8jOS6juaYryoq5Yia5Yig5o6J55qE5a655Zmo6KKr6YeN5paw5bu65oiQ56m65aOzKipcbiAqIO+8iFNRTGl0ZSDkvqflrp7mtYsgNzM3Mjgg5a2X6IqCIC8gNiDlvKDnqbrooajvvIzop4HorqHliJIgwqcxMC4xNDbvvInjgILooajnjrDmmK/vvJpcbiAqIOiwg+eUqOaWueaLv+WIsFwi6ZSA5q+B5oiQ5YqfXCLnmoTmiqXlkYrvvIznm5jkuIrljbTph43mlrDlh7rnjrDkuoblupMg4oCU4oCUIOiAjOWGheWuueivu+WHuuadpeaYr+epuueahO+8jFxuICog5omA5LulKirmsqHmnInku7vkvZXkuIDlsYLkvJror7TosI4qKuOAgui/meaYr1wi5rC46L+c6YCa6L+H55qE5Yik5o2uXCLpgqPkuIDml4/nmoTlrZjlgqjlsYLniYjmnKzjgIJcbiAqXG4gKiDnjrDlnKjplIDmr4HljbPmrbvot6/vvJrnrKzkuozmrKEgYGRlc3Ryb3koKWAg6L+U5Zue5ZCM5LiA5Lu95oql5ZGK77yI5bmC562J5LuN54S25oiQ56uL77yJ77yMXG4gKiDlhbbkvZnku7vkvZXmk43kvZzkuIDlvovmipvov5nkuKrplJnjgILopoHph43mlrDnlKjlsLHmjaLkuIDkuKrmlrDlrp7kvosg4oCU4oCUXG4gKiDmr4/kuKrnnJ/lrp7lrr/kuLvlnKjms6jplIDkuYvlkI7pg73mmK/ov5nkuYjlgZrnmoTvvIjph43mlrDnmbvlvZUgLyDph43lkK/ov5vnqIsgLyDph43mlrDliqDovb3pobXpnaLvvInjgIJcbiAqXG4gKiBga2luZGAg5pivIGBwcm9ncmFtbWluZy1lcnJvcmDvvJrnlKjmiLflr7nlroPml6Dku47kuIvmiYvvvIzog73lgZrnmoTlj6rmnInmiormjqXnur/mlLnlr7lcbiAqIO+8iOmUgOavgeWZqOS5i+WQjuS4jeivpeWGjeacieS6uuaLv+edgOWQjOS4gOS4quWunuS+i+WPkei1t+ivu++8ieOAglxuICovXG5leHBvcnQgY2xhc3MgQWRhcHRlckRlc3Ryb3llZEVycm9yIGV4dGVuZHMgU3RvcmFnZUVycm9yIHtcbiAgY29uc3RydWN0b3IodGFyZ2V0OiBzdHJpbmcpIHtcbiAgICBzdXBlcihcbiAgICAgIGDov5nku73lrZjlgqjlt7LooqvplIDmr4HvvIgke3RhcmdldH3vvInjgILplIDmr4HlkI7nmoTlrp7kvovkuI3lj6/lho3nlKgg4oCU4oCUIOWug+S8muaLkue7neivu+WGme+8jGAgK1xuICAgICAgICAn6ICM5LiN5piv5oqK5Yia5Yig5o6J55qE5a655Zmo6YeN5paw5bu65oiQ56m65aOz44CC6K+35pS555So5LiA5Liq5paw55qE6YCC6YWN5Zmo5a6e5L6L44CCJyxcbiAgICAgIHsga2luZDogJ3Byb2dyYW1taW5nLWVycm9yJyB9LFxuICAgICk7XG4gICAgdGhpcy5uYW1lID0gJ0FkYXB0ZXJEZXN0cm95ZWRFcnJvcic7XG4gIH1cbn1cbiIsIi8qKlxuICogaGV5dGEg5pys5Zyw5pWw5o2u5bqT55qEIHN0b3JlIOS4jue0ouW8leWumuS5ieOAglxuICpcbiAqIOKaoO+4jyDov5nmmK8qKuaMgeS5heWMlue7k+aehCoq77yM5bGe5LqOXCLkuI3lj6/pgIblsYJcIuKAlOKAlOS4gOaXpuWPkeW4g+WwseW+iOmavuaUueOAglxuICog5pS55Yqo5YmN6K+36K+7IGBwYWNrYWdlcy9zaGFyZWQtc2NoZW1hL3NyYy9zY2hlbWEtdmVyc2lvbi50c2Ag55qE54mI5pys5pS/562W44CCXG4gKi9cblxuaW1wb3J0IHR5cGUgeyBPcGVyYXRpb24gfSBmcm9tICdAaGV5dGEvc3luYy1jb3JlJztcblxuLyoqIHN0b3JlIOWQjeensOOAgiAqL1xuZXhwb3J0IGNvbnN0IFNUT1JFUyA9IHtcbiAgLyoqXG4gICAqIOaTjeS9nOaXpeW/l+acrOS9k+OAguWQjOatpeezu+e7n+eahOWUr+S4gOS6i+Wunuadpea6kOOAglxuICAgKlxuICAgKiDkuLvplK7mmK/oh6rlop7nmoQgYHNlcWDvvIjmnKzlnLDljZXosIPpgJLlop7vvInvvIwqKuS4jeaYryoqIG9wIOeahOS4muWKoSBpZCDigJTigJRcbiAgICog5Zug5Li65ZCM5q2l5ri45qCH44CB5bSp5rqD5oGi5aSN6YO96KaB5L6d6LWWXCLljZXosIPkuJTml6DnqbrmtJ5cIueahOacrOWcsOW6j+WPt+OAglxuICAgKi9cbiAgT1BTOiAnb3BzJyxcblxuICAvKiog54mp5YyW5ZCO55qE5a6e5L2T54q25oCB77yI5oqKIG9wcyDph43mlL7lh7rmnaXnmoTnu5PmnpzvvInjgILlj6/ku44gT1BTIOWujOaVtOmHjeW7uuOAgiAqL1xuICBTVEFURTogJ3N0YXRlJyxcblxuICAvKiog6ZSu5YC85Z6L57C/6K6w77ya5a6i5oi356uvIGlk44CB5pyN5Yqh56uv5ri45qCH44CB5Yqg5a+G6YWN572u562J44CCICovXG4gIE1FVEE6ICdtZXRhJyxcblxuICAvKiog5bey5b2S5qGjL+WOi+e8qeeahOaTjeS9nO+8iOS/neeVmeeUqOS6juaBouWkjeeCueS4juWuoeiuoe+8ieOAgiAqL1xuICBBUkNISVZFOiAnYXJjaGl2ZScsXG59IGFzIGNvbnN0O1xuXG5leHBvcnQgdHlwZSBTdG9yZU5hbWUgPSAodHlwZW9mIFNUT1JFUylba2V5b2YgdHlwZW9mIFNUT1JFU107XG5cbi8qKiDlhajpg6ggc3RvcmUg5ZCN56ew77yI5bu65bqT5pe255So77yJ44CCICovXG5leHBvcnQgY29uc3QgQUxMX1NUT1JFUzogU3RvcmVOYW1lW10gPSBbXG4gIFNUT1JFUy5PUFMsXG4gIFNUT1JFUy5TVEFURSxcbiAgU1RPUkVTLk1FVEEsXG4gIFNUT1JFUy5BUkNISVZFLFxuXTtcblxuLyoqXG4gKiBgb3BzYCBzdG9yZSDnmoTlrZfmrrXlkI3jgIJcbiAqXG4gKiDwn5S0ICoq6L+Z5Lqb5bi46YeP5b+F6aG75ZKMIGBAaGV5dGEvc3luYy1jb3JlYCDnmoQgYE9wZXJhdGlvbmAg5aWR57qm5a2X5q615ZCN5Lil5qC85LiA6Ie044CCKipcbiAqXG4gKiDmiJHnrKzkuIDniYjmiorlroPku6zlhpnmiJDmma7pgJrlrZfnrKbkuLLvvIhgT1BfSUQ6ICdvcElkJ2DvvInvvIzogIwgYE9wZXJhdGlvbmAg55qE5a2X5q615YW25a6e5Y+rXG4gKiBgaWRg44CC57uT5p6c5piv5ZSv5LiA57Si5byV55qEIGtleVBhdGgg5oyH5ZCR5LiA5Liq5LiN5a2Y5Zyo55qE5a2X5q61IOKAlOKAlFxuICogKipJbmRleGVkREIg5a+5IHVuZGVmaW5lZCDkuI3lu7rntKLlvJXmnaHnm67vvIzkuI3miqXplJkqKu+8jOS6juaYr+WOu+mHjeWujOWFqOWkseaViO+8mlxuICog5ZCM5LiA5LiqIG9wIOWPr+S7peiiq+aXoOmZkOWGmeWFpe+8jOiAjOaJgOaciea1i+ivleS5i+WklueahOWcsOaWuemDveeci+S4jeWHuuadpeOAglxuICpcbiAqIOS/ruazleS4jeaYr+aUueWvueWtl+espuS4suWwseWujOS6i++8jOiAjOaYryoq6K6p5a6D5Lus5Zyo57G75Z6L5bGC6Z2i6KKr57qm5p2fKirvvJpcbiAqIOS4i+mdoueUqCBgc2F0aXNmaWVzYCDmiormr4/kuKrlrZfmrrXlkI3nu5HlrprliLAgYE9wZXJhdGlvbmAg55qEIGtlee+8jFxuICog5YaZ6ZSZ5a2X5q615ZCN5LyaKirnvJbor5HlpLHotKUqKu+8jOiAjOS4jeaYr+etieWIsOi/kOihjOaXtumdmem7mOWkseaViOOAglxuICovXG5leHBvcnQgY29uc3QgT1BfRklFTERTID0ge1xuICAvKipcbiAgICog4pqg77iPICoq5pys5ZywKiroh6rlop7luo/lj7fjgIJcbiAgICpcbiAgICog5rOo5oSP5LiOIGBPcGVyYXRpb24uc2VxYO+8iCoq5pyN5Yqh56uvKirluo/lj7fvvInljLrliIbvvJrkuKTogIXlkI3lrZfkuIDmoLfkvYblkKvkuYnkuI3lkIzjgIJcbiAgICog5pys5bi46YeP5oyH6aG25bGCIGBTdG9yZWRPcGVyYXRpb24uc2VxYO+8iOWtmOWCqOiusOW9leeahOS4u+mUru+8ie+8jFxuICAgKiDkuI3mmK/ltYzlpZfnmoQgYG9wLnNlcWDjgILntKLlvJUga2V5UGF0aCDlm6DmraTlhpnpobblsYIgYCdzZXEnYOOAglxuICAgKi9cbiAgU0VROiAnc2VxJyxcbiAgLyoqIOaTjeS9nOS4muWKoSBpZO+8iOWuouaIt+err+eUn+aIkOeahCBVVUlEIHY377yJ77yMKirllK/kuIDntKLlvJUqKiDigJTigJQg55So5LqO5Y676YeN44CCICovXG4gIE9QX0lEOiAnaWQnLFxuICBFTlRJVFlfVFlQRTogJ2VudGl0eVR5cGUnLFxuICBFTlRJVFlfSUQ6ICdlbnRpdHlJZCcsXG4gIC8qKiDlpJrlrp7kvZPmibnmrKHmk43kvZzmtonlj4rnmoTlhajpg6jlrp7kvZMgaWTvvIwqKm11bHRpRW50cnkg57Si5byVKirjgIIgKi9cbiAgRU5USVRZX0lEUzogJ2VudGl0eUlkcycsXG4gIFBBWUxPQUQ6ICdwYXlsb2FkJyxcbiAgVkVDVE9SX0NMT0NLOiAndmVjdG9yQ2xvY2snLFxuICBDTElFTlRfSUQ6ICdjbGllbnRJZCcsXG4gIENMSUVOVF9USU1FU1RBTVA6ICd0aW1lc3RhbXAnLFxuICBTQ0hFTUFfVkVSU0lPTjogJ3NjaGVtYVZlcnNpb24nLFxuICAvKipcbiAgICog5LiK5Lyg54q25oCB77yMKirlrZfnrKbkuLLkuI3mmK/luIPlsJQqKuOAglxuICAgKlxuICAgKiDlkIzkuIDkuKrnkIbnlLHlho3ouKnkuIDmrKHlsLHlpKrooKLkuobvvJpJbmRleGVkREIg5LiN6IO957Si5byV5biD5bCU5YC8IOKAlOKAlFxuICAgKiBgdHJ1ZWAg5LiN5piv5ZCI5rOV55qEIElEQiBrZXnvvIzntKLlvJXph4zkuI3kvJrkuqfnlJ/mnaHnm67vvIzmn6Xor6LmgZLov5Tlm57nqboqKuS4lOS4jeaKpemUmSoq44CCXG4gICAqL1xuICBVUExPQURfU1RBVFVTOiAndXBsb2FkU3RhdHVzJyxcbiAgLyoqXG4gICAqIPCflLQg5bqU55So54q25oCB44CCKirlv4XpobvnlKjlrZfnrKbkuLLvvIzkuI3og73nlKjluIPlsJTjgIIqKlxuICAgKlxuICAgKiDkuLrku4DkuYjvvJoqKkluZGV4ZWREQiDkuI3lhYHorrjluIPlsJTlgLzkvZzkuLrplK4qKiDigJTigJQgYHRydWVgIOS4jeaYr+WQiOazleeahCBJREIga2V577yMXG4gICAqIOaJgOS7peWvueW4g+WwlOWtl+auteW7uue0ouW8leaXtu+8jOe0ouW8leadoeebruS8muiiqyoq6Z2Z6buY6Lez6L+HKirvvIjkuI3miqXplJnvvIzlj6rmmK/mn6XkuI3liLDvvInjgIJcbiAgICog5oiR56ys5LiA54mI5bCx5piv55SoIGBwZW5kaW5nQXBwbHk6IHRydWVgIOW7uue0ouW8le+8jOe7k+aenCBgZmluZFBlbmRpbmdBcHBseSgpYFxuICAgKiDmsLjov5zov5Tlm57nqbrmlbDnu4Qg4oCU4oCUIOW0qea6g+aBouWkjeWujOWFqOWkseaViO+8jOiAjOS4lOayoeacieS7u+S9lemUmeivr+aPkOekuuOAglxuICAgKlxuICAgKiDlj5blgLzop4Ege0BsaW5rIEFwcGx5U3RhdHVzfeOAglxuICAgKi9cbiAgQVBQTFlfU1RBVFVTOiAnYXBwbHlTdGF0dXMnLFxufSBhcyBjb25zdDtcblxuLyoqXG4gKiDlupTnlKjnirbmgIHmnLrjgIJcbiAqXG4gKiAgIHBlbmRpbmcgIOKAlOKAlCDlt7LokL3nm5jvvIznrYnlvoUgcmVkdWNlciDmj5DkuqTvvIjltKnmuoPmgaLlpI3opoHmiavov5nkuKrvvIlcbiAqICAgYXBwbGllZCAg4oCU4oCUIOW3suW6lOeUqO+8jOWuieWFqFxuICogICBmYWlsZWQgICDigJTigJQg5bqU55So5aSx6LSl77yM5bey6ZqU56a7XG4gKi9cbmV4cG9ydCB0eXBlIEFwcGx5U3RhdHVzID0gJ3BlbmRpbmcnIHwgJ2FwcGxpZWQnIHwgJ2ZhaWxlZCc7XG5cbi8qKlxuICog5LiK5Lyg54q25oCB44CCXG4gKlxuICogYHBlbmRpbmdgICAg4oCU4oCUIOWwmuacquaIkOWKn+S4iuS8oOe7meacjeWKoeerr++8iOemu+e6v+mYn+WIl+WwseaYr+Wug++8iVxuICogYHVwbG9hZGVkYCAg4oCU4oCUIOacjeWKoeerr+W3suaOpeWPl1xuICogYHJlamVjdGVkYCAg4oCU4oCUIOacjeWKoeerryoq5rC45LmF5ouS57udKirvvIzlt7Lnp7vlh7rpmJ/liJdcbiAqXG4gKiDkuLrku4DkuYjkuI3nlKggYG9wLnNlcSA9PT0gMGAg6KGo56S6XCLmsqHkuIrkvKBcIu+8mumCo+agt+aXoOazlSoq5bu657Si5byVKirvvIxcbiAqIOavj+asoeWQjOatpemDveimgeWFqOihqOaJq+aPj+OAguiAjOS4lOacjeWKoeerr+eQhuiuuuS4iuWPr+iDveWIhumFjSBzZXEgMOOAglxuICog5pi+5byP54q25oCB5q+U54m55Yik5Y+v6Z2g44CCXG4gKlxuICog8J+UtCAqKmByZWplY3RlZGAg5LiN6IO95bm26L+bIGB1cGxvYWRlZGDjgIIqKlxuICpcbiAqIOacjeWKoeerr+WPr+iDvSoq5rC45LmF5ouS57udKirkuIDmnaEgb3DvvJpgSU5WQUxJRF9DTElFTlRfSURgIOivtOaYjui/meadoSBvcCDmoLnmnKzkuI3lsZ7kuo7mnKzmnLpcbiAqIO+8iOavlOWmguacrOWcsOW6k+mHjOa3t+i/m+S6huWPpuS4gOWPsOiuvuWkh+eahOaui+eVmSBvcO+8ie+8jGBJTlZBTElEX09QX0lEYCDor7TmmI7ov5nkuKogaWQg5bey57uP6KKrXG4gKiDlj6bkuIDkuKogb3Ag5Y2g55So44CC6L+Z57G7IG9wIOmHjeivleWkmuWwkeasoemDveS4jeS8muiiq+aOpeWPl++8jOaJgOS7pSoq5b+F6aG756e75Ye65b6F5LiK5Lyg6Zif5YiXKiog4oCU4oCUXG4gKiDlkKbliJnlroPkvJrmr4/mrKHlkIzmraXpg73ooqvph43kvKDjgIHmr4/mrKHpg73ooqvmi5LvvIzorr7lpIfmsLjov5zljaHlnKhcIuWQjOatpeWksei0pSArIOW+heS4iuS8oOaVsOS4jeWHj1wi44CCXG4gKlxuICog5L2G5a6DKirkuI3mmK/kuIrkvKDmiJDlip8qKuOAguagh+aIkCBgdXBsb2FkZWRgIOetieS6juivtFwi6L+Z5p2h5pWw5o2u5Zyo5LqR5LiKXCLvvIzogIzpgqPmmK/lgYfor53vvJpcbiAqIOW+heS4iuS8oOaVsOS8muW9kumbtu+8jOaVsOaNruWNtOWTqumDveayoeWOu++8jOeUqOaIt+WGjeS5n+ayoeacuuS8muefpemBk+Wug+S4ouS6huOAglxuICog5omA5Lul5a6D5pivKirnrKzkuInnp43nirbmgIEqKu+8muS4jeWcqOmYn+WIl+mHjO+8jOS5n+S4jeWjsOensOaIkOWKn+OAglxuICovXG5leHBvcnQgdHlwZSBVcGxvYWRTdGF0dXMgPSAncGVuZGluZycgfCAndXBsb2FkZWQnIHwgJ3JlamVjdGVkJztcblxuZXhwb3J0IGNvbnN0IFVQTE9BRF9TVEFUVVNFUzogcmVhZG9ubHkgVXBsb2FkU3RhdHVzW10gPSBbJ3BlbmRpbmcnLCAndXBsb2FkZWQnLCAncmVqZWN0ZWQnXTtcblxuLyoqXG4gKiDmiorkuIrpnaLpgqPkupvjgIzmjIflkJEgT3BlcmF0aW9uIOWGhemDqOWtl+auteOAjeeahOW4uOmHj+WcqOexu+Wei+WxgumdoumSieatu+OAglxuICpcbiAqIOi/meS4gOWPpeeahOS7t+WAvO+8muS7u+S9leWtl+auteWQjeaLvOmUmeOAgeaIluS4iua4uOaUueS6hiBgT3BlcmF0aW9uYCDnmoTlvaLnirbvvIxcbiAqIOmDveS8muWcqCBgcG5wbSAtciB0eXBlY2hlY2tgIOmYtuauteaKpemUme+8jOiAjOS4jeaYr+WPmOaIkFxuICog44CM57Si5byV6Z2Z6buY5aSx5pWIIOKGkiDljrvph43lpLHmlYgg4oaSIOaVsOaNrumHjeWkjeOAjei/meexu+e6v+S4iuS6i+aVheOAglxuICovXG50eXBlIE9wRmllbGROYW1lID0ga2V5b2YgT3BlcmF0aW9uO1xuY29uc3QgX29wRmllbGRTaGFwZSA9IHtcbiAgT1BfSUQ6IE9QX0ZJRUxEUy5PUF9JRCxcbiAgRU5USVRZX1RZUEU6IE9QX0ZJRUxEUy5FTlRJVFlfVFlQRSxcbiAgRU5USVRZX0lEOiBPUF9GSUVMRFMuRU5USVRZX0lELFxuICBFTlRJVFlfSURTOiBPUF9GSUVMRFMuRU5USVRZX0lEUyxcbiAgUEFZTE9BRDogT1BfRklFTERTLlBBWUxPQUQsXG4gIFZFQ1RPUl9DTE9DSzogT1BfRklFTERTLlZFQ1RPUl9DTE9DSyxcbiAgQ0xJRU5UX0lEOiBPUF9GSUVMRFMuQ0xJRU5UX0lELFxuICBDTElFTlRfVElNRVNUQU1QOiBPUF9GSUVMRFMuQ0xJRU5UX1RJTUVTVEFNUCxcbiAgU0NIRU1BX1ZFUlNJT046IE9QX0ZJRUxEUy5TQ0hFTUFfVkVSU0lPTixcbn0gc2F0aXNmaWVzIFJlY29yZDxzdHJpbmcsIE9wRmllbGROYW1lPjtcbnZvaWQgX29wRmllbGRTaGFwZTtcblxuLyoqIOe0ouW8leWQjeensOOAgiAqL1xuZXhwb3J0IGNvbnN0IE9QX0lOREVYRVMgPSB7XG4gIC8qKiDllK/kuIDvvJrlkIzkuIAgb3Ag5LiN5b6X5YaZ5YWl5Lik5qyh44CCICovXG4gIE9QX0lEOiAnYnlfb3BJZCcsXG4gIC8qKiDmjInlrp7kvZPmn6Xor6LvvJpbJ2VudGl0eVR5cGUnLCdlbnRpdHlJZCddIOWkjeWQiOe0ouW8leOAgiAqL1xuICBFTlRJVFk6ICdieV9lbnRpdHknLFxuICAvKiog5aSa5a6e5L2T5om55qyh77yabXVsdGlFbnRyee+8jOeUqOS6jiBHSU4g5byP5p+l6K+i55qE5a+5562J54mp44CCICovXG4gIEVOVElUWV9JRFM6ICdieV9lbnRpdHlJZHMnLFxuICAvKiog5bSp5rqD5oGi5aSN5omr5o+P77ya5om+5Ye65omA5pyJIGFwcGx5U3RhdHVzPSdwZW5kaW5nJyDnmoTorrDlvZXjgIIgKi9cbiAgUEVORElOR19BUFBMWTogJ2J5X2FwcGx5U3RhdHVzJyxcbiAgLyoqIOaMieS4iuS8oOeKtuaAgeafpeW+heWQjOatpeeahCBvcO+8iOemu+e6v+mYn+WIl++8ieOAgiAqL1xuICBQRU5ESU5HX1VQTE9BRDogJ2J5X3VwbG9hZFN0YXR1cycsXG59IGFzIGNvbnN0O1xuXG4vKiogYHN0YXRlYCBzdG9yZSDnmoTlrZfmrrXlkI3jgIIgKi9cbmV4cG9ydCBjb25zdCBTVEFURV9GSUVMRFMgPSB7XG4gIEVOVElUWV9UWVBFOiAnZW50aXR5VHlwZScsXG4gIEVOVElUWV9JRDogJ2VudGl0eUlkJyxcbiAgREFUQTogJ2RhdGEnLFxuICAvKiog5pyA5ZCO5L2c55So5LqO6K+l5a6e5L2T55qEIG9wIOeahOacrOWcsCBzZXHvvIznlKjkuo7lv6vpgJ/liKTmlq3mlrDpspzluqbjgIIgKi9cbiAgTEFTVF9TRVE6ICdsYXN0U2VxJyxcbn0gYXMgY29uc3Q7XG5cbi8qKiDlpI3lkIjkuLvplK7vvJpzdGF0ZSBzdG9yZSDnlKggW2VudGl0eVR5cGUsIGVudGl0eUlkXeOAgiAqL1xuZXhwb3J0IGNvbnN0IFNUQVRFX0tFWV9QQVRIID0gW1NUQVRFX0ZJRUxEUy5FTlRJVFlfVFlQRSwgU1RBVEVfRklFTERTLkVOVElUWV9JRF0gYXMgY29uc3Q7XG5cbi8qKiBgbWV0YWAgc3RvcmXvvJrplK7lgLzlr7njgIIgKi9cbmV4cG9ydCBjb25zdCBNRVRBX0ZJRUxEUyA9IHtcbiAgS0VZOiAna2V5JyxcbiAgVkFMVUU6ICd2YWx1ZScsXG59IGFzIGNvbnN0O1xuXG4vKipcbiAqIGBtZXRhYCBzdG9yZSDkuK3nmoTlt7Lnn6XplK7jgIJcbiAqXG4gKiDljp/lhYjov5nkuIDoioLlhpnnmoTmmK9cIui/meS6m+aYryoq5ZCM5q2l5Y2P6K6u55qE5YWz6ZSu54q25oCBKirvvIzkuI3mmK/mma7pgJrphY3nva5cIuOAgumCo+WPpeivneWIsOS7iuWkqVxuICog5bey57uP56qE5LqG5LiA5qC877yaYFBVQkxJQ19GQUNUU18qYCDkuI3mmK/lkIzmraXljY/orq7nirbmgIHvvIzlroPkuZ/kuI3mmK/nlKjmiLfphY3nva4g4oCU4oCUXG4gKiDlroPmmK8qKumDqOe9suaWueS4i+WPkeeahOWFrOWFseS6i+Wunioq55qE5pys5Zyw57yT5a2Y77yIQURSLTAwNTIgwqcyLjXvvInjgIJcbiAqXG4gKiDwn5S0IOWug+i/m+i/memHjOiAjOS4jei/myBvcC1sb2cg55qE55CG55Sx77yIQURSLTAwNTIg5Y6f5paH77yJ77ya6L+Z5p2h5LiL6KGM5LiN5pivXCLnlKjmiLfnmoTmn5DkuKrmhI/lm75cIu+8jFxuICog5YaZ6L+bIG9wLWxvZyDkvJrorqnlj6bkuIDlj7Dorr7lpIflm57mlL7lroPml7bkuqfnlJ/kuIDkuKoqKuS7juacquWPkeeUn+i/h+eahOeUqOaIt+WKqOS9nCoq77yM6L+d5Y+NXG4gKiBBR0VOVFMgwqczLjQg6YKj5p2hXCLooqvlm57mlL7nmoQgb3Ag5LiN5b6X5YaN6Kem5Y+R5Ymv5L2c55SoXCLjgILmiYDku6XlroPkuZ/kuI3ot6jorr7lpIfjgIHkuI0gYnVtcFxuICogYENVUlJFTlRfU0NIRU1BX1ZFUlNJT05g77yIQUdFTlRTIMKnMy4z77yJ44CCXG4gKlxuICog5YC855qE5b2i54q277yaYERiQWRhcHRlci5wdXQoc3RvcmUsIHZhbHVlOiB1bmtub3duLCBrZXk/KWAg5pys5p2l5bCx5ZCD5b6X5LiL5a2X56ym5Liy77yMXG4gKiBgcmVzb2x2ZUNsaWVudElkKClg77yIYHBhY2thZ2VzL2FwcC1ob3N0L3NyYy9ob3N0LnRzYO+8ieWwseaYr+W+gOi/memHjOaUvuWtl+espuS4sueahOWFiOS+i+OAglxuICovXG5leHBvcnQgY29uc3QgTUVUQV9LRVlTID0ge1xuICAvKiog5pys6K6+5aSH55qE56iz5a6aIGlk44CCTFdXIOWGsueqgeWGs+iDnOS+neaNru+8jCoq5LiA57uP55Sf5oiQ5LiN5Y+v5pu05pS5KirjgIIgKi9cbiAgQ0xJRU5UX0lEOiAnY2xpZW50SWQnLFxuICAvKiog5bey5LuO5pyN5Yqh56uv5ouJ5Y+W5Yiw55qE5pyA5aSnIHNlcnZlclNlce+8iOWQjOatpea4uOagh++8ieOAgiAqL1xuICBMQVNUX1NFUlZFUl9TRVE6ICdsYXN0U2VydmVyU2VxJyxcbiAgLyoqIOacrOWcsOacgOWkp+eahCBzZXHjgIIgKi9cbiAgTEFTVF9MT0NBTF9TRVE6ICdsYXN0TG9jYWxTZXEnLFxuICAvKiog5Yqg5a+G5piv5ZCm5ZCv55So44CCICovXG4gIEVOQ1JZUFRJT05fRU5BQkxFRDogJ2VuY3J5cHRpb25FbmFibGVkJyxcbiAgLyoqIOacgOWQjuaIkOWKn+WQjOatpeeahOaXtumXtOOAgiAqL1xuICBMQVNUX1NZTkNFRF9BVDogJ2xhc3RTeW5jZWRBdCcsXG4gIC8qKlxuICAgKiDmnI3liqHnq6/lt7Lnoa7orqTnmoTlm6DmnpzliY3msr/jgIJcbiAgICpcbiAgICog6L+Z5piv5ZCM5q2l5oGi5aSN5omA6ZyA55qE54us56uL57C/6K6w77yM5LiN6IO95aSN55SoIG1hdGVyaWFsaXplZCBjaGVja3BvaW5077yaXG4gICAqIGNoZWNrcG9pbnQg5piv5Y+v5Yig6Zmk55qE5pys5Zyw5Yqg6YCf57yT5a2Y77yM6ICM6L+Z5Liq5YmN5rK/5piv5pyN5Yqh56uv56Gu6K6k6L+H55qE5LqL5a6e44CCXG4gICAqL1xuICBPQlNFUlZFRF9DTE9DSzogJ29ic2VydmVkQ2xvY2snLFxuICAvKiog5Y6G5Y+y5pu+57uP5LiN5a6M5pW077yI5L6L5aaC5a2Y5Zyo5peg5rOV6Kej5a+G55qE6L+c56iLIG9w77yJ77yM5Y+q6IO9572uIHRydWXjgIIgKi9cbiAgSElTVE9SWV9JTkNPTVBMRVRFOiAnaGlzdG9yeUluY29tcGxldGUnLFxuICAvKiogT3BhcXVlIHdyYXBwZWQgdmF1bHQga2V5IHBhY2thZ2U7IG5ldmVyIGNvbnRhaW5zIGEgcGxhaW50ZXh0IHJvb3Qga2V5LiAqL1xuICBWQVVMVF9LRVlfUEFDS0FHRTogJ3ZhdWx0S2V5UGFja2FnZVYxJyxcbiAgLyoqIEFjY291bnQvc2VydmVyIHNjb3BlIHBhaXJlZCBhdG9taWNhbGx5IHdpdGggdGhlIG9wYXF1ZSB2YXVsdCBwYWNrYWdlLiAqL1xuICBWQVVMVF9LRVlfU0NPUEU6ICd2YXVsdEtleVNjb3BlVjEnLFxuICAvKiogQ2lwaGVydGV4dC1vbmx5IGR1cmFibGUga2V5LW1pZ3JhdGlvbiBqb3VybmFsOyBubyByb290L3BsYWludGV4dC9wYXNzd29yZC4gKi9cbiAgVkFVTFRfTUlHUkFUSU9OX0pPVVJOQUw6ICd2YXVsdE1pZ3JhdGlvbkpvdXJuYWxWMScsXG4gIC8qKiDkuIrkuIDmrKHmiJDlip/mi4nliLDnmoTlhazlhbHkuovlrp7lk43lupTkvZPvvIhgSG9saWRheUFkanVzdG1lbnRzUmVzcG9uc2VgIOeahCBKU09O77yJ44CCICovXG4gIFBVQkxJQ19GQUNUU19KU09OOiAncHVibGljRmFjdHNKc29uJyxcbiAgLyoqIOWug+WvueW6lOeahOeJiOacrOS7pOeJjO+8iOacjeWKoeerryBFVGFnIOeahOWAmemAieWAvO+8ie+8jOadoeS7tuivt+axguaXtuWOn+agt+WbnuS8oOOAgiAqL1xuICBQVUJMSUNfRkFDVFNfRVRBRzogJ3B1YmxpY0ZhY3RzRXRhZycsXG4gIC8qKiDpgqPmrKHmi4nlj5bnmoTmnKzlnLDmr6vnp5Lml7bpl7TmiLPvvIjlj6rnlKjkuo5cIue8k+WtmOWkmuaXp1wi77yM5LiN5Y+C5LiO5Lu75L2V6KOB5Yaz77yJ44CCICovXG4gIFBVQkxJQ19GQUNUU19GRVRDSEVEX0FUOiAncHVibGljRmFjdHNGZXRjaGVkQXQnLFxuICAvKiogQWN0aXZlIGVuY3J5cHRlZC1wYXlsb2FkIGdlbmVyYXRpb24gcGFpcmVkIHdpdGggdGhlIGxvY2FsIGtleSBwYWNrYWdlLiAqL1xuICBWQVVMVF9QQVlMT0FEX0tFWV9WRVJTSU9OOiAndmF1bHRQYXlsb2FkS2V5VmVyc2lvblYxJyxcbiAgLyoqIEVuY3J5cHRlZCBwZW5kaW5nIHJvb3Qtcm90YXRpb24gdGFyZ2V0OyBuZXZlciBzdG9yZXMgYSBwbGFpbnRleHQgcm9vdC4gKi9cbiAgVkFVTFRfUEVORElOR19ST09UX1JPVEFUSU9OOiAndmF1bHRQZW5kaW5nUm9vdFJvdGF0aW9uVjEnLFxuICAvKiogQWNjb3VudC1zY29wZWQgaW5ib3VuZCBhdXRvbWF0aW9uIHJlY2lwaWVudCBwcml2YXRlIGtleSB3cmFwcGVkIGJ5IHRoZSB2YXVsdCByb290LiAqL1xuICBJTkJPVU5EX1JFQ0lQSUVOVF9LRVk6ICdpbmJvdW5kUmVjaXBpZW50S2V5VjEnLFxuICAvKiogV29ya2VyIHRva2VuIGVudmVsb3BlOyB0aGUgcGxhaW50ZXh0IHRva2VuIG5ldmVyIGVudGVycyB0aGUgb3AtbG9nLiAqL1xuICBJTkJPVU5EX1dPUktFUl9DUkVERU5USUFMOiAnaW5ib3VuZFdvcmtlckNyZWRlbnRpYWxWMScsXG4gIC8qKiBFdmVudCDihpIgb3BhcXVlIGNvbW1pdCBwcm9vZiBqb3VybmFsIHVzZWQgYnkgdGhlIHVwbG9hZCBmZW5jZS4gKi9cbiAgSU5CT1VORF9DT01NSVRfSk9VUk5BTDogJ2luYm91bmRDb21taXRKb3VybmFsVjEnLFxufSBhcyBjb25zdDtcblxuZXhwb3J0IHR5cGUgTWV0YUtleSA9ICh0eXBlb2YgTUVUQV9LRVlTKVtrZXlvZiB0eXBlb2YgTUVUQV9LRVlTXTtcblxuLyoqIGBtZXRhYCDorrDlvZXlvaLnirbjgIIgKi9cbmV4cG9ydCBpbnRlcmZhY2UgTWV0YVJlY29yZDxUID0gdW5rbm93bj4ge1xuICBrZXk6IHN0cmluZztcbiAgdmFsdWU6IFQ7XG59XG4iLCIvKipcbiAqIGhleXRhIOeahOaTjeS9nOaXpeW/l+WtmOWCqOWlkee6puOAglxuICpcbiAqIOi/meS4quaOpeWPo+aYryoq5ZCM5q2l5YaF5qC45LiO5a2Y5YKo5a6e546w5LmL6Ze055qE5o6l57ydKirvvJpcbiAqIC0g5LiK5pa577yaYEBoZXl0YS9zeW5jLWNvcmVgIOeahCBgYXBwbHlSZW1vdGVPcGVyYXRpb25zYCDnrYnljY/osIPlmahcbiAqIC0g5LiL5pa577yaSW5kZXhlZERCIC8gU1FMaXRlIOetieWFt+S9k+WunueOsFxuICpcbiAqIOWugyoq57un5om/KiogYFJlbW90ZU9wZXJhdGlvbkFwcGx5U3RvcmVQb3J0YO+8iHN5bmMtY29yZSDlrprkuYnnmoTltKnmuoPlronlhajlrZjlgqjlpZHnuqbvvInvvIxcbiAqIOW5tuihpeS4iiBoZXl0YSDoh6rlt7HpnIDopoHnmoTmk43kvZzjgIJcbiAqXG4gKiDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcbiAqIOS4uuS7gOS5iOW/hemhu+WMuuWIhlwi5YaZ5YWlXCLkuI5cIuW3suW6lOeUqFwi77yI6L+Z5piv5pW05Liq6K6+6K6h55qE5YWz6ZSu77yJ77yaXG4gKlxuICogICDov5znqIsgb3Ag55qE6JC955uY5LiOXCLph43mlL7liLAgcmVkdWNlclwi5pivKirkuKTkuKrkuI3lkIzml7bliLsqKuOAguWmguaenOWPquacieS4gOadoei3r+W+hO+8jFxuICogICDlnKjkuKTogIXkuYvpl7TltKnmuoPlsLHkvJrlr7zoh7TvvJpvcCDlt7LokL3nm5jkvYbmsqHlupTnlKgg4oaSIOawuOS4jeWGjemHjeaUviDihpIgKirpnZnpu5jkuKLmlbDmja4qKuOAglxuICpcbiAqICAg5Zug5q2kIGBhcHBlbmRCYXRjaFNraXBEdXBsaWNhdGVzKC4uLiwgeyBwZW5kaW5nQXBwbHk6IHRydWUgfSlgIOWFiOWGmeWFpeW5tuaJk+agh++8jFxuICogICDlj6rmnIkgcmVkdWNlciDmj5DkuqTooqvmjIHkuYXljJblkI7miY0gYG1hcmtBcHBsaWVkYOOAguWQr+WKqOaXtuaJq+aPjyBgcGVuZGluZ0FwcGx5YFxuICogICDljbPlj6/lj5HnjrBcIuWGmeS6huS4gOWNilwi55qE5pON5L2c5bm26YeN5pS+44CCXG4gKiDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcbiAqL1xuXG5pbXBvcnQgdHlwZSB7IE9wZXJhdGlvbiwgUmVtb3RlT3BlcmF0aW9uQXBwbHlTdG9yZVBvcnQgfSBmcm9tICdAaGV5dGEvc3luYy1jb3JlJztcbmltcG9ydCB0eXBlIHsgRW50aXR5VHlwZSB9IGZyb20gJ0BoZXl0YS9zaGFyZWQtc2NoZW1hJztcbmltcG9ydCB0eXBlIHsgRGJLZXlSYW5nZSB9IGZyb20gJy4vZGIudHlwZXMnO1xuaW1wb3J0IHR5cGUgeyBBcHBseVN0YXR1cywgVXBsb2FkU3RhdHVzIH0gZnJvbSAnLi9zdG9yZXMnO1xuXG4vKiog5pON5L2c55qE5p2l5rqQ44CCICovXG5leHBvcnQgdHlwZSBPcGVyYXRpb25Tb3VyY2UgPSAnbG9jYWwnIHwgJ3JlbW90ZScgfCAnaW1wb3J0JztcblxuLyoqIOS4gOadoeaMgeS5heWMluWQjueahOaTjeS9nOiusOW9leOAgiAqL1xuZXhwb3J0IGludGVyZmFjZSBTdG9yZWRPcGVyYXRpb248VE9wZXJhdGlvbiBleHRlbmRzIE9wZXJhdGlvbjxzdHJpbmc+ID0gT3BlcmF0aW9uPiB7XG4gIC8qKiDmnKzlnLDoh6rlop7luo/lj7fvvIzkuLvplK7jgILljZXosIPjgIHml6DnqbrmtJ7jgIIgKi9cbiAgc2VxOiBudW1iZXI7XG4gIG9wOiBUT3BlcmF0aW9uO1xuICBzb3VyY2U6IE9wZXJhdGlvblNvdXJjZTtcbiAgLyoqXG4gICAqIOW6lOeUqOeKtuaAgeOAgioq5piv5a2X56ym5Liy5LiN5piv5biD5bCUKiog4oCU4oCUIEluZGV4ZWREQiDkuI3og73ntKLlvJXluIPlsJTlgLzvvIxcbiAgICog6KeBIGBzdG9yZXMudHNgIOeahCB7QGxpbmsgQXBwbHlTdGF0dXN9IOazqOmHiu+8iOi/meaYr+i4qei/h+eahOWdke+8ieOAglxuICAgKi9cbiAgYXBwbHlTdGF0dXM6IEFwcGx5U3RhdHVzO1xuICAvKiog5LiK5Lyg54q25oCB44CC6KeBIGBzdG9yZXMudHNgIOeahCB7QGxpbmsgVXBsb2FkU3RhdHVzfeOAgiAqL1xuICB1cGxvYWRTdGF0dXM6IFVwbG9hZFN0YXR1cztcbiAgLyoqXG4gICAqIOacjeWKoeerr+WIhumFjeeahOW6j+WPt++8iOWQjOatpea4uOagh+S9jee9ru+8ie+8jOS4iuS8oOaIkOWKn+WQjuaJjeacieOAglxuICAgKlxuICAgKiDimqDvuI8gKirkuI3og73loZ7ov5sgYG9wYCDph4wqKuOAgmBPcGVyYXRpb25gIOaYr+e6v+WNj+iuruexu+Wei++8jOWug+eahOWtl+auteS8muiiq+WOn+agt1xuICAgKiDlj5Hnu5nmnI3liqHnq6/vvJtgb3Auc2VxYCDkuI3lnKjlpZHnuqbph4zvvIzlhpnov5vljrvnrYnkuo7lh63nqbrpgKDkuobkuKrlub3ngbXlrZfmrrXjgIJcbiAgICog5pyN5Yqh56uv5bqP5Y+35pivKirmnKzlnLDlrZjlgqjnmoTlhYPmlbDmja4qKu+8jOWSjCBvcCDlhoXlrrnmmK/kuKTlm57kuovjgIJcbiAgICpcbiAgICog5Y+v6YCJ77yM5Zug5Li66ICB5pWw5o2u5rKh5pyJ5a6DIOKAlOKAlCDop4EgQUdFTlRTLm1kIMKnMy4z44CCXG4gICAqL1xuICBzZXJ2ZXJTZXE/OiBudW1iZXI7XG59XG5cbi8qKiBEMSBjaGVja3BvaW50IGVudmVsb3BlLiBgc3RhdGVgIGlzIHJlZHVjZXItZGVmaW5lZCBhbmQgc3RydWN0dXJlZC1jbG9uZSBzYWZlLiAqL1xuZXhwb3J0IGludGVyZmFjZSBNYXRlcmlhbGl6ZWRDaGVja3BvaW50IHtcbiAgZm9ybWF0VmVyc2lvbjogMTtcbiAgY292ZXJlZFNlcTogbnVtYmVyO1xuICBzdGF0ZTogdW5rbm93bjtcbiAgY2xvY2s6IFJlY29yZDxzdHJpbmcsIG51bWJlcj47XG4gIGFwcGxpZWRPcElkczogc3RyaW5nW107XG4gIGNoZWNrc3VtOiBzdHJpbmc7XG59XG5cbi8qKlxuICog5LiA5qyh5a+85YWl6L+95Yqg55qE57uT5p6c44CCXG4gKlxuICog5LiOIGBhcHBlbmRMb2NhbGAg5Y+q6L+U5ZueIHNlcSDkuI3lkIzvvJrlr7zlhaXlv4Xpobvog70qKuWMuuWIhlwi5YaZ6L+b5Y675LqGXCLkuI5cIuW3sue7j+WcqOS6hlwiKirjgIJcbiAqIOS4gOS7veWvvOWHuuiiq+WvvOWFpeS4pOasoeaXtu+8jOesrOS6jOasoeWFqOmDveiiq+i3s+i/hyDigJTigJQg6Iul55yL5LiN5Yiw6L+Z5Liq5beu5Yir77yMXG4gKiDosIPnlKjmlrnlj6rog73miqVcIuaIkOWKn1wi77yM6ICM55So5oi35peg5LuO55+l6YGT6L+Z5qyh54K55Ye75YW25a6e5LuA5LmI6YO95rKh5YGa44CCXG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgSW1wb3J0ZWRBcHBlbmRSZXN1bHQ8VE9wZXJhdGlvbiBleHRlbmRzIE9wZXJhdGlvbjxzdHJpbmc+ID0gT3BlcmF0aW9uPiB7XG4gIC8qKiDnnJ/mraPlhpnov5vljrvnmoQgb3DvvIjmjInkvKDlhaXpobrluo/vvInjgIIgKi9cbiAgYXBwZW5kZWQ6IFRPcGVyYXRpb25bXTtcbiAgLyoqIOWboOS4uiBgb3BJZGAg5bey5a2Y5Zyo6ICM6Lez6L+H55qEIG9w44CCICovXG4gIHNraXBwZWQ6IFRPcGVyYXRpb25bXTtcbiAgLyoqIOS4jiBgYXBwZW5kZWRgIOS4gOS4gOWvueW6lOeahCBzZXHvvIjljZXosIPpgJLlop7jgIHml6DnqbrmtJ7vvInjgIIgKi9cbiAgc2VxczogbnVtYmVyW107XG59XG5cbi8qKlxuICog5pON5L2c5pel5b+X5a2Y5YKo44CCXG4gKlxuICog5a6e546w5pa55b+F6aG75L+d6K+B77yaXG4gKiAtIGBhcHBlbmRCYXRjaFNraXBEdXBsaWNhdGVzYCAqKuWOn+WtkOS4lOW5guetiSoq77yI5ZCM5LiAIG9wSWQg6YeN5aSN5YaZ5YWl5LiN5b6X5Lqn55Sf5Lik5p2h77yJXG4gKiAtIOaJgOacieaWueazlSoq5Y+v5a6J5YWo5bm25Y+R6LCD55SoKirvvIjlubblj5HlpZHnuqbop4EgYERiQWRhcHRlcmDvvIlcbiAqIC0g5bSp5rqD5ZCO77yMYHBlbmRpbmdBcHBseWAg5qCH6K6w55qE6K6w5b2VKirlv4Xpobvku43lj6/ooqvmn6Xlh7oqKlxuICovXG5leHBvcnQgaW50ZXJmYWNlIE9wTG9nU3RvcmU8XG4gIFRPcGVyYXRpb24gZXh0ZW5kcyBPcGVyYXRpb248c3RyaW5nPiA9IE9wZXJhdGlvbixcbj4gZXh0ZW5kcyBSZW1vdGVPcGVyYXRpb25BcHBseVN0b3JlUG9ydDxUT3BlcmF0aW9uPiB7XG4gIC8vIOKUgOKUgCDmnKzlnLDlhpnlhaUg4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG5cbiAgLyoqXG4gICAqIOi/veWKoOacrOWcsOaTjeS9nOOAglxuICAgKiDov5Tlm57liIbphY3liLDnmoQgc2Vx77yI5Y2V6LCD6YCS5aKe77yJ44CCXG4gICAqL1xuICBhcHBlbmRMb2NhbChvcHM6IFRPcGVyYXRpb25bXSk6IFByb21pc2U8bnVtYmVyW10+O1xuXG4gIC8qKlxuICAgKiDov73liqAqKuWvvOWFpSoq55qE5pON5L2c77yI5LuO5LiA5Lu95a+85Ye65paH5qGj6L+Y5Y6f5pys5py65pWw5o2u77yJ44CCXG4gICAqXG4gICAqIOS4jiB7QGxpbmsgYXBwZW5kTG9jYWx9IOeahOW3ruWIq+WPquacieS4pOWkhOivreS5ie+8jOmDveW+iOmHjeimge+8mlxuICAgKlxuICAgKiAgIDEuICoqYHNvdXJjZWAg6K6w5Li6IGAnaW1wb3J0J2DjgIIqKiDov5nkuI3mmK9cIuacrOWcsOeUqOaIt+WImuWBmuS6huS7gOS5iFwi77yMXG4gICAqICAgICAg6K+B5o2u6ZO+5LiK6KaB6IO95Yy65YiGXCLov5nmnaHmmK/miJHlhpnnmoRcIuS4jlwi6L+Z5p2h5piv5LuO5LiA5Lu95paH5Lu26YeM5pCs5Zue5p2l55qEXCLjgIJcbiAgICogICAyLiAqKuS4jei/m+S4iuS8oOmYn+WIl+OAgioqIOWvvOWFpeeahCBvcCDluKbnnYAqKuWOn+adpemCo+WPsOiuvuWkhyoq55qEIGBjbGllbnRJZGDvvIxcbiAgICogICAgICDogIzmnI3liqHnq6/kvJrpgJDmnaHku6UgYElOVkFMSURfQ0xJRU5UX0lEYCDmi5Lnu50gYG9wLmNsaWVudElkYCDkuI7mnKzmnLrkuI3nrKbnmoQgb3BcbiAgICogICAgICDvvIhgc2VydmVyL3NyYy9zeW5jL3NlcnZpY2VzL3ZhbGlkYXRpb24uc2VydmljZS50c2DvvInjgILmiorlroPku6zmjpLov5vkuIrkvKDpmJ/liJdcbiAgICogICAgICDlj6rkvJrlvpfliLDkuIDmibkqKuawuOS5heaLkue7nSoq44CB5oqKXCLlvoXkuIrkvKBcIuawuOi/nOaMguWcqOmCo+mHjCDigJTigJQg6ICM5pWw5o2u5LiA5p2h5Lmf5LiK5LiN5Y6744CCXG4gICAqICAgICAg5omA5Lul5a+85YWl55qEIG9wIOS4gOW+i+iusOaIkCBgdXBsb2FkZWRg77yaKirkuI3mmK9cIuWug+S4iuS6keS6hlwi77yM5pivXCLov5nlj7Dorr7lpIfkuI3or6XjgIFcbiAgICogICAgICDkuZ/kuI3og73kuIrkvKDlroNcIioq44CC6L+Z5LiA54K55b+F6aG75Zyo55WM6Z2i5LiK5aaC5a6e6K+05piO44CCXG4gICAqXG4gICAqIOW5guetie+8muWQjOS4gCBgb3BJZGAg5bey5a2Y5Zyo5pe26Lez6L+H77yI5aSN55So5ZSv5LiA57Si5byV77yM5LiN5YGa5YWI5p+l5ZCO5YaZ77yJ44CCXG4gICAqL1xuICBhcHBlbmRJbXBvcnRlZChvcHM6IFRPcGVyYXRpb25bXSk6IFByb21pc2U8SW1wb3J0ZWRBcHBlbmRSZXN1bHQ8VE9wZXJhdGlvbj4+O1xuXG4gIC8vIOKUgOKUgCDor7vlj5Yg4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG5cbiAgLyoqIEluZGV4ZWQgbG9va3VwIGluIHRoZSBzaGFyZWQgaG90L2FyY2hpdmUgaWRlbnRpdHkgbmFtZXNwYWNlLiAqL1xuICBnZXRPcEJ5SWQob3BJZDogc3RyaW5nKTogUHJvbWlzZTxTdG9yZWRPcGVyYXRpb248VE9wZXJhdGlvbj4gfCB1bmRlZmluZWQ+O1xuXG4gIC8qKiDmjInmnKzlnLAgc2VxIOWMuumXtOivu+WPluaTjeS9nO+8iOWQq+S4i+eVjOOAgeS4jeWQq+S4iueVjO+8ieOAgiAqL1xuICBnZXRPcHNTaW5jZShcbiAgICBzaW5jZVNlcTogbnVtYmVyLFxuICAgIGxpbWl0PzogbnVtYmVyLFxuICAgIGV4Y2x1ZGVDbGllbnQ/OiBzdHJpbmcsXG4gICk6IFByb21pc2U8U3RvcmVkT3BlcmF0aW9uPFRPcGVyYXRpb24+W10+O1xuXG4gIC8qKiDor7vlj5bmn5DkuKrlrp7kvZPnmoTlhajpg6jmk43kvZzvvIzmjIkgc2VxIOWNh+W6j+OAgueUqOS6jumHjeaUvuWNleS4quWunuS9k+OAgiAqL1xuICBnZXRPcHNGb3JFbnRpdHkoXG4gICAgZW50aXR5VHlwZTogRW50aXR5VHlwZSxcbiAgICBlbnRpdHlJZDogc3RyaW5nLFxuICApOiBQcm9taXNlPFN0b3JlZE9wZXJhdGlvbjxUT3BlcmF0aW9uPltdPjtcblxuICAvKiog5pys5Zyw5bey5YiG6YWN55qE5pyA5aSnIHNlceOAgiAqL1xuICBnZXRMYXN0TG9jYWxTZXEoKTogUHJvbWlzZTxudW1iZXI+O1xuXG4gIC8qKiDlhajph4/mk43kvZzvvIjnlKjkuo7lr7zlh7rjgIHlv6vnhafvvInjgIIqKuW/hemhu+WIhumhtSoq77yM5LiN6KaB5LiA5qyh5ouJ5YWo5bqT44CCICovXG4gIGdldEFsbE9wcyhyYW5nZT86IERiS2V5UmFuZ2UsIGxpbWl0PzogbnVtYmVyKTogUHJvbWlzZTxTdG9yZWRPcGVyYXRpb248VE9wZXJhdGlvbj5bXT47XG5cbiAgLyoqXG4gICAqIOWFqOW6k+adoeaVsO+8iCoq54Ot5Yy6ICsg5b2S5qGjKirvvInvvIzkuI3nianljJbku7vkvZXkuIDooYzjgIJcbiAgICpcbiAgICog8J+UtCDkuLrku4DkuYjmjqXlj6PkuIrlv4XpobvmnInlroPvvJrlnKjmraTkuYvliY3vvIxcIuW6k+mHjOacieWkmuWwkeadoSAvIOW6k+mHjOacieayoeacieS4nOilv1wiXG4gICAqIOWPquiDvSBgZ2V0QWxsT3BzKCkubGVuZ3RoYCDigJTigJQg5oqKKirlkKvlr4bmlofmraPmlofnmoTlhajooagqKuivu+i/m+WGheWtmOWGjeaVsOS4gOS4i+OAglxuICAgKiDkuInkuKrnnJ/lrp7mtojotLnogIXpg73ku5jov5nku73pkrHvvJrlpIfku73ov5jljp/nmoTnqbrlupPlrojljavjgIHlkIzmraXmo4Dmn6XngrnnmoTliY3nva7liKTlrprjgIFcbiAgICog5Lul5Y+K55WM6Z2i5LiK55qE5b6F5LiK5Lyg5pWw44CCXG4gICAqXG4gICAqIOKaoO+4jyDlv4XpobsqKuWQq+W9kuahoyoq77ya5b2S5qGj55qE6YKj5LqbIG9wIOS7jeeEtuaYr+i/meWPsOiuvuWkh+eahOWOhuWPsuOAguWPquaVsOeDreWMuuS8muiuqVxuICAgKiDjgIzov5jljp/lj6rlhYHorrjnqbrlupPjgI3ov5nmnaHlrojljavlnKjkuIDlj7DmnInlvZLmoaPljoblj7LnmoTorr7lpIfkuIrmlL7ooYzvvIxcbiAgICog5LqO5piv6L+Y5Y6f5oqK5pWw5o2u5YaZ6L+b5LiA5LiqKirlhbblrp7kuI3nqboqKueahOW6k+OAglxuICAgKlxuICAgKiDkuI4ge0BsaW5rIGdldEFsbE9wc30g55qE6K+t5LmJ562J5Lu35oCn55Sx5aWR57qm5rWL6K+V6ZKJ5L2P77yI5ZCM5LiA5Lu95aS55YW35Lik5p2h6Lev5b+F6aG75ZCM5pWw77yJ44CCXG4gICAqL1xuICBjb3VudEFsbE9wcygpOiBQcm9taXNlPG51bWJlcj47XG5cbiAgLy8g4pSA4pSAIOW0qea6g+aBouWkjSDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcblxuICAvKipcbiAgICog5om+5Ye65omA5pyJXCLlt7LokL3nm5jkvYbmnKrlupTnlKhcIueahOaTjeS9nOOAglxuICAgKlxuICAgKiDlkK/liqjml7bosIPnlKjjgILov5Tlm57pnZ7nqbrmhI/lkbPnnYDkuIrmrKHov5DooYzlnKjlupTnlKjov4fnqIvkuK3ltKnmuoPkuobvvIxcbiAgICog5b+F6aG75YWI5oqK6L+Z5LqbIG9wIOmHjeaUvuWujO+8jCoq5YaNKirmjqXlj5fmlrDnmoTlkIzmraXjgIJcbiAgICovXG4gIGZpbmRQZW5kaW5nQXBwbHkoKTogUHJvbWlzZTxTdG9yZWRPcGVyYXRpb248VE9wZXJhdGlvbj5bXT47XG5cbiAgLyoqXG4gICAqIOOAjOacieayoeacieW3suiQveebmOacquW6lOeUqOeahCBvcOOAjeeahCoq5L6/5a6c54mI5pysKirvvIjmnaHmlbDvvIzkuI3nianljJbooYzvvInjgIJcbiAgICpcbiAgICog5qOA5p+l54K55YmN572u5Yik5a6a5Y+q6ZyA6KaB5LiA5LiqIGA+IDBg77yM6ICM5a6D5Lul5YmN5oqK5pW05p2h6Zif5YiX77yI5ZCr5a+G5paH5q2j5paH77yJ6K+76L+b5YaF5a2YXG4gICAqIOWGjeaVsOOAguivreS5ieetieS7t+aAp+eUseWlkee6pua1i+ivleS4jiB7QGxpbmsgZmluZFBlbmRpbmdBcHBseX0g5a+56LSm44CCXG4gICAqL1xuICBjb3VudFBlbmRpbmdBcHBseSgpOiBQcm9taXNlPG51bWJlcj47XG5cbiAgLyoqXG4gICAqIOW+heS4iuS8oOeahOacrOWcsCBvcO+8iOemu+e6v+mYn+WIl++8ie+8jOaMieacrOWcsCBzZXEg5Y2H5bqP44CCXG4gICAqXG4gICAqIOKaoO+4jyDkuI4ge0BsaW5rIGZpbmRQZW5kaW5nQXBwbHl9IOaYryoq5Lik5Liq5LiN5ZCM55qE6Zif5YiXKirvvIzkuI3opoHmt7fnlKjvvJpcbiAgICogICAtIHBlbmRpbmdBcHBsee+8mui/nOeoi+adpeeahOOAgeW3suiQveebmOS9hui/mOayoeW6lOeUqCDihpIg5bSp5rqD5oGi5aSN5raI6LS5XG4gICAqICAgLSBwZW5kaW5nVXBsb2Fk77ya5pys5Zyw5Lqn55Sf55qE44CB6L+Y5rKh5LiK5Lyg57uZ5pyN5Yqh56uvIOKGkiDlkIzmraXlrqLmiLfnq6/mtojotLlcbiAgICog5LiA5p2hIG9wIOWPr+iDveWQjOaXtuaYr1wi5b6F5bqU55SoXCLlkoxcIuS4jemcgOimgeS4iuS8oFwi77yI6L+c56iLIG9w77yJ77yMXG4gICAqIOS5n+WPr+iDveaYr1wi5bey5bqU55SoXCLkvYZcIuW+heS4iuS8oFwi77yI5pys5ZywIG9w77yJ44CC6L+Z5bCx5piv5Li65LuA5LmI5a6D5Lus5piv5Lik5Liq5a2X5q6144CCXG4gICAqL1xuICBmaW5kUGVuZGluZ1VwbG9hZCgpOiBQcm9taXNlPFN0b3JlZE9wZXJhdGlvbjxUT3BlcmF0aW9uPltdPjtcblxuICAvKipcbiAgICog5b6F5LiK5Lyg6Zif5YiX55qE5p2h5pWw77yI5LiN54mp5YyW6KGM77yJ4oCU4oCUIOeVjOmdouS4iumCo+S4quOAjOW+heS4iuS8oCBOIOmhueOAjeW+veagh+imgeeUqOWug+OAglxuICAgKlxuICAgKiDwn5S0IOWug+S4jiBgZW5naW5lLmdldFBlbmRpbmdVcGxvYWQoKS5sZW5ndGhgIOeahCoq562J5Lu35oCn5LiN5piv5YWN6LS555qEKirvvJpcbiAgICog5byV5pOO6YKj6L655Lya5YaNIGBmaWx0ZXIociA9PiByLnNvdXJjZSA9PT0gJ2xvY2FsJylg44CC5LmL5omA5Lul5Y+v5Lul55u05o6l5pWw57Si5byV77yMXG4gICAqIOaYr+WboOS4uiBgdXBsb2FkU3RhdHVzID09PSAncGVuZGluZydgIOWPquWcqCoq5pys5Zyw5YaZ5YWlKirpgqPkuIDlpITooqvotYvlgLxcbiAgICog77yIYGRiLW9wLWxvZy1zdG9yZS50c2Ag6YeMIGBzb3VyY2UgPT09ICdsb2NhbCcgPyAncGVuZGluZycgOiAndXBsb2FkZWQnYO+8ieOAglxuICAgKiDpgqPmnaHkuI3lj5jph4/nlLHmnKzljIXnmoTlpZHnuqbmtYvor5XpkonkvY8g4oCU4oCUIOiwgeWTquWkqeiuqei/nOerryBvcCDkuZ/ov5sgcGVuZGluZ++8jFxuICAgKiDov5nkuKrorqHmlbDlsLHkvJrlvIDlp4vlpJrmiqXvvIzogIzpgqPmraPmmK9cIuW+veagh+ivtOiwjlwi55qE5b2i54q244CCXG4gICAqL1xuICBjb3VudFBlbmRpbmdVcGxvYWQoKTogUHJvbWlzZTxudW1iZXI+O1xuXG4gIC8qKiDmoIforrAgb3Ag5bey5LiK5Lyg77yM5bm25Zue5YaZ5pyN5Yqh56uv5YiG6YWN55qEIHNlceOAgui/lOWbnuabtOaWsOadoeaVsOOAgiAqL1xuICBtYXJrVXBsb2FkZWQoc2VydmVyU2Vxc0J5T3BJZDogUmVhZG9ubHlNYXA8c3RyaW5nLCBudW1iZXI+KTogUHJvbWlzZTxudW1iZXI+O1xuXG4gIC8qKlxuICAgKiDkuKLlvIPlvoXkuIrkvKDnmoTmnKzlnLAgb3DvvIjmiorlroPnp7vlh7rkuIrkvKDpmJ/liJfvvIzkvYYqKuS4jeWIoOmZpCoq77yJ44CCXG4gICAqXG4gICAqIOeUqOS6juWGsueqgeino+WGs+WIpOWumuS4ulwi6L+c56uv6IOc5Ye6XCLml7bvvJrmnKzlnLDov5nmnaHkuI3or6Xlho3kuIrkvKDvvIxcbiAgICog5L2GIG9wLWxvZyDmmK/kuovlrp7mnaXmupDvvIwqKuS4jeiDveeJqeeQhuWIoOmZpCoqIOKAlOKAlCDliKDkuoblsLHml6Dms5Xop6Pph4pcbiAgICogXCLkuLrku4DkuYjmnKzlnLDmm77nu4/mmK/ov5nkuKrlgLxcIu+8jOmHjeaUvuS5n+S8muS4juWFtuWug+iuvuWkh+S4jeS4gOiHtOOAglxuICAgKi9cbiAgZGlzY2FyZFBlbmRpbmdVcGxvYWQob3BJZHM6IHN0cmluZ1tdKTogUHJvbWlzZTxudW1iZXI+O1xuXG4gIC8qKlxuICAgKiDmiorjgIzmnI3liqHnq68qKuawuOS5heaLkue7nSoq44CN55qEIG9wIOenu+WHuuS4iuS8oOmYn+WIl++8iCoq5LiN5Yig6ZmkKiogb3DvvInjgIJcbiAgICpcbiAgICog5LiOIHtAbGluayBkaXNjYXJkUGVuZGluZ1VwbG9hZH0g55qE5Yy65Yir5Y+q5ZyoKiror63kuYnkuI7lj6/op4LmtYvmgKcqKuS4iu+8mlxuICAgKiBgZGlzY2FyZFBlbmRpbmdVcGxvYWRgIOeUqOS6jlwi5oiR5Lus5Li75Yqo5Yaz5a6a5LiN5YaN5LiK5Lyg6L+Z5p2hXCLvvIjlhrLnqoHph4zpgInkuobkv53nlZnov5znq6/vvInvvIxcbiAgICog6YKj56Gu5a6e562J5ZCM5LqOXCLmnKzmnLrlr7nov5nmnaHlt7Lnu4/msqHmnInmnKrlrozmiJDnmoTkuIrkvKDmhI/lm75cIu+8m1xuICAgKiDogIzov5nph4zorrDnmoTmmK8qKuacjeWKoeerr+ivtOWug+awuOi/nOS4jeS8muaOpeWPl+i/meadoSoqIOKAlOKAlCDmlbDmja7msqHkuIrkupHjgIJcbiAgICpcbiAgICog8J+UtCDkuLrku4DkuYjlv4XpobvlnKjlrZjlgqjlsYLljLrliIbvvIzogIzkuI3mmK/lpI3nlKjkuIDkuKogYCd1cGxvYWRlZCdg77yaXG4gICAqICAgMS4g55WM6Z2i5LiK55qEXCLlvoXkuIrkvKDmlbBcIuS4jlwi5bey5ZCM5q2lXCLkvJrlm6DmraTor7TlgYfor53vvJtcbiAgICogICAyLiDov5nmnaHnvLrpmbfnmoQqKuWIpOaNrioq6KaB6IO96KeC5a+f5Yiw5a6DIOKAlOKAlCDlpoLmnpzmi5Lnu53mgIHlkozmiJDlip/mgIHplb/lvpfkuIDmoLfvvIxcbiAgICogICAgICDpqozmlLbohJrmnKzlsLHlj6rog73mlq3oqIBcIumYn+WIl+epuuS6hlwi77yM6ICMXCLpmJ/liJfnqbrkuoZcIuWcqCoq5pWw5o2u6KKr6Z2Z6buY5Lii5byDKirml7blkIzmoLfmiJDnq4vjgIJcbiAgICpcbiAgICog5Li65LuA5LmI5LiN6IO95bmy6ISG6YeN6K+V5Yiw5bqV77yI5YOP5Y6f5p2l6YKj5qC35oqb6ZSZ77yJ77ya6YKj5Lya6K6p6K6+5aSHKirmsLjkuYXljaHmrbsqKiDigJTigJQg5q+P5qyh5ZCM5q2lXG4gICAqIOmDvemHjeS8oOi/meadoeOAgeavj+asoemDveiiq+aLku+8jOiAjOaKm+mUmeWPkeeUn+WcqOS4i+i9veS5i+WJje+8jOS6juaYryoq6L+Z5Y+w6K6+5aSH5YaN5Lmf5ouJ5LiN5Yiw5Lu75L2V5pWw5o2uKirjgIJcbiAgICovXG4gIG1hcmtSZWplY3RlZChvcElkczogc3RyaW5nW10pOiBQcm9taXNlPG51bWJlcj47XG5cbiAgLy8g4pSA4pSAIOWOi+e8qSAvIOW9kuahoyDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcblxuICAvKipcbiAgICog5oqKIGB1cFRvU2VxYCDkuYvliY3nmoTmk43kvZznp7vlhaXlvZLmoaMgc3RvcmXjgIJcbiAgICpcbiAgICog5YmN5o+Q77ya6L+Z5LqbIG9wIOeahOaViOaenOW3sue7j+iiq+W/q+eFp+aIliBzdGF0ZSDlrozmlbTmjZXojrfjgIJcbiAgICog6L+U5Zue6KKr5b2S5qGj55qE5p2h5pWw44CCXG4gICAqL1xuICBhcmNoaXZlVXBUbyh1cFRvU2VxOiBudW1iZXIpOiBQcm9taXNlPG51bWJlcj47XG5cbiAgLy8g4pSA4pSAIOewv+iusCDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcblxuICAvKiog6K+75Y+W5ZCM5q2l5ri45qCH77yI5bey5ouJ5Y+W5Yiw55qE5pyA5aSnIHNlcnZlclNlce+8ieOAgiAqL1xuICBnZXRMYXN0U2VydmVyU2VxKCk6IFByb21pc2U8bnVtYmVyPjtcblxuICAvKiog5YaZ5YWl5ZCM5q2l5ri45qCH44CCICovXG4gIHNldExhc3RTZXJ2ZXJTZXEoc2VxOiBudW1iZXIpOiBQcm9taXNlPHZvaWQ+O1xuXG4gIC8qKiBPcHRpb25hbCBtYXRlcmlhbGl6ZWQtc3RhdGUgY2hlY2twb2ludCBob29rcyAob2xkZXIgaG9zdHMgbWF5IG9taXQgdGhlbSkuICovXG4gIHJlYWRDaGVja3BvaW50PygpOiBQcm9taXNlPE1hdGVyaWFsaXplZENoZWNrcG9pbnQgfCB1bmRlZmluZWQ+O1xuICB3cml0ZUNoZWNrcG9pbnQ/KGNoZWNrcG9pbnQ6IE1hdGVyaWFsaXplZENoZWNrcG9pbnQpOiBQcm9taXNlPHZvaWQ+O1xuXG4gIC8qKlxuICAgKiBSZWFkIHRoZSBkdXJhYmxlIHNlcnZlci1vYnNlcnZlZCBjYXVzYWwgZnJvbnRpZXIuXG4gICAqXG4gICAqIFRoaXMgaXMgZGVsaWJlcmF0ZWx5IHNlcGFyYXRlIGZyb20gdGhlIGRlbGV0YWJsZSBtYXRlcmlhbGl6ZWQgY2hlY2twb2ludC5cbiAgICogT2xkZXIgc3RvcmFnZSBob3N0cyBtYXkgb21pdCB0aGUgb3B0aW9uYWwgaG9vazsgaW1wbGVtZW50YXRpb25zIHRoYXQgZXhwb3NlXG4gICAqIGl0IG11c3QgcmV0dXJuIGFuIGVtcHR5IGNsb2NrIHdoZW4gbm8gZnJvbnRpZXIgaGFzIGJlZW4gcmVjb3JkZWQuXG4gICAqL1xuICByZWFkT2JzZXJ2ZWRDbG9jaz8oKTogUHJvbWlzZTxSZWNvcmQ8c3RyaW5nLCBudW1iZXI+PjtcblxuICAvKiogTWVyZ2UgYSBzZXJ2ZXItb2JzZXJ2ZWQgY2F1c2FsIGZyb250aWVyIHVzaW5nIGNvbXBvbmVudC13aXNlIG1heC4gKi9cbiAgbWVyZ2VPYnNlcnZlZENsb2NrPyhjbG9jazogUmVjb3JkPHN0cmluZywgbnVtYmVyPik6IFByb21pc2U8dm9pZD47XG5cbiAgLyoqIFJlYWQgdGhlIGR1cmFibGUgb25lLXdheSBtYXJrZXIgdGhhdCBzb21lIGhpc3RvcnkgY291bGQgbm90IGJlIHJlY292ZXJlZC4gKi9cbiAgaGFzSW5jb21wbGV0ZUhpc3Rvcnk/KCk6IFByb21pc2U8Ym9vbGVhbj47XG5cbiAgLyoqIFBlcm1hbmVudGx5IG1hcmsgaGlzdG9yeSBhcyBpbmNvbXBsZXRlOyB0aGVyZSBpcyBpbnRlbnRpb25hbGx5IG5vIGNsZWFyIGhvb2suICovXG4gIG1hcmtIaXN0b3J5SW5jb21wbGV0ZT8oKTogUHJvbWlzZTx2b2lkPjtcbiAgLyoqXG4gICAqIOivuyBgU1RPUkVTLk1FVEFgIOmHjOeahOS4gOS4qumUru+8iOWOn+agt+i/lOWbnuWtmOeahOWAvO+8ieOAglxuICAgKlxuICAgKiDwn5S0IOS4uuS7gOS5iOaKiiBNRVRBIOeahOmAmueUqOivu+azleW8gOWcqCoq6L+Z5Liq5o6l5Y+jKirkuIrvvIzogIzkuI3mmK/orqnosIPnlKjmlrnoh6rlt7Hmi78gYERiQWRhcHRlcmDvvJpcbiAgICogICB3ZWIg55qE6buY6K6k5a2Y5YKo6Lev5b6E5pivICoqV29ya2VyICsgT1BGUyBTUUxpdGUqKu+8jOahjOmdouWjs+mCo+adoeaYryoq5aOz6YeM55qEIFNRTGl0ZSoqIOKAlOKAlFxuICAgKiAgIOi/meS4pOadoei3r+S4iioq6aG15L6n5qC55pys5rKh5pyJIGBEYkFkYXB0ZXJgKirvvIzlj6rmnInkuIDkuKogYE9wTG9nU3RvcmVgIOS7o+eQhuOAglxuICAgKiAgIOWmguaenOi/meS4quiDveWKm+WPquWtmOWcqOS6jiBgRGJBZGFwdGVyYO+8jFwi5YWs5YWx5LqL5a6e57yT5a2Y5ZyoIHdlYiDkuIrog73nlKhcIuWwseS8mioq6Z2Z6buY5Zyw5YGHKipcbiAgICogICDvvIhBRFItMDA1MiDCpzIuNSDngrnlkI3opoHov5sgYFNUT1JFUy5NRVRBYO+8jOiAjOS4ieadoeWQjuerr+i3r+W+hOmDveW+l+i/m+W+l+S6hu+8ieOAglxuICAgKiAgIOW8gOWcqOaOpeWPo+S4iuS5i+WQju+8jOahpeS4iueahOi9rOWPkeWIl+ihqOaYryoq5pi+5byP5YiX5Ye655qEKirvvIjop4EgYG9wbG9nLXdvcmtlci1icmlkZ2UudHNgIOmCo+adoVxuICAgKiAgIFwi5LiN55SoIFByb3h5XCLnmoTnkIbnlLHvvInvvIzmvI/ovazlj5HkvJrlnKgqKuesrOS4gOasoeiwg+eUqOaXtuWTjeS6ruaKpemUmSoq77yM5LiN5piv6L+U5Zue56m65YC844CCXG4gICAqXG4gICAqIOmUruWQjeWPquWcqCBgTUVUQV9LRVlTYCDlrprkuYnkuIDmrKHvvJvov5nph4zkuI3orqTor4blhbfkvZPplK7vvIzpgb/lhY3mioror63kuYnlpI3liLbov5vlrZjlgqjlsYLjgIJcbiAgICovXG4gIGdldE1ldGFWYWx1ZShrZXk6IHN0cmluZyk6IFByb21pc2U8c3RyaW5nIHwgbnVtYmVyIHwgdW5kZWZpbmVkPjtcblxuICAvKiog5YaZIGBTVE9SRVMuTUVUQWAg6YeM55qE5LiA5Liq6ZSu44CC5YC85Y+q5YWB6K64IGBzdHJpbmcgfCBudW1iZXJg77yI6KaB6L+H57uT5p6E5YyW5YWL6ZqG77yJ44CCICovXG4gIHNldE1ldGFWYWx1ZShrZXk6IHN0cmluZywgdmFsdWU6IHN0cmluZyB8IG51bWJlcik6IFByb21pc2U8dm9pZD47XG59XG5cbi8qKiDlrZjlgqjlsYLnmoTlpLHotKXljp/lm6DvvIzkvpvkuIrlsYLljLrliIblpITnkIbjgIIgKi9cbmV4cG9ydCBlbnVtIE9wTG9nU3RvcmVFcnJvckNvZGUge1xuICAvKiog5ZCM5LiAIG9wSWQg6KKr5YaZ5YWl5LqG5Lik5qyh77yI6LCD55So5pa5IGJ1ZyDmiJbmgbbmhI/ovpPlhaXvvInjgIIgKi9cbiAgRFVQTElDQVRFX09QX0lEID0gJ0RVUExJQ0FURV9PUF9JRCcsXG4gIC8qKiBzZXEg5Ye6546w56m65rSeIOKAlOKAlCDor7TmmI7lj5HnlJ/kuobpnZ7ljp/lrZDlhpnlhaXmiJbmlbDmja7mjZ/lnY/jgIIgKi9cbiAgU0VRX0dBUCA9ICdTRVFfR0FQJyxcbiAgLyoqIOS6i+WKoeW1jOWll+iwg+eUqOOAgiAqL1xuICBORVNURURfVFJBTlNBQ1RJT04gPSAnTkVTVEVEX1RSQU5TQUNUSU9OJyxcbiAgLyoqIOWtmOWCqOS4jeWPr+eUqO+8iOmFjemineiAl+WwveOAgeiiq+a1j+iniOWZqOWbnuaUtuetie+8ieOAgiAqL1xuICBTVE9SQUdFX1VOQVZBSUxBQkxFID0gJ1NUT1JBR0VfVU5BVkFJTEFCTEUnLFxuICAvKiog5b2S5qGj6L6555WM5rKh5pyJ6KKr5LiA5Liq5a6M5pW044CB5Y+v5qCh6aqM55qE54mp5YyW5qOA5p+l54K56KaG55uW44CCICovXG4gIEFSQ0hJVkVfUkVRVUlSRVNfQ0hFQ0tQT0lOVCA9ICdBUkNISVZFX1JFUVVJUkVTX0NIRUNLUE9JTlQnLFxufVxuXG5leHBvcnQgY2xhc3MgT3BMb2dTdG9yZUVycm9yIGV4dGVuZHMgRXJyb3Ige1xuICBjb25zdHJ1Y3RvcihcbiAgICBwdWJsaWMgcmVhZG9ubHkgY29kZTogT3BMb2dTdG9yZUVycm9yQ29kZSxcbiAgICBtZXNzYWdlOiBzdHJpbmcsXG4gICkge1xuICAgIHN1cGVyKG1lc3NhZ2UpO1xuICAgIHRoaXMubmFtZSA9ICdPcExvZ1N0b3JlRXJyb3InO1xuICB9XG59XG4iLCJpbXBvcnQgdHlwZSB7IE1hdGVyaWFsaXplZENoZWNrcG9pbnQgfSBmcm9tICcuL29wLWxvZy1zdG9yZS5qcyc7XG5cbi8qKlxuICogRGV0ZXJtaW5pc3RpYyBpbnRlZ3JpdHkgdGFnIGZvciBhIG1hdGVyaWFsaXplZCBjaGVja3BvaW50LlxuICpcbiAqIFRoaXMgaW50ZW50aW9uYWxseSBpcyBub3QgYSBjcnlwdG9ncmFwaGljIE1BQzogdGhlIGNoZWNrcG9pbnQgaXMgYSBsb2NhbFxuICogYWNjZWxlcmF0aW9uIGNhY2hlLCB3aGlsZSB0aGUgb3AtbG9nIHJlbWFpbnMgdGhlIHNvdXJjZSBvZiB0cnV0aC4gIEl0IGlzXG4gKiBvbmx5IG1lYW50IHRvIGRldGVjdCB0b3JuIHdyaXRlcywgdHJ1bmNhdGlvbiwgYW5kIGluY29tcGF0aWJsZSBwYXlsb2Fkc1xuICogYmVmb3JlIGEgY2FsbGVyIHVzZXMgdGhlIGNoZWNrcG9pbnQgYXMgYSByZXBsYXkgYm91bmRhcnkuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBjaGVja3BvaW50Q2hlY2tzdW0oXG4gIGNoZWNrcG9pbnQ6IE9taXQ8TWF0ZXJpYWxpemVkQ2hlY2twb2ludCwgJ2NoZWNrc3VtJz4sXG4pOiBzdHJpbmcge1xuICBjb25zdCBpbnB1dCA9IEpTT04uc3RyaW5naWZ5KGNoZWNrcG9pbnQpO1xuICBsZXQgaGFzaCA9IDB4ODExYzlkYzU7XG4gIGZvciAobGV0IGluZGV4ID0gMDsgaW5kZXggPCBpbnB1dC5sZW5ndGg7IGluZGV4ICs9IDEpIHtcbiAgICBoYXNoIF49IGlucHV0LmNoYXJDb2RlQXQoaW5kZXgpO1xuICAgIGhhc2ggPSBNYXRoLmltdWwoaGFzaCwgMHgwMTAwMDE5Myk7XG4gIH1cbiAgcmV0dXJuIChoYXNoID4+PiAwKS50b1N0cmluZygxNikucGFkU3RhcnQoOCwgJzAnKTtcbn1cblxuLyoqIFN0cnVjdHVyYWwgYW5kIGNoZWNrc3VtIHZhbGlkYXRpb24gc2hhcmVkIGJ5IHJlY292ZXJ5IGFuZCBhcmNoaXZpbmcuICovXG5leHBvcnQgZnVuY3Rpb24gaXNWYWxpZENoZWNrcG9pbnQoXG4gIGNoZWNrcG9pbnQ6IHVua25vd24sXG4gIGxhc3RMb2NhbFNlcTogbnVtYmVyLFxuKTogY2hlY2twb2ludCBpcyBNYXRlcmlhbGl6ZWRDaGVja3BvaW50IHtcbiAgaWYgKCFjaGVja3BvaW50IHx8IHR5cGVvZiBjaGVja3BvaW50ICE9PSAnb2JqZWN0JyB8fCBBcnJheS5pc0FycmF5KGNoZWNrcG9pbnQpKSByZXR1cm4gZmFsc2U7XG4gIGNvbnN0IGNhbmRpZGF0ZSA9IGNoZWNrcG9pbnQgYXMgTWF0ZXJpYWxpemVkQ2hlY2twb2ludDtcbiAgaWYgKGNhbmRpZGF0ZS5mb3JtYXRWZXJzaW9uICE9PSAxKSByZXR1cm4gZmFsc2U7XG4gIGlmICghTnVtYmVyLmlzSW50ZWdlcihjYW5kaWRhdGUuY292ZXJlZFNlcSkgfHwgY2FuZGlkYXRlLmNvdmVyZWRTZXEgPCAwKSByZXR1cm4gZmFsc2U7XG4gIGlmIChjYW5kaWRhdGUuY292ZXJlZFNlcSA+IGxhc3RMb2NhbFNlcSkgcmV0dXJuIGZhbHNlO1xuICBpZiAoY2FuZGlkYXRlLnN0YXRlID09PSB1bmRlZmluZWQgfHwgY2FuZGlkYXRlLnN0YXRlID09PSBudWxsKSByZXR1cm4gZmFsc2U7XG4gIGlmIChjYW5kaWRhdGUuY2xvY2sgPT09IG51bGwgfHwgdHlwZW9mIGNhbmRpZGF0ZS5jbG9jayAhPT0gJ29iamVjdCcpIHJldHVybiBmYWxzZTtcbiAgaWYgKEFycmF5LmlzQXJyYXkoY2FuZGlkYXRlLmNsb2NrKSB8fCBPYmplY3QudmFsdWVzKGNhbmRpZGF0ZS5jbG9jaykuc29tZShcbiAgICAoY291bnRlcikgPT4gIU51bWJlci5pc1NhZmVJbnRlZ2VyKGNvdW50ZXIpIHx8IGNvdW50ZXIgPCAwKSkgcmV0dXJuIGZhbHNlO1xuICBpZiAoIUFycmF5LmlzQXJyYXkoY2FuZGlkYXRlLmFwcGxpZWRPcElkcykgfHwgY2FuZGlkYXRlLmFwcGxpZWRPcElkcy5zb21lKChpZCkgPT4gdHlwZW9mIGlkICE9PSAnc3RyaW5nJykpIHJldHVybiBmYWxzZTtcbiAgaWYgKHR5cGVvZiBjYW5kaWRhdGUuY2hlY2tzdW0gIT09ICdzdHJpbmcnIHx8IGNhbmRpZGF0ZS5jaGVja3N1bS5sZW5ndGggPT09IDApIHJldHVybiBmYWxzZTtcblxuICBjb25zdCB7IGNoZWNrc3VtLCAuLi5iYXNlIH0gPSBjYW5kaWRhdGU7XG4gIHJldHVybiBjaGVja3N1bSA9PT0gY2hlY2twb2ludENoZWNrc3VtKGJhc2UpO1xufVxuIiwiLyoqXG4gKiBJbmRleGVkREIg6YCC6YWN5ZmoXG4gKiA9PT09PT09PT09PT09PT09PT1cbiAqXG4gKiDlrp7njrAge0BsaW5rIERiQWRhcHRlcn3jgIJXZWIg56uv55qE55Sf5Lqn5a2Y5YKo44CCXG4gKlxuICog4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG4gKiDkuInkuKrlv4XpobvlpITnkIblr7nnmoQgSW5kZXhlZERCIOmZt+mYse+8iOmDvei4qei/hyAvIOmDveaYr+ecn+WunuaVhemanOW9oueKtu+8ie+8mlxuICpcbiAqIDEuICoq5LqL5Yqh5Lya5ZyoXCLmsqHmnInlvoXlpITnkIbor7fmsYJcIuaXtuiHquWKqOaPkOS6pOOAgioqXG4gKiAgICDkuIDml6YgYXdhaXQg5LqG5LiA5Liq6Z2eIElEQiDnmoQgcHJvbWlzZe+8iOavlOWmgiBmZXRjaOOAgXNldFRpbWVvdXTvvInvvIxcbiAqICAgIOS6i+WKoeWwseWFs+mXreS6hu+8jOWQjue7reaTjeS9nOaKpSBgVHJhbnNhY3Rpb25JbmFjdGl2ZUVycm9yYOOAglxuICogICAg6L+Z5pivIEluZGV4ZWREQiDmnIDpmr7mn6XnmoTplJnor6/kuYvkuIDvvIzlm6DkuLrlroPlnKjnroDljZXmtYvor5Xph4zkuI3kvJrlh7rnjrDjgIJcbiAqICAgIOKGkiDmnKzpgILphY3lmagqKuS4jSBhd2FpdCDku7vkvZXlpJbpg6ggcHJvbWlzZSoq77yM5omA5pyJ6K+35rGC5o6S5Zyo5ZCM5LiA5om56YeM44CCXG4gKlxuICogMi4gKipgdHJhbnNhY3Rpb24ub25jb21wbGV0ZWAg5omN5piv5o+Q5Lqk54K577yM5LiN5piv5pyA5ZCO5LiA5LiqIHJlcXVlc3Qub25zdWNjZXNz44CCKipcbiAqICAgIOWcqCBvbnN1Y2Nlc3Mg6YeM5bCxIHJlc29sdmUg5Lya6K6p6LCD55So5pa55Lul5Li65bey5o+Q5Lqk77yM5a6e6ZmF5Y+v6IO96KKr5Zue5rua44CCXG4gKiAgICDihpIg5Y+q5ZyoIGBvbmNvbXBsZXRlYCByZXNvbHZl77yMYG9uYWJvcnRgL2BvbmVycm9yYCByZWplY3TjgIJcbiAqXG4gKiAzLiAqKmBhZGQoKWAg5Li76ZSu5Yay56qB5pivIGBDb25zdHJhaW50RXJyb3Jg77yM5LiN5pivXCLlt7LlrZjlnKhcIuOAgioqXG4gKiAgICDljrvph43pgLvovpHlv4XpobvpnaDllK/kuIDntKLlvJUgKyDplJnor6/noIHvvIzkuI3og73pnaDlhYjmn6XlkI7lhplcbiAqICAgIO+8iOmCo+aciSBUT0NUT1Ug56ue5oCB77ya5Lik5Liq5bm25Y+R5YaZ5YWl6YO96IO95p+l5YiwXCLkuI3lrZjlnKhcIu+8ieOAglxuICog4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG4gKi9cblxuaW1wb3J0IHR5cGUge1xuICBEYkFkYXB0ZXIsXG4gIERiQ3Vyc29yQWN0aW9uLFxuICBEYkN1cnNvclZpc2l0b3IsXG4gIERiRGVzdHJveVJlcG9ydCxcbiAgRGJJbmRleFF1ZXJ5LFxuICBEYkl0ZXJhdGVPcHRpb25zLFxuICBEYktleSxcbiAgRGJLZXlSYW5nZSxcbiAgRGJUeCxcbiAgRGJUeE1vZGUsXG4gIERiVG9sZXJhbnRBZGRSZXN1bHQsXG4gIFN0b3JlU2NoZW1hLFxufSBmcm9tICcuLi9kYi50eXBlcy5qcyc7XG5pbXBvcnQgeyBhc3NlcnRJdGVyYXRlTGltaXQgfSBmcm9tICcuLi9kYi50eXBlcy5qcyc7XG5pbXBvcnQgeyBBZGFwdGVyRGVzdHJveWVkRXJyb3IsIFN0b3JhZ2VFcnJvciwgYXNTdG9yYWdlRXJyb3IsIHN0b3JhZ2VFcnJvciB9IGZyb20gJy4uL2Vycm9ycy5qcyc7XG5pbXBvcnQge1xuICBBTExfU1RPUkVTLFxuICBPUF9GSUVMRFMsXG4gIE9QX0lOREVYRVMsXG4gIFNUT1JFUyxcbiAgdHlwZSBTdG9yZU5hbWUsXG59IGZyb20gJy4uL3N0b3Jlcy5qcyc7XG5cbi8qKiDlu7rlupPmiYDpnIDnmoQgc3RvcmUg5LiO57Si5byV5a6a5LmJ44CC5oyB5LmF5YyW57uT5p6E77yM5pS55Yqo6KaB6LCo5oWO77yI6KeBIHN0b3Jlcy50c++8ieOAgiAqL1xuLy8gYFN0b3JlU2NoZW1hYCDlt7Lmj5DliLAgYGRiLnR5cGVzLnRzYCDigJTigJQg5a6D5b+F6aG75Zyo5a6e546w5LmL6Ze05YWx5Lqr44CCXG4vLyDov5nph4zph43mlrDlr7zlh7rvvIzkv53mjIHml6LmnIkgaW1wb3J0IOi3r+W+hOWPr+eUqOOAglxuXG5leHBvcnQgdHlwZSB7IFN0b3JlU2NoZW1hIH07XG5cbmV4cG9ydCAvKipcbiAqIEluZGV4ZWREQiBzY2hlbWEg54mI5pys44CCXG4gKlxuICog4pqg77iPICoq5Yqg57Si5byVL+WKoCBzdG9yZSDlv4XpobsgYnVtcCDov5nkuKrlgLzjgIIqKlxuICog5bey5pyJ5pWw5o2u5bqT5LiN5Lya5Zug5Li65Luj56CB5Y+Y5LqG5bCx6YeN5bu6IOKAlOKAlCBgb251cGdyYWRlbmVlZGVkYCDlj6rlnKhcbiAqIOivt+axgueahOeJiOacrCoq6auY5LqOKirno4Hnm5jkuIrnmoTniYjmnKzml7bop6blj5HjgILkuI0gYnVtcCDnmoTor53mlrDntKLlvJXmsLjov5zkuI3kvJpcbiAqIOiiq+WIm+W7uu+8jOiAjOWfuuS6juWug+eahOafpeivouS8mioq6Z2Z6buY6L+U5Zue56m6KirvvIjlkIwgYXBwbHlTdGF0dXMg6YKj57G75Z2R77yJ44CCXG4gKlxuICogdjLvvJrmlrDlop4gYGJ5X3VwbG9hZFN0YXR1c2Ag57Si5byV77yI56a757q/5LiK5Lyg6Zif5YiX77yJ44CCXG4gKi9cbmNvbnN0IERCX1NDSEVNQV9WRVJTSU9OID0gMjtcblxuZXhwb3J0IGNvbnN0IElOREVYRUREQl9TQ0hFTUE6IFN0b3JlU2NoZW1hW10gPSBbXG4gIHtcbiAgICBuYW1lOiBTVE9SRVMuT1BTLFxuICAgIGtleVBhdGg6IE9QX0ZJRUxEUy5TRVEsXG4gICAgYXV0b0luY3JlbWVudDogdHJ1ZSxcbiAgICBpbmRleGVzOiBbXG4gICAgICAvLyDimqDvuI8ga2V5UGF0aCDlv4XpobvmjIflkJEgYG9wLipg44CC5a2Y6L+b5Y6755qE6K6w5b2V5b2i54q25pivIHsgb3AsIHNvdXJjZSwgYXBwbHlTdGF0dXMgfe+8jFxuICAgICAgLy8gb3Ag55qE5Lia5Yqh5a2X5q615pivKirltYzlpZcqKueahOOAguaIkeesrOS4gOeJiOaKiiBrZXlQYXRoIOWGmeaIkOmhtuWxgiBgZW50aXR5VHlwZWDvvIxcbiAgICAgIC8vIOS6juaYr+e0ouW8leWFqOmDqOWRveS4reS4jeWIsOS7u+S9leiusOW9lSDigJTigJQg5LiN5oql6ZSZ77yM5Y+q5piv5p+l6K+i5oGS6L+U5Zue56m644CCXG4gICAgICB7IG5hbWU6IE9QX0lOREVYRVMuT1BfSUQsIGtleVBhdGg6IGBvcC4ke09QX0ZJRUxEUy5PUF9JRH1gLCB1bmlxdWU6IHRydWUgfSxcbiAgICAgIHsgbmFtZTogT1BfSU5ERVhFUy5QRU5ESU5HX1VQTE9BRCwga2V5UGF0aDogT1BfRklFTERTLlVQTE9BRF9TVEFUVVMgfSxcbiAgICAgIHtcbiAgICAgICAgbmFtZTogT1BfSU5ERVhFUy5FTlRJVFksXG4gICAgICAgIGtleVBhdGg6IFtgb3AuJHtPUF9GSUVMRFMuRU5USVRZX1RZUEV9YCwgYG9wLiR7T1BfRklFTERTLkVOVElUWV9JRH1gXSxcbiAgICAgIH0sXG4gICAgICB7XG4gICAgICAgIG5hbWU6IE9QX0lOREVYRVMuRU5USVRZX0lEUyxcbiAgICAgICAga2V5UGF0aDogYG9wLiR7T1BfRklFTERTLkVOVElUWV9JRFN9YCxcbiAgICAgICAgbXVsdGlFbnRyeTogdHJ1ZSxcbiAgICAgIH0sXG4gICAgICAvLyBhcHBseVN0YXR1cyDmmK8qKuWtl+espuS4sioq77yI5LiN5piv5biD5bCU77yJ4oCU4oCUIOW4g+WwlOS4jeiDveS9nOS4uiBJREIg6ZSuXG4gICAgICB7IG5hbWU6IE9QX0lOREVYRVMuUEVORElOR19BUFBMWSwga2V5UGF0aDogT1BfRklFTERTLkFQUExZX1NUQVRVUyB9LFxuICAgIF0sXG4gIH0sXG4gIHtcbiAgICBuYW1lOiBTVE9SRVMuU1RBVEUsXG4gICAga2V5UGF0aDogWydlbnRpdHlUeXBlJywgJ2VudGl0eUlkJ10sXG4gIH0sXG4gIHtcbiAgICBuYW1lOiBTVE9SRVMuTUVUQSxcbiAgICBrZXlQYXRoOiAna2V5JyxcbiAgfSxcbiAge1xuICAgIG5hbWU6IFNUT1JFUy5BUkNISVZFLFxuICAgIGtleVBhdGg6IE9QX0ZJRUxEUy5TRVEsXG4gICAgaW5kZXhlczogW1xuICAgICAgeyBuYW1lOiBPUF9JTkRFWEVTLk9QX0lELCBrZXlQYXRoOiBgb3AuJHtPUF9GSUVMRFMuT1BfSUR9YCwgdW5pcXVlOiB0cnVlIH0sXG4gICAgXSxcbiAgfSxcbl07XG5cbi8qKlxuICog5oqK5LiA5Liq5p+l6K+i5Y+C5pWw6L2s5oiQIElEQiDog73mjqXlj5fnmoTlvaLlvI/jgIJcbiAqXG4gKiDimqDvuI8g5LiJ56eN5oOF5Ya15b+F6aG75YiG5byA77yM5LiN6IO95LiA5b6LIGJ1aWxkUmFuZ2XvvJpcbiAqICAgLSB1bmRlZmluZWQgICAgICAgIOKGkiB1bmRlZmluZWTvvIjlhajooajvvIlcbiAqICAgLSDmlbDnu4QgICAgICAgICAgICAg4oaSIOWkjeWQiOe0ouW8leeahOeyvuehruWMuemFje+8jOebtOaOpeS8oFxuICogICAtIOagh+mHj++8iHN0cmluZy9udW1iZXLvvInihpIgKirnm7TmjqXkvKAqKu+8jOS4jeiDveWhnui/myBidWlsZFJhbmdlXG4gKiAgICAgICAgICAgICAgICAgICAgICAgIO+8iGJ1aWxkUmFuZ2Ug5Y+q6K6kIHtsb3dlciwgdXBwZXJ9IOW9oueKtueahOWvueixoe+8jFxuICogICAgICAgICAgICAgICAgICAgICAgICAg5Lyg5qCH6YeP5Lya5b6X5YiwIHVuZGVmaW5lZO+8jOmdmem7mOWPmOaIkOWFqOihqOaJq+aPj++8iVxuICogICAtIOWMuumXtOWvueixoSAgICAgICAgIOKGkiBidWlsZFJhbmdlXG4gKi9cbmZ1bmN0aW9uIHRvSWRiUXVlcnkoXG4gIHF1ZXJ5PzogRGJJbmRleFF1ZXJ5LFxuKTogSURCVmFsaWRLZXkgfCBJREJWYWxpZEtleVtdIHwgSURCS2V5UmFuZ2UgfCB1bmRlZmluZWQge1xuICBpZiAocXVlcnkgPT09IHVuZGVmaW5lZCkgcmV0dXJuIHVuZGVmaW5lZDtcbiAgaWYgKEFycmF5LmlzQXJyYXkocXVlcnkpKSByZXR1cm4gcXVlcnkgYXMgSURCVmFsaWRLZXlbXTtcbiAgaWYgKHR5cGVvZiBxdWVyeSA9PT0gJ3N0cmluZycgfHwgdHlwZW9mIHF1ZXJ5ID09PSAnbnVtYmVyJykgcmV0dXJuIHF1ZXJ5O1xuICByZXR1cm4gYnVpbGRSYW5nZShxdWVyeSk7XG59XG5cbi8qKiDmnoTpgKAgSURCS2V5UmFuZ2XvvIzlpITnkIblvIDpl63ljLrpl7TjgIIgKi9cbmZ1bmN0aW9uIGJ1aWxkUmFuZ2UocmFuZ2U/OiBEYktleVJhbmdlKTogSURCS2V5UmFuZ2UgfCB1bmRlZmluZWQge1xuICBpZiAocmFuZ2UgPT09IHVuZGVmaW5lZCkgcmV0dXJuIHVuZGVmaW5lZDtcbiAgY29uc3QgeyBsb3dlciwgdXBwZXIsIGxvd2VyT3BlbiwgdXBwZXJPcGVuIH0gPSByYW5nZTtcblxuICBpZiAobG93ZXIgIT09IHVuZGVmaW5lZCAmJiB1cHBlciAhPT0gdW5kZWZpbmVkKSB7XG4gICAgcmV0dXJuIElEQktleVJhbmdlLmJvdW5kKGxvd2VyLCB1cHBlciwgbG93ZXJPcGVuID8/IGZhbHNlLCB1cHBlck9wZW4gPz8gZmFsc2UpO1xuICB9XG4gIGlmIChsb3dlciAhPT0gdW5kZWZpbmVkKSByZXR1cm4gSURCS2V5UmFuZ2UubG93ZXJCb3VuZChsb3dlciwgbG93ZXJPcGVuID8/IGZhbHNlKTtcbiAgaWYgKHVwcGVyICE9PSB1bmRlZmluZWQpIHJldHVybiBJREJLZXlSYW5nZS51cHBlckJvdW5kKHVwcGVyLCB1cHBlck9wZW4gPz8gZmFsc2UpO1xuICByZXR1cm4gdW5kZWZpbmVkO1xufVxuXG4vKiog5oqK5oiR5Lus55qE5ri45qCH5Yqo5L2c5pig5bCE5YiwIElEQiDnmoQgY3Vyc29yIOaWueazleOAgiAqL1xuZnVuY3Rpb24gYXBwbHlDdXJzb3JBY3Rpb24oY3Vyc29yOiBJREJDdXJzb3JXaXRoVmFsdWUsIGFjdGlvbjogRGJDdXJzb3JBY3Rpb24pOiBib29sZWFuIHtcbiAgc3dpdGNoIChhY3Rpb24pIHtcbiAgICBjYXNlICdjb250aW51ZSc6XG4gICAgICBjdXJzb3IuY29udGludWUoKTtcbiAgICAgIHJldHVybiB0cnVlO1xuICAgIGNhc2UgJ3N0b3AnOlxuICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIGNhc2UgJ2RlbGV0ZSc6XG4gICAgICBjdXJzb3IuZGVsZXRlKCk7XG4gICAgICBjdXJzb3IuY29udGludWUoKTtcbiAgICAgIHJldHVybiB0cnVlO1xuICAgIGNhc2UgJ2RlbGV0ZS1zdG9wJzpcbiAgICAgIGN1cnNvci5kZWxldGUoKTtcbiAgICAgIHJldHVybiBmYWxzZTtcbiAgfVxufVxuXG4vKipcbiAqIOaKiiBJREJSZXF1ZXN0IOWMheaIkCBQcm9taXNl44CCXG4gKlxuICog4pqg77iPIOWPquWcqCBgb25lcnJvcmAg6YeMIHJlamVjdCDigJTigJQg5LiN6KaB5Zyo6L+Z6YeM5aSE55CG5LqL5Yqh57qn5Yir55qE6ZSZ6K+v77yMXG4gKiDpgqPnlLEge0BsaW5rIEluZGV4ZWREYkFkYXB0ZXIudHJhbnNhY3Rpb259IOe7n+S4gOWkhOeQhu+8jOWQpuWImeS8muWPjOmHjSByZWplY3TjgIJcbiAqXG4gKiDimqDvuI/imqDvuI8gYHN1cHByZXNzRXJyb3JgIOaYryoq5b+F6aG755qEKirvvIzkuI3mmK/kvJjljJbvvJpcbiAqIEluZGV4ZWREQiDph4zkuIDkuKror7fmsYLmiqXplJnml7bvvIzplJnor6/kuovku7bkvJoqKuWGkuazoeW5tuS4reatouaVtOS4quS6i+WKoSoqIOKAlOKAlFxuICog6Zmk6Z2e5ZyoIG9uZXJyb3Ig6YeM6LCD55SoIGBwcmV2ZW50RGVmYXVsdCgpYOOAglxuICog5omA5LulXCLllK/kuIDntKLlvJXlhrLnqoHlsLHot7Pov4fov5nmnaHjgIHnu6fnu63lhpnlhbbkvZnnmoRcIui/meenjemcgOaxgu+8jFxuICogKirkuI0gcHJldmVudERlZmF1bHQg5piv5YGa5LiN5Yiw55qEKirvvJrkuovliqHkvJrooqvkuK3mraLvvIzmlbTmibnlm57mu5rjgIJcbiAqIOaIkeesrOS4gOeJiOayoeWBmu+8jOihqOeOsOS4uuWOu+mHjeWujOWFqOWkseaViO+8iOmHjeWkjSBvcCDlhajooqvlhpnov5vljrvkuobvvInjgIJcbiAqL1xuZnVuY3Rpb24gcmVxPFQ+KHJlcXVlc3Q6IElEQlJlcXVlc3Q8VD4sIHN1cHByZXNzRXJyb3IgPSBmYWxzZSk6IFByb21pc2U8VD4ge1xuICByZXR1cm4gbmV3IFByb21pc2U8VD4oKHJlc29sdmUsIHJlamVjdCkgPT4ge1xuICAgIHJlcXVlc3Qub25zdWNjZXNzID0gKCkgPT4gcmVzb2x2ZShyZXF1ZXN0LnJlc3VsdCk7XG4gICAgcmVxdWVzdC5vbmVycm9yID0gKGV2ZW50KSA9PiB7XG4gICAgICBpZiAoc3VwcHJlc3NFcnJvcikge1xuICAgICAgICAvLyDpmLvmraLplJnor6/lhpLms6HliLDkuovliqHvvIzkuovliqHlvpfku6Xnu6fnu61cbiAgICAgICAgZXZlbnQucHJldmVudERlZmF1bHQoKTtcbiAgICAgICAgZXZlbnQuc3RvcFByb3BhZ2F0aW9uKCk7XG4gICAgICB9XG4gICAgICByZWplY3Qoc3RvcmFnZUVycm9yKHJlcXVlc3QuZXJyb3IsICdJbmRleGVkREIg6K+35rGC5aSx6LSlJywgeyBraW5kOiAncmVxdWVzdC1mYWlsZWQnIH0pKTtcbiAgICB9O1xuICB9KTtcbn1cblxuLyoqIOWwneivlSBhZGQg55qE57uT5p6c44CC5Yay56qB5LiN5piv6ZSZ6K+v77yM5pivXCLlt7LlrZjlnKhcIuOAgiAqL1xuLyoqXG4gKiBAZGVwcmVjYXRlZCDnlKggYGRiLnR5cGVzLnRzYCDnmoQge0BsaW5rIERiVG9sZXJhbnRBZGRSZXN1bHR944CCXG4gKlxuICog6L+Z6YeM5pu+57uP5pyJ5LiA5Lu9Kiroh6rlt7HnmoQqKuWumuS5ieOAguWFseS6q+Wlkee6puS4gOi3keWwseaatOmcsuS6hu+8mlxuICog5o6l5Y+j5LiK5aOw5piO55qE5pivIGBEYlRvbGVyYW50QWRkUmVzdWx0YO+8iGtleSDmmK8gbnVtYmVy77yJ77yMXG4gKiDogIzov5nph4zmmK8gYElEQlZhbGlkS2V5YCDigJTigJQg5Lik5aWX5a6a5LmJ77yM5LiA5Liq5qaC5b+144CCXG4gKiDlt7LlkIjlubbvvIzliKvlkI3lj6rkuLrkuI3mlLnliqjml6LmnInlvJXnlKjjgIJcbiAqL1xuZXhwb3J0IHR5cGUgQWRkT3V0Y29tZSA9IERiVG9sZXJhbnRBZGRSZXN1bHQ7XG5cbmV4cG9ydCBjbGFzcyBJbmRleGVkRGJBZGFwdGVyIGltcGxlbWVudHMgRGJBZGFwdGVyIHtcbiAgcHJpdmF0ZSBkYjogSURCRGF0YWJhc2UgfCB1bmRlZmluZWQ7XG4gIHByaXZhdGUgb3BlbmluZzogUHJvbWlzZTxJREJEYXRhYmFzZT4gfCB1bmRlZmluZWQ7XG5cbiAgLyoqIOmUgOavgeWNs+atu+i3ryDigJTigJQg55CG55Sx5LiOIGBzcWxpdGUtYWRhcHRlci50c2Ag55qEIGBkZXN0cm95ZWRgIOmCo+auteebuOWQjO+8iEUyIOWPo+W+hCBC77yJ44CCICovXG4gIHByaXZhdGUgZGVzdHJveWVkID0gZmFsc2U7XG5cbiAgLyoqIOesrOS6jOasoSBgZGVzdHJveSgpYCDnlKjov5nku73nvJPlrZjvvIzkuI3lho3ot5HkuIDpgY0gYGRlbGV0ZURhdGFiYXNlYOOAgiAqL1xuICBwcml2YXRlIGRlc3Ryb3lpbmc6IFByb21pc2U8RGJEZXN0cm95UmVwb3J0PiB8IHVuZGVmaW5lZDtcblxuICBjb25zdHJ1Y3Rvcihwcml2YXRlIHJlYWRvbmx5IGRiTmFtZTogc3RyaW5nID0gJ2hleXRhJykge31cblxuICBpbml0KCk6IFByb21pc2U8dm9pZD4ge1xuICAgIHJldHVybiB0aGlzLm9wZW4oKS50aGVuKCgpID0+IHVuZGVmaW5lZCk7XG4gIH1cblxuICAvKipcbiAgICog5omT5byA5pWw5o2u5bqT44CCXG4gICAqXG4gICAqICoq5bm25Y+R5a6J5YWoKirvvJrnlKggYG9wZW5pbmdgIOe8k+WtmCBpbi1mbGlnaHQg55qEIFByb21pc2Ug4oCU4oCUXG4gICAqIOWQpuWImeW5tuWPkSBpbml0IOS8muW8gOWkmuS4qui/nuaOpe+8jOiAjCB1cGdyYWRlIOS6i+WKoeWcqOWkmuS4qui/nuaOpemXtOS8muS6kuebuOmYu+WhnuOAglxuICAgKi9cbiAgcHJpdmF0ZSBvcGVuKCk6IFByb21pc2U8SURCRGF0YWJhc2U+IHtcbiAgICAvLyDwn5S0IEUyIOWPo+W+hCBCIOeahOiQveeCue+8mmBkZWxldGVEYXRhYmFzZWAg5LmL5ZCO5Lu75L2V5LiA5qyh5pmu6YCa6K+76YO95Lya6LWw5Yiw6L+Z6YeM77yMXG4gICAgLy8g6ICMIGBpbmRleGVkREIub3BlbmAg5pivKirliJvlu7oqKuivreS5iSDigJTigJQg5bqT5Lya5bim552A5YWo5aWXIHN0b3JlIOmHjeaWsOWHuueOsOOAglxuICAgIC8vIOatpOWJjei/memHjOayoeacieWuiOWNq++8jOS6juaYr1wi6ZSA5q+B5oiQ5YqfXCLkuI5cIuWuueWZqOiiq+mHjeW7ulwi5Zyo5ZCM5LiA5qyh6L+Q6KGM6YeM6YO95Lya5Y+R55Sf44CCXG4gICAgaWYgKHRoaXMuZGVzdHJveWVkKSByZXR1cm4gUHJvbWlzZS5yZWplY3QobmV3IEFkYXB0ZXJEZXN0cm95ZWRFcnJvcih0aGlzLmRiTmFtZSkpO1xuICAgIGlmICh0aGlzLmRiICE9PSB1bmRlZmluZWQpIHJldHVybiBQcm9taXNlLnJlc29sdmUodGhpcy5kYik7XG4gICAgaWYgKHRoaXMub3BlbmluZyAhPT0gdW5kZWZpbmVkKSByZXR1cm4gdGhpcy5vcGVuaW5nO1xuXG4gICAgdGhpcy5vcGVuaW5nID0gbmV3IFByb21pc2U8SURCRGF0YWJhc2U+KChyZXNvbHZlLCByZWplY3QpID0+IHtcbiAgICAgIGNvbnN0IHJlcXVlc3QgPSBpbmRleGVkREIub3Blbih0aGlzLmRiTmFtZSwgREJfU0NIRU1BX1ZFUlNJT04pO1xuXG4gICAgICByZXF1ZXN0Lm9udXBncmFkZW5lZWRlZCA9ICgpID0+IHtcbiAgICAgICAgY29uc3QgZGIgPSByZXF1ZXN0LnJlc3VsdDtcbiAgICAgICAgZm9yIChjb25zdCBzdG9yZSBvZiBJTkRFWEVEREJfU0NIRU1BKSB7XG4gICAgICAgICAgY29uc3Qgb2JqZWN0U3RvcmUgPSBkYi5vYmplY3RTdG9yZU5hbWVzLmNvbnRhaW5zKHN0b3JlLm5hbWUpXG4gICAgICAgICAgICA/IHJlcXVlc3QudHJhbnNhY3Rpb24hLm9iamVjdFN0b3JlKHN0b3JlLm5hbWUpXG4gICAgICAgICAgICA6IGRiLmNyZWF0ZU9iamVjdFN0b3JlKHN0b3JlLm5hbWUsIHtcbiAgICAgICAgICAgICAgICBrZXlQYXRoOiBzdG9yZS5rZXlQYXRoLFxuICAgICAgICAgICAgICAgIGF1dG9JbmNyZW1lbnQ6IHN0b3JlLmF1dG9JbmNyZW1lbnQgPz8gZmFsc2UsXG4gICAgICAgICAgICAgIH0pO1xuXG4gICAgICAgICAgZm9yIChjb25zdCBpbmRleCBvZiBzdG9yZS5pbmRleGVzID8/IFtdKSB7XG4gICAgICAgICAgICBpZiAob2JqZWN0U3RvcmUuaW5kZXhOYW1lcy5jb250YWlucyhpbmRleC5uYW1lKSkgY29udGludWU7XG4gICAgICAgICAgICBvYmplY3RTdG9yZS5jcmVhdGVJbmRleChpbmRleC5uYW1lLCBpbmRleC5rZXlQYXRoLCB7XG4gICAgICAgICAgICAgIHVuaXF1ZTogaW5kZXgudW5pcXVlID8/IGZhbHNlLFxuICAgICAgICAgICAgICBtdWx0aUVudHJ5OiBpbmRleC5tdWx0aUVudHJ5ID8/IGZhbHNlLFxuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICB9O1xuXG4gICAgICByZXF1ZXN0Lm9uc3VjY2VzcyA9ICgpID0+IHtcbiAgICAgICAgdGhpcy5kYiA9IHJlcXVlc3QucmVzdWx0O1xuICAgICAgICAvLyDov57mjqXooqvlpJbpg6jlhbPpl63vvIjlpoLmtY/op4jlmajlm57mlLbvvInml7bmuIXmjonnvJPlrZjvvIzkuIvmrKHosIPnlKjkvJrph43lvIBcbiAgICAgICAgcmVxdWVzdC5yZXN1bHQub25jbG9zZSA9ICgpID0+IHtcbiAgICAgICAgICB0aGlzLmRiID0gdW5kZWZpbmVkO1xuICAgICAgICAgIHRoaXMub3BlbmluZyA9IHVuZGVmaW5lZDtcbiAgICAgICAgfTtcbiAgICAgICAgLy8g8J+UtCAqKuiuqeS9jSoq57uZ5Yir5Lq655qEIGBkZWxldGVEYXRhYmFzZWDvvIjmiJbljYfniYjmnKzvvInjgILmtY/op4jlmajlnKjmiafooYzliKDpmaTliY3kvJrnu5lcbiAgICAgICAgLy8g5omA5pyJ5pei5pyJ6L+e5o6l5Y+RIGB2ZXJzaW9uY2hhbmdlYO+8myoq5LiN5o6l6L+Z5Liq5LqL5Lu2ID0g6YKj5qyh5Yig6Zmk5rC46L+c5YGc5ZyoIGJsb2NrZWQqKuOAglxuICAgICAgICAvLyDov5nmnaHkuI3mmK/lgYfmg7PvvJrms6jplIDot6/lvoTkuIrplIDmr4HlmajlvIDnmoTmmK8qKuWPpuS4gOS4qioqIGBJbmRleGVkRGJBZGFwdGVyYCDlrp7kvotcbiAgICAgICAgLy8g77yIYGFwcHMvd2ViL3NyYy9saWIvbG9jYWwtZGF0YS1kZXN0cnVjdGlvbi50czoyNjJg77yJ77yM6ICM5rS76L+e5o6l5o+h5Zyo5bqU55So5omL6YeMXG4gICAgICAgIC8vIO+8iGBvcGxvZy50czoxMzVgIOeahOS4u+W6k+OAgWB2YXVsdC1zZXNzaW9uLnRzOjY5YCDnmoQgYGhleXRhLXZhdWx0YO+8ieOAglxuICAgICAgICAvLyDmsqHmnInkuIvpnaLkuInooYzvvIxXZWIg55qEXCLlvZPlnLrmuIXmjonmnKzmnLrmmI7mlodcIuS8mioq5oyC5L2P5LiN6L+U5ZueKiog4oCU4oCUXG4gICAgICAgIC8vIOiAjOaMguS9j+S4jei/lOWbnuWcqOeVjOmdouS4iumVv+W+l+WDj1wi5q2j5Zyo5rOo6ZSAXCLvvIzku4DkuYjpg73kuI3miqXjgIJcbiAgICAgICAgLy8g5LiOIGB0ZXN0cy9kZXN0cm95LnNwZWMudHNgIOmCo+adoVwi5Yir55qE6L+e5o6l5Y2g552AIOKHkiBkZXN0cm95IOS4jeiuuCByZXNvbHZlXCLmmK/lkIzkuIDmnLrliLbnmoRcbiAgICAgICAgLy8g5Lik6Z2i77ya6YKj5LiA6Z2i6K+B5piOXCLkuI3orqnkvY3lsLHkvJrmjKHkvY9cIu+8jOi/meS4gOmdou+8iGDmnKzpgILphY3lmajoh6rlt7HkuI3orrjmjKHkvY9g77yJ6ZKJXCLmiJHku6zorqnkvY1cIuOAglxuICAgICAgICByZXF1ZXN0LnJlc3VsdC5vbnZlcnNpb25jaGFuZ2UgPSAoKSA9PiB7XG4gICAgICAgICAgcmVxdWVzdC5yZXN1bHQuY2xvc2UoKTtcbiAgICAgICAgICB0aGlzLmRiID0gdW5kZWZpbmVkO1xuICAgICAgICAgIHRoaXMub3BlbmluZyA9IHVuZGVmaW5lZDtcbiAgICAgICAgfTtcbiAgICAgICAgcmVzb2x2ZShyZXF1ZXN0LnJlc3VsdCk7XG4gICAgICB9O1xuXG4gICAgICByZXF1ZXN0Lm9uZXJyb3IgPSAoKSA9PlxuICAgICAgICByZWplY3Qoc3RvcmFnZUVycm9yKHJlcXVlc3QuZXJyb3IsICfml6Dms5XmiZPlvIAgSW5kZXhlZERCJywgeyBraW5kOiAnb3Blbi1mYWlsZWQnIH0pKTtcbiAgICAgIC8vIPCflLQg6L+Z5LiA5p2hKirml6DmnaHku7YqKuaKm++8iGBvbmJsb2NrZWRgIOS6i+S7tuayoeaciSBlcnJvciDlr7nosaHvvInvvIxcbiAgICAgIC8vIOaJgOS7peWug+aYr+mUmeivr+Wxj+S4iuecn+ato+S8mumcsuWHuuadpeeahOmCo+WPpeS4reaWh+OAglxuICAgICAgcmVxdWVzdC5vbmJsb2NrZWQgPSAoKSA9PlxuICAgICAgICByZWplY3QoXG4gICAgICAgICAgbmV3IFN0b3JhZ2VFcnJvcihcbiAgICAgICAgICAgICdJbmRleGVkREIg5Y2H57qn6KKr5YW25a6D5qCH562+6aG16Zi75aGeIOKAlOKAlCDor7flhbPpl63or6XlupTnlKjnmoTlhbblroPnqpflj6PlkI7ph43or5UnLFxuICAgICAgICAgICAgeyBraW5kOiAndXBncmFkZS1ibG9ja2VkJyB9LFxuICAgICAgICAgICksXG4gICAgICAgICk7XG4gICAgfSk7XG5cbiAgICByZXR1cm4gdGhpcy5vcGVuaW5nO1xuICB9XG5cbiAgY2xvc2UoKTogdm9pZCB7XG4gICAgdGhpcy5kYj8uY2xvc2UoKTtcbiAgICB0aGlzLmRiID0gdW5kZWZpbmVkO1xuICAgIHRoaXMub3BlbmluZyA9IHVuZGVmaW5lZDtcbiAgfVxuXG4gIC8vIOKUgOKUgCDkuovliqEg4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG5cbiAgLyoqXG4gICAqIOaJp+ihjOS4gOS4quWOn+WtkOS6i+WKoeOAglxuICAgKlxuICAgKiDimqDvuI8g6L+U5Zue55qEIFByb21pc2UgKirlnKggb25jb21wbGV0ZSDmiY3lhrPorq4qKu+8iOingeaWh+S7tuWktOmZt+mYsSAy77yJ44CCXG4gICAqL1xuICBhc3luYyB0cmFuc2FjdGlvbjxUPihcbiAgICBzdG9yZXM6IHN0cmluZ1tdLFxuICAgIG1vZGU6IERiVHhNb2RlLFxuICAgIGZuOiAodHg6IERiVHgpID0+IFByb21pc2U8VD4sXG4gICk6IFByb21pc2U8VD4ge1xuICAgIGNvbnN0IGRiID0gYXdhaXQgdGhpcy5vcGVuKCk7XG5cbiAgICByZXR1cm4gbmV3IFByb21pc2U8VD4oKHJlc29sdmUsIHJlamVjdCkgPT4ge1xuICAgICAgbGV0IGlkYlR4OiBJREJUcmFuc2FjdGlvbjtcbiAgICAgIHRyeSB7XG4gICAgICAgIGlkYlR4ID0gZGIudHJhbnNhY3Rpb24oc3RvcmVzLCBtb2RlKTtcbiAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgIC8vIOi1sOWIsOi/memHjOWHoOS5juWPquacieS4gOenjeWPr+iDve+8muiwg+eUqOeahCBzdG9yZSDlkI3miJbmqKHlvI/kuI3lkIjms5Ug4oCU4oCUIOe8lueoi+mUmeivr+OAglxuICAgICAgICByZWplY3QoYXNTdG9yYWdlRXJyb3IoZXJyb3IsICfml6Dms5XlvIDlp4vkuovliqEnLCB7IGtpbmQ6ICdwcm9ncmFtbWluZy1lcnJvcicgfSkpO1xuICAgICAgICByZXR1cm47XG4gICAgICB9XG5cbiAgICAgIGxldCByZXN1bHQ6IFQ7XG4gICAgICBsZXQgc2V0dGxlZCA9IGZhbHNlO1xuXG4gICAgICBpZGJUeC5vbmNvbXBsZXRlID0gKCkgPT4ge1xuICAgICAgICBzZXR0bGVkID0gdHJ1ZTtcbiAgICAgICAgcmVzb2x2ZShyZXN1bHQpO1xuICAgICAgfTtcbiAgICAgIGlkYlR4Lm9uYWJvcnQgPSAoKSA9PiB7XG4gICAgICAgIGlmIChzZXR0bGVkKSByZXR1cm47XG4gICAgICAgIHNldHRsZWQgPSB0cnVlO1xuICAgICAgICByZWplY3Qoc3RvcmFnZUVycm9yKGlkYlR4LmVycm9yLCAnSW5kZXhlZERCIOS6i+WKoeiiq+S4reatoicsIHsga2luZDogJ3RyYW5zYWN0aW9uLWZhaWxlZCcgfSkpO1xuICAgICAgfTtcbiAgICAgIGlkYlR4Lm9uZXJyb3IgPSAoKSA9PiB7XG4gICAgICAgIGlmIChzZXR0bGVkKSByZXR1cm47XG4gICAgICAgIHNldHRsZWQgPSB0cnVlO1xuICAgICAgICByZWplY3Qoc3RvcmFnZUVycm9yKGlkYlR4LmVycm9yLCAnSW5kZXhlZERCIOS6i+WKoeWksei0pScsIHsga2luZDogJ3RyYW5zYWN0aW9uLWZhaWxlZCcgfSkpO1xuICAgICAgfTtcblxuICAgICAgY29uc3QgdHggPSB0aGlzLm1ha2VUeChpZGJUeCwgc3RvcmVzKTtcblxuICAgICAgZm4odHgpLnRoZW4oXG4gICAgICAgICh2YWx1ZSkgPT4ge1xuICAgICAgICAgIHJlc3VsdCA9IHZhbHVlO1xuICAgICAgICAgIC8vIOKaoO+4jyDov5nph4wqKuS4jSByZXNvbHZlKiog4oCU4oCUIOetiSBvbmNvbXBsZXRl44CCXG4gICAgICAgICAgLy8g5L2G5pyJ5Liq6Zm36Zix77ya5aaC5p6cIGZuIOmHjOayoeacieWPkeWHuuS7u+S9leivt+axgu+8iOS+i+WmguWPquWBmue6r+iuoeeul++8ie+8jFxuICAgICAgICAgIC8vIOS6i+WKoeS4jeS8muacieW+heWkhOeQhuivt+axgu+8jG9uY29tcGxldGUg5Y+v6IO95bey57uPL+WNs+WwhuinpuWPkeOAglxuICAgICAgICAgIC8vIOS4u+WKqCBjb21taXQg5LiA5LiL5piv5a6J5YWo55qE77yI5bey5o+Q5Lqk5pe25pivIG5vLW9w77yJ44CCXG4gICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIGlkYlR4LmNvbW1pdD8uKCk7XG4gICAgICAgICAgfSBjYXRjaCB7XG4gICAgICAgICAgICAvLyDogIHmtY/op4jlmajmsqHmnIkgY29tbWl0KCnvvIzlv73nlaVcbiAgICAgICAgICB9XG4gICAgICAgIH0sXG4gICAgICAgIChlcnJvcjogdW5rbm93bikgPT4ge1xuICAgICAgICAgIHNldHRsZWQgPSB0cnVlO1xuICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICBpZGJUeC5hYm9ydCgpO1xuICAgICAgICAgIH0gY2F0Y2gge1xuICAgICAgICAgICAgLy8g5bey57uT5p2fXG4gICAgICAgICAgfVxuICAgICAgICAgIHJlamVjdChhc1N0b3JhZ2VFcnJvcihlcnJvciwgJ+S6i+WKoeWGheeahOaTjeS9nOWksei0pScsIHsga2luZDogJ3JlcXVlc3QtZmFpbGVkJyB9KSk7XG4gICAgICAgIH0sXG4gICAgICApO1xuICAgIH0pO1xuICB9XG5cbiAgcHJpdmF0ZSBtYWtlVHgoaWRiVHg6IElEQlRyYW5zYWN0aW9uLCBhbGxvd2VkOiBzdHJpbmdbXSk6IERiVHgge1xuICAgIGNvbnN0IHN0b3JlTmFtZXMgPSBuZXcgU2V0KGFsbG93ZWQpO1xuXG4gICAgY29uc3QgYXNzZXJ0ID0gKHN0b3JlOiBzdHJpbmcpOiB2b2lkID0+IHtcbiAgICAgIGlmICghc3RvcmVOYW1lcy5oYXMoc3RvcmUpKSB7XG4gICAgICAgIC8vIOaYjuehruaKm+mUmeiAjOS4jeaYr+iuqSBJREIg5oqbIOKAlOKAlCDlkI7ogIXkv6Hmga/ph4/lpKrkvY5cbiAgICAgICAgdGhyb3cgbmV3IFN0b3JhZ2VFcnJvcihcbiAgICAgICAgICBg5LqL5Yqh5pyq5YyF5ZCrIHN0b3Jl44CMJHtzdG9yZX3jgI3jgILor7fmiorlroPliqDov5sgdHJhbnNhY3Rpb24oWy4uLl0pIOeahOWIl+ihqO+8miR7YWxsb3dlZC5qb2luKCcsICcpfWAsXG4gICAgICAgICAgeyBraW5kOiAncHJvZ3JhbW1pbmctZXJyb3InIH0sXG4gICAgICAgICk7XG4gICAgICB9XG4gICAgfTtcblxuICAgIGNvbnN0IHN0b3JlID0gKG5hbWU6IHN0cmluZyk6IElEQk9iamVjdFN0b3JlID0+IHtcbiAgICAgIGFzc2VydChuYW1lKTtcbiAgICAgIHJldHVybiBpZGJUeC5vYmplY3RTdG9yZShuYW1lKTtcbiAgICB9O1xuXG4gICAgY29uc3QgYXBpOiBEYlR4ICYge1xuICAgICAgYWRkVG9sZXJhdGluZ0R1cGxpY2F0ZTogKHN0b3JlTmFtZTogc3RyaW5nLCB2YWx1ZTogdW5rbm93bikgPT4gUHJvbWlzZTxEYlRvbGVyYW50QWRkUmVzdWx0PjtcbiAgICB9ID0ge1xuICAgICAgYWRkOiAocywgdmFsdWUpID0+IHJlcShzdG9yZShzKS5hZGQodmFsdWUpKSBhcyBQcm9taXNlPG51bWJlcj4sXG5cbiAgICAgIC8qKlxuICAgICAgICog5Yay56qB5Y+v5a655b+N55qEIGFkZOOAglxuICAgICAgICpcbiAgICAgICAqIOeUqOWcqCBvcC1sb2cg5YaZ5YWl5LiK77ya5ZCM5LiA5LiqIG9wSWQg6KKr6YeN5aSN5oqV6YCS5pivKirmraPluLjot6/lvoQqKlxuICAgICAgICog77yI5ZCM5q2l5Lya6YeN5pS+44CB5a6i5oi356uv5Lya6YeN6K+V77yJ77yM5LiN5piv5byC5bi444CCXG4gICAgICAgKi9cbiAgICAgIGFkZFRvbGVyYXRpbmdEdXBsaWNhdGU6IGFzeW5jIChzdG9yZU5hbWUsIHZhbHVlKSA9PiB7XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgY29uc3Qga2V5ID0gYXdhaXQgcmVxKHN0b3JlKHN0b3JlTmFtZSkuYWRkKHZhbHVlKSwgdHJ1ZSk7XG4gICAgICAgICAgLy8g5pys6aG555uu5omA5pyJ5Li76ZSu6YO95pivIHN0cmluZyB8IG51bWJlcu+8jOS4lOiHquWinumUruS4gOWumuaYryBudW1iZXLjgIJcbiAgICAgICAgICAvLyDlnKjovrnnlYzlpITmlLbnqoTvvIzogIzkuI3mmK/mioogYERiVG9sZXJhbnRBZGRSZXN1bHQua2V5YCDmlL7lrr3liLAgSURCVmFsaWRLZXlcbiAgICAgICAgICAvLyDigJTigJQg6YKj5Lya6K6p5LiK5bGC5Lmf6KKr6L+r5aSE55CGIERhdGUgLyBBcnJheUJ1ZmZlcuOAglxuICAgICAgICAgIHJldHVybiB7IG9rOiB0cnVlLCBrZXk6IHR5cGVvZiBrZXkgPT09ICdudW1iZXInID8ga2V5IDogTnVtYmVyKGtleSkgfTtcbiAgICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgICAvLyDwn5S0IOeci+eahOaYryoq6amx5Yqo6Ieq5bex55qEKirplJnor6/lkI3jgILmipvlh7rmnaXnmoTnjrDlnKjkuIDlvovmmK8gYFN0b3JhZ2VFcnJvcmBcbiAgICAgICAgICAvLyDvvIhgbmFtZWAg5bey57uP6KKr5o2i5oiQIGAnU3RvcmFnZUVycm9yJ2DvvInvvIzmiYDku6Xlv4XpobvlvoAgYGNhdXNlYCDph4zmib5cbiAgICAgICAgICAvLyDigJTigJQg5ZCm5YiZ5ZSv5LiA57Si5byV5Yay56qB5Lya6KKr5b2T5oiQ55yf5aSx6LSl77yM5bmC562J5YaZ5YWl55u05o6l5Z2P5o6J44CCXG4gICAgICAgICAgY29uc3QgZHJpdmVyRXJyb3IgPSBlcnJvciBpbnN0YW5jZW9mIFN0b3JhZ2VFcnJvciA/IGVycm9yLmNhdXNlIDogZXJyb3I7XG4gICAgICAgICAgaWYgKFxuICAgICAgICAgICAgdHlwZW9mIGRyaXZlckVycm9yID09PSAnb2JqZWN0JyAmJlxuICAgICAgICAgICAgZHJpdmVyRXJyb3IgIT09IG51bGwgJiZcbiAgICAgICAgICAgICduYW1lJyBpbiBkcml2ZXJFcnJvciAmJlxuICAgICAgICAgICAgKGRyaXZlckVycm9yIGFzIHsgbmFtZTogc3RyaW5nIH0pLm5hbWUgPT09ICdDb25zdHJhaW50RXJyb3InXG4gICAgICAgICAgKSB7XG4gICAgICAgICAgICByZXR1cm4geyBvazogZmFsc2UsIHJlYXNvbjogJ2R1cGxpY2F0ZScgfTtcbiAgICAgICAgICB9XG4gICAgICAgICAgdGhyb3cgZXJyb3I7XG4gICAgICAgIH1cbiAgICAgIH0sXG4gICAgICBwdXQ6IChzLCB2YWx1ZSwga2V5KSA9PlxuICAgICAgICBrZXkgPT09IHVuZGVmaW5lZFxuICAgICAgICAgID8gcmVxKHN0b3JlKHMpLnB1dCh2YWx1ZSkpLnRoZW4oKCkgPT4gdW5kZWZpbmVkKVxuICAgICAgICAgIDogcmVxKHN0b3JlKHMpLnB1dCh2YWx1ZSwga2V5KSkudGhlbigoKSA9PiB1bmRlZmluZWQpLFxuICAgICAgZ2V0OiA8VCw+KHM6IHN0cmluZywga2V5OiBEYktleSkgPT5cbiAgICAgICAgcmVxKHN0b3JlKHMpLmdldChrZXkpKSBhcyBQcm9taXNlPFQgfCB1bmRlZmluZWQ+LFxuICAgICAgZ2V0QWxsOiA8VCw+KHM6IHN0cmluZywgcmFuZ2U/OiBEYktleVJhbmdlLCBsaW1pdD86IG51bWJlcikgPT4ge1xuICAgICAgICBhc3NlcnRJdGVyYXRlTGltaXQobGltaXQpO1xuICAgICAgICByZXR1cm4gcmVxKHN0b3JlKHMpLmdldEFsbChidWlsZFJhbmdlKHJhbmdlKSwgbGltaXQpKSBhcyBQcm9taXNlPFRbXT47XG4gICAgICB9LFxuICAgICAgZGVsZXRlOiAocywga2V5KSA9PiByZXEoc3RvcmUocykuZGVsZXRlKGtleSkpLnRoZW4oKCkgPT4gdW5kZWZpbmVkKSxcbiAgICAgIGNsZWFyOiAocykgPT4gcmVxKHN0b3JlKHMpLmNsZWFyKCkpLnRoZW4oKCkgPT4gdW5kZWZpbmVkKSxcbiAgICAgIGNvdW50OiAocywgcmFuZ2U/OiBEYktleVJhbmdlKSA9PiByZXEoc3RvcmUocykuY291bnQoYnVpbGRSYW5nZShyYW5nZSkpKSxcblxuICAgICAgZ2V0RnJvbUluZGV4OiA8VCw+KHM6IHN0cmluZywgaW5kZXg6IHN0cmluZywga2V5OiBEYktleSB8IERiS2V5W10pID0+XG4gICAgICAgIHJlcShzdG9yZShzKS5pbmRleChpbmRleCkuZ2V0KGtleSkpIGFzIFByb21pc2U8VCB8IHVuZGVmaW5lZD4sXG4gICAgICAvLyBJREJWYWxpZEtleSDmr5TmiJHku6znmoQgRGJLZXkg5a6977yI6L+Y5YyF5ZCrIERhdGUgLyBBcnJheUJ1ZmZlcu+8ie+8jFxuICAgICAgLy8g5L2G5pys6aG555uu5omA5pyJ5Li76ZSu6YO95pivIHN0cmluZyB8IG51bWJlcuOAguWcqOi+ueeVjOWkhOaUtueqhOW5tuazqOaYju+8jFxuICAgICAgLy8g6ICM5LiN5piv5oqKIERiS2V5IOaUvuWuveWIsCBJREJWYWxpZEtleSDigJTigJQg6YKj5Lya6K6p5LiK5bGC5Lmf5b6X5aSE55CGIERhdGXjgIJcbiAgICAgIGdldEtleUZyb21JbmRleDogKHMsIGluZGV4LCBrZXkpID0+XG4gICAgICAgIHJlcShzdG9yZShzKS5pbmRleChpbmRleCkuZ2V0S2V5KGtleSkpIGFzIFByb21pc2U8RGJLZXkgfCB1bmRlZmluZWQ+LFxuICAgICAgZ2V0QWxsRnJvbUluZGV4OiA8VCw+KHM6IHN0cmluZywgaW5kZXg6IHN0cmluZywgcXVlcnk/OiBEYkluZGV4UXVlcnkpID0+IHtcbiAgICAgICAgcmV0dXJuIHJlcShzdG9yZShzKS5pbmRleChpbmRleCkuZ2V0QWxsKHRvSWRiUXVlcnkocXVlcnkpKSkgYXMgUHJvbWlzZTxUW10+O1xuICAgICAgfSxcbiAgICAgIGNvdW50RnJvbUluZGV4OiAocywgaW5kZXgsIHF1ZXJ5PzogRGJJbmRleFF1ZXJ5KSA9PiB7XG4gICAgICAgIHJldHVybiByZXEoc3RvcmUocykuaW5kZXgoaW5kZXgpLmNvdW50KHRvSWRiUXVlcnkocXVlcnkpKSk7XG4gICAgICB9LFxuXG4gICAgICBpdGVyYXRlOiA8VCw+KFxuICAgICAgICBzOiBzdHJpbmcsXG4gICAgICAgIG9wdGlvbnM6IERiSXRlcmF0ZU9wdGlvbnMsXG4gICAgICAgIHZpc2l0OiBEYkN1cnNvclZpc2l0b3I8VD4sXG4gICAgICApID0+IHRoaXMuaXRlcmF0ZUluKHN0b3JlKHMpLCBvcHRpb25zLCB2aXNpdCksXG4gICAgfTtcbiAgICByZXR1cm4gYXBpO1xuICB9XG5cbiAgLyoqIOa4uOagh+mBjeWOhuOAguaKveWHuuadpeaYr+WboOS4uumhtuWxguaWueazleWSjOS6i+WKoeaWueazleWFseeUqOWug+OAgiAqL1xuICBwcml2YXRlIGl0ZXJhdGVJbjxUPihcbiAgICBzb3VyY2U6IElEQk9iamVjdFN0b3JlIHwgSURCSW5kZXgsXG4gICAgb3B0aW9uczogRGJJdGVyYXRlT3B0aW9ucyxcbiAgICB2aXNpdDogRGJDdXJzb3JWaXNpdG9yPFQ+LFxuICApOiBQcm9taXNlPHZvaWQ+IHtcbiAgICBhc3NlcnRJdGVyYXRlTGltaXQob3B0aW9ucy5saW1pdCk7XG5cbiAgICByZXR1cm4gbmV3IFByb21pc2U8dm9pZD4oKHJlc29sdmUsIHJlamVjdCkgPT4ge1xuICAgICAgbGV0IHZpc2l0ZWQgPSAwO1xuICAgICAgY29uc3QgbGltaXQgPSBvcHRpb25zLmxpbWl0O1xuICAgICAgY29uc3QgcmFuZ2UgPSBidWlsZFJhbmdlKHsgbG93ZXI6IG9wdGlvbnMubG93ZXIsIHVwcGVyOiBvcHRpb25zLnVwcGVyIH0pO1xuICAgICAgY29uc3QgZGlyZWN0aW9uOiBJREJDdXJzb3JEaXJlY3Rpb24gPSBvcHRpb25zLmRpcmVjdGlvbiA/PyAnbmV4dCc7XG5cbiAgICAgIGNvbnN0IHJlcXVlc3QgPSBzb3VyY2Uub3BlbkN1cnNvcihyYW5nZSwgZGlyZWN0aW9uKTtcblxuICAgICAgcmVxdWVzdC5vbnN1Y2Nlc3MgPSAoKSA9PiB7XG4gICAgICAgIGNvbnN0IGN1cnNvciA9IHJlcXVlc3QucmVzdWx0O1xuICAgICAgICBpZiAoY3Vyc29yID09PSBudWxsKSB7XG4gICAgICAgICAgcmVzb2x2ZSgpO1xuICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICBpZiAobGltaXQgIT09IHVuZGVmaW5lZCAmJiB2aXNpdGVkID49IGxpbWl0KSB7XG4gICAgICAgICAgcmVzb2x2ZSgpO1xuICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuXG4gICAgICAgIHZpc2l0ZWQgKz0gMTtcbiAgICAgICAgLy8gY3Vyc29yLmtleSDmmK8gSURCVmFsaWRLZXnvvIjmr5QgRGJLZXkg5a6977yM5ZCrIERhdGUvQXJyYXlCdWZmZXLvvInjgIJcbiAgICAgICAgLy8g5pys6aG555uu5Li76ZSu6YO95pivIHN0cmluZ3xudW1iZXLvvIzovrnnlYzlpITmlLbnqoTlubbms6jmmI7jgIJcbiAgICAgICAgY29uc3QgYWN0aW9uID0gdmlzaXQoY3Vyc29yLnZhbHVlIGFzIFQsIGN1cnNvci5rZXkgYXMgRGJLZXkpO1xuICAgICAgICBpZiAoIWFwcGx5Q3Vyc29yQWN0aW9uKGN1cnNvciwgYWN0aW9uKSkge1xuICAgICAgICAgIHJlc29sdmUoKTtcbiAgICAgICAgfVxuICAgICAgfTtcblxuICAgICAgcmVxdWVzdC5vbmVycm9yID0gKCkgPT5cbiAgICAgICAgcmVqZWN0KHN0b3JhZ2VFcnJvcihyZXF1ZXN0LmVycm9yLCAnSW5kZXhlZERCIOa4uOagh+Wksei0pScsIHsga2luZDogJ3JlcXVlc3QtZmFpbGVkJyB9KSk7XG4gICAgfSk7XG4gIH1cblxuICAvLyDilIDilIAg6aG25bGC5L6/5o235pa55rOV77ya5YyF5LiA5Liq5Y2VIHN0b3JlIOS6i+WKoSDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcblxuICBhc3luYyBhZGQoc3RvcmU6IHN0cmluZywgdmFsdWU6IHVua25vd24pOiBQcm9taXNlPG51bWJlcj4ge1xuICAgIHJldHVybiB0aGlzLnRyYW5zYWN0aW9uKFtzdG9yZV0sICdyZWFkd3JpdGUnLCAodHgpID0+IHR4LmFkZChzdG9yZSwgdmFsdWUpKTtcbiAgfVxuXG4gIGFzeW5jIHB1dChzdG9yZTogc3RyaW5nLCB2YWx1ZTogdW5rbm93biwga2V5PzogRGJLZXkpOiBQcm9taXNlPHZvaWQ+IHtcbiAgICByZXR1cm4gdGhpcy50cmFuc2FjdGlvbihbc3RvcmVdLCAncmVhZHdyaXRlJywgKHR4KSA9PiB0eC5wdXQoc3RvcmUsIHZhbHVlLCBrZXkpKTtcbiAgfVxuXG4gIGFzeW5jIGdldDxUPihzdG9yZTogc3RyaW5nLCBrZXk6IERiS2V5KTogUHJvbWlzZTxUIHwgdW5kZWZpbmVkPiB7XG4gICAgcmV0dXJuIHRoaXMudHJhbnNhY3Rpb24oW3N0b3JlXSwgJ3JlYWRvbmx5JywgKHR4KSA9PiB0eC5nZXQ8VD4oc3RvcmUsIGtleSkpO1xuICB9XG5cbiAgYXN5bmMgZ2V0QWxsPFQ+KHN0b3JlOiBzdHJpbmcsIHJhbmdlPzogRGJLZXlSYW5nZSwgbGltaXQ/OiBudW1iZXIpOiBQcm9taXNlPFRbXT4ge1xuICAgIHJldHVybiB0aGlzLnRyYW5zYWN0aW9uKFtzdG9yZV0sICdyZWFkb25seScsICh0eCkgPT4gdHguZ2V0QWxsPFQ+KHN0b3JlLCByYW5nZSwgbGltaXQpKTtcbiAgfVxuXG4gIGFzeW5jIGRlbGV0ZShzdG9yZTogc3RyaW5nLCBrZXk6IERiS2V5KTogUHJvbWlzZTx2b2lkPiB7XG4gICAgcmV0dXJuIHRoaXMudHJhbnNhY3Rpb24oW3N0b3JlXSwgJ3JlYWR3cml0ZScsICh0eCkgPT4gdHguZGVsZXRlKHN0b3JlLCBrZXkpKTtcbiAgfVxuXG4gIGFzeW5jIGNsZWFyKHN0b3JlOiBzdHJpbmcpOiBQcm9taXNlPHZvaWQ+IHtcbiAgICByZXR1cm4gdGhpcy50cmFuc2FjdGlvbihbc3RvcmVdLCAncmVhZHdyaXRlJywgKHR4KSA9PiB0eC5jbGVhcihzdG9yZSkpO1xuICB9XG5cbiAgYXN5bmMgY291bnQoc3RvcmU6IHN0cmluZywgcmFuZ2U/OiBEYktleVJhbmdlKTogUHJvbWlzZTxudW1iZXI+IHtcbiAgICByZXR1cm4gdGhpcy50cmFuc2FjdGlvbihbc3RvcmVdLCAncmVhZG9ubHknLCAodHgpID0+IHR4LmNvdW50KHN0b3JlLCByYW5nZSkpO1xuICB9XG5cbiAgYXN5bmMgZ2V0RnJvbUluZGV4PFQ+KFxuICAgIHN0b3JlOiBzdHJpbmcsXG4gICAgaW5kZXg6IHN0cmluZyxcbiAgICBrZXk6IERiS2V5IHwgRGJLZXlbXSxcbiAgKTogUHJvbWlzZTxUIHwgdW5kZWZpbmVkPiB7XG4gICAgcmV0dXJuIHRoaXMudHJhbnNhY3Rpb24oW3N0b3JlXSwgJ3JlYWRvbmx5JywgKHR4KSA9PlxuICAgICAgdHguZ2V0RnJvbUluZGV4PFQ+KHN0b3JlLCBpbmRleCwga2V5KSxcbiAgICApO1xuICB9XG5cbiAgYXN5bmMgZ2V0S2V5RnJvbUluZGV4KFxuICAgIHN0b3JlOiBzdHJpbmcsXG4gICAgaW5kZXg6IHN0cmluZyxcbiAgICBrZXk6IERiS2V5IHwgRGJLZXlbXSxcbiAgKTogUHJvbWlzZTxEYktleSB8IHVuZGVmaW5lZD4ge1xuICAgIHJldHVybiB0aGlzLnRyYW5zYWN0aW9uKFtzdG9yZV0sICdyZWFkb25seScsICh0eCkgPT5cbiAgICAgIHR4LmdldEtleUZyb21JbmRleChzdG9yZSwgaW5kZXgsIGtleSksXG4gICAgKTtcbiAgfVxuXG4gIGFzeW5jIGdldEFsbEZyb21JbmRleDxUPihcbiAgICBzdG9yZTogc3RyaW5nLFxuICAgIGluZGV4OiBzdHJpbmcsXG4gICAgcXVlcnk/OiBEYkluZGV4UXVlcnksXG4gICk6IFByb21pc2U8VFtdPiB7XG4gICAgcmV0dXJuIHRoaXMudHJhbnNhY3Rpb24oW3N0b3JlXSwgJ3JlYWRvbmx5JywgKHR4KSA9PlxuICAgICAgdHguZ2V0QWxsRnJvbUluZGV4PFQ+KHN0b3JlLCBpbmRleCwgcXVlcnkpLFxuICAgICk7XG4gIH1cblxuICBhc3luYyBjb3VudEZyb21JbmRleChcbiAgICBzdG9yZTogc3RyaW5nLFxuICAgIGluZGV4OiBzdHJpbmcsXG4gICAgcXVlcnk/OiBEYkluZGV4UXVlcnksXG4gICk6IFByb21pc2U8bnVtYmVyPiB7XG4gICAgcmV0dXJuIHRoaXMudHJhbnNhY3Rpb24oW3N0b3JlXSwgJ3JlYWRvbmx5JywgKHR4KSA9PlxuICAgICAgdHguY291bnRGcm9tSW5kZXgoc3RvcmUsIGluZGV4LCBxdWVyeSksXG4gICAgKTtcbiAgfVxuXG4gIGFzeW5jIGl0ZXJhdGU8VD4oXG4gICAgc3RvcmU6IHN0cmluZyxcbiAgICBvcHRpb25zOiBEYkl0ZXJhdGVPcHRpb25zLFxuICAgIHZpc2l0OiBEYkN1cnNvclZpc2l0b3I8VD4sXG4gICk6IFByb21pc2U8dm9pZD4ge1xuICAgIC8vIOKaoO+4jyDnlKggcmVhZHdyaXRlIOiAjOS4jeaYryByZWFkb25see+8muiuv+mXruiAheWPr+S7pei/lOWbniAnZGVsZXRlJyAvICdkZWxldGUtc3RvcCfvvIxcbiAgICAvLyDogIwgYGN1cnNvci5kZWxldGUoKWAg5Zyo5Y+q6K+75LqL5Yqh6YeM5Lya5oqbIEFib3J0RXJyb3LvvIxcbiAgICAvLyDlpLHotKXmlrnlvI/ov5jmmK9cIuaVtOS4quS6i+WKoeS4reatolwi6ICM5LiN5piv5LiA5Liq5riF5pmw55qE6ZSZ6K+v44CCXG4gICAgcmV0dXJuIHRoaXMudHJhbnNhY3Rpb24oW3N0b3JlXSwgJ3JlYWR3cml0ZScsIGFzeW5jICh0eCkgPT4ge1xuICAgICAgYXdhaXQgdHguaXRlcmF0ZTxUPihzdG9yZSwgb3B0aW9ucywgdmlzaXQpO1xuICAgIH0pO1xuICB9XG5cbiAgLyoqXG4gICAqIOWIoOmZpOaVtOS4quaVsOaNruW6k++8iGBpbmRleGVkREIuZGVsZXRlRGF0YWJhc2Vg77yJ44CCXG4gICAqXG4gICAqIPCflLQgYG9uYmxvY2tlZGAgKirku6XliY3mmK8gYHJlc29sdmUoKWAg55qE77yM6YKj5piv5YGH5Yet5o2uKirvvJpibG9ja2VkIOeahOWQq+S5ieaYr1xuICAgKiBcIui/mOacieWIq+eahOagh+etvumhtS/nqpflj6PmjIHmnInov57mjqXvvIzliKDpmaTor7fmsYLmjpLlnKjlroPlkI7pnaJcIu+8jOatpOWIu+aVsOaNruW6kyoq6L+Y5ZyoKirjgIJcbiAgICog5b2T5Zy6IHJlc29sdmUg5Lya6K6p6ZSA5q+B5oql5ZGK5ZyoXCLku4DkuYjpg73msqHliKDmjolcIueahOaDheWGteS4i+ivtFwi5Yig5LqGXCLvvIxcbiAgICog6ICM6LCD55So5pa55ou/5Yiw55qE5q2j5piv6YKj5Y+l55So5p2l5a+555So5oi35om/6K+655qE6K+d44CCXG4gICAqIOeOsOWcqCBibG9ja2VkIOWPquaYryoq562J5b6FKirvvJrlhrPorq7lj6rmnaXoh6ogb25zdWNjZXNzIC8gb25lcnJvcuOAglxuICAgKlxuICAgKiDimqDvuI8g5Luj5Lu36KaB5oOz5riF5qWa77ya5Y+m5LiA5Liq5qCH562+6aG15rC45LiN5YWz6Zet5pe277yM6L+Z5LiqIFByb21pc2Ug5Lya5LiA55u05oyC552A44CCXG4gICAqIOi/meaYryoq6K+a5a6e55qEKirmjILotbfvvIhcIuaIkei/mOayoeWBmuWIsFwi77yJ77yM6ICM5LiN5piv6Jma5YGH55qE5a6M5oiQ77yIXCLmiJHlgZrliLDkuoZcIu+8ieOAglxuICAgKiDlrr/kuLvlpoLmnpzopoHnu5nnlKjmiLfkuIDkuKrmnJ/pmZDvvIzlupTor6XlnKgqKuiwg+eUqOi/meS4gOWxgueahOeVjOmdoioq5LiK5YGa6LaF5pe25bm26K+0XG4gICAqIFwi5Y+m5pyJ5LiA5Liq56qX5Y+j5byA552A77yM5YWz5o6J5a6D5omN6IO95riF5bmy5YeAXCIg4oCU4oCUIOmCo+S4jeaYr+i/meS4gOWxguiDveabv+eUqOaIt+WGs+WumueahOS6i+OAglxuICAgKi9cbiAgYXN5bmMgZGVzdHJveSgpOiBQcm9taXNlPERiRGVzdHJveVJlcG9ydD4ge1xuICAgIGlmICh0aGlzLmRlc3Ryb3lpbmcgIT09IHVuZGVmaW5lZCkgcmV0dXJuIHRoaXMuZGVzdHJveWluZztcbiAgICB0aGlzLmRlc3Ryb3llZCA9IHRydWU7XG4gICAgY29uc3QgcGVuZGluZyA9IChhc3luYyAoKTogUHJvbWlzZTxEYkRlc3Ryb3lSZXBvcnQ+ID0+IHtcbiAgICAgIHRoaXMuY2xvc2UoKTtcbiAgICAgIGF3YWl0IG5ldyBQcm9taXNlPHZvaWQ+KChyZXNvbHZlLCByZWplY3QpID0+IHtcbiAgICAgICAgY29uc3QgcmVxdWVzdCA9IGluZGV4ZWREQi5kZWxldGVEYXRhYmFzZSh0aGlzLmRiTmFtZSk7XG4gICAgICAgIHJlcXVlc3Qub25zdWNjZXNzID0gKCkgPT4gcmVzb2x2ZSgpO1xuICAgICAgICByZXF1ZXN0Lm9uZXJyb3IgPSAoKSA9PlxuICAgICAgICAgIHJlamVjdChzdG9yYWdlRXJyb3IocmVxdWVzdC5lcnJvciwgJ+WIoOmZpOaVsOaNruW6k+Wksei0pScsIHsga2luZDogJ3JlcXVlc3QtZmFpbGVkJyB9KSk7XG4gICAgICAgIHJlcXVlc3Qub25ibG9ja2VkID0gKCkgPT4ge1xuICAgICAgICAgIC8vIOS7gOS5iOmDveS4jeWBmu+8muetiSBvbnN1Y2Nlc3PjgILop4HkuIrpnaLpgqPmrrXjgIJcbiAgICAgICAgfTtcbiAgICAgIH0pO1xuICAgICAgcmV0dXJuIHsgdGFyZ2V0OiB0aGlzLmRiTmFtZSwgY29udGFpbmVyUmVtb3ZlZDogdHJ1ZSwgc3RvcmVzQ2xlYXJlZDogQUxMX1NUT1JFUy5sZW5ndGggfTtcbiAgICB9KSgpO1xuICAgIC8vIPCflLQg5aSx6LSl6KaB5oqK6Ze46Zeo5pKk5Zue5Y6777yaYGRlc3Ryb3llZGAg5Y+q5ZyoKirnnJ/nmoTliKDmjonkuoYqKuS5i+WQjuaJjeaIkOeri+OAglxuICAgIC8vIOiiq+WIq+eahOagh+etvumhteWgteS9j+iAjOacgOe7iCBgb25lcnJvcmAg5pe277yM6L+Z5Lu95bqT6L+Y5Zyo55uY5LiK77yM5a6e5L6L5LiN6K+l5YGH6KOF6Ieq5bex5L2c5bqf5LqGXG4gICAgLy8g77yI5ZCm5YiZXCLplIDmr4HlpLHotKVcIuS8muihqOeOsOaIkFwi6L+Z5Liq5bqU55So5LuO5q2k5LiN6IO955SoXCLvvIzogIzmraPnoa7lpITnva7mmK/ph43or5XvvInjgIJcbiAgICB0aGlzLmRlc3Ryb3lpbmcgPSBwZW5kaW5nLmNhdGNoKChlcnJvcjogdW5rbm93bikgPT4ge1xuICAgICAgdGhpcy5kZXN0cm95ZWQgPSBmYWxzZTtcbiAgICAgIHRoaXMuZGVzdHJveWluZyA9IHVuZGVmaW5lZDtcbiAgICAgIHRocm93IGVycm9yO1xuICAgIH0pO1xuICAgIHJldHVybiB0aGlzLmRlc3Ryb3lpbmc7XG4gIH1cbn1cblxuLyoqIOaJgOaciSBzdG9yZSDlkI3vvIjkvpvlu7rlupPkuI7mtYvor5Xmlq3oqIDvvInjgIIgKi9cbmV4cG9ydCBjb25zdCBBTExfU1RPUkVfTkFNRVM6IFN0b3JlTmFtZVtdID0gQUxMX1NUT1JFUztcbiIsIi8qKlxuICogU1FMaXRlIOmAgumFjeWZqCDigJTigJQgaU9TIC8gSGFybW9ueU9TIOeahOeUn+S6p+WtmOWCqOWunueOsO+8jOS5n+eUqOS6jiBOb2RlIOerr+agoemqjOOAglxuICpcbiAqIOWunueOsCB7QGxpbmsgRGJBZGFwdGVyfe+8jOW5tuS4lCoq5b+F6aG76YCa6L+H5LiOIEluZGV4ZWREQiAvIOWGheWtmOWunueOsOWujOWFqOebuOWQjOeahOmCo+S4gOWll1xuICog5YWx5Lqr5aWR57qmKirvvIhgdGVzdHMvY29udHJhY3QvYWRhcHRlci5jb250cmFjdC50c2DvvInjgILov5nmmK8gQURSLTAwMDMgwqcyLjIg55qE56Gs6KaB5rGC77yaXG4gKiDmjaLlkI7nq6/ml7bkuIrlsYLkuIDooYzkuI3nlKjmlLnjgIJcbiAqXG4gKiDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcbiAqIOS4ieS4quW/hemhu+WkhOeQhuWvueeahOiuvuiuoeeCue+8iOmDveaYr1wi55yL6LW35p2l6IO96LeR44CB5YW25a6e6ZSZ5LqGXCLnmoTlvaLnirbvvInvvJpcbiAqXG4gKiAxLiAqKvCflLQg6ZSu5bqP5b+F6aG75LiOIEluZGV4ZWREQiDkuIDoh7TjgIIqKlxuICogICAgSW5kZXhlZERCIOeahOmUruW6j+aYryBudW1iZXIgPCBzdHJpbmcgPCBhcnJheeOAglNRTGl0ZSDpu5jorqTnmoTliJfmr5TovoPmgbDlpb3mmK9cbiAqICAgIOaVsOWAvCA8IOaWh+acrO+8iOWtmOWCqOexu+mhuuW6j++8ie+8jCoq5L2G6L+Z5Y+q5pyJ5Zyo5YiX5rKh5pyJIE5VTUVSSUMg5Lqy5ZKM5oCn5pe25oiQ56uLKiog4oCU4oCUXG4gKiAgICDoi6XmiorkuLvplK7liJflo7DmmI7miJAgSU5URUdFUi9URVhU77yMU1FMaXRlIOS8muaKiiBgJzEyMydgIOi/meenjeaWh+acrOmUruaChOaChOi9rOaIkOaVsOWtl++8jFxuICogICAg5LqO5pivIGBtZXRhYCDnmoQgYFwia2V5XCJgIOS4jiBgXCIxMjNcImAg5Lya5pKe5Zyo5LiA6LW344CC5omA5Lul5omA5pyJ6ZSu5YiXKirkuI3lo7DmmI7nsbvlnosqKlxuICogICAg77yIQkxPQiDkurLlkozmgKfvvIzkuI3lgZrku7vkvZXovazmjaLvvInvvIzorqkgU1FMaXRlIOaMieWAvOiHqui6q+eahOWtmOWCqOexu+avlOi+g+OAglxuICogICAg5aSN5ZCI6ZSu5YiZ5ouG5oiQ5aSa5YiXIGBPUkRFUiBCWSBwazAsIHBrMWDvvJrpgJDliJfmr5TovoMgPSDmlbDnu4TpgJDlhYPntKDmr5TovoPvvIxcbiAqICAgIOS4lOavj+WIl+WGhemDqOeahCBudW1iZXIgPCBzdHJpbmcg5LiOIEluZGV4ZWREQiDnmoTlhYPntKDnsbvlnovluo/kuIDoh7TjgIJcbiAqICAgIOaVheaEjyoq5LiN55SoKiogSlNPTiDlrZfnrKbkuLLnvJbnoIHlpI3lkIjplK4g4oCU4oCUIOmCo+S8muaKiiBgMTBgIOaOkuWcqCBgMmAg5YmN6Z2i44CCXG4gKlxuICogMi4gKirkuovliqHlv4XpobvmmK/nnJ/nmoTjgIIqKiDljZXov57mjqUgU1FMaXRlIOeUqCBgQkVHSU4gSU1NRURJQVRFYCAvIGBDT01NSVRgIC9cbiAqICAgIGBST0xMQkFDS2DvvIzlubbkuJTmiYDmnInmk43kvZzpgJrov4cgRklGTyDpmJ/liJfkuLLooYzljJbvvIjosIPnlKjmlrnmsLjov5zkuI3liqDplIHvvInjgIJcbiAqICAgIOWbnua7muimhueblioq5bey5pyJ6K6w5b2V55qE5L+u5pS5KirvvJrmlbTmnaEgRE1MIOmDveWcqOWQjOS4gOS4qiBTUUxpdGUg5LqL5Yqh6YeM44CCXG4gKlxuICogMy4gKirllK/kuIDntKLlvJXlhrLnqoHml7bmlbTmnaHorrDlvZXkuI3lhaXlupPjgIIqKiDntKLlvJXlgLznm7TmjqXkvZzkuLrkuLvooajnmoTliJcgKyDnnJ/mraPnmoRcbiAqICAgIGBVTklRVUUgSU5ERVhg77yM5Yay56qB5Y+R55Sf5Zyo5Y2V5p2hIElOU0VSVCDkuIog4oCU4oCUIOS4jeS8mueVmeS4i1wi6K6w5b2V5Zyo44CB57Si5byV5LiN5ZyoXCJcbiAqICAgIOeahOWNiuaIqueKtuaAgeOAgmBhZGRUb2xlcmF0aW5nRHVwbGljYXRlYCDnmoTljrvph43or63kuYnkvp3otZblroPjgIJcbiAqIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuICovXG5cbmltcG9ydCB7XG4gIGFzc2VydEl0ZXJhdGVMaW1pdCxcbiAgREVGQVVMVF9JVEVSQVRFX0xJTUlULFxuICB0eXBlIERiQWRhcHRlcixcbiAgdHlwZSBEYkN1cnNvckFjdGlvbixcbiAgdHlwZSBEYkN1cnNvclZpc2l0b3IsXG4gIHR5cGUgRGJEZXN0cm95UmVwb3J0LFxuICB0eXBlIERiSW5kZXhRdWVyeSxcbiAgdHlwZSBEYkl0ZXJhdGVPcHRpb25zLFxuICB0eXBlIERiS2V5LFxuICB0eXBlIERiS2V5UmFuZ2UsXG4gIHR5cGUgRGJUeCxcbiAgdHlwZSBEYlR4TW9kZSxcbiAgdHlwZSBTdG9yZVNjaGVtYSxcbn0gZnJvbSAnLi4vZGIudHlwZXMuanMnO1xuaW1wb3J0IHR5cGUgeyBTcWxWYWx1ZSwgU3FsaXRlRHJpdmVyIH0gZnJvbSAnLi9zcWxpdGUtZHJpdmVyLmpzJztcbmltcG9ydCB7IEFkYXB0ZXJEZXN0cm95ZWRFcnJvciB9IGZyb20gJy4uL2Vycm9ycy5qcyc7XG5cbi8qKiDokL3ov5sgU1FMaXRlIOeahOmUruWIhumHj+OAgiAqL1xudHlwZSBLZXlWYWx1ZSA9IHN0cmluZyB8IG51bWJlcjtcblxuLyoqIOmpseWKqOi/lOWbnueahOS4gOihjOOAgiAqL1xudHlwZSBTcWxSb3cgPSBSZWNvcmQ8c3RyaW5nLCBTcWxWYWx1ZT47XG5cbi8qKiDmoIfor4bnrKblvJXnlKjjgIJzdG9yZSAvIGluZGV4IOWQjeadpeiHquS7o+eggeW4uOmHj++8jOS9huS7jeeEtuS4gOW+i+W8leeUqO+8jOmYsuatouWQjeWtl+mHjOWHuueOsOWFs+mUruWtl+OAgiAqL1xuY29uc3QgcSA9IChpZGVudGlmaWVyOiBzdHJpbmcpOiBzdHJpbmcgPT4gYFwiJHtpZGVudGlmaWVyLnJlcGxhY2UoL1wiL2csICdcIlwiJyl9XCJgO1xuXG4vKiog6Ieq5aKe6K6h5pWw5Zmo55qE6KGo5ZCN44CC54us56uL5LqO5Lia5YqhIHN0b3Jl77yM6YG/5YWN5rGh5p+TIGBBTExfU1RPUkVTYOOAgiAqL1xuY29uc3QgU0VRX1RBQkxFID0gJ19faGV5dGFfc2VxJztcblxuLy8g4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG4vLyDplK7mr5TovoMg4oCU4oCUIOW/hemhu+S4jiBJbmRleGVkREIg5LiA6Ie077yM6K+t5LmJ5LiOIGBtZW1vcnktYWRhcHRlci50c2Ag55u45ZCM44CCXG4vLyDvvIjlhoXlrZjlrp7njrDph4znmoQgY29tcGFyZUtleXMg5rKh5pyJ5a+85Ye677yb6L+Z6YeM5aSN5Yi25LiA5Lu96ICM5LiN5piv5Y675pS55Yqo5a6D77yMXG4vLyAg5Zug5Li65aWR57qm6KaB5rGCXCLlrp7njrDkuYvpl7Tlj6/mm7/mjaJcIu+8jOiAjOS4jeaYr1wi5a6e546w5LmL6Ze05LqS55u4IGltcG9ydFwi44CC77yJXG4vLyDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcblxuZnVuY3Rpb24ga2V5UmFuayhrOiB1bmtub3duKTogbnVtYmVyIHtcbiAgaWYgKHR5cGVvZiBrID09PSAnbnVtYmVyJykgcmV0dXJuIDA7XG4gIGlmICh0eXBlb2YgayA9PT0gJ3N0cmluZycpIHJldHVybiAyO1xuICBpZiAoQXJyYXkuaXNBcnJheShrKSkgcmV0dXJuIDQ7XG4gIHJldHVybiAzO1xufVxuXG5mdW5jdGlvbiBjb21wYXJlS2V5cyhhOiBLZXlWYWx1ZSB8IEtleVZhbHVlW10sIGI6IEtleVZhbHVlIHwgS2V5VmFsdWVbXSk6IG51bWJlciB7XG4gIGlmIChBcnJheS5pc0FycmF5KGEpIHx8IEFycmF5LmlzQXJyYXkoYikpIHtcbiAgICAvLyDmlbDnu4TkuI7moIfph4/kuI3lgZrpgJDlhYPntKDmr5TovoPvvIzlhYjmjInnsbvlnovluo/mjpLlvIBcbiAgICBpZiAoQXJyYXkuaXNBcnJheShhKSAhPT0gQXJyYXkuaXNBcnJheShiKSkgcmV0dXJuIGtleVJhbmsoYSkgLSBrZXlSYW5rKGIpO1xuICAgIGNvbnN0IGFyckEgPSBhIGFzIEtleVZhbHVlW107XG4gICAgY29uc3QgYXJyQiA9IGIgYXMgS2V5VmFsdWVbXTtcbiAgICBjb25zdCBsZW4gPSBNYXRoLm1pbihhcnJBLmxlbmd0aCwgYXJyQi5sZW5ndGgpO1xuICAgIGZvciAobGV0IGkgPSAwOyBpIDwgbGVuOyBpKyspIHtcbiAgICAgIGNvbnN0IGRpZmYgPSBjb21wYXJlS2V5cyhhcnJBW2ldISwgYXJyQltpXSEpO1xuICAgICAgaWYgKGRpZmYgIT09IDApIHJldHVybiBkaWZmO1xuICAgIH1cbiAgICByZXR1cm4gYXJyQS5sZW5ndGggLSBhcnJCLmxlbmd0aDtcbiAgfVxuXG4gIGNvbnN0IHJhbmtEaWZmID0ga2V5UmFuayhhKSAtIGtleVJhbmsoYik7XG4gIGlmIChyYW5rRGlmZiAhPT0gMCkgcmV0dXJuIHJhbmtEaWZmO1xuICBpZiAodHlwZW9mIGEgPT09ICdudW1iZXInICYmIHR5cGVvZiBiID09PSAnbnVtYmVyJykgcmV0dXJuIGEgLSBiO1xuICBjb25zdCBzYSA9IFN0cmluZyhhKTtcbiAgY29uc3Qgc2IgPSBTdHJpbmcoYik7XG4gIHJldHVybiBzYSA8IHNiID8gLTEgOiBzYSA+IHNiID8gMSA6IDA7XG59XG5cbmZ1bmN0aW9uIGtleUluUmFuZ2Uoa2V5OiBLZXlWYWx1ZSB8IEtleVZhbHVlW10sIHJhbmdlPzogRGJLZXlSYW5nZSk6IGJvb2xlYW4ge1xuICBpZiAocmFuZ2UgPT09IHVuZGVmaW5lZCkgcmV0dXJuIHRydWU7XG4gIGNvbnN0IHsgbG93ZXIsIHVwcGVyLCBsb3dlck9wZW4sIHVwcGVyT3BlbiB9ID0gcmFuZ2U7XG4gIGlmIChsb3dlciAhPT0gdW5kZWZpbmVkKSB7XG4gICAgY29uc3QgZGlmZiA9IGNvbXBhcmVLZXlzKGtleSwgbG93ZXIpO1xuICAgIGlmIChkaWZmIDwgMCB8fCAoZGlmZiA9PT0gMCAmJiBsb3dlck9wZW4gPT09IHRydWUpKSByZXR1cm4gZmFsc2U7XG4gIH1cbiAgaWYgKHVwcGVyICE9PSB1bmRlZmluZWQpIHtcbiAgICBjb25zdCBkaWZmID0gY29tcGFyZUtleXMoa2V5LCB1cHBlcik7XG4gICAgaWYgKGRpZmYgPiAwIHx8IChkaWZmID09PSAwICYmIHVwcGVyT3BlbiA9PT0gdHJ1ZSkpIHJldHVybiBmYWxzZTtcbiAgfVxuICByZXR1cm4gdHJ1ZTtcbn1cblxuLyoqIOayv+eCueWIhui3r+W+hOWPluWAvO+8iGBvcC5pZGAg6KaB6IO95Y+W5Yiw5bWM5aWX5a2X5q6177yJ44CCICovXG5mdW5jdGlvbiB2YWx1ZUF0UGF0aCh2YWx1ZTogdW5rbm93biwgcGF0aDogc3RyaW5nKTogdW5rbm93biB7XG4gIGxldCBjdXJyZW50OiB1bmtub3duID0gdmFsdWU7XG4gIGZvciAoY29uc3Qgc2VnbWVudCBvZiBwYXRoLnNwbGl0KCcuJykpIHtcbiAgICBpZiAoY3VycmVudCA9PT0gbnVsbCB8fCB0eXBlb2YgY3VycmVudCAhPT0gJ29iamVjdCcpIHJldHVybiB1bmRlZmluZWQ7XG4gICAgY3VycmVudCA9IChjdXJyZW50IGFzIFJlY29yZDxzdHJpbmcsIHVua25vd24+KVtzZWdtZW50XTtcbiAgfVxuICByZXR1cm4gY3VycmVudDtcbn1cblxuLyoqIOiHquWinuaXtuaKiumUruWGmeWbnuiusOW9le+8iGluLWxpbmUga2V577yJ77yM5LiOIEluZGV4ZWREQiAvIOWGheWtmOWunueOsOS4gOiHtOOAgiAqL1xuZnVuY3Rpb24gc2V0QXRQYXRoKHRhcmdldDogUmVjb3JkPHN0cmluZywgdW5rbm93bj4sIHBhdGg6IHN0cmluZywgdmFsdWU6IHVua25vd24pOiB2b2lkIHtcbiAgY29uc3Qgc2VnbWVudHMgPSBwYXRoLnNwbGl0KCcuJyk7XG4gIGxldCBjdXJyZW50OiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPiA9IHRhcmdldDtcbiAgZm9yIChsZXQgaSA9IDA7IGkgPCBzZWdtZW50cy5sZW5ndGggLSAxOyBpKyspIHtcbiAgICBjb25zdCBzZWdtZW50ID0gc2VnbWVudHNbaV0hO1xuICAgIGNvbnN0IG5leHQgPSBjdXJyZW50W3NlZ21lbnRdO1xuICAgIGlmIChuZXh0ID09PSBudWxsIHx8IHR5cGVvZiBuZXh0ICE9PSAnb2JqZWN0JykgY3VycmVudFtzZWdtZW50XSA9IHt9O1xuICAgIGN1cnJlbnQgPSBjdXJyZW50W3NlZ21lbnRdIGFzIFJlY29yZDxzdHJpbmcsIHVua25vd24+O1xuICB9XG4gIGN1cnJlbnRbc2VnbWVudHNbc2VnbWVudHMubGVuZ3RoIC0gMV0hXSA9IHZhbHVlO1xufVxuXG5mdW5jdGlvbiBpc0tleVZhbHVlKHY6IHVua25vd24pOiB2IGlzIEtleVZhbHVlIHtcbiAgcmV0dXJuIHR5cGVvZiB2ID09PSAnc3RyaW5nJyB8fCB0eXBlb2YgdiA9PT0gJ251bWJlcic7XG59XG5cbi8vIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuLy8gc2NoZW1hIOKGkiDniannkIborqHliJJcbi8vIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuXG5pbnRlcmZhY2UgSW5kZXhQbGFuIHtcbiAgbmFtZTogc3RyaW5nO1xuICAvKiog5Li76KGo5Lit5om/6L2957Si5byV5YC855qE5YiX77yIbXVsdGlFbnRyeSDmsqHmnInlhoXogZTliJfvvInjgIIgKi9cbiAgY29sdW1uczogc3RyaW5nW107XG4gIG11bHRpRW50cnk6IGJvb2xlYW47XG4gIHVuaXF1ZTogYm9vbGVhbjtcbiAgLyoqIG11bHRpRW50cnkg55qE5a2Q6KGo77yI5LiA5p2h6K6w5b2V5LiA5p2h57Si5byV6aG555qE5bGV5byA57uT5p6c77yJ44CCICovXG4gIGNoaWxkVGFibGU/OiBzdHJpbmc7XG4gIGNoaWxkSW5kZXg/OiBzdHJpbmc7XG4gIC8qKiDlvZLkuIDljJblkI7nmoQga2V5UGF0aCDliIbph4/jgIIgKi9cbiAgcGF0aHM6IHN0cmluZ1tdO1xufVxuXG5pbnRlcmZhY2UgU3RvcmVQbGFuIHtcbiAgc2NoZW1hOiBTdG9yZVNjaGVtYTtcbiAgdGFibGU6IHN0cmluZztcbiAgcGtDb2x1bW5zOiBzdHJpbmdbXTtcbiAgcGtQYXRoczogc3RyaW5nW107XG4gIGRhdGFDb2x1bW46IHN0cmluZztcbiAgaW5kZXhlczogSW5kZXhQbGFuW107XG4gIGJ5TmFtZTogTWFwPHN0cmluZywgSW5kZXhQbGFuPjtcbn1cblxuZnVuY3Rpb24gYnVpbGRTdG9yZVBsYW4oc2NoZW1hOiBTdG9yZVNjaGVtYSk6IFN0b3JlUGxhbiB7XG4gIGNvbnN0IHRhYmxlID0gc2NoZW1hLm5hbWU7XG4gIGNvbnN0IHBrUGF0aHMgPSB0eXBlb2Ygc2NoZW1hLmtleVBhdGggPT09ICdzdHJpbmcnID8gW3NjaGVtYS5rZXlQYXRoXSA6IFsuLi5zY2hlbWEua2V5UGF0aF07XG4gIGNvbnN0IHBrQ29sdW1ucyA9IHBrUGF0aHMubWFwKChfcCwgaSkgPT4gYHBrJHtpfWApO1xuXG4gIGNvbnN0IGluZGV4ZXM6IEluZGV4UGxhbltdID0gW107XG4gIGNvbnN0IGJ5TmFtZSA9IG5ldyBNYXA8c3RyaW5nLCBJbmRleFBsYW4+KCk7XG5cbiAgKHNjaGVtYS5pbmRleGVzID8/IFtdKS5mb3JFYWNoKChpbmRleCwgb3JkaW5hbCkgPT4ge1xuICAgIGNvbnN0IHBhdGhzID0gdHlwZW9mIGluZGV4LmtleVBhdGggPT09ICdzdHJpbmcnID8gW2luZGV4LmtleVBhdGhdIDogWy4uLmluZGV4LmtleVBhdGhdO1xuICAgIGlmIChpbmRleC5tdWx0aUVudHJ5ID09PSB0cnVlICYmIHBhdGhzLmxlbmd0aCAhPT0gMSkge1xuICAgICAgLy8gSW5kZXhlZERCIOacrOi6q+S5n+emgeatoiBtdWx0aUVudHJ5IOS9v+eUqOaVsOe7hCBrZXlQYXRo77yISW52YWxpZEFjY2Vzc0Vycm9y77yJ44CCXG4gICAgICAvLyDkuI7lhbbpnZnpu5jmjInlhoXlrZjlrp7njrDnmoRcIuWxleW8gOaVsOe7hFwi6K+t5LmJ6LeR77yM5LiN5aaC5Zyo6L+Z6YeM5piO56Gu5ouS57ud44CCXG4gICAgICB0aHJvdyBuZXcgRXJyb3IoXG4gICAgICAgIGDntKLlvJXjgIwke2luZGV4Lm5hbWV944CN77yabXVsdGlFbnRyeSDlj6rmlK/mjIHljZXkuKoga2V5UGF0aO+8jOaUtuWIsCAke0pTT04uc3RyaW5naWZ5KGluZGV4LmtleVBhdGgpfWAsXG4gICAgICApO1xuICAgIH1cbiAgICBjb25zdCBwbGFuOiBJbmRleFBsYW4gPSB7XG4gICAgICBuYW1lOiBpbmRleC5uYW1lLFxuICAgICAgbXVsdGlFbnRyeTogaW5kZXgubXVsdGlFbnRyeSA9PT0gdHJ1ZSxcbiAgICAgIHVuaXF1ZTogaW5kZXgudW5pcXVlID09PSB0cnVlLFxuICAgICAgcGF0aHMsXG4gICAgICBjb2x1bW5zOiBpbmRleC5tdWx0aUVudHJ5ID09PSB0cnVlID8gW10gOiBwYXRocy5tYXAoKF9wLCBpKSA9PiBgaXgke29yZGluYWx9XyR7aX1gKSxcbiAgICAgIGNoaWxkVGFibGU6IGluZGV4Lm11bHRpRW50cnkgPT09IHRydWUgPyBgJHt0YWJsZX1fX210JHtvcmRpbmFsfWAgOiB1bmRlZmluZWQsXG4gICAgICBjaGlsZEluZGV4OiBpbmRleC5tdWx0aUVudHJ5ID09PSB0cnVlID8gYCR7dGFibGV9X19tdCR7b3JkaW5hbH1fZWxlbWAgOiB1bmRlZmluZWQsXG4gICAgfTtcbiAgICBpbmRleGVzLnB1c2gocGxhbik7XG4gICAgYnlOYW1lLnNldChwbGFuLm5hbWUsIHBsYW4pO1xuICB9KTtcblxuICByZXR1cm4geyBzY2hlbWEsIHRhYmxlLCBwa0NvbHVtbnMsIHBrUGF0aHMsIGRhdGFDb2x1bW46ICdkYXRhJywgaW5kZXhlcywgYnlOYW1lIH07XG59XG5cbmNsYXNzIFNxbGl0ZUFkYXB0ZXIgaW1wbGVtZW50cyBEYkFkYXB0ZXIge1xuICBwcml2YXRlIHJlYWRvbmx5IHBsYW5zOiBTdG9yZVBsYW5bXSA9IFtdO1xuICBwcml2YXRlIHJlYWRvbmx5IHBsYW5CeU5hbWUgPSBuZXcgTWFwPHN0cmluZywgU3RvcmVQbGFuPigpO1xuICBwcml2YXRlIGRyaXZlcjogU3FsaXRlRHJpdmVyIHwgdW5kZWZpbmVkO1xuICBwcml2YXRlIG9wZW5pbmc6IFByb21pc2U8U3FsaXRlRHJpdmVyPiB8IHVuZGVmaW5lZDtcblxuICAvKipcbiAgICog6ZSA5q+B5Y2z5q276Lev77yI5om55qyhIEUyIOWPo+W+hCBC77yJ44CCXG4gICAqXG4gICAqIPCflLQg5oyh55qE5piv6L+Z5LiA5p2h77yaYGRlc3Ryb3koKWAg5oqK6L+e5o6l5YWz5o6J5bm25oqK5paH5Lu25Yig5LqG77yM6ICM5q2k5ZCOKirku7vkvZXkuIDmrKHmma7pgJror7sqKlxuICAgKiDpg73kvJrotbAgYGVuc3VyZU9wZW4oKWAg55qE6YeN5byA6Lev5b6EIOKAlOKAlCDkuo7mmK/liJrliKDmjonnmoTlrrnlmajooqvph43mlrDlu7rmiJDkuIDlvKDnqbrlo7NcbiAgICog77yI5a6e5rWLIDczNzI4IOWtl+iKgiAvIDYg5byg56m66KGo77yM5a2X6IqC5pWw5LiOIGlPUyDorr7lpIfnuqfpgqPmnprmrovnlZnpgJDlrZfnm7jlkIzvvIzop4HorqHliJIgwqcxMC4xNDbvvInjgIJcbiAgICog6YKj5LiA6Laf6YeMXCLplIDmr4HmiJDlip9cIueahOaKpeWRiuWSjFwi55uY5LiK5Y+I5pyJ5bqT5LqGXCLmmK8qKuWQjOS4gOenkioq5omT5Y2w55qE77yM6ICM6K+75Ye65p2l55qE5YaF5a65XG4gICAqIOehruWunuaYr+epuueahCDih5Ig5q+P5LiA5bGC6YO96KeJ5b6X6Ieq5bex5rKh6K+06LCO44CCXG4gICAqL1xuICBwcml2YXRlIGRlc3Ryb3llZCA9IGZhbHNlO1xuXG4gIC8qKiDnrKzkuozmrKEgYGRlc3Ryb3koKWAg6LWw6L+Z5Lu957yT5a2Y77yM6ICM5LiN5piv5oqKXCLliKDkuIDpgY1cIuWGjei3keS4gOasoe+8iOmCo+mcgOimgeWFiOmHjeW8gO+8ieOAgiAqL1xuICBwcml2YXRlIGRlc3Ryb3lpbmc6IFByb21pc2U8RGJEZXN0cm95UmVwb3J0PiB8IHVuZGVmaW5lZDtcblxuICAvKipcbiAgICogRklGTyDpmJ/liJfjgILljZXov57mjqUgU1FMaXRlIOS4jeiDveW5tuWPkei3keS6i+WKoe+8jOaJgOS7pemAgumFjeWZqOiHquW3seaOkumYnyDigJTigJRcbiAgICog6L+Z5q2j5pivIGBEYkFkYXB0ZXJgIOWlkee6plwi6LCD55So5pa55LiN6ZyA6KaB5Yqg6ZSBXCLnmoTokL3lnLDmlrnlvI/jgIJcbiAgICovXG4gIHByaXZhdGUgcXVldWU6IFByb21pc2U8dW5rbm93bj4gPSBQcm9taXNlLnJlc29sdmUoKTtcblxuICAvKipcbiAgICog5bWM5aWX5qOA5rWL5Y+q6KaG55uWKirlkIzmraXliY3nvIAqKu+8jOWPluiIjeS4jueQhueUseWQjCBgbWVtb3J5LWFkYXB0ZXIudHNg77yaXG4gICAqIOeUqOS4gOS4quWFqOWxgOW4g+WwlOS8muaKiioq5bm25Y+RKirkuZ/lvZPmiJDltYzlpZfmi6bkuIvmnaXvvIzogIzlubblj5HmmK/lpZHnuqbmmI7noa7opoHmsYLnmoTlkIjms5XnlKjms5XjgIJcbiAgICovXG4gIHByaXZhdGUgc3luY0RlcHRoID0gMDtcblxuICAvKipcbiAgICog4pqg77iPIOazqOWFpeeahOaYr+mpseWKqCoq5bel5Y6CKirogIzkuI3mmK/pqbHliqjlrp7kvovjgILljp/lm6DvvJpgRGJBZGFwdGVyLmNsb3NlKClgIOimgeaxglxuICAgKiBcIuWQjue7reaTjeS9nOmAj+aYjumHjeW8gFwi77yM6ICM5LiA5Liq5beyIGBjbG9zZSgpYCDnmoTpqbHliqjlrp7kvovml6Dms5XlpI3mtLvjgIJcbiAgICog5bel5Y6C6K6pIGNsb3NlIOKGkiDph43lvIDmiJDnq4vvvIjljp/nlJ/nq6/mr4/mrKHph43lvIDms6jlhaXmlrDnmoTlj6Xmn4TvvInjgIJcbiAgICovXG4gIHByaXZhdGUgcmVhZG9ubHkgZHJpdmVyRmFjdG9yeTogKCkgPT4gU3FsaXRlRHJpdmVyO1xuXG4gIGNvbnN0cnVjdG9yKG9wdGlvbnM6IFNxbGl0ZUFkYXB0ZXJPcHRpb25zKSB7XG4gICAgdGhpcy5kcml2ZXJGYWN0b3J5ID0gb3B0aW9ucy5kcml2ZXJGYWN0b3J5O1xuICAgIGZvciAoY29uc3Qgc2NoZW1hIG9mIG9wdGlvbnMuc2NoZW1hKSB7XG4gICAgICBjb25zdCBwbGFuID0gYnVpbGRTdG9yZVBsYW4oc2NoZW1hKTtcbiAgICAgIHRoaXMucGxhbnMucHVzaChwbGFuKTtcbiAgICAgIHRoaXMucGxhbkJ5TmFtZS5zZXQocGxhbi50YWJsZSwgcGxhbik7XG4gICAgfVxuICB9XG5cbiAgLy8g4pSA4pSAIOeUn+WRveWRqOacnyDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcblxuICBpbml0KCk6IFByb21pc2U8dm9pZD4ge1xuICAgIHJldHVybiB0aGlzLmVuc3VyZU9wZW4oKS50aGVuKCgpID0+IHVuZGVmaW5lZCk7XG4gIH1cblxuICBjbG9zZSgpOiB2b2lkIHtcbiAgICB0aGlzLmRyaXZlcj8uY2xvc2UoKTtcbiAgICB0aGlzLmRyaXZlciA9IHVuZGVmaW5lZDtcbiAgICB0aGlzLm9wZW5pbmcgPSB1bmRlZmluZWQ7XG4gIH1cblxuICAvKipcbiAgICog6ZSA5q+B6L+Z5Lu95bqT77yaKirmjpLnqbrlnKjpgJTkuovliqEg4oaSIERST1Ag5YWo6YOo6KGoIOKGkiBWQUNVVU0g4oaSIGNsb3NlIOKGkiDorqnpqbHliqjliKDmlofku7YqKuOAglxuICAgKlxuICAgKiDwn5S0IOS4uuS7gOS5iOS4jVwi6YCQ6KGMIGBERUxFVEUgRlJPTWAg5bCx5aSf5LqGXCLvvIjov5nkuIDniYjkuYvliY3nmoTlgZrms5XmmK/moLnmnKzmsqHmnInov5nkuIDmraXvvInvvJpcbiAgICogIGBERUxFVEUgRlJPTWAg5Y+q5oqK6aG15qCH5oiQ56m66Zey77yMKirlhoXlrrnov5jlnKjmlofku7bph4wqKu+8jOiAjCBTUUxpdGUg6buY6K6k6L+Y5LyaXG4gICAqICDnu6fnu63mioogV0FMIOWGmeWIsCBgLXdhbGDjgIJgVkFDVVVNYCDph43lhpnmlbTkuKrlupPmlofku7bvvIzmiornqbrpl7LpobXkuKLlm57ljrvvvJtcbiAgICogIOecn+ato+eahOaUtuWwvuaYryoq5Yig5paH5Lu2KirvvIhgZHJpdmVyLnJlbW92ZURhdGFiYXNlYO+8ieKAlOKAlCDliKDkuI3mjonml7ZcbiAgICogIOaKpeWRiumHjOW/hemhu+WGmea4hVwi5a655Zmo6L+Y5ZyoXCLvvIzosIPnlKjmlrnmiY3nn6XpgZPoh6rlt7Hmib/or7rkuoblpJrlsJHjgIJcbiAgICpcbiAgICog8J+UtCAqKui1sOmYn+WIlyoq77yI5LiOIGB0cmFuc2FjdGlvbmAg5ZCM5LiA5p2hIGB0aGlzLnF1ZXVlYO+8ie+8mumUgOavgeS4juWGmeWFpeW5tuWPkeaXtu+8jFxuICAgKiAg5LiN5YWl6Zif5Lya6K6pXCLlhpnlrozlj4jokL3lm57mnaVcIueahCBvcCDlnKggRFJPUCDkuYvlkI7ph43mlrDlu7rooagg4oCU4oCUXG4gICAqICDpgqPml7bmiqXlkYrlt7Lnu4/or7TkuoZcIumUgOavgeaIkOWKn1wi77yM6ICM5pWw5o2u6L+Y5Zyo44CC6L+Z5piv5pys5p2h5aWR57qm5ZSv5LiA55yf5q2j6KaB6Ziy55qE56ue5oCB44CCXG4gICAqL1xuICBhc3luYyBkZXN0cm95KCk6IFByb21pc2U8RGJEZXN0cm95UmVwb3J0PiB7XG4gICAgLy8g5bmC562J77ya56ys5LqM5qyh6ZSA5q+BKirkuI3orrgqKumHjeW8gOi/meS7veW6k++8iOmCo+ato+aYr+S4iumdoumCo+aemuepuuWjs+eahOadpei3r++8ie+8jFxuICAgIC8vIOiAjOaYr+aKiuesrOS4gOasoeeahOS5pumdouWHreaNruWOn+agt+S6pOWbnuWOu+OAglxuICAgIGlmICh0aGlzLmRlc3Ryb3lpbmcgIT09IHVuZGVmaW5lZCkgcmV0dXJuIHRoaXMuZGVzdHJveWluZztcblxuICAgIGNvbnN0IHJ1biA9IGFzeW5jICgpOiBQcm9taXNlPERiRGVzdHJveVJlcG9ydD4gPT4ge1xuICAgICAgLy8g5Y2z5L2/6L+Z5Lu95bqT6L+Z5qyh5LuO5rKh5byA6L+H5Lmf6KaB5byA5LiA5LiL77ya5paH5Lu25Y+v6IO955Sx5LiK5LiA5qyh6L+Q6KGM55WZ5LiL77yMXG4gICAgICAvLyDogIxcIumUgOavgeS4gOS7veayoeaJk+W8gOi/h+eahOW6k1wi5b+F6aG75pivKirluYLnrYnmiJDlip8qKu+8jOS4jeaYr+epuuaTjeS9nOOAglxuICAgICAgY29uc3QgZHJpdmVyID0gYXdhaXQgdGhpcy5lbnN1cmVPcGVuKCk7XG5cbiAgICAgIGxldCBzdG9yZXNDbGVhcmVkID0gMDtcbiAgICAgIGZvciAoY29uc3QgcGxhbiBvZiB0aGlzLnBsYW5zKSB7XG4gICAgICAgIGRyaXZlci5leGVjKGBEUk9QIFRBQkxFIElGIEVYSVNUUyAke3EocGxhbi50YWJsZSl9YCk7XG4gICAgICAgIHN0b3Jlc0NsZWFyZWQgKz0gMTtcbiAgICAgICAgZm9yIChjb25zdCBpbmRleCBvZiBwbGFuLmluZGV4ZXMpIHtcbiAgICAgICAgICBpZiAoaW5kZXgubXVsdGlFbnRyeSAhPT0gdHJ1ZSkgY29udGludWU7XG4gICAgICAgICAgZHJpdmVyLmV4ZWMoYERST1AgVEFCTEUgSUYgRVhJU1RTICR7cShpbmRleC5jaGlsZFRhYmxlISl9YCk7XG4gICAgICAgICAgc3RvcmVzQ2xlYXJlZCArPSAxO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgICBkcml2ZXIuZXhlYyhgRFJPUCBUQUJMRSBJRiBFWElTVFMgJHtxKFNFUV9UQUJMRSl9YCk7XG4gICAgICBzdG9yZXNDbGVhcmVkICs9IDE7XG4gICAgICAvLyDkuKLmjonnqbrpl7LpobXph4zmrovnlZnnmoTmmI7mlofvvIjlrrnlmajliKDkuI3mjonml7bvvIzov5nmmK/llK/kuIDnmoTooaXmlZHvvIzkuJTkuI3lrozlpIfvvInjgIJcbiAgICAgIGRyaXZlci5leGVjKCdWQUNVVU0nKTtcblxuICAgICAgdGhpcy5jbG9zZSgpO1xuICAgICAgLy8g5LuO6L+Z5LiA6KGM6LW36L+Z5Liq5a6e5L6L5bCx5piv5q276Lev77yaYGNsb3NlKClgIOeahOWlkee6puaYr1wi5ZCO57ut5pON5L2c6YCP5piO6YeN5byAXCLvvIxcbiAgICAgIC8vIOiAjOmUgOavgeeahOWlkee6puaYryoq5LiN6K64Kirph43lvIDvvIjop4HkuIrpnaIgYGRlc3Ryb3llZGAg6YKj5q6177yJ44CCXG4gICAgICB0aGlzLmRlc3Ryb3llZCA9IHRydWU7XG5cbiAgICAgIGlmIChkcml2ZXIucmVtb3ZlRGF0YWJhc2UgPT09IHVuZGVmaW5lZCkge1xuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgIHRhcmdldDogJ3NxbGl0ZScsXG4gICAgICAgICAgY29udGFpbmVyUmVtb3ZlZDogZmFsc2UsXG4gICAgICAgICAgcmVhc29uOiAn6L+Z5Liq6amx5Yqo5rKh5pyJIHJlbW92ZURhdGFiYXNl77yI5Y6f55Sf5qGl5bCa5pyq5a6e546w77yM6KeB5om55qyhIEXvvInvvJrlhoXlrrnlt7LmuIXnqbrvvIzmlofku7bku43lnKgnLFxuICAgICAgICAgIHN0b3Jlc0NsZWFyZWQsXG4gICAgICAgIH07XG4gICAgICB9XG4gICAgICBjb25zdCByZW1vdmFsID0gYXdhaXQgZHJpdmVyLnJlbW92ZURhdGFiYXNlKCk7XG4gICAgICByZXR1cm4geyAuLi5yZW1vdmFsLCBzdG9yZXNDbGVhcmVkIH07XG4gICAgfTtcblxuICAgIGNvbnN0IHJlc3VsdCA9IHRoaXMucXVldWUudGhlbihydW4sIHJ1bik7XG4gICAgLy8g8J+UtCDplIDmr4EqKuWksei0pSoq5LiN6K645oqK6L+Z5Liq5a6e5L6L5rC45LmF6ZSB5q2777ya6KKr5aC15L2PL+WIoOaWh+S7tuaKpemUmeaXtuW6k+i/mOWcqOebmOS4iu+8jFxuICAgIC8vIOiwg+eUqOaWueeahOato+ehruWkhOe9ruaYr+mHjeivle+8jOiAjOS4jeaYr+S7juatpOavj+asoeivu+mDveaKm1wi5bey6ZSA5q+BXCLjgIJcbiAgICAvLyDmiJDlip/ml7bmiY3nlZnkuIvnvJPlrZjvvIjnrKzkuozmrKEgZGVzdHJveSDnm7TmjqXlpI3nlKjnrKzkuIDmrKHnmoTkuabpnaLlh63mja7vvInjgIJcbiAgICB0aGlzLmRlc3Ryb3lpbmcgPSByZXN1bHQuY2F0Y2goKGVycm9yOiB1bmtub3duKSA9PiB7XG4gICAgICB0aGlzLmRlc3Ryb3lpbmcgPSB1bmRlZmluZWQ7XG4gICAgICB0aGlzLmRlc3Ryb3llZCA9IGZhbHNlO1xuICAgICAgdGhyb3cgZXJyb3I7XG4gICAgfSk7XG4gICAgdGhpcy5xdWV1ZSA9IHJlc3VsdC50aGVuKFxuICAgICAgKCkgPT4gdW5kZWZpbmVkLFxuICAgICAgKCkgPT4gdW5kZWZpbmVkLFxuICAgICk7XG4gICAgcmV0dXJuIHRoaXMuZGVzdHJveWluZztcbiAgfVxuXG4gIC8qKiDmiZPlvIDov57mjqXlubblu7ogc2NoZW1h44CC5bmC562J77yIYENSRUFURSAuLi4gSUYgTk9UIEVYSVNUU2DvvInvvIzlj6/lubblj5HosIPnlKjjgIIgKi9cbiAgcHJpdmF0ZSBlbnN1cmVPcGVuKCk6IFByb21pc2U8U3FsaXRlRHJpdmVyPiB7XG4gICAgLy8g8J+UtCDov5nkuIDooYzmmK8gRTIg5Y+j5b6EIEIg55qE5YWo6YOo6JC954K577ya6ZSA5q+B5LmL5ZCOKirmsqHmnIkqKlwi6YCP5piO6YeN5byAXCLov5nmnaHot6/jgIJcbiAgICAvLyDmipvplJnogIzkuI3mmK/ov5Tlm57nqbrnu5Pmnpwg4oCU4oCUIOWQjuiAheS8muiuqeS4iuWxguaKilwi6K+75YiwIDAg5p2hXCLlvZPmiJBcIuW6k+aYr+epuueahFwi77yMXG4gICAgLy8g6ICM55yf5q2j5Y+R55Sf55qE5LqL5oOF5piv5a655Zmo5Yia5Yia6KKr6YeN5bu644CCXG4gICAgaWYgKHRoaXMuZGVzdHJveWVkKSByZXR1cm4gUHJvbWlzZS5yZWplY3QobmV3IEFkYXB0ZXJEZXN0cm95ZWRFcnJvcignc3FsaXRlJykpO1xuICAgIGlmICh0aGlzLmRyaXZlciAhPT0gdW5kZWZpbmVkKSByZXR1cm4gUHJvbWlzZS5yZXNvbHZlKHRoaXMuZHJpdmVyKTtcbiAgICBpZiAodGhpcy5vcGVuaW5nICE9PSB1bmRlZmluZWQpIHJldHVybiB0aGlzLm9wZW5pbmc7XG4gICAgdGhpcy5vcGVuaW5nID0gUHJvbWlzZS5yZXNvbHZlKCkudGhlbigoKSA9PiB7XG4gICAgICBjb25zdCBkcml2ZXIgPSB0aGlzLmRyaXZlckZhY3RvcnkoKTtcbiAgICAgIHRyeSB7XG4gICAgICAgIHRoaXMuY3JlYXRlU2NoZW1hKGRyaXZlcik7XG4gICAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgICBkcml2ZXIuY2xvc2UoKTtcbiAgICAgICAgdGhpcy5vcGVuaW5nID0gdW5kZWZpbmVkO1xuICAgICAgICB0aHJvdyBlcnJvcjtcbiAgICAgIH1cbiAgICAgIHRoaXMuZHJpdmVyID0gZHJpdmVyO1xuICAgICAgcmV0dXJuIGRyaXZlcjtcbiAgICB9KTtcbiAgICByZXR1cm4gdGhpcy5vcGVuaW5nO1xuICB9XG5cbiAgcHJpdmF0ZSBjcmVhdGVTY2hlbWEoZHJpdmVyOiBTcWxpdGVEcml2ZXIpOiB2b2lkIHtcbiAgICBmb3IgKGNvbnN0IHBsYW4gb2YgdGhpcy5wbGFucykge1xuICAgICAgY29uc3QgZGVmaW5pdGlvbnMgPSBbXG4gICAgICAgIC8vIOmUruWIly/ntKLlvJXliJfmlYXmhI8qKuS4jeWjsOaYjuexu+WeiyoqIOKGkiBCTE9CIOS6suWSjOaApyDihpIg5LiN5YGa5pWw5YC86L2s5o2i44CCXG4gICAgICAgIC4uLnBsYW4ucGtDb2x1bW5zLm1hcCgoYykgPT4gcShjKSksXG4gICAgICAgIC4uLnBsYW4uaW5kZXhlc1xuICAgICAgICAgIC5maWx0ZXIoKGkpID0+ICFpLm11bHRpRW50cnkpXG4gICAgICAgICAgLmZsYXRNYXAoKGkpID0+IGkuY29sdW1ucy5tYXAoKGMpID0+IHEoYykpKSxcbiAgICAgICAgYCR7cShwbGFuLmRhdGFDb2x1bW4pfSBURVhUIE5PVCBOVUxMYCxcbiAgICAgICAgYFBSSU1BUlkgS0VZICgke3BsYW4ucGtDb2x1bW5zLm1hcChxKS5qb2luKCcsICcpfSlgLFxuICAgICAgXTtcbiAgICAgIGRyaXZlci5leGVjKFxuICAgICAgICBgQ1JFQVRFIFRBQkxFIElGIE5PVCBFWElTVFMgJHtxKHBsYW4udGFibGUpfSAoJHtkZWZpbml0aW9ucy5qb2luKCcsICcpfSlgLFxuICAgICAgKTtcblxuICAgICAgZm9yIChjb25zdCBpbmRleCBvZiBwbGFuLmluZGV4ZXMpIHtcbiAgICAgICAgaWYgKGluZGV4Lm11bHRpRW50cnkpIHtcbiAgICAgICAgICBkcml2ZXIuZXhlYyhcbiAgICAgICAgICAgIGBDUkVBVEUgVEFCTEUgSUYgTk9UIEVYSVNUUyAke3EoaW5kZXguY2hpbGRUYWJsZSEpfSAoJHtbXG4gICAgICAgICAgICAgIC4uLnBsYW4ucGtDb2x1bW5zLm1hcCgoYykgPT4gcShjKSksXG4gICAgICAgICAgICAgICdcImVsZW1cIicsXG4gICAgICAgICAgICBdLmpvaW4oJywgJyl9KWAsXG4gICAgICAgICAgKTtcbiAgICAgICAgICBkcml2ZXIuZXhlYyhcbiAgICAgICAgICAgIGBDUkVBVEUgSU5ERVggSUYgTk9UIEVYSVNUUyAke3EoaW5kZXguY2hpbGRJbmRleCEpfSBPTiAke3EoaW5kZXguY2hpbGRUYWJsZSEpfSAoXCJlbGVtXCIpYCxcbiAgICAgICAgICApO1xuICAgICAgICAgIGNvbnRpbnVlO1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IHVuaXF1ZSA9IGluZGV4LnVuaXF1ZSA/ICdVTklRVUUgJyA6ICcnO1xuICAgICAgICBkcml2ZXIuZXhlYyhcbiAgICAgICAgICBgQ1JFQVRFICR7dW5pcXVlfUlOREVYIElGIE5PVCBFWElTVFMgJHtxKGAke3BsYW4udGFibGV9X19pJHtpbmRleC5jb2x1bW5zWzBdfWApfSBgICtcbiAgICAgICAgICAgIGBPTiAke3EocGxhbi50YWJsZSl9ICgke2luZGV4LmNvbHVtbnMubWFwKHEpLmpvaW4oJywgJyl9KWAsXG4gICAgICAgICk7XG4gICAgICB9XG4gICAgfVxuXG4gICAgZHJpdmVyLmV4ZWMoXG4gICAgICBgQ1JFQVRFIFRBQkxFIElGIE5PVCBFWElTVFMgJHtxKFNFUV9UQUJMRSl9IChcInN0b3JlXCIgVEVYVCBQUklNQVJZIEtFWSwgXCJuZXh0XCIgSU5URUdFUiBOT1QgTlVMTClgLFxuICAgICk7XG4gIH1cblxuICAvLyDilIDilIAg5LqL5YqhIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuXG4gIHRyYW5zYWN0aW9uPFQ+KFxuICAgIHN0b3Jlczogc3RyaW5nW10sXG4gICAgX21vZGU6IERiVHhNb2RlLFxuICAgIGZuOiAodHg6IERiVHgpID0+IFByb21pc2U8VD4sXG4gICk6IFByb21pc2U8VD4ge1xuICAgIGlmICh0aGlzLnN5bmNEZXB0aCA+IDApIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcign5LiN5pSv5oyB5bWM5aWX5LqL5Yqh77ya5Zyo5LqL5Yqh6YeM5Y+I6LCD55So5LqGIHRyYW5zYWN0aW9uKCknKTtcbiAgICB9XG4gICAgLy8g5o+Q5YmN5ZCM5q2l5qCh6aqM77yM6K6pXCJzdG9yZSDmi7zplJkv5pyq5YiX5YWlXCLnq4vliLvngrjvvIzogIzkuI3mmK/mjpLliLDpmJ/lsL7miY3ngrhcbiAgICBmb3IgKGNvbnN0IG5hbWUgb2Ygc3RvcmVzKSB7XG4gICAgICBpZiAoIXRoaXMucGxhbkJ5TmFtZS5oYXMobmFtZSkpIHtcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKFxuICAgICAgICAgIGDkuovliqHorr/pl67kuobmnKrlrprkuYnnmoQgc3RvcmXvvJrjgIwke25hbWV944CN44CC5bey5a6a5LmJ77yaJHtbLi4udGhpcy5wbGFuQnlOYW1lLmtleXMoKV0uam9pbignLCAnKX1gLFxuICAgICAgICApO1xuICAgICAgfVxuICAgIH1cblxuICAgIGNvbnN0IHJ1biA9IGFzeW5jICgpOiBQcm9taXNlPFQ+ID0+IHtcbiAgICAgIGNvbnN0IGRyaXZlciA9IGF3YWl0IHRoaXMuZW5zdXJlT3BlbigpO1xuICAgICAgZHJpdmVyLmV4ZWMoJ0JFR0lOIElNTUVESUFURScpO1xuICAgICAgbGV0IHBlbmRpbmc6IFByb21pc2U8VD47XG4gICAgICB0aGlzLnN5bmNEZXB0aCsrO1xuICAgICAgdHJ5IHtcbiAgICAgICAgcGVuZGluZyA9IGZuKHRoaXMubWFrZVR4KHN0b3JlcywgZHJpdmVyKSk7XG4gICAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgICAvLyBmbiDnmoTlkIzmraXliY3nvIDlsLHmipvkuobvvJrlm57mu5rlkI7ljp/moLfmipvlh7pcbiAgICAgICAgdGhpcy5zeW5jRGVwdGgtLTtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICBkcml2ZXIuZXhlYygnUk9MTEJBQ0snKTtcbiAgICAgICAgfSBjYXRjaCB7XG4gICAgICAgICAgLy8g5bey5Zue5ruaXG4gICAgICAgIH1cbiAgICAgICAgdGhyb3cgZXJyb3I7XG4gICAgICB9XG4gICAgICB0aGlzLnN5bmNEZXB0aC0tO1xuICAgICAgdHJ5IHtcbiAgICAgICAgY29uc3QgcmVzdWx0ID0gYXdhaXQgcGVuZGluZztcbiAgICAgICAgZHJpdmVyLmV4ZWMoJ0NPTU1JVCcpO1xuICAgICAgICByZXR1cm4gcmVzdWx0O1xuICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgLy8g8J+UtCDov5nmmK9cIuWPlua2iOW3suaPkOS6pOS/ruaUuVwi55qE5ZSv5LiA5q2j56Gu5YGa5rOV77ya5pW05LiqIFNRTGl0ZSDkuovliqHlm57mu5rjgIJcbiAgICAgICAgLy8g5Y+q5Yig5paw5o+S5YWl55qE6KGM5piv5LiN5aSf55qEIOKAlOKAlCDlt7LmnInorrDlvZXooqvmlLnliqjml7bkuI3kvJrmgaLlpI3jgIJcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICBkcml2ZXIuZXhlYygnUk9MTEJBQ0snKTtcbiAgICAgICAgfSBjYXRjaCB7XG4gICAgICAgICAgLy8g6L+e5o6l5Y+v6IO95bey5Z2P77yM5Yir6K6pIHJvbGxiYWNrIOeahOWksei0peebluS9j+WOn+Wni+mUmeivr1xuICAgICAgICB9XG4gICAgICAgIHRocm93IGVycm9yO1xuICAgICAgfVxuICAgIH07XG5cbiAgICBjb25zdCByZXN1bHQgPSB0aGlzLnF1ZXVlLnRoZW4ocnVuLCBydW4pO1xuICAgIC8vIOmYn+WIl+S4jeiDveWboOS4uuafkOasoeS6i+WKoeWksei0peiAjOS4reaWrVxuICAgIHRoaXMucXVldWUgPSByZXN1bHQudGhlbihcbiAgICAgICgpID0+IHVuZGVmaW5lZCxcbiAgICAgICgpID0+IHVuZGVmaW5lZCxcbiAgICApO1xuICAgIHJldHVybiByZXN1bHQ7XG4gIH1cblxuICAvLyDilIDilIAg6aG25bGC5L6/5o235pa55rOV77ya5ZCE6Ieq5YyF5LiA5Liq5Y2VIHN0b3JlIOS6i+WKoSDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcblxuICBhZGQoc3RvcmU6IHN0cmluZywgdmFsdWU6IHVua25vd24pOiBQcm9taXNlPG51bWJlcj4ge1xuICAgIHJldHVybiB0aGlzLnRyYW5zYWN0aW9uKFtzdG9yZV0sICdyZWFkd3JpdGUnLCAodHgpID0+IHR4LmFkZChzdG9yZSwgdmFsdWUpKTtcbiAgfVxuXG4gIHB1dChzdG9yZTogc3RyaW5nLCB2YWx1ZTogdW5rbm93biwga2V5PzogRGJLZXkpOiBQcm9taXNlPHZvaWQ+IHtcbiAgICByZXR1cm4gdGhpcy50cmFuc2FjdGlvbihbc3RvcmVdLCAncmVhZHdyaXRlJywgKHR4KSA9PiB0eC5wdXQoc3RvcmUsIHZhbHVlLCBrZXkpKTtcbiAgfVxuXG4gIGdldDxUPihzdG9yZTogc3RyaW5nLCBrZXk6IERiS2V5KTogUHJvbWlzZTxUIHwgdW5kZWZpbmVkPiB7XG4gICAgcmV0dXJuIHRoaXMudHJhbnNhY3Rpb24oW3N0b3JlXSwgJ3JlYWRvbmx5JywgKHR4KSA9PiB0eC5nZXQ8VD4oc3RvcmUsIGtleSkpO1xuICB9XG5cbiAgZ2V0QWxsPFQ+KHN0b3JlOiBzdHJpbmcsIHJhbmdlPzogRGJLZXlSYW5nZSwgbGltaXQ/OiBudW1iZXIpOiBQcm9taXNlPFRbXT4ge1xuICAgIHJldHVybiB0aGlzLnRyYW5zYWN0aW9uKFtzdG9yZV0sICdyZWFkb25seScsICh0eCkgPT4gdHguZ2V0QWxsPFQ+KHN0b3JlLCByYW5nZSwgbGltaXQpKTtcbiAgfVxuXG4gIGRlbGV0ZShzdG9yZTogc3RyaW5nLCBrZXk6IERiS2V5KTogUHJvbWlzZTx2b2lkPiB7XG4gICAgcmV0dXJuIHRoaXMudHJhbnNhY3Rpb24oW3N0b3JlXSwgJ3JlYWR3cml0ZScsICh0eCkgPT4gdHguZGVsZXRlKHN0b3JlLCBrZXkpKTtcbiAgfVxuXG4gIGNsZWFyKHN0b3JlOiBzdHJpbmcpOiBQcm9taXNlPHZvaWQ+IHtcbiAgICByZXR1cm4gdGhpcy50cmFuc2FjdGlvbihbc3RvcmVdLCAncmVhZHdyaXRlJywgKHR4KSA9PiB0eC5jbGVhcihzdG9yZSkpO1xuICB9XG5cbiAgY291bnQoc3RvcmU6IHN0cmluZywgcmFuZ2U/OiBEYktleVJhbmdlKTogUHJvbWlzZTxudW1iZXI+IHtcbiAgICByZXR1cm4gdGhpcy50cmFuc2FjdGlvbihbc3RvcmVdLCAncmVhZG9ubHknLCAodHgpID0+IHR4LmNvdW50KHN0b3JlLCByYW5nZSkpO1xuICB9XG5cbiAgZ2V0RnJvbUluZGV4PFQ+KHN0b3JlOiBzdHJpbmcsIGluZGV4OiBzdHJpbmcsIGtleTogRGJLZXkgfCBEYktleVtdKTogUHJvbWlzZTxUIHwgdW5kZWZpbmVkPiB7XG4gICAgcmV0dXJuIHRoaXMudHJhbnNhY3Rpb24oW3N0b3JlXSwgJ3JlYWRvbmx5JywgKHR4KSA9PiB0eC5nZXRGcm9tSW5kZXg8VD4oc3RvcmUsIGluZGV4LCBrZXkpKTtcbiAgfVxuXG4gIGdldEtleUZyb21JbmRleChzdG9yZTogc3RyaW5nLCBpbmRleDogc3RyaW5nLCBrZXk6IERiS2V5IHwgRGJLZXlbXSk6IFByb21pc2U8RGJLZXkgfCB1bmRlZmluZWQ+IHtcbiAgICByZXR1cm4gdGhpcy50cmFuc2FjdGlvbihbc3RvcmVdLCAncmVhZG9ubHknLCAodHgpID0+IHR4LmdldEtleUZyb21JbmRleChzdG9yZSwgaW5kZXgsIGtleSkpO1xuICB9XG5cbiAgZ2V0QWxsRnJvbUluZGV4PFQ+KHN0b3JlOiBzdHJpbmcsIGluZGV4OiBzdHJpbmcsIHF1ZXJ5PzogRGJJbmRleFF1ZXJ5KTogUHJvbWlzZTxUW10+IHtcbiAgICByZXR1cm4gdGhpcy50cmFuc2FjdGlvbihbc3RvcmVdLCAncmVhZG9ubHknLCAodHgpID0+XG4gICAgICB0eC5nZXRBbGxGcm9tSW5kZXg8VD4oc3RvcmUsIGluZGV4LCBxdWVyeSksXG4gICAgKTtcbiAgfVxuXG4gIGNvdW50RnJvbUluZGV4KHN0b3JlOiBzdHJpbmcsIGluZGV4OiBzdHJpbmcsIHF1ZXJ5PzogRGJJbmRleFF1ZXJ5KTogUHJvbWlzZTxudW1iZXI+IHtcbiAgICByZXR1cm4gdGhpcy50cmFuc2FjdGlvbihbc3RvcmVdLCAncmVhZG9ubHknLCAodHgpID0+IHR4LmNvdW50RnJvbUluZGV4KHN0b3JlLCBpbmRleCwgcXVlcnkpKTtcbiAgfVxuXG4gIGl0ZXJhdGU8VD4oXG4gICAgc3RvcmU6IHN0cmluZyxcbiAgICBvcHRpb25zOiBEYkl0ZXJhdGVPcHRpb25zLFxuICAgIHZpc2l0OiBEYkN1cnNvclZpc2l0b3I8VD4sXG4gICk6IFByb21pc2U8dm9pZD4ge1xuICAgIC8vIHJlYWR3cml0ZSDogIzkuI3mmK8gcmVhZG9ubHnvvJrorr/pl67ogIXlj6/ov5Tlm54gJ2RlbGV0ZScgLyAnZGVsZXRlLXN0b3AnXG4gICAgcmV0dXJuIHRoaXMudHJhbnNhY3Rpb24oW3N0b3JlXSwgJ3JlYWR3cml0ZScsICh0eCkgPT4gdHguaXRlcmF0ZTxUPihzdG9yZSwgb3B0aW9ucywgdmlzaXQpKTtcbiAgfVxuXG4gIHByaXZhdGUgbWFrZVR4KGFsbG93ZWQ6IHN0cmluZ1tdLCBkcml2ZXI6IFNxbGl0ZURyaXZlcik6IERiVHgge1xuICAgIGNvbnN0IGFzc2VydCA9IChzdG9yZTogc3RyaW5nKTogU3RvcmVQbGFuID0+IHtcbiAgICAgIGlmICghYWxsb3dlZC5pbmNsdWRlcyhzdG9yZSkpIHtcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKFxuICAgICAgICAgIGBzdG9yZeOAjCR7c3RvcmV944CN5LiN5Zyo5pys5qyh5LqL5Yqh55qE6IyD5Zu05YaF77yaJHthbGxvd2VkLmpvaW4oJywgJyl9YCxcbiAgICAgICAgKTtcbiAgICAgIH1cbiAgICAgIGNvbnN0IHBsYW4gPSB0aGlzLnBsYW5CeU5hbWUuZ2V0KHN0b3JlKTtcbiAgICAgIGlmIChwbGFuID09PSB1bmRlZmluZWQpIHRocm93IG5ldyBFcnJvcihg5pyq5a6a5LmJ55qEIHN0b3Jl77ya44CMJHtzdG9yZX3jgI1gKTtcbiAgICAgIHJldHVybiBwbGFuO1xuICAgIH07XG5cbiAgICBjb25zdCBmaW5kSW5kZXggPSAocGxhbjogU3RvcmVQbGFuLCBpbmRleE5hbWU6IHN0cmluZyk6IEluZGV4UGxhbiA9PiB7XG4gICAgICBjb25zdCBpbmRleCA9IHBsYW4uYnlOYW1lLmdldChpbmRleE5hbWUpO1xuICAgICAgaWYgKGluZGV4ID09PSB1bmRlZmluZWQpIHtcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKGBzdG9yZeOAjCR7cGxhbi50YWJsZX3jgI3kuIrmsqHmnInntKLlvJXjgIwke2luZGV4TmFtZX3jgI1gKTtcbiAgICAgIH1cbiAgICAgIHJldHVybiBpbmRleDtcbiAgICB9O1xuXG4gICAgLyoqXG4gICAgICog5o+S5YWl5LiA5p2h6K6w5b2V77yM6L+U5Zue5YiG6YWN55qE6ZSu44CC5ZSv5LiA5Yay56qB55Sx6LCD55So5pa55Yaz5a6a5aaC5L2V5aSE55CG44CCXG4gICAgICpcbiAgICAgKiDimqDvuI8g6Ieq5aKe6K6h5pWw5ZmoKirlnKggSU5TRVJUIOaIkOWKn+S5i+WQjioq5omN6JC955uY44CC6Iul5o+S5YWl5YmN5bCx6YCS5aKe77yMXG4gICAgICogYGFkZFRvbGVyYXRpbmdEdXBsaWNhdGVgIOWQnuaOiemHjeWkjemhueaXtuS8mueVmeS4iyBzZXEg56m65rSeIOKAlOKAlFxuICAgICAqIOiAjCBzZXEg5piv5ZCM5q2l5ri45qCH55qE5Z+656GA77yM56m65rSeID0g5aKe6YeP5ZCM5q2l5rC45LmF5ryP5pWw5o2u44CCXG4gICAgICovXG4gICAgY29uc3QgaW5zZXJ0UmVjb3JkID0gKHN0b3JlTmFtZTogc3RyaW5nLCB2YWx1ZTogdW5rbm93bik6IHsga2V5OiBudW1iZXI7IHBrOiBLZXlWYWx1ZVtdIH0gPT4ge1xuICAgICAgY29uc3QgcGxhbiA9IGFzc2VydChzdG9yZU5hbWUpO1xuICAgICAgY29uc3QgcmVjb3JkID0gdmFsdWUgYXMgUmVjb3JkPHN0cmluZywgdW5rbm93bj47XG4gICAgICBjb25zdCByZWNvcmRLZXkgPSB0aGlzLnJlYWRSZWNvcmRLZXkocGxhbiwgcmVjb3JkKTtcbiAgICAgIGxldCBwazogS2V5VmFsdWVbXTtcbiAgICAgIGxldCBhbGxvY2F0ZWQ6IG51bWJlciB8IHVuZGVmaW5lZDtcblxuICAgICAgaWYgKHJlY29yZEtleSA9PT0gdW5kZWZpbmVkKSB7XG4gICAgICAgIGlmIChwbGFuLnNjaGVtYS5hdXRvSW5jcmVtZW50ICE9PSB0cnVlKSB7XG4gICAgICAgICAgdGhyb3cgbmV3IEVycm9yKFxuICAgICAgICAgICAgYHN0b3Jl44CMJHtzdG9yZU5hbWV944CN55qE6K6w5b2V57y65bCR5Li76ZSu5a2X5q6144CMJHtwbGFuLnBrUGF0aHMuam9pbignLCAnKX3jgI1gLFxuICAgICAgICAgICk7XG4gICAgICAgIH1cbiAgICAgICAgYWxsb2NhdGVkID0gdGhpcy5wZWVrQXV0b0luY3JlbWVudChkcml2ZXIsIHBsYW4pO1xuICAgICAgICBwayA9IFthbGxvY2F0ZWRdO1xuICAgICAgICAvLyDkuI4gSW5kZXhlZERCIC8g5YaF5a2Y5a6e546w5LiA6Ie077ya6Ieq5aKe6ZSu5YaZ5Zue6K6w5b2V5pys6Lqr77yIaW4tbGluZSBrZXnvvIlcbiAgICAgICAgc2V0QXRQYXRoKHJlY29yZCwgcGxhbi5wa1BhdGhzWzBdISwgYWxsb2NhdGVkKTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHBrID0gcmVjb3JkS2V5O1xuICAgICAgfVxuXG4gICAgICAvLyDljZXmnaEgSU5TRVJU77ya5ZSv5LiA57Si5byV5Yay56qB5pW05p2h5aSx6LSl77yM5LiN55WZ5Y2K5oiq5pWw5o2uXG4gICAgICB0aGlzLmluc2VydFJvdyhkcml2ZXIsIHBsYW4sIHBrLCByZWNvcmQpO1xuXG4gICAgICBpZiAoYWxsb2NhdGVkICE9PSB1bmRlZmluZWQpIHtcbiAgICAgICAgdGhpcy53cml0ZVNlcShkcml2ZXIsIHBsYW4sIGFsbG9jYXRlZCk7XG4gICAgICB9IGVsc2UgaWYgKHBsYW4uc2NoZW1hLmF1dG9JbmNyZW1lbnQgPT09IHRydWUgJiYgdHlwZW9mIHBrWzBdID09PSAnbnVtYmVyJykge1xuICAgICAgICB0aGlzLmJ1bXBBdXRvSW5jcmVtZW50KGRyaXZlciwgcGxhbiwgcGtbMF0pO1xuICAgICAgfVxuICAgICAgcmV0dXJuIHsga2V5OiB0eXBlb2YgcGtbMF0gPT09ICdudW1iZXInID8gcGtbMF0gOiAwLCBwayB9O1xuICAgIH07XG5cbiAgICByZXR1cm4ge1xuICAgICAgYWRkOiBhc3luYyAoc3RvcmVOYW1lLCB2YWx1ZSkgPT4gaW5zZXJ0UmVjb3JkKHN0b3JlTmFtZSwgdmFsdWUpLmtleSxcblxuICAgICAgLyoqXG4gICAgICAgKiDlrrnlv43llK/kuIDlhrLnqoHnmoTmj5LlhaXvvIhgRGJUeGAg5o6l5Y+j6KaB5rGC77yMb3AtbG9nIOW5guetieWOu+mHjeeahOaguOW/g++8ieOAglxuICAgICAgICpcbiAgICAgICAqIFNRTGl0ZSDph4zljZXmnaHnuqbmnZ/lhrLnqoEqKuS4jeS8mioq5Lit5q2i5pW05Liq5LqL5Yqh77yI6L+Z54K55LiOIEluZGV4ZWREQiDnm7jlj40g4oCU4oCUXG4gICAgICAgKiBJbmRleGVkREIg5b+F6aG7IGBwcmV2ZW50RGVmYXVsdCgpYCDmiY3kuI3kuK3mraLkuovliqHvvInvvIzmiYDku6Xnm7TmjqXmjZXojrfljbPlj6/vvIxcbiAgICAgICAqIOWQjue7reivreWPpeS4jiBDT01NSVQg5LuN6IO95q2j5bi45omn6KGM44CCXG4gICAgICAgKi9cbiAgICAgIGFkZFRvbGVyYXRpbmdEdXBsaWNhdGU6IGFzeW5jIChzdG9yZU5hbWUsIHZhbHVlKSA9PiB7XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgY29uc3QgeyBrZXkgfSA9IGluc2VydFJlY29yZChzdG9yZU5hbWUsIHZhbHVlKTtcbiAgICAgICAgICByZXR1cm4geyBvazogdHJ1ZSBhcyBjb25zdCwga2V5IH07XG4gICAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgICAgaWYgKHRoaXMuaXNVbmlxdWVWaW9sYXRpb24oZHJpdmVyLCBlcnJvcikpIHtcbiAgICAgICAgICAgIHJldHVybiB7IG9rOiBmYWxzZSBhcyBjb25zdCwgcmVhc29uOiAnZHVwbGljYXRlJyBhcyBjb25zdCB9O1xuICAgICAgICAgIH1cbiAgICAgICAgICB0aHJvdyBlcnJvcjtcbiAgICAgICAgfVxuICAgICAgfSxcblxuICAgICAgcHV0OiBhc3luYyAoc3RvcmVOYW1lLCB2YWx1ZSwgZXhwbGljaXRLZXkpID0+IHtcbiAgICAgICAgY29uc3QgcGxhbiA9IGFzc2VydChzdG9yZU5hbWUpO1xuICAgICAgICBjb25zdCByZWNvcmQgPSB2YWx1ZSBhcyBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPjtcbiAgICAgICAgY29uc3QgcGsgPSB0aGlzLm5vcm1hbGl6ZUV4cGxpY2l0S2V5KHBsYW4sIGV4cGxpY2l0S2V5KSA/PyB0aGlzLnJlYWRSZWNvcmRLZXkocGxhbiwgcmVjb3JkKTtcbiAgICAgICAgaWYgKHBrID09PSB1bmRlZmluZWQpIHtcbiAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoYHN0b3Jl44CMJHtzdG9yZU5hbWV944CN55qEIHB1dCDnvLrlsJHkuLvplK5gKTtcbiAgICAgICAgfVxuICAgICAgICAvLyDlhYjliKDlkI7mj5LvvJrljp/lrZDmgKfnlLHlpJblsYIgU1FMaXRlIOS6i+WKoeS/neivge+8m+i/meagtyBjaGlsZO+8iG11bHRpRW50cnnvvIlcbiAgICAgICAgLy8g55qE5pen57Si5byV6aG55Lmf5LiA5a6a6KKr5riF5o6J77yM5LiN5Lya55WZ5LiL5oyH5ZCR5bey5pS56K6w5b2V55qE5bm954G15p2h55uu44CCXG4gICAgICAgIHRoaXMuZGVsZXRlUm93KGRyaXZlciwgcGxhbiwgcGspO1xuICAgICAgICB0aGlzLmluc2VydFJvdyhkcml2ZXIsIHBsYW4sIHBrLCByZWNvcmQpO1xuICAgICAgfSxcblxuICAgICAgZ2V0OiBhc3luYyA8VCw+KHN0b3JlTmFtZTogc3RyaW5nLCBrZXk6IERiS2V5KSA9PiB7XG4gICAgICAgIGNvbnN0IHBsYW4gPSBhc3NlcnQoc3RvcmVOYW1lKTtcbiAgICAgICAgY29uc3QgcGsgPSB0aGlzLm5vcm1hbGl6ZUV4cGxpY2l0S2V5KHBsYW4sIGtleSk7XG4gICAgICAgIGlmIChwayA9PT0gdW5kZWZpbmVkKSByZXR1cm4gdW5kZWZpbmVkO1xuICAgICAgICBjb25zdCByb3dzID0gZHJpdmVyLmFsbDxTcWxSb3c+KFxuICAgICAgICAgIGBTRUxFQ1QgJHtxKHBsYW4uZGF0YUNvbHVtbil9IEZST00gJHtxKHBsYW4udGFibGUpfSBXSEVSRSAke3BrV2hlcmUocGxhbil9YCxcbiAgICAgICAgICBwayxcbiAgICAgICAgKTtcbiAgICAgICAgcmV0dXJuIHJvd3MubGVuZ3RoID09PSAwID8gdW5kZWZpbmVkIDogKEpTT04ucGFyc2UoU3RyaW5nKHJvd3NbMF0hW3BsYW4uZGF0YUNvbHVtbl0pKSBhcyBUKTtcbiAgICAgIH0sXG5cbiAgICAgIGdldEFsbDogYXN5bmMgPFQsPihzdG9yZU5hbWU6IHN0cmluZywgcmFuZ2U/OiBEYktleVJhbmdlLCBsaW1pdD86IG51bWJlcikgPT4ge1xuICAgICAgICBhc3NlcnRJdGVyYXRlTGltaXQobGltaXQpO1xuICAgICAgICBjb25zdCBwbGFuID0gYXNzZXJ0KHN0b3JlTmFtZSk7XG4gICAgICAgIHJldHVybiB0aGlzLmZldGNoUmVjb3Jkcyhkcml2ZXIsIHBsYW4sIHJhbmdlLCBsaW1pdCkubWFwKChyKSA9PiByLmRhdGEgYXMgVCk7XG4gICAgICB9LFxuXG4gICAgICBkZWxldGU6IGFzeW5jIChzdG9yZU5hbWUsIGtleSkgPT4ge1xuICAgICAgICBjb25zdCBwbGFuID0gYXNzZXJ0KHN0b3JlTmFtZSk7XG4gICAgICAgIGNvbnN0IHBrID0gdGhpcy5ub3JtYWxpemVFeHBsaWNpdEtleShwbGFuLCBrZXkpO1xuICAgICAgICBpZiAocGsgPT09IHVuZGVmaW5lZCkgcmV0dXJuO1xuICAgICAgICB0aGlzLmRlbGV0ZVJvdyhkcml2ZXIsIHBsYW4sIHBrKTtcbiAgICAgIH0sXG5cbiAgICAgIGNsZWFyOiBhc3luYyAoc3RvcmVOYW1lKSA9PiB7XG4gICAgICAgIGNvbnN0IHBsYW4gPSBhc3NlcnQoc3RvcmVOYW1lKTtcbiAgICAgICAgZHJpdmVyLnJ1bihgREVMRVRFIEZST00gJHtxKHBsYW4udGFibGUpfWApO1xuICAgICAgICBmb3IgKGNvbnN0IGluZGV4IG9mIHBsYW4uaW5kZXhlcykge1xuICAgICAgICAgIGlmIChpbmRleC5tdWx0aUVudHJ5KSBkcml2ZXIucnVuKGBERUxFVEUgRlJPTSAke3EoaW5kZXguY2hpbGRUYWJsZSEpfWApO1xuICAgICAgICB9XG4gICAgICB9LFxuXG4gICAgICBjb3VudDogYXN5bmMgKHN0b3JlTmFtZSwgcmFuZ2U/OiBEYktleVJhbmdlKSA9PiB7XG4gICAgICAgIGNvbnN0IHBsYW4gPSBhc3NlcnQoc3RvcmVOYW1lKTtcbiAgICAgICAgLy8g5aSN5ZCI5Li76ZSu55qE5Yy66Ze05ZyoIEpTIOmHjOi/h+a7pO+8iOingSBmZXRjaFJlY29yZHPvvInvvIzmiYDku6Xov5nph4znu5/kuIDotbAgY291bnQg6YC76L6RXG4gICAgICAgIGlmIChwbGFuLnBrQ29sdW1ucy5sZW5ndGggPT09IDEgJiYgcmFuZ2UgIT09IHVuZGVmaW5lZCkge1xuICAgICAgICAgIGNvbnN0IHBhcmFtczogU3FsVmFsdWVbXSA9IFtdO1xuICAgICAgICAgIGNvbnN0IHdoZXJlID0gcmFuZ2VDb25kaXRpb25zKHEocGxhbi5wa0NvbHVtbnNbMF0hKSwgcmFuZ2UsIHBhcmFtcyk7XG4gICAgICAgICAgY29uc3Qgcm93cyA9IGRyaXZlci5hbGw8U3FsUm93PihcbiAgICAgICAgICAgIGBTRUxFQ1QgQ09VTlQoKikgQVMgbiBGUk9NICR7cShwbGFuLnRhYmxlKX0ke3doZXJlLmxlbmd0aCA/IGAgV0hFUkUgJHt3aGVyZS5qb2luKCcgQU5EICcpfWAgOiAnJ31gLFxuICAgICAgICAgICAgcGFyYW1zLFxuICAgICAgICAgICk7XG4gICAgICAgICAgcmV0dXJuIE51bWJlcihyb3dzWzBdPy5bJ24nXSA/PyAwKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gdGhpcy5mZXRjaFJlY29yZHMoZHJpdmVyLCBwbGFuLCByYW5nZSkubGVuZ3RoO1xuICAgICAgfSxcblxuICAgICAgZ2V0RnJvbUluZGV4OiBhc3luYyA8VCw+KHN0b3JlTmFtZTogc3RyaW5nLCBpbmRleE5hbWU6IHN0cmluZywga2V5OiBEYktleSB8IERiS2V5W10pID0+IHtcbiAgICAgICAgY29uc3QgcGxhbiA9IGFzc2VydChzdG9yZU5hbWUpO1xuICAgICAgICBjb25zdCBpbmRleCA9IGZpbmRJbmRleChwbGFuLCBpbmRleE5hbWUpO1xuICAgICAgICBjb25zdCByZWNvcmRzID0gdGhpcy5mZXRjaEluZGV4UmVjb3Jkcyhkcml2ZXIsIHBsYW4sIGluZGV4LCBrZXkpO1xuICAgICAgICByZXR1cm4gcmVjb3Jkcy5sZW5ndGggPT09IDAgPyB1bmRlZmluZWQgOiAocmVjb3Jkc1swXSEuZGF0YSBhcyBUKTtcbiAgICAgIH0sXG5cbiAgICAgIGdldEtleUZyb21JbmRleDogYXN5bmMgKHN0b3JlTmFtZSwgaW5kZXhOYW1lLCBrZXkpID0+IHtcbiAgICAgICAgY29uc3QgcGxhbiA9IGFzc2VydChzdG9yZU5hbWUpO1xuICAgICAgICBjb25zdCBpbmRleCA9IGZpbmRJbmRleChwbGFuLCBpbmRleE5hbWUpO1xuICAgICAgICBjb25zdCByZWNvcmRzID0gdGhpcy5mZXRjaEluZGV4UmVjb3Jkcyhkcml2ZXIsIHBsYW4sIGluZGV4LCBrZXkpO1xuICAgICAgICByZXR1cm4gcmVjb3Jkcy5sZW5ndGggPT09IDAgPyB1bmRlZmluZWQgOiB0b0RiS2V5KHBsYW4sIHJlY29yZHNbMF0hLnBrKTtcbiAgICAgIH0sXG5cbiAgICAgIGdldEFsbEZyb21JbmRleDogYXN5bmMgPFQsPihzdG9yZU5hbWU6IHN0cmluZywgaW5kZXhOYW1lOiBzdHJpbmcsIHF1ZXJ5PzogRGJJbmRleFF1ZXJ5KSA9PiB7XG4gICAgICAgIGNvbnN0IHBsYW4gPSBhc3NlcnQoc3RvcmVOYW1lKTtcbiAgICAgICAgY29uc3QgaW5kZXggPSBmaW5kSW5kZXgocGxhbiwgaW5kZXhOYW1lKTtcbiAgICAgICAgcmV0dXJuIHRoaXMuZmV0Y2hJbmRleFJlY29yZHMoZHJpdmVyLCBwbGFuLCBpbmRleCwgcXVlcnkpLm1hcCgocikgPT4gci5kYXRhIGFzIFQpO1xuICAgICAgfSxcblxuICAgICAgY291bnRGcm9tSW5kZXg6IGFzeW5jIChzdG9yZU5hbWUsIGluZGV4TmFtZSwgcXVlcnk/OiBEYkluZGV4UXVlcnkpID0+IHtcbiAgICAgICAgY29uc3QgcGxhbiA9IGFzc2VydChzdG9yZU5hbWUpO1xuICAgICAgICBjb25zdCBpbmRleCA9IGZpbmRJbmRleChwbGFuLCBpbmRleE5hbWUpO1xuICAgICAgICByZXR1cm4gdGhpcy5mZXRjaEluZGV4UmVjb3Jkcyhkcml2ZXIsIHBsYW4sIGluZGV4LCBxdWVyeSkubGVuZ3RoO1xuICAgICAgfSxcblxuICAgICAgaXRlcmF0ZTogYXN5bmMgPFQsPihcbiAgICAgICAgc3RvcmVOYW1lOiBzdHJpbmcsXG4gICAgICAgIG9wdGlvbnM6IERiSXRlcmF0ZU9wdGlvbnMsXG4gICAgICAgIHZpc2l0OiBEYkN1cnNvclZpc2l0b3I8VD4sXG4gICAgICApID0+IHtcbiAgICAgICAgY29uc3QgcGxhbiA9IGFzc2VydChzdG9yZU5hbWUpO1xuICAgICAgICBhc3NlcnRJdGVyYXRlTGltaXQob3B0aW9ucy5saW1pdCk7XG5cbiAgICAgICAgY29uc3QgeyBkaXJlY3Rpb24gPSAnbmV4dCcsIGxvd2VyLCB1cHBlciwgbGltaXQsIGluZGV4IH0gPSBvcHRpb25zO1xuICAgICAgICBsZXQgcmVjb3JkczogUGh5c2ljYWxSZWNvcmRbXTtcbiAgICAgICAgaWYgKGluZGV4ID09PSB1bmRlZmluZWQpIHtcbiAgICAgICAgICByZWNvcmRzID0gdGhpcy5mZXRjaFJlY29yZHMoZHJpdmVyLCBwbGFuLCB7IGxvd2VyLCB1cHBlciB9KTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICBjb25zdCBpbmRleFBsYW4gPSBmaW5kSW5kZXgocGxhbiwgaW5kZXgpO1xuICAgICAgICAgIHJlY29yZHMgPSB0aGlzLmZldGNoSW5kZXhSZWNvcmRzKGRyaXZlciwgcGxhbiwgaW5kZXhQbGFuLCB7IGxvd2VyLCB1cHBlciB9KTtcbiAgICAgICAgfVxuICAgICAgICBpZiAoZGlyZWN0aW9uID09PSAncHJldicpIHJlY29yZHMucmV2ZXJzZSgpO1xuXG4gICAgICAgIGNvbnN0IGNhcCA9IGxpbWl0ID8/IERFRkFVTFRfSVRFUkFURV9MSU1JVDtcbiAgICAgICAgbGV0IHZpc2l0ZWQgPSAwO1xuICAgICAgICBmb3IgKGNvbnN0IHJlY29yZCBvZiByZWNvcmRzKSB7XG4gICAgICAgICAgaWYgKHZpc2l0ZWQgPj0gY2FwKSBicmVhaztcbiAgICAgICAgICB2aXNpdGVkKys7XG4gICAgICAgICAgY29uc3QgYWN0aW9uOiBEYkN1cnNvckFjdGlvbiA9IHZpc2l0KHJlY29yZC5kYXRhIGFzIFQsIHRvRGJLZXkocGxhbiwgcmVjb3JkLnBrKSk7XG4gICAgICAgICAgaWYgKGFjdGlvbiA9PT0gJ2RlbGV0ZScgfHwgYWN0aW9uID09PSAnZGVsZXRlLXN0b3AnKSB7XG4gICAgICAgICAgICB0aGlzLmRlbGV0ZVJvdyhkcml2ZXIsIHBsYW4sIHJlY29yZC5wayk7XG4gICAgICAgICAgfVxuICAgICAgICAgIGlmIChhY3Rpb24gPT09ICdzdG9wJyB8fCBhY3Rpb24gPT09ICdkZWxldGUtc3RvcCcpIGJyZWFrO1xuICAgICAgICB9XG4gICAgICB9LFxuICAgIH07XG4gIH1cblxuICAvLyDilIDilIAg54mp55CG5pON5L2cIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuXG4gIHByaXZhdGUgcmVhZFJlY29yZEtleShwbGFuOiBTdG9yZVBsYW4sIHJlY29yZDogUmVjb3JkPHN0cmluZywgdW5rbm93bj4pOiBLZXlWYWx1ZVtdIHwgdW5kZWZpbmVkIHtcbiAgICBjb25zdCBvdXQ6IEtleVZhbHVlW10gPSBbXTtcbiAgICBmb3IgKGNvbnN0IHBhdGggb2YgcGxhbi5wa1BhdGhzKSB7XG4gICAgICBjb25zdCB2ID0gdmFsdWVBdFBhdGgocmVjb3JkLCBwYXRoKTtcbiAgICAgIGlmICghaXNLZXlWYWx1ZSh2KSkgcmV0dXJuIHVuZGVmaW5lZDtcbiAgICAgIG91dC5wdXNoKHYpO1xuICAgIH1cbiAgICByZXR1cm4gb3V0O1xuICB9XG5cbiAgcHJpdmF0ZSBub3JtYWxpemVFeHBsaWNpdEtleShwbGFuOiBTdG9yZVBsYW4sIGtleTogRGJLZXkgfCBEYktleVtdIHwgdW5kZWZpbmVkKTogS2V5VmFsdWVbXSB8IHVuZGVmaW5lZCB7XG4gICAgaWYgKGtleSA9PT0gdW5kZWZpbmVkKSByZXR1cm4gdW5kZWZpbmVkO1xuICAgIGNvbnN0IHBhcnRzID0gQXJyYXkuaXNBcnJheShrZXkpID8ga2V5IDogW2tleV07XG4gICAgaWYgKHBhcnRzLmxlbmd0aCAhPT0gcGxhbi5wa0NvbHVtbnMubGVuZ3RoKSByZXR1cm4gdW5kZWZpbmVkO1xuICAgIGlmICghcGFydHMuZXZlcnkoaXNLZXlWYWx1ZSkpIHJldHVybiB1bmRlZmluZWQ7XG4gICAgcmV0dXJuIHBhcnRzO1xuICB9XG5cbiAgLyoqXG4gICAqIOiuoeeul+S4i+S4gOS4quiHquWinumUru+8jOS9hioq5LiN6JC955uYKirvvIjmj5LlhaXmiJDlip/lkI7miY3nlLHosIPnlKjmlrnlhpnlm57orqHmlbDlmajvvInjgIJcbiAgICog5ZCM5pe25Y+C6ICD6K6h5pWw5Zmo5LiO6KGo5YaFIE1BWO+8jOmBv+WFjeiuoeaVsOWZqOihqOS4ouWkseWQjuWbnumAgOWkjeeUqOaXp+mUruOAglxuICAgKi9cbiAgcHJpdmF0ZSBwZWVrQXV0b0luY3JlbWVudChkcml2ZXI6IFNxbGl0ZURyaXZlciwgcGxhbjogU3RvcmVQbGFuKTogbnVtYmVyIHtcbiAgICBjb25zdCBzZXFSb3cgPSBkcml2ZXIuYWxsPFNxbFJvdz4oXG4gICAgICBgU0VMRUNUIFwibmV4dFwiIEZST00gJHtxKFNFUV9UQUJMRSl9IFdIRVJFIFwic3RvcmVcIiA9ID9gLFxuICAgICAgW3BsYW4udGFibGVdLFxuICAgIClbMF07XG4gICAgY29uc3Qgc3RvcmVkID0gc2VxUm93ID09PSB1bmRlZmluZWQgPyAwIDogTnVtYmVyKHNlcVJvd1snbmV4dCddKTtcbiAgICBjb25zdCBtYXhSb3cgPSBkcml2ZXIuYWxsPFNxbFJvdz4oXG4gICAgICBgU0VMRUNUIE1BWCgke3EocGxhbi5wa0NvbHVtbnNbMF0hKX0pIEFTIFwibVwiIEZST00gJHtxKHBsYW4udGFibGUpfWAsXG4gICAgKVswXTtcbiAgICBjb25zdCBtYXhQayA9IG1heFJvdyAhPT0gdW5kZWZpbmVkICYmIHR5cGVvZiBtYXhSb3dbJ20nXSA9PT0gJ251bWJlcicgPyBtYXhSb3dbJ20nXSA6IDA7XG4gICAgcmV0dXJuIE1hdGgubWF4KHN0b3JlZCwgbWF4UGspICsgMTtcbiAgfVxuXG4gIC8qKiDliKTlrprlvILluLjmmK/lkKbkuLrllK/kuIDnuqbmnZ/lhrLnqoHvvJvpqbHliqjlj6/pgInmi6nnsr7noa7lrp7njrDjgIIgKi9cbiAgcHJpdmF0ZSBpc1VuaXF1ZVZpb2xhdGlvbihkcml2ZXI6IFNxbGl0ZURyaXZlciwgZXJyb3I6IHVua25vd24pOiBib29sZWFuIHtcbiAgICBpZiAoZHJpdmVyLmlzVW5pcXVlVmlvbGF0aW9uICE9PSB1bmRlZmluZWQpIHJldHVybiBkcml2ZXIuaXNVbmlxdWVWaW9sYXRpb24oZXJyb3IpO1xuICAgIHJldHVybiBkZWZhdWx0SXNVbmlxdWVWaW9sYXRpb24oZXJyb3IpO1xuICB9XG5cbiAgcHJpdmF0ZSBidW1wQXV0b0luY3JlbWVudChkcml2ZXI6IFNxbGl0ZURyaXZlciwgcGxhbjogU3RvcmVQbGFuLCBrZXk6IG51bWJlcik6IHZvaWQge1xuICAgIGNvbnN0IHNlcVJvdyA9IGRyaXZlci5hbGw8U3FsUm93PihcbiAgICAgIGBTRUxFQ1QgXCJuZXh0XCIgRlJPTSAke3EoU0VRX1RBQkxFKX0gV0hFUkUgXCJzdG9yZVwiID0gP2AsXG4gICAgICBbcGxhbi50YWJsZV0sXG4gICAgKVswXTtcbiAgICBjb25zdCBzdG9yZWQgPSBzZXFSb3cgPT09IHVuZGVmaW5lZCA/IDAgOiBOdW1iZXIoc2VxUm93WyduZXh0J10pO1xuICAgIGlmIChrZXkgPiBzdG9yZWQpIHRoaXMud3JpdGVTZXEoZHJpdmVyLCBwbGFuLCBrZXkpO1xuICB9XG5cbiAgcHJpdmF0ZSB3cml0ZVNlcShkcml2ZXI6IFNxbGl0ZURyaXZlciwgcGxhbjogU3RvcmVQbGFuLCBuZXh0OiBudW1iZXIpOiB2b2lkIHtcbiAgICBkcml2ZXIucnVuKFxuICAgICAgYElOU0VSVCBPUiBSRVBMQUNFIElOVE8gJHtxKFNFUV9UQUJMRSl9IChcInN0b3JlXCIsIFwibmV4dFwiKSBWQUxVRVMgKD8sID8pYCxcbiAgICAgIFtwbGFuLnRhYmxlLCBuZXh0XSxcbiAgICApO1xuICB9XG5cbiAgcHJpdmF0ZSBpbnNlcnRSb3coXG4gICAgZHJpdmVyOiBTcWxpdGVEcml2ZXIsXG4gICAgcGxhbjogU3RvcmVQbGFuLFxuICAgIHBrOiBLZXlWYWx1ZVtdLFxuICAgIHJlY29yZDogUmVjb3JkPHN0cmluZywgdW5rbm93bj4sXG4gICk6IHZvaWQge1xuICAgIGNvbnN0IGNvbHVtbnMgPSBbLi4ucGxhbi5wa0NvbHVtbnNdO1xuICAgIGNvbnN0IHZhbHVlczogU3FsVmFsdWVbXSA9IFsuLi5wa107XG5cbiAgICBmb3IgKGNvbnN0IGluZGV4IG9mIHBsYW4uaW5kZXhlcykge1xuICAgICAgaWYgKGluZGV4Lm11bHRpRW50cnkpIGNvbnRpbnVlO1xuICAgICAgY29uc3QgZW50cnkgPSBpbmxpbmVJbmRleFZhbHVlcyhpbmRleCwgcmVjb3JkKTtcbiAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgaW5kZXguY29sdW1ucy5sZW5ndGg7IGkrKykge1xuICAgICAgICBjb2x1bW5zLnB1c2goaW5kZXguY29sdW1uc1tpXSEpO1xuICAgICAgICB2YWx1ZXMucHVzaChlbnRyeSA9PT0gdW5kZWZpbmVkID8gbnVsbCA6IGVudHJ5W2ldISk7XG4gICAgICB9XG4gICAgfVxuXG4gICAgY29sdW1ucy5wdXNoKHBsYW4uZGF0YUNvbHVtbik7XG4gICAgdmFsdWVzLnB1c2goSlNPTi5zdHJpbmdpZnkocmVjb3JkKSk7XG5cbiAgICBkcml2ZXIucnVuKFxuICAgICAgYElOU0VSVCBJTlRPICR7cShwbGFuLnRhYmxlKX0gKCR7Y29sdW1ucy5tYXAocSkuam9pbignLCAnKX0pIFZBTFVFUyAoJHtjb2x1bW5zLm1hcCgoKSA9PiAnPycpLmpvaW4oJywgJyl9KWAsXG4gICAgICB2YWx1ZXMsXG4gICAgKTtcblxuICAgIGZvciAoY29uc3QgaW5kZXggb2YgcGxhbi5pbmRleGVzKSB7XG4gICAgICBpZiAoIWluZGV4Lm11bHRpRW50cnkpIGNvbnRpbnVlO1xuICAgICAgZm9yIChjb25zdCBlbGVtZW50IG9mIG11bHRpRW50cnlWYWx1ZXMoaW5kZXgsIHJlY29yZCkpIHtcbiAgICAgICAgZHJpdmVyLnJ1bihcbiAgICAgICAgICBgSU5TRVJUIElOVE8gJHtxKGluZGV4LmNoaWxkVGFibGUhKX0gKCR7W1xuICAgICAgICAgICAgLi4ucGxhbi5wa0NvbHVtbnMubWFwKHEpLFxuICAgICAgICAgICAgJ1wiZWxlbVwiJyxcbiAgICAgICAgICBdLmpvaW4oJywgJyl9KSBWQUxVRVMgKCR7Wy4uLnBsYW4ucGtDb2x1bW5zLm1hcCgoKSA9PiAnPycpLCAnPyddLmpvaW4oJywgJyl9KWAsXG4gICAgICAgICAgWy4uLnBrLCBlbGVtZW50XSxcbiAgICAgICAgKTtcbiAgICAgIH1cbiAgICB9XG4gIH1cblxuICBwcml2YXRlIGRlbGV0ZVJvdyhkcml2ZXI6IFNxbGl0ZURyaXZlciwgcGxhbjogU3RvcmVQbGFuLCBwazogS2V5VmFsdWVbXSk6IHZvaWQge1xuICAgIGRyaXZlci5ydW4oYERFTEVURSBGUk9NICR7cShwbGFuLnRhYmxlKX0gV0hFUkUgJHtwa1doZXJlKHBsYW4pfWAsIHBrKTtcbiAgICBmb3IgKGNvbnN0IGluZGV4IG9mIHBsYW4uaW5kZXhlcykge1xuICAgICAgaWYgKGluZGV4Lm11bHRpRW50cnkpIHtcbiAgICAgICAgZHJpdmVyLnJ1bihgREVMRVRFIEZST00gJHtxKGluZGV4LmNoaWxkVGFibGUhKX0gV0hFUkUgJHtwa1doZXJlKHBsYW4pfWAsIHBrKTtcbiAgICAgIH1cbiAgICB9XG4gIH1cblxuICBwcml2YXRlIGZldGNoUmVjb3JkcyhcbiAgICBkcml2ZXI6IFNxbGl0ZURyaXZlcixcbiAgICBwbGFuOiBTdG9yZVBsYW4sXG4gICAgcmFuZ2U/OiBEYktleVJhbmdlLFxuICAgIGxpbWl0PzogbnVtYmVyLFxuICApOiBQaHlzaWNhbFJlY29yZFtdIHtcbiAgICBjb25zdCBwYXJhbXM6IFNxbFZhbHVlW10gPSBbXTtcbiAgICBsZXQgd2hlcmUgPSAnJztcbiAgICAvLyDljZXliJfkuLvplK7vvJrljLrpl7TkuIvmjqjliLAgU1FM77yIb3BzIOeahCBzZXEg5Yy66Ze05piv5pyA54Ot55qE5p+l6K+i77yJ44CCXG4gICAgLy8g5aSN5ZCI5Li76ZSu77yaU1FMIE9SREVSIEJZIHBrIOWQjuaMiemAkOWFg+e0oOavlOi+g+WcqCBKUyDph4zov4fmu6Qg4oCU4oCUIOe7k+aenOmhuuW6j+S4jlxuICAgIC8vIEluZGV4ZWREQiDnmoRcIuaMieS4u+mUruWNh+W6j1wi5LiA6Ie077yM5LiU5LiN5Lya5oqKIGAxMGAg5o6S5ZyoIGAyYCDliY3jgIJcbiAgICBjb25zdCBwdXNoRG93biA9IHBsYW4ucGtDb2x1bW5zLmxlbmd0aCA9PT0gMSAmJiByYW5nZSAhPT0gdW5kZWZpbmVkO1xuICAgIGlmIChwdXNoRG93bikge1xuICAgICAgY29uc3QgY29uZGl0aW9ucyA9IHJhbmdlQ29uZGl0aW9ucyhxKHBsYW4ucGtDb2x1bW5zWzBdISksIHJhbmdlISwgcGFyYW1zKTtcbiAgICAgIGlmIChjb25kaXRpb25zLmxlbmd0aCA+IDApIHdoZXJlID0gYCBXSEVSRSAke2NvbmRpdGlvbnMuam9pbignIEFORCAnKX1gO1xuICAgIH1cblxuICAgIGNvbnN0IHNxbExpbWl0ID0gbGltaXQgIT09IHVuZGVmaW5lZCAmJiAocHVzaERvd24gfHwgcmFuZ2UgPT09IHVuZGVmaW5lZCk7XG4gICAgaWYgKHNxbExpbWl0KSBwYXJhbXMucHVzaChsaW1pdCk7XG4gICAgY29uc3Qgcm93cyA9IGRyaXZlci5hbGw8U3FsUm93PihcbiAgICAgIGBTRUxFQ1QgKiBGUk9NICR7cShwbGFuLnRhYmxlKX0ke3doZXJlfSBPUkRFUiBCWSAke29yZGVyQnlQayhwbGFuKX0ke3NxbExpbWl0ID8gJyBMSU1JVCA/JyA6ICcnfWAsXG4gICAgICBwYXJhbXMsXG4gICAgKTtcblxuICAgIGNvbnN0IHByb2plY3RlZCA9IHJvd3MubWFwKChyb3cpID0+IHRoaXMudG9QaHlzaWNhbFJlY29yZChwbGFuLCByb3cpKTtcbiAgICByZXR1cm4gKHB1c2hEb3duID8gcHJvamVjdGVkIDogcHJvamVjdGVkLmZpbHRlcigocikgPT4ga2V5SW5SYW5nZShyLnBrLCByYW5nZSkpKS5zbGljZSgwLCBsaW1pdCk7XG4gIH1cblxuICBwcml2YXRlIGZldGNoSW5kZXhSZWNvcmRzKFxuICAgIGRyaXZlcjogU3FsaXRlRHJpdmVyLFxuICAgIHBsYW46IFN0b3JlUGxhbixcbiAgICBpbmRleDogSW5kZXhQbGFuLFxuICAgIHF1ZXJ5PzogRGJJbmRleFF1ZXJ5LFxuICApOiBQaHlzaWNhbFJlY29yZFtdIHtcbiAgICBpZiAoaW5kZXgubXVsdGlFbnRyeSkge1xuICAgICAgY29uc3QgcGFyYW1zOiBTcWxWYWx1ZVtdID0gW107XG4gICAgICBjb25zdCBjb25kaXRpb25zOiBzdHJpbmdbXSA9IFtdO1xuICAgICAgaWYgKHF1ZXJ5ICE9PSB1bmRlZmluZWQpIHtcbiAgICAgICAgaWYgKGlzS2V5VmFsdWUocXVlcnkpKSB7XG4gICAgICAgICAgY29uZGl0aW9ucy5wdXNoKCdjLlwiZWxlbVwiID0gPycpO1xuICAgICAgICAgIHBhcmFtcy5wdXNoKHF1ZXJ5KTtcbiAgICAgICAgICAvLyBtdWx0aUVudHJ5IOeahOe0ouW8lemhueawuOi/nOaYr+agh+mHj++8jOaVsOe7hC/lpI3lkIjmn6Xor6LkuI3lj6/og73lkb3kuK1cbiAgICAgICAgfSBlbHNlIGlmIChBcnJheS5pc0FycmF5KHF1ZXJ5KSkge1xuICAgICAgICAgIHJldHVybiBbXTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICBjb25kaXRpb25zLnB1c2goLi4ucmFuZ2VDb25kaXRpb25zKCdjLlwiZWxlbVwiJywgcXVlcnksIHBhcmFtcykpO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgICBjb25zdCBleHRyYSA9IGNvbmRpdGlvbnMubGVuZ3RoID4gMCA/IGAgQU5EICR7Y29uZGl0aW9ucy5qb2luKCcgQU5EICcpfWAgOiAnJztcbiAgICAgIGNvbnN0IHJvd3MgPSBkcml2ZXIuYWxsPFNxbFJvdz4oXG4gICAgICAgIGBTRUxFQ1Qgcy4qIEZST00gJHtxKHBsYW4udGFibGUpfSBzIGAgK1xuICAgICAgICAgIGBXSEVSRSBFWElTVFMgKFNFTEVDVCAxIEZST00gJHtxKGluZGV4LmNoaWxkVGFibGUhKX0gYyBgICtcbiAgICAgICAgICBgV0hFUkUgJHtqb2luT25QaygnYycsICdzJywgcGxhbil9JHtleHRyYX0pIGAgK1xuICAgICAgICAgIGBPUkRFUiBCWSAke29yZGVyQnlQayhwbGFuLCAncycpfWAsXG4gICAgICAgIHBhcmFtcyxcbiAgICAgICk7XG4gICAgICByZXR1cm4gcm93cy5tYXAoKHJvdykgPT4gdGhpcy50b1BoeXNpY2FsUmVjb3JkKHBsYW4sIHJvdykpO1xuICAgIH1cblxuICAgIGNvbnN0IHBhcmFtczogU3FsVmFsdWVbXSA9IFtdO1xuICAgIGNvbnN0IGNvbmRpdGlvbnM6IHN0cmluZ1tdID0gW107XG5cbiAgICBpZiAocXVlcnkgPT09IHVuZGVmaW5lZCkge1xuICAgICAgLy8g57Si5byV6ZSu57y65aSx55qE6K6w5b2V5ZyoIEluZGV4ZWREQiDph4wqKuayoeaciee0ouW8lemhuSoq77yM5YWo57Si5byV5omr5o+P5LiN6K+l5bim5Ye65a6D5Lus44CCXG4gICAgICBmb3IgKGNvbnN0IGNvbHVtbiBvZiBpbmRleC5jb2x1bW5zKSBjb25kaXRpb25zLnB1c2goYCR7cShjb2x1bW4pfSBJUyBOT1QgTlVMTGApO1xuICAgIH0gZWxzZSBpZiAoaXNLZXlWYWx1ZShxdWVyeSkpIHtcbiAgICAgIGlmIChpbmRleC5jb2x1bW5zLmxlbmd0aCAhPT0gMSkgcmV0dXJuIFtdO1xuICAgICAgY29uZGl0aW9ucy5wdXNoKGAke3EoaW5kZXguY29sdW1uc1swXSEpfSA9ID9gKTtcbiAgICAgIHBhcmFtcy5wdXNoKHF1ZXJ5KTtcbiAgICB9IGVsc2UgaWYgKEFycmF5LmlzQXJyYXkocXVlcnkpKSB7XG4gICAgICBpZiAocXVlcnkubGVuZ3RoICE9PSBpbmRleC5jb2x1bW5zLmxlbmd0aCkgcmV0dXJuIFtdO1xuICAgICAgaW5kZXguY29sdW1ucy5mb3JFYWNoKChjb2x1bW4sIGkpID0+IHtcbiAgICAgICAgY29uZGl0aW9ucy5wdXNoKGAke3EoY29sdW1uKX0gPSA/YCk7XG4gICAgICAgIHBhcmFtcy5wdXNoKHF1ZXJ5W2ldISk7XG4gICAgICB9KTtcbiAgICB9IGVsc2UgaWYgKGluZGV4LmNvbHVtbnMubGVuZ3RoID09PSAxKSB7XG4gICAgICBjb25kaXRpb25zLnB1c2goLi4ucmFuZ2VDb25kaXRpb25zKHEoaW5kZXguY29sdW1uc1swXSEpLCBxdWVyeSwgcGFyYW1zKSk7XG4gICAgfSBlbHNlIHtcbiAgICAgIC8vIOWkjeWQiOe0ouW8leeahOWMuumXtOafpeivou+8muWPluWbnuWQjuaMieWFg+e7hOmAkOWFg+e0oOavlOi+g+i/h+a7pO+8iOS4juWGheWtmOWunueOsOS4gOiHtO+8jFxuICAgICAgLy8g5LiU5LiN5b+F5omL5YaZIFNRTCDnmoTlrZflhbjluo/lhYPnu4Tmr5TovoPvvInjgIJcbiAgICAgIGZvciAoY29uc3QgY29sdW1uIG9mIGluZGV4LmNvbHVtbnMpIGNvbmRpdGlvbnMucHVzaChgJHtxKGNvbHVtbil9IElTIE5PVCBOVUxMYCk7XG4gICAgfVxuXG4gICAgY29uc3Qgd2hlcmUgPSBjb25kaXRpb25zLmxlbmd0aCA+IDAgPyBgIFdIRVJFICR7Y29uZGl0aW9ucy5qb2luKCcgQU5EICcpfWAgOiAnJztcbiAgICBjb25zdCByb3dzID0gZHJpdmVyLmFsbDxTcWxSb3c+KFxuICAgICAgYFNFTEVDVCAqIEZST00gJHtxKHBsYW4udGFibGUpfSR7d2hlcmV9IE9SREVSIEJZICR7b3JkZXJCeVBrKHBsYW4pfWAsXG4gICAgICBwYXJhbXMsXG4gICAgKTtcblxuICAgIGxldCBwcm9qZWN0ZWQgPSByb3dzLm1hcCgocm93KSA9PiB0aGlzLnRvUGh5c2ljYWxSZWNvcmQocGxhbiwgcm93KSk7XG4gICAgaWYgKFxuICAgICAgcXVlcnkgIT09IHVuZGVmaW5lZCAmJlxuICAgICAgIWlzS2V5VmFsdWUocXVlcnkpICYmXG4gICAgICAhQXJyYXkuaXNBcnJheShxdWVyeSkgJiZcbiAgICAgIGluZGV4LmNvbHVtbnMubGVuZ3RoID4gMVxuICAgICkge1xuICAgICAgcHJvamVjdGVkID0gcHJvamVjdGVkLmZpbHRlcigocikgPT5cbiAgICAgICAga2V5SW5SYW5nZShcbiAgICAgICAgICBpbmRleC5jb2x1bW5zLm1hcCgoYykgPT4gci5yb3dbY10gYXMgS2V5VmFsdWUpLFxuICAgICAgICAgIHF1ZXJ5LFxuICAgICAgICApLFxuICAgICAgKTtcbiAgICB9XG4gICAgcmV0dXJuIHByb2plY3RlZDtcbiAgfVxuXG4gIHByaXZhdGUgdG9QaHlzaWNhbFJlY29yZChwbGFuOiBTdG9yZVBsYW4sIHJvdzogU3FsUm93KTogUGh5c2ljYWxSZWNvcmQge1xuICAgIHJldHVybiB7XG4gICAgICBkYXRhOiBKU09OLnBhcnNlKFN0cmluZyhyb3dbcGxhbi5kYXRhQ29sdW1uXSkpLFxuICAgICAgcGs6IHBsYW4ucGtDb2x1bW5zLm1hcCgoYykgPT4gcm93W2NdIGFzIEtleVZhbHVlKSxcbiAgICAgIHJvdyxcbiAgICB9O1xuICB9XG59XG5cbmludGVyZmFjZSBQaHlzaWNhbFJlY29yZCB7XG4gIGRhdGE6IHVua25vd247XG4gIHBrOiBLZXlWYWx1ZVtdO1xuICAvKiog5Y6f5aeL6KGM77yM55WZ57uZXCLlpI3lkIjntKLlvJXljLrpl7RcIui/meexu+mcgOimgeWbnueci+e0ouW8leWIl+eahOi/h+a7pOOAgiAqL1xuICByb3c6IFNxbFJvdztcbn1cblxuLy8g4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG4vLyBTUUwg54mH5q6155Sf5oiQXG4vLyDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcblxuLyoqXG4gKiDpqbHliqjnmoTpu5jorqRcIuWUr+S4gOWGsueqgVwi5Yik5a6a44CCXG4gKlxuICogU1FMaXRlIOeahOaJqeWxlee7k+aenOeggSAxNTU1IC8gMjA2NyDliIbliKvlr7nlupTkuLvplK7lhrLnqoHkuI7llK/kuIDntKLlvJXlhrLnqoHvvIxcbiAqIOaWh+acrOaYr+agh+WHhueahCBgVU5JUVVFIGNvbnN0cmFpbnQgZmFpbGVkOiAuLi5g44CC5Y6f55Sf57uR5a6a5aSa5pWw5Lya6YCP5Ye65YW25Lit5LmL5LiA44CCXG4gKiDoi6Xnu5HlrprkuKTogIXpg73kuI3nu5nvvIzlupTlrp7njrAgYFNxbGl0ZURyaXZlci5pc1VuaXF1ZVZpb2xhdGlvbmAg57K+56Gu6KaG55uW44CCXG4gKi9cbmZ1bmN0aW9uIGRlZmF1bHRJc1VuaXF1ZVZpb2xhdGlvbihlcnJvcjogdW5rbm93bik6IGJvb2xlYW4ge1xuICBpZiAodHlwZW9mIGVycm9yICE9PSAnb2JqZWN0JyB8fCBlcnJvciA9PT0gbnVsbCkgcmV0dXJuIGZhbHNlO1xuICBjb25zdCBjYW5kaWRhdGUgPSBlcnJvciBhcyB7IGVycmNvZGU/OiB1bmtub3duOyBjb2RlPzogdW5rbm93bjsgbWVzc2FnZT86IHVua25vd24gfTtcbiAgZm9yIChjb25zdCBjb2RlIG9mIFtjYW5kaWRhdGUuZXJyY29kZSwgY2FuZGlkYXRlLmNvZGVdKSB7XG4gICAgaWYgKHR5cGVvZiBjb2RlID09PSAnbnVtYmVyJyAmJiAoY29kZSA9PT0gMTU1NSB8fCBjb2RlID09PSAyMDY3KSkgcmV0dXJuIHRydWU7XG4gIH1cbiAgcmV0dXJuIChcbiAgICB0eXBlb2YgY2FuZGlkYXRlLm1lc3NhZ2UgPT09ICdzdHJpbmcnICYmXG4gICAgL1VOSVFVRSBjb25zdHJhaW50IGZhaWxlZC9pLnRlc3QoY2FuZGlkYXRlLm1lc3NhZ2UpXG4gICk7XG59XG5cbmZ1bmN0aW9uIHBrV2hlcmUocGxhbjogU3RvcmVQbGFuLCBhbGlhcz86IHN0cmluZyk6IHN0cmluZyB7XG4gIGNvbnN0IHByZWZpeCA9IGFsaWFzID09PSB1bmRlZmluZWQgPyAnJyA6IGAke2FsaWFzfS5gO1xuICByZXR1cm4gcGxhbi5wa0NvbHVtbnMubWFwKChjKSA9PiBgJHtwcmVmaXh9JHtxKGMpfSA9ID9gKS5qb2luKCcgQU5EICcpO1xufVxuXG5mdW5jdGlvbiBqb2luT25QayhsZWZ0OiBzdHJpbmcsIHJpZ2h0OiBzdHJpbmcsIHBsYW46IFN0b3JlUGxhbik6IHN0cmluZyB7XG4gIHJldHVybiBwbGFuLnBrQ29sdW1ucy5tYXAoKGMpID0+IGAke2xlZnR9LiR7cShjKX0gPSAke3JpZ2h0fS4ke3EoYyl9YCkuam9pbignIEFORCAnKTtcbn1cblxuZnVuY3Rpb24gb3JkZXJCeVBrKHBsYW46IFN0b3JlUGxhbiwgYWxpYXM/OiBzdHJpbmcpOiBzdHJpbmcge1xuICBjb25zdCBwcmVmaXggPSBhbGlhcyA9PT0gdW5kZWZpbmVkID8gJycgOiBgJHthbGlhc30uYDtcbiAgcmV0dXJuIHBsYW4ucGtDb2x1bW5zLm1hcCgoYykgPT4gYCR7cHJlZml4fSR7cShjKX1gKS5qb2luKCcsICcpO1xufVxuXG5mdW5jdGlvbiByYW5nZUNvbmRpdGlvbnMoY29sdW1uOiBzdHJpbmcsIHJhbmdlOiBEYktleVJhbmdlLCBwYXJhbXM6IFNxbFZhbHVlW10pOiBzdHJpbmdbXSB7XG4gIGNvbnN0IGNvbmRpdGlvbnM6IHN0cmluZ1tdID0gW107XG4gIGlmIChyYW5nZS5sb3dlciAhPT0gdW5kZWZpbmVkKSB7XG4gICAgY29uZGl0aW9ucy5wdXNoKGAke2NvbHVtbn0gJHtyYW5nZS5sb3dlck9wZW4gPT09IHRydWUgPyAnPicgOiAnPj0nfSA/YCk7XG4gICAgcGFyYW1zLnB1c2gocmFuZ2UubG93ZXIpO1xuICB9XG4gIGlmIChyYW5nZS51cHBlciAhPT0gdW5kZWZpbmVkKSB7XG4gICAgY29uZGl0aW9ucy5wdXNoKGAke2NvbHVtbn0gJHtyYW5nZS51cHBlck9wZW4gPT09IHRydWUgPyAnPCcgOiAnPD0nfSA/YCk7XG4gICAgcGFyYW1zLnB1c2gocmFuZ2UudXBwZXIpO1xuICB9XG4gIHJldHVybiBjb25kaXRpb25zO1xufVxuXG4vKiog5YaF6IGU57Si5byV5YC877yb5Lu75LiA5YiG6YeP57y65aSxL+mdnumUriDihpIg5rKh5pyJ57Si5byV6aG577yI6L+U5ZueIHVuZGVmaW5lZCDihpIg5a2YIE5VTEzvvInjgIIgKi9cbmZ1bmN0aW9uIGlubGluZUluZGV4VmFsdWVzKFxuICBpbmRleDogSW5kZXhQbGFuLFxuICByZWNvcmQ6IFJlY29yZDxzdHJpbmcsIHVua25vd24+LFxuKTogS2V5VmFsdWVbXSB8IHVuZGVmaW5lZCB7XG4gIGNvbnN0IG91dDogS2V5VmFsdWVbXSA9IFtdO1xuICBmb3IgKGNvbnN0IHBhdGggb2YgaW5kZXgucGF0aHMpIHtcbiAgICBjb25zdCB2ID0gdmFsdWVBdFBhdGgocmVjb3JkLCBwYXRoKTtcbiAgICBpZiAoIWlzS2V5VmFsdWUodikpIHJldHVybiB1bmRlZmluZWQ7XG4gICAgb3V0LnB1c2godik7XG4gIH1cbiAgcmV0dXJuIG91dDtcbn1cblxuLyoqIG11bHRpRW50cnkg57Si5byV6aG577ya5pWw57uE5a2X5q615bGV5byA77yM5ZCM5LiA6K6w5b2V5YaF6YeN5aSN5YWD57Sg5Y676YeN77yISW5kZXhlZERCIOivreS5ie+8ieOAgiAqL1xuZnVuY3Rpb24gbXVsdGlFbnRyeVZhbHVlcyhpbmRleDogSW5kZXhQbGFuLCByZWNvcmQ6IFJlY29yZDxzdHJpbmcsIHVua25vd24+KTogS2V5VmFsdWVbXSB7XG4gIGNvbnN0IHJhdyA9IHZhbHVlQXRQYXRoKHJlY29yZCwgaW5kZXgucGF0aHNbMF0hKTtcbiAgaWYgKCFBcnJheS5pc0FycmF5KHJhdykpIHJldHVybiBbXTtcbiAgY29uc3Qgb3V0OiBLZXlWYWx1ZVtdID0gW107XG4gIGZvciAoY29uc3QgdiBvZiByYXcpIHtcbiAgICBpZiAoaXNLZXlWYWx1ZSh2KSAmJiAhb3V0LnNvbWUoKGV4aXN0aW5nKSA9PiBjb21wYXJlS2V5cyhleGlzdGluZywgdikgPT09IDApKSBvdXQucHVzaCh2KTtcbiAgfVxuICByZXR1cm4gb3V0O1xufVxuXG5mdW5jdGlvbiB0b0RiS2V5KHBsYW46IFN0b3JlUGxhbiwgcGs6IEtleVZhbHVlW10pOiBEYktleSB7XG4gIC8vIOKaoO+4jyDlpI3lkIjkuLvplK7ml7bov5nph4zlrp7pmYXmmK/mlbDnu4TvvIzogIwgYERiQWRhcHRlcmAg5Y+q5aOw5piO5LqGIGBEYktleWDjgIJcbiAgLy8g5LiO5YaF5a2Y5a6e546w5LiA5qC377yM5Zyo6L6555WM5aSE5pS256qE77yb546w5pyJ6LCD55So5pa56YO96LWw5Y2V6ZSu44CCXG4gIHJldHVybiAocGxhbi5wa0NvbHVtbnMubGVuZ3RoID09PSAxID8gcGtbMF0hIDogKHBrIGFzIHVua25vd24gYXMgRGJLZXkpKSBhcyBEYktleTtcbn1cblxuZXhwb3J0IGludGVyZmFjZSBTcWxpdGVBZGFwdGVyT3B0aW9ucyB7XG4gIHNjaGVtYTogcmVhZG9ubHkgU3RvcmVTY2hlbWFbXTtcbiAgLyoqIOingeaehOmAoOWHveaVsOivtOaYju+8muazqOWFpSoq5bel5Y6CKirvvIzorqkgYGNsb3NlKClgIOWQjueahOmAj+aYjumHjeW8gOaIkOeri+OAgiAqL1xuICBkcml2ZXJGYWN0b3J5OiAoKSA9PiBTcWxpdGVEcml2ZXI7XG59XG5cbmV4cG9ydCB7IFNxbGl0ZUFkYXB0ZXIgfTtcbiIsIi8qKlxuICogb3AtbG9nIOWtmOWCqOeahCAqKldvcmtlciDmoaXmjqUqKuOAglxuICpcbiAqIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuICog5Li65LuA5LmI6ZyA6KaB5a6D77yI5LiN5piv5LiA5LiqXCLkvJjljJZcIu+8jOaYr+W5s+WPsOe6puadn++8iVxuICog4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG4gKiBbQURSLTAwMjhdKC4uLy4uLy4uLy4uL2RvY3MvYWRyLzAwMjgtd2ViLXNxbGl0ZS1tdXN0LXJ1bi1pbi13b3JrZXIubWQpIOWunua1i++8mlxuICog6aG16Z2i5Li757q/56iLKirmi7/kuI3liLAqKiBgRmlsZVN5c3RlbUZpbGVIYW5kbGUucHJvdG90eXBlLmNyZWF0ZVN5bmNBY2Nlc3NIYW5kbGVgXG4gKiDvvIjop4TojIMgYFtFeHBvc2VkPURlZGljYXRlZFdvcmtlcl1g77yJ77yM5omA5LulIE9QRlMg55qEIFNBSCBQb29sIFZGU1xuICogKirlj6rog73lnKggV29ya2VyIOmHjOijhSoq44CC5LqO5pivIHdlYiDnmoQgU1FMaXRlIOW/heeEtuWcqCBXb3JrZXIg6YeM44CCXG4gKlxuICog4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG4gKiDwn5S0IOi+ueeVjOeUu+WcqCBgT3BMb2dTdG9yZWDvvIzkuI3nlLvlnKggYERiQWRhcHRlcmBcbiAqIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuICog6L+Z5piv5pys5paH5Lu25pyA6YeN6KaB55qE5LiA5Liq5Yaz5a6a77yM5o2i5LiA56eN5YiH5rOV5bCx5YGa5LiN5oiQ77yaXG4gKlxuICogYERiQWRhcHRlci50cmFuc2FjdGlvbihzdG9yZXMsIG1vZGUsIGZuKWAgKirmjqXmlLbkuIDkuKrlm57osIMqKuOAglxuICog5Zue6LCDKirml6Dms5Xot6ggV29ya2VyIOW6j+WIl+WMlioqIOKAlOKAlCDlpoLmnpzovrnnlYznlLvlnKggYERiQWRhcHRlcmDvvIxcbiAqIOS4u+e6v+eoi+WwseW/hemhu+aKiuWbnuiwg+aLhuaIkOS4gOS4suWNleeLrOeahOivt+axguWPkei/h+WOu++8jOmCo+etieS6jioq5oqK5LqL5Yqh55qE5Y6f5a2Q5oCn5ouG5o6JKirvvJpcbiAqIOS4remAlOWksei0peWwseeVmeS4i+S4gOWNiuWGmeWFpe+8jOiAjFwi5Y2V5Liq5Y6f5a2Q5LqL5YqhXCLmraPmmK/ov5nkuKrmjqXlj6PnmoTmib/or7rjgIJcbiAqXG4gKiDmiYDku6XvvJoqKmBTcWxpdGVBZGFwdGVyYCDlkowgYERiT3BMb2dTdG9yZWAg6YO955WZ5ZyoIFdvcmtlciDph4wqKu+8jFxuICog5Li757q/56iL5Y+q5ou/5LiA5LiqIGBPcExvZ1N0b3JlYCDku6PnkIbjgIJcbiAqXG4gKiDlpb3lpITkuI3lj6rmmK9cIuiDvei3kVwi77yaXG4gKiAtIOS6i+WKoeeahOWOn+WtkOaApyoq5Y6f5Zyw5L+d5oyBKirvvIzmsqHmnInooqvmi4bmiJDlpJrmrKHlvoDov5TvvJtcbiAqIC0g6YCC6YWN5Zmo6YC76L6RKirlj6rmnInkuIDku70qKu+8iEFEUi0wMDAzIMKnMi4y77yJ4oCU4oCUIFdvcmtlciDph4zpgqPku73lsLHmmK/lpZHnuqbmtYvor5Xot5Hov4fnmoTpgqPku73vvJtcbiAqIC0g5Li757q/56iL5ou/5Yiw55qE5o6l5Y+j5LiOIGBJbmRleGVkRGJPcExvZ1N0b3JlYCAqKuWujOWFqOWQjOWeiyoq77yMXG4gKiAgIOaJgOS7pSBgYXBwcy93ZWJgIOaNoui/h+adpeaYryoq5o2i5LiA5Liq5a6e546wKirvvIzkuI3mmK/mlLnkuIDlsYLmnrbmnoTjgIJcbiAqXG4gKiDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcbiAqIOWNj+iuruS4uuS7gOS5iOaYr1wi5rOb5Z6L5pa55rOV5ZCNICsg5pWw57uE5Y+C5pWwXCJcbiAqIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuICog5Zug5Li6IGBPcExvZ1N0b3JlYCDnmoTmr4/kuKrmlrnms5Xpg73mu6HotrPkuKTkuKrmnaHku7bvvIjov5nmmK8qKumAkOS4quaguOWvuei/hyoq55qE77yM5LiN5piv5YGH6K6+77yJ77yaXG4gKiAgIDEuIOi/lOWbniBgUHJvbWlzZWDvvJtcbiAqICAgMi4g5Y+C5pWw5YWo6YOo5Y+vKirnu5PmnoTljJblhYvpmoYqKuOAglxuICpcbiAqIOesrCAyIOadoemHjOWUr+S4gOmcgOimgeeVmeaEj+eahOaYryBgbWFya1VwbG9hZGVkKFJlYWRvbmx5TWFwPHN0cmluZywgbnVtYmVyPilgIOKAlOKAlFxuICogYE1hcGAgKirmmK8qKuWPr+e7k+aehOWMluWFi+mahueahO+8iGBzdHJ1Y3R1cmVkQ2xvbmVgIOaUr+aMgSBNYXAvU2V0L0RhdGUvQXJyYXlCdWZmZXLvvInvvIxcbiAqIOaJgOS7peWug+WOn+agt+iDvei/h++8jOS4jemcgOimgei9rOaIkCBgW1trLHZdXWDjgIJcbiAqXG4gKiDlj43ov4fmnaXor7TvvJoqKuWTquWkqee7mSBgT3BMb2dTdG9yZWAg5Yqg5LqG5bim5Zue6LCD55qE5pa55rOV77yM6L+Z6YeM5Lya6Z2Z6buY5aSx5pWIKiog4oCU4oCUXG4gKiDlm57osIPlnKjlhYvpmobml7bnm7TmjqXmipsgYERhdGFDbG9uZUVycm9yYO+8jOaJgOS7peiHs+WwkeS4jeaYr+mdmem7mOeahOOAglxuICovXG5cbmltcG9ydCB0eXBlIHsgT3BlcmF0aW9uIH0gZnJvbSAnQGhleXRhL3N5bmMtY29yZSc7XG5cbmltcG9ydCB0eXBlIHsgT3BMb2dTdG9yZSB9IGZyb20gJy4uL29wLWxvZy1zdG9yZS5qcyc7XG5cbi8qKlxuICogV29ya2VyIOS+p+imgeacjeWKoeeahCBzdG9yZeOAgioq5pWF5oSP5Y+q6KaBIGBPcExvZ1N0b3JlYCoqIOKAlOKAlFxuICog5a6D5q+UIGBEYkFkYXB0ZXJgIOeqhO+8jOiAjOeqhOeahOi+ueeVjOabtOWlveWuiOOAglxuICovXG5leHBvcnQgdHlwZSBPcExvZ1dvcmtlclN0b3JlPFRPcGVyYXRpb24gZXh0ZW5kcyBPcGVyYXRpb248c3RyaW5nPiA9IE9wZXJhdGlvbj4gPVxuICBPcExvZ1N0b3JlPFRPcGVyYXRpb24+O1xuXG4vKiog5Y+v5Lul5LuO5Li757q/56iL6LCD5YiwIFdvcmtlciDnmoTmlrnms5XlkI3vvIg9IGBPcExvZ1N0b3JlYCDnmoTplK7vvInjgIIgKi9cbmV4cG9ydCB0eXBlIE9wTG9nV29ya2VyTWV0aG9kID0ga2V5b2YgT3BMb2dTdG9yZTxPcGVyYXRpb24+O1xuXG5leHBvcnQgaW50ZXJmYWNlIE9wTG9nV29ya2VyUmVxdWVzdCB7XG4gIHJlYWRvbmx5IGlkOiBudW1iZXI7XG4gIHJlYWRvbmx5IG1ldGhvZDogc3RyaW5nO1xuICByZWFkb25seSBhcmdzOiB1bmtub3duW107XG59XG5cbi8qKiDplJnor6/kuZ/opoHov4fkuIDkuIvnu5PmnoTljJblhYvpmobvvJpgRXJyb3JgIOWunuS+i+acrOi6q+i/h+S4jeWOu++8jOaJgOS7peaLhuaIkOaZrumAmuWvueixoeOAgiAqL1xuZXhwb3J0IGludGVyZmFjZSBTZXJpYWxpemVkRXJyb3Ige1xuICByZWFkb25seSBuYW1lOiBzdHJpbmc7XG4gIHJlYWRvbmx5IG1lc3NhZ2U6IHN0cmluZztcbiAgcmVhZG9ubHkgc3RhY2s/OiBzdHJpbmc7XG59XG5cbmV4cG9ydCB0eXBlIE9wTG9nV29ya2VyUmVzcG9uc2UgPVxuICB8IHsgcmVhZG9ubHkgaWQ6IG51bWJlcjsgcmVhZG9ubHkgb2s6IHRydWU7IHJlYWRvbmx5IHZhbHVlOiB1bmtub3duIH1cbiAgfCB7IHJlYWRvbmx5IGlkOiBudW1iZXI7IHJlYWRvbmx5IG9rOiBmYWxzZTsgcmVhZG9ubHkgZXJyb3I6IFNlcmlhbGl6ZWRFcnJvciB9O1xuXG4vKipcbiAqIFdvcmtlciDkvqfnmoQqKuWIneWni+WMluS6pOaPoSoq44CC5a6D5rKh5pyJIGBpZGDvvIzmiYDku6XkuI3kvJrlkozor7fmsYIv5ZON5bqU5a+55pKe5LiK44CCXG4gKlxuICog5LmL5omA5Lul6KaB5Lqk5o+h6ICM5LiN5piv6K6p5Li757q/56iL55uy562J77yaYGNsaWVudElkYCDmmK8gTFdXIOWGsueqgeeahCoq5Yaz6IOc5L6d5o2uKipcbiAqIO+8iOingSBgYXBwcy93ZWIvc3JjL2xpYi9vcGxvZy50c2Ag6YeM55qE5pWZ6K6t77yJ77yM5b+F6aG755SxKipXb3JrZXIg6YeM6YKj5Liq5bqTKipcbiAqIOe7meWHuuadg+WogeWAvO+8jOiAjOS4jeaYr+S4u+e6v+eoi+iHquW3seWGjeeul+S4gOS4quOAglxuICpcbiAqIOaIkOWKn+aXtuW4piBgY2xpZW50SWRg77yM5aSx6LSl5pe25bimIGBlcnJvcmAg4oCU4oCUICoq5aSx6LSl5Lmf5b+F6aG75oqlKirvvIxcbiAqIOWQpuWImeS4u+e6v+eoi+S8muWcqOS4gOS4quawuOi/nOS4jeS8muWlvei1t+adpeeahOW6k+S4iuS4gOebtOi9rOWciOOAglxuICovXG5leHBvcnQgdHlwZSBPcExvZ1dvcmtlclJlYWR5ID1cbiAgfCB7IHJlYWRvbmx5IHR5cGU6ICdyZWFkeSc7IHJlYWRvbmx5IGNsaWVudElkOiBzdHJpbmcgfVxuICB8IHsgcmVhZG9ubHkgdHlwZTogJ3JlYWR5JzsgcmVhZG9ubHkgZXJyb3I6IFNlcmlhbGl6ZWRFcnJvciB9O1xuXG4vKiog5oqK5Lu75oSP5byC5bi45Y6L5oiQ5Y+v5YWL6ZqG55qE5b2i54q244CCICovXG5leHBvcnQgZnVuY3Rpb24gc2VyaWFsaXplRXJyb3IoZXJyb3I6IHVua25vd24pOiBTZXJpYWxpemVkRXJyb3Ige1xuICBpZiAoZXJyb3IgaW5zdGFuY2VvZiBFcnJvcikge1xuICAgIHJldHVybiB7XG4gICAgICBuYW1lOiBlcnJvci5uYW1lLFxuICAgICAgbWVzc2FnZTogZXJyb3IubWVzc2FnZSxcbiAgICAgIC8vIGBzdGFja2Ag5Y+q5Zyo5a2Y5Zyo5pe25bim5LiKIOKAlOKAlCDmn5DkupvlvJXmk44v5YyF6KOF5LiL5a6D5Y+v6IO95rKh5pyJ44CCXG4gICAgICAuLi4oZXJyb3Iuc3RhY2sgPT09IHVuZGVmaW5lZCA/IHt9IDogeyBzdGFjazogZXJyb3Iuc3RhY2sgfSksXG4gICAgfTtcbiAgfVxuICByZXR1cm4geyBuYW1lOiAnRXJyb3InLCBtZXNzYWdlOiBTdHJpbmcoZXJyb3IpIH07XG59XG5cbi8qKiDlnKjosIPnlKjmlrnph43lu7rlvILluLjjgILkv53nlZkgYG5hbWVgIOS4jiBgc3RhY2tg77yM5ZCm5YiZ5aCG5qCI5Lya5pat5Zyo5qGl6L+Z6YeM44CCICovXG5mdW5jdGlvbiBkZXNlcmlhbGl6ZUVycm9yKGVycm9yOiBTZXJpYWxpemVkRXJyb3IpOiBFcnJvciB7XG4gIGNvbnN0IHJlYnVpbHQgPSBuZXcgRXJyb3IoZXJyb3IubWVzc2FnZSk7XG4gIHJlYnVpbHQubmFtZSA9IGVycm9yLm5hbWU7XG4gIGlmIChlcnJvci5zdGFjayAhPT0gdW5kZWZpbmVkKSByZWJ1aWx0LnN0YWNrID0gZXJyb3Iuc3RhY2s7XG4gIHJldHVybiByZWJ1aWx0O1xufVxuXG4vKipcbiAqICoqV29ya2VyIOS+pyoq77ya5aSE55CG5LiA5p2h6K+35rGC44CCXG4gKlxuICog5Y2V54us5a+85Ye677yI6ICM5LiN5Y+q5piv5YaF6IGU5Zyo5YWl5Y+j6YeM77yJ5piv5Li65LqG5a6D6IO96KKrKirnm7TmjqXmtYvor5UqKiDigJTigJRcbiAqIOS4jemcgOimgeecn+eahOi1t+S4gOS4qiBXb3JrZXIg5bCx6IO96aqMXCLmlrnms5XlkI3kuI3orqTor4bml7bmiqXku4DkuYjplJlcIui/meexu+WIhuaUr+OAglxuICovXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gaGFuZGxlT3BMb2dXb3JrZXJSZXF1ZXN0KFxuICBzdG9yZTogT3BMb2dXb3JrZXJTdG9yZSxcbiAgcmVxdWVzdDogT3BMb2dXb3JrZXJSZXF1ZXN0LFxuKTogUHJvbWlzZTxPcExvZ1dvcmtlclJlc3BvbnNlPiB7XG4gIGNvbnN0IGZuID0gKHN0b3JlIGFzIHVua25vd24gYXMgUmVjb3JkPHN0cmluZywgdW5rbm93bj4pW3JlcXVlc3QubWV0aG9kXTtcbiAgaWYgKHR5cGVvZiBmbiAhPT0gJ2Z1bmN0aW9uJykge1xuICAgIC8qKlxuICAgICAqIOKaoO+4jyDov5nph4wqKuS4jeimgSoq5oKE5oKE6L+U5ZueIHVuZGVmaW5lZOOAglxuICAgICAqIOaWueazleWQjeaJk+mUme+8iOaIliBgT3BMb2dTdG9yZWAg5pS55ZCN6ICM5qGl5LiK5rKh6Lef5LiK77yJ5pe277yMXG4gICAgICog6Z2Z6buY6L+U5ZueIHVuZGVmaW5lZCDkvJrorqnosIPnlKjmlrnmi7/liLDkuIDkuKpcIuWBh+eahOepuue7k+aenFwi77yMXG4gICAgICog6ICM55yf5a6e5Y6f5Zug5pivXCLov5nkuKrmlrnms5XljovmoLnmsqHooqvovazlj5FcIiDigJTigJQg5Y+I5piv5LiA5qyhXCLku4DkuYjpg73msqHlj5HnlJ9cIuOAglxuICAgICAqL1xuICAgIHJldHVybiB7XG4gICAgICBpZDogcmVxdWVzdC5pZCxcbiAgICAgIG9rOiBmYWxzZSxcbiAgICAgIGVycm9yOiB7XG4gICAgICAgIG5hbWU6ICdUeXBlRXJyb3InLFxuICAgICAgICBtZXNzYWdlOiBgT3BMb2dTdG9yZSDkuIrmsqHmnInmlrnms5UgXCIke3JlcXVlc3QubWV0aG9kfVwi44CC6K+35qC45a+5IE9wTG9nU3RvcmUg5piv5ZCm5pS55ZCN44CB5Lul5Y+K5qGl5LiK55qE6L2s5Y+R5YiX6KGo5piv5ZCm6Lef5LiK44CCYCxcbiAgICAgIH0sXG4gICAgfTtcbiAgfVxuXG4gIHRyeSB7XG4gICAgY29uc3QgdmFsdWUgPSBhd2FpdCAoZm4gYXMgKC4uLmE6IHVua25vd25bXSkgPT4gUHJvbWlzZTx1bmtub3duPikuYXBwbHkoc3RvcmUsIHJlcXVlc3QuYXJncyk7XG4gICAgcmV0dXJuIHsgaWQ6IHJlcXVlc3QuaWQsIG9rOiB0cnVlLCB2YWx1ZSB9O1xuICB9IGNhdGNoIChlcnJvcikge1xuICAgIHJldHVybiB7IGlkOiByZXF1ZXN0LmlkLCBvazogZmFsc2UsIGVycm9yOiBzZXJpYWxpemVFcnJvcihlcnJvcikgfTtcbiAgfVxufVxuXG4vKipcbiAqICoqV29ya2VyIOS+pyoq77ya5oqKIHN0b3JlIOaOpeWIsOS4gOS4qiBgcG9zdE1lc3NhZ2VgIOerr+WPo+S4iuOAglxuICpcbiAqIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuICog8J+UtCDkuLrku4DkuYjopoHmlLbkuIDkuKogYFByb21pc2VgIOiAjOS4jeaYr+W3sue7j+W7uuWlveeahCBzdG9yZVxuICog4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG4gKiDlm6DkuLogd29ya2VyIOmHjFwi5byA5bqTXCLmmK8qKuW8guatpSoq55qE77yI6KOFIE9QRlMgVkZT44CB5bu66KGo77yJ77yM6ICM5Li757q/56iL5Y+v6IO9Kirnq4vliLsqKlxuICog5bCx5Y+R6LW36K+35rGC44CC5Lik56eN5YaZ5rOV6YO96ZSZ77yaXG4gKiAgIC0g562J5byA5a6M5bqT5YaN5oyCIGBvbm1lc3NhZ2VgIOKGkiDmnJ/pl7TliLDovr7nmoTmtojmga8qKuebtOaOpeS4ouWksSoq77yM6KGo546w5Li6XCLnrKzkuIDmrKHlhpnlhaXkuI3op4HkuoZcIu+8m1xuICogICAtIOaMguS4iuS9huS4jeeuoemhuuW6jyDihpIg6K+35rGC5Zyo5bqT6L+Y5rKh5aW95pe26KKr5aSE55CGIOKGkiDmiqXkuIDkuKrlkoznnJ/lrp7ljp/lm6Dml6DlhbPnmoTplJnjgIJcbiAqXG4gKiDmiYDku6Xov5nph4wqKuWFiOaMguebkeWQrOOAgeaKiuivt+axgue8k+WGsui1t+adpSoq77yM562JIGByZWFkeWAg5Yaz6K6u5ZCO5YaN5o6S56m66Zif5YiX44CCXG4gKiDmtojmga/pobrluo/nlLHmraQqKuS4jeS+nei1lioq5Lik6L6555qE5ZCv5Yqo5b+r5oWiIOKAlOKAlCDpgqPmnKzmnaXlsLHmmK/kuI3noa7lrprnmoTjgIJcbiAqXG4gKiDmjpLnqbrmmK8qKuaMieWIsOi+vumhuuW6j+S4suihjCoq55qE77yIYGF3YWl0YCDliY3kuIDmnaHlho3lpITnkIbkuIvkuIDmnaHvvInvvJpgU3FsaXRlQWRhcHRlcmBcbiAqIOWGhemDqOiZveeEtuaciSBGSUZPIOmYn+WIl++8jOS9huiuqeivt+axguaMieWOn+mhuuW6j+i/m+WFpeWug+abtOS4jeWuueaYk+WHuuaEj+Wklu+8jOiAjOS4lOS7o+S7t+aYr+S4gOasoVxuICog5b6u5Lu75Yqh44CC6L+Z6YeM55qE5Liy6KGM5Y+q5b2x5ZONXCLlj5Hlh7rljrvnmoTpobrluo9cIu+8jOS4jeW9seWTjeWQnuWQkCDigJTigJQg5q+P5p2h5LuN5piv54us56uLIFByb21pc2XjgIJcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHNlcnZlT3BMb2dXb3JrZXIoXG4gIHBvcnQ6IHtcbiAgICBvbm1lc3NhZ2U6ICgoZXZlbnQ6IHsgZGF0YTogdW5rbm93biB9KSA9PiB2b2lkKSB8IG51bGw7XG4gICAgcG9zdE1lc3NhZ2UobWVzc2FnZTogdW5rbm93bik6IHZvaWQ7XG4gIH0sXG4gIHJlYWR5OiBQcm9taXNlPHsgcmVhZG9ubHkgc3RvcmU6IE9wTG9nV29ya2VyU3RvcmU7IHJlYWRvbmx5IGNsaWVudElkOiBzdHJpbmcgfT4sXG4pOiB2b2lkIHtcbiAgLyoqIOW8gOW6k+WujOaIkOWJjeWIsOi+vueahOivt+axguOAgiAqL1xuICBjb25zdCBiYWNrbG9nOiBPcExvZ1dvcmtlclJlcXVlc3RbXSA9IFtdO1xuICBsZXQgc3RvcmU6IE9wTG9nV29ya2VyU3RvcmUgfCBudWxsID0gbnVsbDtcblxuICBjb25zdCBkaXNwYXRjaCA9IGFzeW5jIChyZXF1ZXN0OiBPcExvZ1dvcmtlclJlcXVlc3QpOiBQcm9taXNlPHZvaWQ+ID0+IHtcbiAgICBpZiAoc3RvcmUgPT09IG51bGwpIHtcbiAgICAgIGJhY2tsb2cucHVzaChyZXF1ZXN0KTtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBoYW5kbGVPcExvZ1dvcmtlclJlcXVlc3Qoc3RvcmUsIHJlcXVlc3QpO1xuICAgIHBvcnQucG9zdE1lc3NhZ2UocmVzcG9uc2UpO1xuICB9O1xuXG4gIC8vIPCflLQg5YWI5oyC55uR5ZCs77yM5YaN562JIHJlYWR5IOKAlOKAlCDpobrluo/kuI3og73lj43jgIJcbiAgcG9ydC5vbm1lc3NhZ2UgPSAoZXZlbnQpID0+IHtcbiAgICB2b2lkIGRpc3BhdGNoKGV2ZW50LmRhdGEgYXMgT3BMb2dXb3JrZXJSZXF1ZXN0KTtcbiAgfTtcblxuICByZWFkeS50aGVuKFxuICAgIChvcGVuZWQpID0+IHtcbiAgICAgIHN0b3JlID0gb3BlbmVkLnN0b3JlO1xuICAgICAgLy8g5YWI5oqlIHJlYWR577ya5Li757q/56iL55qEIGByZWFkeWAgUHJvbWlzZSDnlLHmraTlhrPorq7jgIJcbiAgICAgIHBvcnQucG9zdE1lc3NhZ2UoeyB0eXBlOiAncmVhZHknLCBjbGllbnRJZDogb3BlbmVkLmNsaWVudElkIH0gc2F0aXNmaWVzIE9wTG9nV29ya2VyUmVhZHkpO1xuICAgICAgLyoqXG4gICAgICAgKiDmjpLnqbrnvJPlhrLjgIIqKuWFiOaVtOaJueWPlui1sOWGjemAkOadoeWkhOeQhioqIOKAlOKAlCDlpITnkIbov4fnqIvkuK3ov5jkvJrmnInmlrDmtojmga/ov5vmnaXvvIxcbiAgICAgICAqIOWug+S7rOWcqCBgZGlzcGF0Y2hgIOmHjOeci+WIsCBgc3RvcmUgIT09IG51bGxgIOS8muebtOaOpei1sO+8jOS4jeS8muaPkui/m+i/meS4gOaJueOAglxuICAgICAgICovXG4gICAgICBjb25zdCBwZW5kaW5nUmVxdWVzdHMgPSBiYWNrbG9nLnNwbGljZSgwLCBiYWNrbG9nLmxlbmd0aCk7XG4gICAgICB2b2lkIChhc3luYyAoKSA9PiB7XG4gICAgICAgIGZvciAoY29uc3QgcmVxdWVzdCBvZiBwZW5kaW5nUmVxdWVzdHMpIHtcbiAgICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGhhbmRsZU9wTG9nV29ya2VyUmVxdWVzdChvcGVuZWQuc3RvcmUsIHJlcXVlc3QpO1xuICAgICAgICAgIHBvcnQucG9zdE1lc3NhZ2UocmVzcG9uc2UpO1xuICAgICAgICB9XG4gICAgICB9KSgpO1xuICAgIH0sXG4gICAgKGVycm9yOiB1bmtub3duKSA9PiB7XG4gICAgICAvLyDlvIDlupPlpLHotKXvvJoqKuW/hemhu+iuqeS4u+e6v+eoi+S5n+Wksei0pSoq77yM5ZCm5YiZ5a6D55qE6K+35rGC5Lya5rC46L+c5oKs552A77yI55WM6Z2i5LiA55u06L2s5ZyI77yJ44CCXG4gICAgICBwb3J0LnBvc3RNZXNzYWdlKHsgdHlwZTogJ3JlYWR5JywgZXJyb3I6IHNlcmlhbGl6ZUVycm9yKGVycm9yKSB9IHNhdGlzZmllcyBPcExvZ1dvcmtlclJlYWR5KTtcbiAgICAgIGNvbnN0IGZhaWx1cmUgPSBzZXJpYWxpemVFcnJvcihlcnJvcik7XG4gICAgICBjb25zdCBwZW5kaW5nUmVxdWVzdHMgPSBiYWNrbG9nLnNwbGljZSgwLCBiYWNrbG9nLmxlbmd0aCk7XG4gICAgICBmb3IgKGNvbnN0IHJlcXVlc3Qgb2YgcGVuZGluZ1JlcXVlc3RzKSB7XG4gICAgICAgIHBvcnQucG9zdE1lc3NhZ2UoeyBpZDogcmVxdWVzdC5pZCwgb2s6IGZhbHNlLCBlcnJvcjogZmFpbHVyZSB9KTtcbiAgICAgIH1cbiAgICB9LFxuICApO1xufVxuXG4vKiogYGNyZWF0ZVdvcmtlck9wTG9nU2Vzc2lvbmAg55qE6L+U5Zue5YC844CCICovXG5leHBvcnQgaW50ZXJmYWNlIFdvcmtlck9wTG9nU2Vzc2lvbjxUT3BlcmF0aW9uIGV4dGVuZHMgT3BlcmF0aW9uPHN0cmluZz4gPSBPcGVyYXRpb24+IHtcbiAgLyoqIOS4juacrOWcsOebtOi/nioq5ZCM5Z6LKirnmoQgc3RvcmUg5Luj55CG44CCICovXG4gIHJlYWRvbmx5IHN0b3JlOiBPcExvZ1N0b3JlPFRPcGVyYXRpb24+O1xuICAvKipcbiAgICogV29ya2VyIOWujOaIkOW8gOW6k+OAgeW5tue7meWHuioq5p2D5aiBIGBjbGllbnRJZGAqKiDlkI7lhrPorq7jgIJcbiAgICpcbiAgICog8J+UtCDosIPnlKjmlrkqKuW/hemhu+WFiCBhd2FpdCDlroPlho3mnoTpgKDlvJXmk44qKiDigJTigJQg5ZCm5YiZ5Lya5ou/552A5LiA5Liq6L+Y5rKh5a6a55qEXG4gICAqIGBjbGllbnRJZGAg5Y675bu65ZCR6YeP5pe26ZKf77yM6YKj5q2j5pivXCLkuKTku70gY2xpZW50SWQg5a6e546wXCLpgqPnsbsgYnVnIOeahOa4qeW6iuOAglxuICAgKi9cbiAgcmVhZG9ubHkgcmVhZHk6IFByb21pc2U8eyByZWFkb25seSBjbGllbnRJZDogc3RyaW5nIH0+O1xufVxuXG4vKipcbiAqICoq5Li757q/56iL5L6nKirvvJpgT3BMb2dTdG9yZWAg55qEIFdvcmtlciDku6PnkIYgKyDliJ3lp4vljJbkuqTmj6HjgIJcbiAqXG4gKiDlroPlrp7njrDnmoTmmK8qKuWQjOS4gOS4quaOpeWPoyoq77yM5omA5LulIGBhcHBzL3dlYmAg6YKj6L655o2i6L+H5p2l5Y+q5piv5o2i5LiA5Liq5a6e546wIOKAlOKAlFxuICogYE9wTG9nRW5naW5lYOOAgeWQjOatpeWuouaIt+err+OAgeWQhCBmZWF0dXJlIHN0b3JlIOmDveS4jeefpemBk+WQjumdouaNouS6huW8leaTjuOAglxuICovXG5leHBvcnQgZnVuY3Rpb24gY3JlYXRlV29ya2VyT3BMb2dTZXNzaW9uPFRPcGVyYXRpb24gZXh0ZW5kcyBPcGVyYXRpb248c3RyaW5nPiA9IE9wZXJhdGlvbj4oXG4gIHdvcmtlcjogeyBwb3N0TWVzc2FnZShtZXNzYWdlOiB1bmtub3duKTogdm9pZCB9LFxuKTogV29ya2VyT3BMb2dTZXNzaW9uPFRPcGVyYXRpb24+IHtcbiAgbGV0IG5leHRJZCA9IDA7XG4gIGNvbnN0IHBlbmRpbmcgPSBuZXcgTWFwPFxuICAgIG51bWJlcixcbiAgICB7IHJlc29sdmU6ICh2YWx1ZTogdW5rbm93bikgPT4gdm9pZDsgcmVqZWN0OiAoZXJyb3I6IHVua25vd24pID0+IHZvaWQgfVxuICA+KCk7XG5cbiAgbGV0IHJlc29sdmVSZWFkeTogKHZhbHVlOiB7IHJlYWRvbmx5IGNsaWVudElkOiBzdHJpbmcgfSkgPT4gdm9pZCA9ICgpID0+IHVuZGVmaW5lZDtcbiAgbGV0IHJlamVjdFJlYWR5OiAoZXJyb3I6IHVua25vd24pID0+IHZvaWQgPSAoKSA9PiB1bmRlZmluZWQ7XG4gIGNvbnN0IHJlYWR5ID0gbmV3IFByb21pc2U8eyByZWFkb25seSBjbGllbnRJZDogc3RyaW5nIH0+KChyZXNvbHZlLCByZWplY3QpID0+IHtcbiAgICByZXNvbHZlUmVhZHkgPSByZXNvbHZlO1xuICAgIHJlamVjdFJlYWR5ID0gcmVqZWN0O1xuICB9KTtcbiAgLy8g5rKh5Lq6IGF3YWl0IGByZWFkeWAg5pe25LiN6KaB6K6pIE5vZGUg5oqlIHVuaGFuZGxlZCByZWplY3Rpb27vvIhob3N0IOS+p+S7jeWcqOi3ke+8ieOAglxuICByZWFkeS5jYXRjaCgoKSA9PiB1bmRlZmluZWQpO1xuXG4gIC8qKlxuICAgKiDimqDvuI8g6L+Z6YeM5b+F6aG7Kiroh6rlt7HmjILnnYAqKiBgb25tZXNzYWdlYO+8jOS4jeiDveS+nei1luiwg+eUqOaWueWOu+i9rOOAglxuICAgKiDku6PnkIbmjIHmnIkgUHJvbWlzZSDlhrPorq7mnYPvvIzmtojmga/kuIDml6booqvliKvkurrmtojotLnmjonvvIzov5nph4zlsLHmsLjov5zmgqznnYAg4oCU4oCUXG4gICAqIOihqOeOsOS4ulwi55WM6Z2i5LiA55u06L2s5ZyIXCLvvIzogIzkuI3mmK/kuIDkuKrplJnor6/jgIJcbiAgICovXG4gIGNvbnN0IHJlY2VpdmVyID0gd29ya2VyIGFzIHVua25vd24gYXMge1xuICAgIG9ubWVzc2FnZTogKChldmVudDogeyBkYXRhOiB1bmtub3duIH0pID0+IHZvaWQpIHwgbnVsbDtcbiAgICBhZGRFdmVudExpc3RlbmVyPzogKHR5cGU6IHN0cmluZywgbGlzdGVuZXI6IChldmVudDogeyBkYXRhOiB1bmtub3duIH0pID0+IHZvaWQpID0+IHZvaWQ7XG4gIH07XG5cbiAgY29uc3Qgb25NZXNzYWdlID0gKGV2ZW50OiB7IGRhdGE6IHVua25vd24gfSk6IHZvaWQgPT4ge1xuICAgIGNvbnN0IGRhdGEgPSBldmVudC5kYXRhIGFzIE9wTG9nV29ya2VyUmVzcG9uc2UgfCBPcExvZ1dvcmtlclJlYWR5O1xuXG4gICAgLyoqXG4gICAgICog8J+UtCAqKuWFiOWIpOaYr+S4jeaYr+S6pOaPoea2iOaBryoq44CC5a6D5rKh5pyJIGBpZGDvvIzoi6XmjInlk43lupTlpITnkIbvvIxcbiAgICAgKiBgcGVuZGluZy5nZXQodW5kZWZpbmVkKWAg5Lya5b6X5YiwIHVuZGVmaW5lZCDnhLblkI7ooqvpnZnpu5jlv73nlaUg4oCU4oCUXG4gICAgICog5LqO5pivIGByZWFkeWAg5rC46L+c5LiN5Yaz6K6u77yM6KGo546w5Li6XCLlupTnlKjljaHlnKjlkK/liqhcIuOAglxuICAgICAqL1xuICAgIGlmICgndHlwZScgaW4gZGF0YSAmJiBkYXRhLnR5cGUgPT09ICdyZWFkeScpIHtcbiAgICAgIGlmICgnY2xpZW50SWQnIGluIGRhdGEpIHJlc29sdmVSZWFkeSh7IGNsaWVudElkOiBkYXRhLmNsaWVudElkIH0pO1xuICAgICAgZWxzZSByZWplY3RSZWFkeShkZXNlcmlhbGl6ZUVycm9yKGRhdGEuZXJyb3IpKTtcbiAgICAgIHJldHVybjtcbiAgICB9XG5cbiAgICBjb25zdCByZXNwb25zZSA9IGRhdGEgYXMgT3BMb2dXb3JrZXJSZXNwb25zZTtcbiAgICBjb25zdCB3YWl0ZXIgPSBwZW5kaW5nLmdldChyZXNwb25zZS5pZCk7XG4gICAgaWYgKHdhaXRlciA9PT0gdW5kZWZpbmVkKSByZXR1cm47XG4gICAgcGVuZGluZy5kZWxldGUocmVzcG9uc2UuaWQpO1xuICAgIGlmIChyZXNwb25zZS5vaykgd2FpdGVyLnJlc29sdmUocmVzcG9uc2UudmFsdWUpO1xuICAgIGVsc2Ugd2FpdGVyLnJlamVjdChkZXNlcmlhbGl6ZUVycm9yKHJlc3BvbnNlLmVycm9yKSk7XG4gIH07XG5cbiAgLy8gYGFkZEV2ZW50TGlzdGVuZXJgIOS8mOWFiO+8mmBvbm1lc3NhZ2VgIOaYr+WNleanveeahO+8jOiiq+imhuebluWwsemdmem7mOWkseWOu+aOpeaUtuiDveWKm+OAglxuICBpZiAodHlwZW9mIHJlY2VpdmVyLmFkZEV2ZW50TGlzdGVuZXIgPT09ICdmdW5jdGlvbicpIHtcbiAgICByZWNlaXZlci5hZGRFdmVudExpc3RlbmVyKCdtZXNzYWdlJywgb25NZXNzYWdlKTtcbiAgfSBlbHNlIHtcbiAgICByZWNlaXZlci5vbm1lc3NhZ2UgPSBvbk1lc3NhZ2U7XG4gIH1cblxuICBjb25zdCBjYWxsID0gKG1ldGhvZDogc3RyaW5nLCBhcmdzOiB1bmtub3duW10pOiBQcm9taXNlPHVua25vd24+ID0+IHtcbiAgICBjb25zdCBpZCA9ICsrbmV4dElkO1xuICAgIHJldHVybiBuZXcgUHJvbWlzZSgocmVzb2x2ZSwgcmVqZWN0KSA9PiB7XG4gICAgICBwZW5kaW5nLnNldChpZCwgeyByZXNvbHZlLCByZWplY3QgfSk7XG4gICAgICB3b3JrZXIucG9zdE1lc3NhZ2UoeyBpZCwgbWV0aG9kLCBhcmdzIH0gc2F0aXNmaWVzIE9wTG9nV29ya2VyUmVxdWVzdCk7XG4gICAgfSk7XG4gIH07XG5cbiAgLyoqXG4gICAqIOS7o+eQhuacrOS9k+OAglxuICAgKlxuICAgKiDwn5S0ICoq5pa55rOV5ZCN6YCQ5Liq5YiX5Ye65p2l77yM5LiN55SoIGBQcm94eWAg6Ieq5Yqo6L2s5Y+RKirvvJpcbiAgICog6Ieq5Yqo6L2s5Y+R5Lya6K6pXCLmjqXlj6PliqDkuobmlrnms5XkvYbmoaXkuIrlv5jkuobovazlj5FcIuWPmOaIkOi/kOihjOaXtuaJjeWPkeeOsOeahOS6i++8jFxuICAgKiDogIzkuJQgVHlwZVNjcmlwdCDkuZ/luK7kuI3kuIrlv5njgILmmL7lvI/liJflh7rml7bvvIzmjqXlj6PkuIDmlLnov5nph4wqKue8luivkeWwsei/h+S4jeWOuyoq44CCXG4gICAqL1xuICBjb25zdCBzdG9yZTogT3BMb2dTdG9yZTxUT3BlcmF0aW9uPiA9IHtcbiAgICBhcHBlbmRMb2NhbDogKG9wcykgPT4gY2FsbCgnYXBwZW5kTG9jYWwnLCBbb3BzXSkgYXMgUHJvbWlzZTxudW1iZXJbXT4sXG4gICAgYXBwZW5kSW1wb3J0ZWQ6IChvcHMpID0+IGNhbGwoJ2FwcGVuZEltcG9ydGVkJywgW29wc10pIGFzIFJldHVyblR5cGU8XG4gICAgICBPcExvZ1N0b3JlPFRPcGVyYXRpb24+WydhcHBlbmRJbXBvcnRlZCddXG4gICAgPixcbiAgICBnZXRPcHNTaW5jZTogKHNpbmNlU2VxLCBsaW1pdCwgZXhjbHVkZUNsaWVudCkgPT5cbiAgICAgIGNhbGwoJ2dldE9wc1NpbmNlJywgW3NpbmNlU2VxLCBsaW1pdCwgZXhjbHVkZUNsaWVudF0pIGFzIFJldHVyblR5cGU8XG4gICAgICAgIE9wTG9nU3RvcmU8VE9wZXJhdGlvbj5bJ2dldE9wc1NpbmNlJ11cbiAgICAgID4sXG4gICAgZ2V0T3BCeUlkOiAob3BJZCkgPT4gY2FsbCgnZ2V0T3BCeUlkJywgW29wSWRdKSBhcyBSZXR1cm5UeXBlPE9wTG9nU3RvcmU8VE9wZXJhdGlvbj5bJ2dldE9wQnlJZCddPixcbiAgICBnZXRPcHNGb3JFbnRpdHk6IChlbnRpdHlUeXBlLCBlbnRpdHlJZCkgPT5cbiAgICAgIGNhbGwoJ2dldE9wc0ZvckVudGl0eScsIFtlbnRpdHlUeXBlLCBlbnRpdHlJZF0pIGFzIFJldHVyblR5cGU8XG4gICAgICAgIE9wTG9nU3RvcmU8VE9wZXJhdGlvbj5bJ2dldE9wc0ZvckVudGl0eSddXG4gICAgICA+LFxuICAgIGdldExhc3RMb2NhbFNlcTogKCkgPT4gY2FsbCgnZ2V0TGFzdExvY2FsU2VxJywgW10pIGFzIFByb21pc2U8bnVtYmVyPixcbiAgICBnZXRBbGxPcHM6IChyYW5nZSwgbGltaXQpID0+XG4gICAgICBjYWxsKCdnZXRBbGxPcHMnLCBbcmFuZ2UsIGxpbWl0XSkgYXMgUmV0dXJuVHlwZTxPcExvZ1N0b3JlPFRPcGVyYXRpb24+WydnZXRBbGxPcHMnXT4sXG4gICAgY291bnRBbGxPcHM6ICgpID0+IGNhbGwoJ2NvdW50QWxsT3BzJywgW10pIGFzIFByb21pc2U8bnVtYmVyPixcbiAgICBmaW5kUGVuZGluZ0FwcGx5OiAoKSA9PlxuICAgICAgY2FsbCgnZmluZFBlbmRpbmdBcHBseScsIFtdKSBhcyBSZXR1cm5UeXBlPE9wTG9nU3RvcmU8VE9wZXJhdGlvbj5bJ2ZpbmRQZW5kaW5nQXBwbHknXT4sXG4gICAgY291bnRQZW5kaW5nQXBwbHk6ICgpID0+IGNhbGwoJ2NvdW50UGVuZGluZ0FwcGx5JywgW10pIGFzIFByb21pc2U8bnVtYmVyPixcbiAgICBmaW5kUGVuZGluZ1VwbG9hZDogKCkgPT5cbiAgICAgIGNhbGwoJ2ZpbmRQZW5kaW5nVXBsb2FkJywgW10pIGFzIFJldHVyblR5cGU8T3BMb2dTdG9yZTxUT3BlcmF0aW9uPlsnZmluZFBlbmRpbmdVcGxvYWQnXT4sXG4gICAgY291bnRQZW5kaW5nVXBsb2FkOiAoKSA9PiBjYWxsKCdjb3VudFBlbmRpbmdVcGxvYWQnLCBbXSkgYXMgUHJvbWlzZTxudW1iZXI+LFxuICAgIG1hcmtVcGxvYWRlZDogKHNlcnZlclNlcXNCeU9wSWQpID0+XG4gICAgICBjYWxsKCdtYXJrVXBsb2FkZWQnLCBbc2VydmVyU2Vxc0J5T3BJZF0pIGFzIFByb21pc2U8bnVtYmVyPixcbiAgICBkaXNjYXJkUGVuZGluZ1VwbG9hZDogKG9wSWRzKSA9PiBjYWxsKCdkaXNjYXJkUGVuZGluZ1VwbG9hZCcsIFtvcElkc10pIGFzIFByb21pc2U8bnVtYmVyPixcbiAgICBtYXJrUmVqZWN0ZWQ6IChvcElkcykgPT4gY2FsbCgnbWFya1JlamVjdGVkJywgW29wSWRzXSkgYXMgUHJvbWlzZTxudW1iZXI+LFxuICAgIGFyY2hpdmVVcFRvOiAodXBUb1NlcSkgPT4gY2FsbCgnYXJjaGl2ZVVwVG8nLCBbdXBUb1NlcV0pIGFzIFByb21pc2U8bnVtYmVyPixcbiAgICByZWFkQ2hlY2twb2ludDogKCkgPT4gY2FsbCgncmVhZENoZWNrcG9pbnQnLCBbXSkgYXMgUmV0dXJuVHlwZTxcbiAgICAgIE5vbk51bGxhYmxlPE9wTG9nU3RvcmU8VE9wZXJhdGlvbj5bJ3JlYWRDaGVja3BvaW50J10+XG4gICAgPixcbiAgICB3cml0ZUNoZWNrcG9pbnQ6IChjaGVja3BvaW50KSA9PiBjYWxsKCd3cml0ZUNoZWNrcG9pbnQnLCBbY2hlY2twb2ludF0pIGFzIFJldHVyblR5cGU8XG4gICAgICBOb25OdWxsYWJsZTxPcExvZ1N0b3JlPFRPcGVyYXRpb24+Wyd3cml0ZUNoZWNrcG9pbnQnXT5cbiAgICA+LFxuICAgIHJlYWRPYnNlcnZlZENsb2NrOiAoKSA9PiBjYWxsKCdyZWFkT2JzZXJ2ZWRDbG9jaycsIFtdKSBhcyBSZXR1cm5UeXBlPFxuICAgICAgTm9uTnVsbGFibGU8T3BMb2dTdG9yZTxUT3BlcmF0aW9uPlsncmVhZE9ic2VydmVkQ2xvY2snXT5cbiAgICA+LFxuICAgIG1lcmdlT2JzZXJ2ZWRDbG9jazogKGNsb2NrKSA9PiBjYWxsKCdtZXJnZU9ic2VydmVkQ2xvY2snLCBbY2xvY2tdKSBhcyBSZXR1cm5UeXBlPFxuICAgICAgTm9uTnVsbGFibGU8T3BMb2dTdG9yZTxUT3BlcmF0aW9uPlsnbWVyZ2VPYnNlcnZlZENsb2NrJ10+XG4gICAgPixcbiAgICBoYXNJbmNvbXBsZXRlSGlzdG9yeTogKCkgPT4gY2FsbCgnaGFzSW5jb21wbGV0ZUhpc3RvcnknLCBbXSkgYXMgUmV0dXJuVHlwZTxcbiAgICAgIE5vbk51bGxhYmxlPE9wTG9nU3RvcmU8VE9wZXJhdGlvbj5bJ2hhc0luY29tcGxldGVIaXN0b3J5J10+XG4gICAgPixcbiAgICBtYXJrSGlzdG9yeUluY29tcGxldGU6ICgpID0+IGNhbGwoJ21hcmtIaXN0b3J5SW5jb21wbGV0ZScsIFtdKSBhcyBSZXR1cm5UeXBlPFxuICAgICAgTm9uTnVsbGFibGU8T3BMb2dTdG9yZTxUT3BlcmF0aW9uPlsnbWFya0hpc3RvcnlJbmNvbXBsZXRlJ10+XG4gICAgPixcblxuICAgIC8vIOKUgOKUgCDnsL/orrDvvIjlkIzmraXmuLjmoIfvvInilIDilIBcbiAgICBnZXRMYXN0U2VydmVyU2VxOiAoKSA9PiBjYWxsKCdnZXRMYXN0U2VydmVyU2VxJywgW10pIGFzIFByb21pc2U8bnVtYmVyPixcbiAgICBzZXRMYXN0U2VydmVyU2VxOiAoc2VxKSA9PiBjYWxsKCdzZXRMYXN0U2VydmVyU2VxJywgW3NlcV0pIGFzIFByb21pc2U8dm9pZD4sXG5cbiAgICAvLyDilIDilIAgTUVUQSDpgJrnlKjor7vlhpnvvIjlhazlhbHkuovlrp7nvJPlrZjotbDov5nph4zvvIxBRFItMDA1MiDCpzIuNe+8ieKUgOKUgFxuICAgIC8vIPCflLQg6aG15L6nKirmsqHmnIkqKiBgRGJBZGFwdGVyYO+8iOW6k+WcqCBXb3JrZXIgLyDlo7Pph4zvvInvvIzmiYDku6Xov5nmnaHmmK/kuInmnaHlkI7nq6/ot6/lvoRcbiAgICAvLyDllK/kuIDpg73og73liLDovr4gYFNUT1JFUy5NRVRBYCDnmoTlj6PlrZDjgILmvI/ovazlj5HkuI3kvJrpnZnpu5jov5Tlm57nqbrlgLzvvJpcbiAgICAvLyBgaGFuZGxlT3BMb2dXb3JrZXJSZXF1ZXN0YCDmib7kuI3liLDmlrnms5XlkI3ml7bkvJrlk43kuq7miqXplJnjgIJcbiAgICBnZXRNZXRhVmFsdWU6IChrZXkpID0+IGNhbGwoJ2dldE1ldGFWYWx1ZScsIFtrZXldKSBhcyBQcm9taXNlPHN0cmluZyB8IG51bWJlciB8IHVuZGVmaW5lZD4sXG4gICAgc2V0TWV0YVZhbHVlOiAoa2V5LCB2YWx1ZSkgPT4gY2FsbCgnc2V0TWV0YVZhbHVlJywgW2tleSwgdmFsdWVdKSBhcyBQcm9taXNlPHZvaWQ+LFxuXG4gICAgLy8g4pSA4pSAIOe7p+aJv+iHqiBgUmVtb3RlT3BlcmF0aW9uQXBwbHlTdG9yZVBvcnRgIOKUgOKUgFxuICAgIGFwcGVuZEJhdGNoU2tpcER1cGxpY2F0ZXM6IChvcHMsIHNvdXJjZSwgb3B0aW9ucykgPT5cbiAgICAgIGNhbGwoJ2FwcGVuZEJhdGNoU2tpcER1cGxpY2F0ZXMnLCBbb3BzLCBzb3VyY2UsIG9wdGlvbnNdKSBhcyBSZXR1cm5UeXBlPFxuICAgICAgICBPcExvZ1N0b3JlPFRPcGVyYXRpb24+WydhcHBlbmRCYXRjaFNraXBEdXBsaWNhdGVzJ11cbiAgICAgID4sXG4gICAgbWVyZ2VSZW1vdGVPcENsb2NrczogKG9wcykgPT4gY2FsbCgnbWVyZ2VSZW1vdGVPcENsb2NrcycsIFtvcHNdKSBhcyBQcm9taXNlPHZvaWQ+LFxuICAgIG1hcmtSZWR1Y2Vyc0NvbW1pdHRlZEFuZE1lcmdlQ2xvY2tzOiAoc2Vxcywgb3BzLCByZWplY3RlZE9wSWRzKSA9PlxuICAgICAgY2FsbCgnbWFya1JlZHVjZXJzQ29tbWl0dGVkQW5kTWVyZ2VDbG9ja3MnLCBbc2Vxcywgb3BzLCByZWplY3RlZE9wSWRzXSkgYXMgUHJvbWlzZTx2b2lkPixcbiAgICBtYXJrQXBwbGllZDogKHNlcXMpID0+IGNhbGwoJ21hcmtBcHBsaWVkJywgW3NlcXNdKSBhcyBQcm9taXNlPHZvaWQ+LFxuICAgIG1hcmtGYWlsZWQ6IChvcElkcykgPT4gY2FsbCgnbWFya0ZhaWxlZCcsIFtvcElkc10pIGFzIFByb21pc2U8dm9pZD4sXG4gICAgY2xlYXJGdWxsU3RhdGVPcHNFeGNlcHQ6IChleGNsdWRlSWRzKSA9PlxuICAgICAgY2FsbCgnY2xlYXJGdWxsU3RhdGVPcHNFeGNlcHQnLCBbZXhjbHVkZUlkc10pIGFzIFByb21pc2U8bnVtYmVyPixcbiAgfTtcblxuICByZXR1cm4geyBzdG9yZSwgcmVhZHkgfTtcbn1cblxuLyoqXG4gKiDlj6ropoEgc3RvcmXjgIHkuI3opoHkuqTmj6EgUHJvbWlzZSDnmoTkvr/mjbflhpnms5XjgIJcbiAqXG4gKiDimqDvuI8gKirlj6rlnKhcIuiwg+eUqOaWueiHquW3seiDveS/neivgSBXb3JrZXIg5bey5bCx57uqXCLml7bnlKjlroMqKu+8iOS+i+WmguWlkee6pua1i+ivlemHjFxuICog56uv5Y+j5piv5ZCM5q2l5oyC5LiK55qE77yJ44CC55Sf5Lqn5Luj56CB5bqU5b2T55SoIGBjcmVhdGVXb3JrZXJPcExvZ1Nlc3Npb25gIOW5tlxuICogYGF3YWl0IHJlYWR5YCDigJTigJQg6YKj6YeM5bim5Ye65p2l55qEIGBjbGllbnRJZGAg5omN5piv5p2D5aiB5YC844CCXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBjcmVhdGVXb3JrZXJPcExvZ1N0b3JlPFRPcGVyYXRpb24gZXh0ZW5kcyBPcGVyYXRpb248c3RyaW5nPiA9IE9wZXJhdGlvbj4oXG4gIHdvcmtlcjogeyBwb3N0TWVzc2FnZShtZXNzYWdlOiB1bmtub3duKTogdm9pZCB9LFxuKTogT3BMb2dTdG9yZTxUT3BlcmF0aW9uPiB7XG4gIHJldHVybiBjcmVhdGVXb3JrZXJPcExvZ1Nlc3Npb248VE9wZXJhdGlvbj4od29ya2VyKS5zdG9yZTtcbn1cbiIsIi8qKlxuICogb3AtbG9nIOahpeeahCoq57q/56CBKirvvIh3aXJlIGNvZGVj77yJ4oCU4oCUIOiuqeWNj+iuruS4jeWGjeS+nei1luOAjOe7k+aehOWMluWFi+mahuOAjVxuICogPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XG4gKlxuICogIyMg5Li65LuA5LmI6ZyA6KaB5a6D77yIMjAyNi0wOS0zMCDlrp7mtYvvvIzkuI3mmK/pooTpmLLmgKforr7orqHvvIlcbiAqXG4gKiBgb3Bsb2ctd29ya2VyLWJyaWRnZS50c2Ag55qE5Y2P6K6u5YGH6K6+Kirlj4LmlbDlj6/nu5PmnoTljJblhYvpmoYqKu+8jOW5tuWcqOazqOmHiumHjOS4k+mXqFxuICog54K55ZCN5LqG5ZSv5LiA5LiA5Liq6ZyA6KaB5rOo5oSP55qE57G75Z6L77yaXG4gKlxuICogPiBgbWFya1VwbG9hZGVkKFJlYWRvbmx5TWFwPHN0cmluZywgbnVtYmVyPilgIOKAlOKAlCBgTWFwYCAqKuaYryoq5Y+v57uT5p6E5YyW5YWL6ZqG55qE77yMXG4gKiA+IOaJgOS7peWug+WOn+agt+iDvei/h++8jOS4jemcgOimgei9rOaIkCBgW1trLHZdXWDjgIJcbiAqXG4gKiDov5nlnKggKipXb3JrZXIg5Lyg6L6TKirkuIrmiJDnq4vjgILkvYbmoYzpnaLnq6/nmoTlrr/kuLvovrnnlYwqKuS4jeaYryoq57uT5p6E5YyW5YWL6ZqG77yaXG4gKiBXZWJWaWV3MiDnmoQgYFBvc3RXZWJNZXNzYWdlQXNKc29uYCDkuI4gV0tXZWJWaWV3IOeahCBgZXZhbHVhdGVKYXZhU2NyaXB0YFxuICogKirlj6rov4cgSlNPTioq77yM6ICMIGBKU09OLnN0cmluZ2lmeShuZXcgTWFwKCkpYCDlvpfliLAgYHt9YOOAglxuICpcbiAqIOWunua1i++8iOaKiiBvcC1sb2cg5aWR57qm6LeR5Zyo5LiA5p2h5pi+5byPIEpTT04g5b6A6L+U55qE56uv5Y+j5LiK77yJ77yaXG4gKlxuICogYGBgXG4gKiBUeXBlRXJyb3I6IHNlcnZlclNlcXNCeU9wSWQgaXMgbm90IGl0ZXJhYmxlXG4gKiAgIGF0IERiT3BMb2dTdG9yZS5tYXJrVXBsb2FkZWQgIHNyYy9kYi1vcC1sb2ctc3RvcmUudHM6NDAyXG4gKiBgYGBcbiAqXG4gKiAxMyDmnaHlpZHnuqblkIzml7bnuqLjgILih5IgKirmoYzpnaLnq6/pgqPmnaHkvKDovpPkuI3og73mmK/oo7ggSlNPTioq77yM5b+F6aG75pyJ5LiA5bGC57q/56CB44CCXG4gKiDov5nkuKrpl67popjlpoLmnpznlZnliLDlo7Pph4zljrvlj5HnjrDvvIzku6Pku7fmmK9cIkMjICsg5Lik5Liq5aOz6YO95YaZ5a6M5LqG5omN54K4XCLjgIJcbiAqXG4gKiAjIyDorr7orqHlj5boiI3vvJoqKuWPquaUr+aMgemcgOimgeeahO+8jOmBh+WIsOayoeimhueblueahOWTjeS6ruWksei0pSoqXG4gKlxuICog5Yi75oSPKirkuI3lgZoqKumAmueUqOeahOe7k+aehOWMluWFi+mahuaooeaLn++8iOmCo+imgeWkhOeQhiBEYXRlL1JlZ0V4cC9BcnJheUJ1ZmZlci/lvqrnjq/lvJXnlKjigKbigKZcbiAqIOiAjCBgT3BMb2dTdG9yZWAg55qE5YWs5byA6Z2i5LiA5Liq6YO95rKh55So5Yiw77yJ44CC5Lmf5Yi75oSPKirkuI3pnZnpu5jpmY3nuqcqKiDigJTigJRcbiAqIOmBh+WIsOayoeimhueblueahOWuv+S4u+exu+Wei+WwseaKm++8jOmUmeivr+S/oeaBr+ebtOaOpeivtOaYjlwi6KaB5Zyo6L+Z6YeM6KGl57yW56CBXCLjgIJcbiAqXG4gKiDnkIbnlLHvvJrpnZnpu5jnvJblnY/nmoTooajnjrDmmK8qKuS4iuWxguaLv+WIsOmUmeeahOaVsOaNrioq77yM6ICM5pys5LuT5pyA5b+M6K6z55qE5q2j5piv6L+Z5LiqXG4gKiDvvIhcIueVjOmdouivtOiwjlwi6YKj5LiA57G777yJ44CC5a6B5Y+v5b2T5Zy654K444CCXG4gKlxuICog4pqg77iPIOS4pOS4quWunueOsOmDveW/hemhu+eUqCoq5ZCM5LiA5Lu9KirnoIHvvJrnvJbnoIHlnKjlj5HpgIHkvqfjgIHop6PnoIHlnKjmjqXmlLbkvqfvvIwqKuS4pOS+p+WvueensCoq44CCXG4gKiDlj6rlgZrkuIDljYrnmoTooajnjrDmmK9cIuafkOS6m+iwg+eUqOiDveeUqOOAgeafkOS6m+S4jeiDvVwi77yM5q+U5YWo5Z2P5pu06Zq+5p+l44CCXG4gKi9cblxuLyoqIOe6v+eggeeahOagh+iusOmUruOAgueUqOi2s+Wkn+mVv+eahOWQjeWtl++8jOmBv+WFjeS4juecn+WunuaVsOaNrumHjOeahOmUruaSnuS4iuOAgiAqL1xuY29uc3QgVEFHID0gJ19faGV5dGFXaXJlJztcblxuLyoqIOWIpOWumlwi6L+Z5piv5oiR5Lus6Ieq5bex55qE57yW56CB55uSXCLvvJrlv4XpobsqKuaBsOWlvSoq5Y+q5pyJ5Lik5Liq6ZSu77yM6YG/5YWN5oqK55So5oi355qE5ZCM5ZCN5a+56LGh5ZCD5o6J44CCICovXG5mdW5jdGlvbiBpc0JveCh2YWx1ZTogdW5rbm93bik6IHZhbHVlIGlzIHsgW1RBR106IHN0cmluZzsgdjogdW5rbm93biB9IHtcbiAgaWYgKHR5cGVvZiB2YWx1ZSAhPT0gJ29iamVjdCcgfHwgdmFsdWUgPT09IG51bGwgfHwgQXJyYXkuaXNBcnJheSh2YWx1ZSkpIHJldHVybiBmYWxzZTtcbiAgY29uc3Qga2V5cyA9IE9iamVjdC5rZXlzKHZhbHVlKTtcbiAgcmV0dXJuIGtleXMubGVuZ3RoID09PSAyICYmIGtleXMuaW5jbHVkZXMoVEFHKTtcbn1cblxuLyoqXG4gKiDnvJbnoIHvvJrmiorov4fkuI3kuoYgSlNPTiDnmoTlgLzmjaLmiJAgSlNPTiDog73mib/ovb3nmoTlvaLnirbjgIJcbiAqXG4gKiDopobnm5YgYE9wTG9nU3RvcmVgIOWFrOW8gOmdoioq5a6e6ZmF55So5YiwKirnmoTpnZ4gSlNPTiDnsbvlnovvvJpcbiAqICAgLSBgTWFwYO+8iGBtYXJrVXBsb2FkZWRgIOeahCBgUmVhZG9ubHlNYXBg77yJ4oaSIGBbW2ssIHZdLCDigKZdYFxuICogICAtIGBTZXRgIOKGkiBgW+KApl1gXG4gKiAgIC0gYHVuZGVmaW5lZGAg4oaSIOaYvuW8j+ebkuWtkO+8iCoq6L+Z5p2h5pyA6KaB57SnKirvvJpKU09OIOS8muaKiuWvueixoeWxnuaAp+S4juaVsOe7hOWFg+e0oOmHjOeahFxuICogICAgIGB1bmRlZmluZWRgIOebtOaOpeS4ouaOie+8jOS6juaYryoq5L2N572u5Y+C5pWw5Lya56e75L2NKirvvIzogIzpgqPmmK/pnZnpu5jnmoTmlbDmja7plJnkvY3vvIlcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGVuY29kZU9wTG9nV2lyZSh2YWx1ZTogdW5rbm93bik6IHVua25vd24ge1xuICAvKipcbiAgICog8J+UtCBgdW5kZWZpbmVkYCDnmoTnm5LlrZDlv4XpobvluKYgYHZg77yI5ZOq5oCV5pivIGBudWxsYO+8ieKAlOKAlCAqKuS4jeiDveWPquWGmeS4gOS4qumUrioq44CCXG4gICAqXG4gICAqIOWunua1i+i4qei/h++8iDIwMjYtMDktMzDvvIzlpZHnuqbph4wgMTIg5p2h5ZCM5pe257qi77yJ77ya56ys5LiA54mI5YaZ5oiQXG4gICAqIGB7IF9faGV5dGFXaXJlOiAndW5kZWZpbmVkJyB9YO+8iCoqMSDkuKrplK4qKu+8ie+8jOiAjOino+eggeS+p+eahCBgaXNCb3hgIOimgeaxglxuICAgKiAqKuaBsOWlvSAyIOS4qumUrioqIOKHkiDov5nkuKrnm5LlrZDkuI3ooqvorqTmiJDnm5LlrZDvvIzooqvlvZPmiJDmma7pgJrlr7nosaHop6Plh7rmnaXjgIJcbiAgICog5ZCO5p6c5pivIGBnZXRBbGxPcHMocmFuZ2UpYCDnmoQgYHJhbmdlYCDku44gYHVuZGVmaW5lZGAg5Y+Y5oiQ5LqG5LiA5LiqKirnnJ/lgLzlr7nosaEqKu+8jFxuICAgKiBgZ2V0QWxsKE9QUywg6YKj5Liq5a+56LGhKWAg5LiA5p2h6YO95Yy56YWN5LiN5YiwIOKHkiDor7vlm57nqbrmlbDnu4TvvIxcbiAgICog6ICM5YaZ5YWl44CBc2Vx44CB6Zif5YiX5YWo6YO95q2j5bi4IOKAlOKAlCDnl4fnirbmmK9cIuWGmei/m+WOu+S6huS9huivu+S4jeWHuuadpVwi44CCXG4gICAqL1xuICBpZiAodmFsdWUgPT09IHVuZGVmaW5lZCkgcmV0dXJuIHsgW1RBR106ICd1bmRlZmluZWQnLCB2OiBudWxsIH07XG4gIGlmICh2YWx1ZSA9PT0gbnVsbCkgcmV0dXJuIG51bGw7XG5cbiAgaWYgKHZhbHVlIGluc3RhbmNlb2YgTWFwKSB7XG4gICAgcmV0dXJuIHsgW1RBR106ICdNYXAnLCB2OiBbLi4udmFsdWUuZW50cmllcygpXS5tYXAoKFtrLCB2XSkgPT4gW2VuY29kZU9wTG9nV2lyZShrKSwgZW5jb2RlT3BMb2dXaXJlKHYpXSkgfTtcbiAgfVxuICBpZiAodmFsdWUgaW5zdGFuY2VvZiBTZXQpIHtcbiAgICByZXR1cm4geyBbVEFHXTogJ1NldCcsIHY6IFsuLi52YWx1ZS52YWx1ZXMoKV0ubWFwKGVuY29kZU9wTG9nV2lyZSkgfTtcbiAgfVxuICBpZiAoQXJyYXkuaXNBcnJheSh2YWx1ZSkpIHJldHVybiB2YWx1ZS5tYXAoZW5jb2RlT3BMb2dXaXJlKTtcblxuICBpZiAodHlwZW9mIHZhbHVlID09PSAnb2JqZWN0Jykge1xuICAgIGNvbnN0IG91dDogUmVjb3JkPHN0cmluZywgdW5rbm93bj4gPSB7fTtcbiAgICBmb3IgKGNvbnN0IFtrLCB2XSBvZiBPYmplY3QuZW50cmllcyh2YWx1ZSkpIG91dFtrXSA9IGVuY29kZU9wTG9nV2lyZSh2KTtcbiAgICByZXR1cm4gb3V0O1xuICB9XG5cbiAgaWYgKHR5cGVvZiB2YWx1ZSA9PT0gJ2Z1bmN0aW9uJyB8fCB0eXBlb2YgdmFsdWUgPT09ICdzeW1ib2wnIHx8IHR5cGVvZiB2YWx1ZSA9PT0gJ2JpZ2ludCcpIHtcbiAgICB0aHJvdyBuZXcgRXJyb3IoXG4gICAgICBgb3AtbG9nIOe6v+egge+8miR7dHlwZW9mIHZhbHVlfSDov4fkuI3kuoblrr/kuLvovrnnlYzvvIhKU09OIOS8muS4oi/lj5jlvaLnirbvvInjgIJgICtcbiAgICAgICAgJ+iLpeehruWunumcgOimge+8jOivt+WcqCBlbmNvZGVPcExvZ1dpcmUvZGVjb2RlT3BMb2dXaXJlIOmHjOaIkOWvueWcsOWKoOe8lueggSDigJTigJQgJyArXG4gICAgICAgICfkuI3opoHlnKjlj5HpgIHkvqfljZXmlrnpnaJcIui9rOaIkOWtl+espuS4slwi77yM6YKj5Lya6K6p5o6l5pS25L6n5ou/5Yiw6ZSZ55qE5pWw5o2u44CCJyxcbiAgICApO1xuICB9XG5cbiAgLy8gc3RyaW5nIC8gbnVtYmVyIC8gYm9vbGVhbiDljp/moLfjgIJcbiAgLy8g4pqg77iPIGBOYU5gIC8gYEluZmluaXR5YCDkvJrooqsgSlNPTiDlj5jmiJAgYG51bGxgIOKAlOKAlCDov5nph4zkuI3mi6bvvIzlm6DkuLrlrZjlgqjlsYLkuI3nlKjlroPku6zvvJtcbiAgLy8gICAg55yf55So5Yiw5pe25bqU5b2T5Zyo5LiK6Z2i5pi+5byP5aSE55CG77yM6ICM5LiN5piv6Z2g6LCD55So5pa55bCP5b+D44CCXG4gIHJldHVybiB2YWx1ZTtcbn1cblxuLyoqIOino+egge+8mmBlbmNvZGVPcExvZ1dpcmVgIOeahOmAhuOAguS4pOS+p+W/hemhu+aIkOWvueOAgiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGRlY29kZU9wTG9nV2lyZSh2YWx1ZTogdW5rbm93bik6IHVua25vd24ge1xuICBpZiAodmFsdWUgPT09IG51bGwgfHwgdHlwZW9mIHZhbHVlICE9PSAnb2JqZWN0JykgcmV0dXJuIHZhbHVlO1xuXG4gIGlmIChpc0JveCh2YWx1ZSkpIHtcbiAgICBjb25zdCBraW5kID0gKHZhbHVlIGFzIFJlY29yZDxzdHJpbmcsIHVua25vd24+KVtUQUddO1xuICAgIGNvbnN0IHBheWxvYWQgPSAodmFsdWUgYXMgUmVjb3JkPHN0cmluZywgdW5rbm93bj4pWyd2J107XG4gICAgaWYgKGtpbmQgPT09ICd1bmRlZmluZWQnKSByZXR1cm4gdW5kZWZpbmVkO1xuICAgIGlmIChraW5kID09PSAnTWFwJykge1xuICAgICAgY29uc3QgZW50cmllcyA9IHBheWxvYWQgYXMgW3Vua25vd24sIHVua25vd25dW107XG4gICAgICByZXR1cm4gbmV3IE1hcChlbnRyaWVzLm1hcCgoW2ssIHZdKSA9PiBbZGVjb2RlT3BMb2dXaXJlKGspLCBkZWNvZGVPcExvZ1dpcmUodildKSk7XG4gICAgfVxuICAgIGlmIChraW5kID09PSAnU2V0Jykge1xuICAgICAgY29uc3QgdmFsdWVzID0gcGF5bG9hZCBhcyB1bmtub3duW107XG4gICAgICByZXR1cm4gbmV3IFNldCh2YWx1ZXMubWFwKGRlY29kZU9wTG9nV2lyZSkpO1xuICAgIH1cbiAgICB0aHJvdyBuZXcgRXJyb3IoYG9wLWxvZyDnur/noIHvvJrkuI3orqTor4bnmoTmoIforrAgJHtTdHJpbmcoa2luZCl9IOKAlOKAlCDkuKTkvqfnmoTnoIHniYjmnKzkuI3kuIDoh7TvvJ9gKTtcbiAgfVxuXG4gIGlmIChBcnJheS5pc0FycmF5KHZhbHVlKSkgcmV0dXJuIHZhbHVlLm1hcChkZWNvZGVPcExvZ1dpcmUpO1xuXG4gIGNvbnN0IG91dDogUmVjb3JkPHN0cmluZywgdW5rbm93bj4gPSB7fTtcbiAgZm9yIChjb25zdCBbaywgdl0gb2YgT2JqZWN0LmVudHJpZXModmFsdWUpKSBvdXRba10gPSBkZWNvZGVPcExvZ1dpcmUodik7XG4gIHJldHVybiBvdXQ7XG59XG5cbi8qKlxuICog5LiA5LiqIGBwb3N0TWVzc2FnZWAg56uv5Y+j55qEKirmnIDlsI/lvaLnirYqKuOAglxuICpcbiAqIOS4jiBgb3Bsb2ctd29ya2VyLWJyaWRnZS50c2Ag6YeM5qGl5pyf5pyb55qE5b2i54q25LiA6Ie0IOKAlOKAlCDov5nph4zliLvmhI8qKuS4jeaUueahpSoq77yaXG4gKiDmoYzpnaLnq6/opoHmjaLnmoTlj6rmmK9cIua2iOaBr+aAjuS5iOi/h+e9kee7nFwi77yM5LiN5piv5qGl55qE5Y2P6K6u44CCXG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgT3BMb2dXaXJlUG9ydCB7XG4gIHBvc3RNZXNzYWdlKG1lc3NhZ2U6IHVua25vd24pOiB2b2lkO1xuICBvbm1lc3NhZ2U/OiAoKGV2ZW50OiB7IGRhdGE6IHVua25vd24gfSkgPT4gdm9pZCkgfCBudWxsO1xuICBhZGRFdmVudExpc3RlbmVyPyh0eXBlOiBzdHJpbmcsIGxpc3RlbmVyOiAoZXZlbnQ6IHsgZGF0YTogdW5rbm93biB9KSA9PiB2b2lkKTogdm9pZDtcbn1cblxuLyoqXG4gKiDmiorkuIDkuKrnq6/lj6PljIXmiJAqKuW4pue6v+eggSoq55qE56uv5Y+j77ya5Ye656uZ57yW56CB44CB5YWl56uZ6Kej56CB44CCXG4gKlxuICog8J+UtCAqKuS4pOS+p+W/hemhu+WQhOWMheS4gOasoSoq77yI6aG15L6n5LiA5qyh44CB5aOz5L6n5LiA5qyh77yJ44CC5Y+q5YyF5LiA5L6n55qE6KGo546w5pivXG4gKiBcIuafkOS6m+iwg+eUqOiDveeUqOOAgeafkOS6m+S4jeiDvVwi77yM5q+U5YWo5Z2P5pu06Zq+5p+lIOKAlOKAlCDmiYDku6XkuI3opoFcIumhuuaJi+WcqOafkOS4gOS+p+ino+eggVwi44CCXG4gKlxuICog55So5rOV77yI6aG15L6n5LiO5aOz5L6n6YCQ5a2X55u45ZCM77yJ77yaXG4gKlxuICogYGBgdHNcbiAqIGNvbnN0IHBvcnQgPSBjcmVhdGVPcExvZ1dpcmVQb3J0KHJhd1BvcnQpOyAgIC8vIHJhd1BvcnQg55Sx5a6/5Li75rOo5YWlXG4gKiBgYGBcbiAqXG4gKiDimqDvuI8g5a6DKirkuI3norAqKuahpemCo+i+ueeahOS7u+S9leS7o+egge+8muahpeS7jeeEtuWPqueci+ingVwi5LiA5Liq5LyaIHBvc3RNZXNzYWdlIOeahOerr+WPo1wi44CCXG4gKiDov5nkuIDngrnlvojph43opoEg4oCU4oCUIOahpeeahCBXb3JrZXIg6YCa6Lev5LuK5aSp5Zyo6LeR77yM5LiN6IO95Li65LqG5qGM6Z2i56uv5Y675Yqo5a6D44CCXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBjcmVhdGVPcExvZ1dpcmVQb3J0PFAgZXh0ZW5kcyBPcExvZ1dpcmVQb3J0Pihwb3J0OiBQKTogUCB7XG4gIGNvbnN0IGRlY29kZUV2ZW50ID0gKGV2ZW50OiB7IGRhdGE6IHVua25vd24gfSk6IHsgZGF0YTogdW5rbm93biB9ID0+ICh7XG4gICAgZGF0YTogZGVjb2RlT3BMb2dXaXJlKGV2ZW50LmRhdGEpLFxuICB9KTtcblxuICBjb25zdCB3cmFwcGVyOiBPcExvZ1dpcmVQb3J0ID0ge1xuICAgIHBvc3RNZXNzYWdlKG1lc3NhZ2U6IHVua25vd24pOiB2b2lkIHtcbiAgICAgIHBvcnQucG9zdE1lc3NhZ2UoZW5jb2RlT3BMb2dXaXJlKG1lc3NhZ2UpKTtcbiAgICB9LFxuICB9O1xuXG4gIC8qKlxuICAgKiDlhaXnq5nmlrnlkJHot5/nnYAqKuW6leWxguerr+WPo+WunumZheaPkOS+m+eahOacuuWItioq6LWw77yM6ICM5LiN5piv5oiR5Lus5oyR5LiA5Liq77yaXG4gICAqIGBvcGxvZy13b3JrZXItYnJpZGdlLnRzYCDkvJjlhYjnlKggYGFkZEV2ZW50TGlzdGVuZXJg44CB5ZCm5YiZ55So5Y2V5qe9IGBvbm1lc3NhZ2Vg44CCXG4gICAqIOWMhemUmeacuuWItueahOeXh+eKtuaYr1wi5Y+R5b6X5Ye65Y6744CB5pS25LiN5Zue5p2lXCLvvIjor7fmsYLmsLjov5zmgqznnYDvvInjgIJcbiAgICovXG4gIGlmICh0eXBlb2YgcG9ydC5hZGRFdmVudExpc3RlbmVyID09PSAnZnVuY3Rpb24nKSB7XG4gICAgd3JhcHBlci5hZGRFdmVudExpc3RlbmVyID0gKHR5cGUsIGxpc3RlbmVyKSA9PiB7XG4gICAgICBwb3J0LmFkZEV2ZW50TGlzdGVuZXI/Lih0eXBlLCAoZXZlbnQpID0+IHtcbiAgICAgICAgbGlzdGVuZXIoZGVjb2RlRXZlbnQoZXZlbnQpKTtcbiAgICAgIH0pO1xuICAgIH07XG4gIH0gZWxzZSB7XG4gICAgT2JqZWN0LmRlZmluZVByb3BlcnR5KHdyYXBwZXIsICdvbm1lc3NhZ2UnLCB7XG4gICAgICBnZXQ6ICgpID0+IHBvcnQub25tZXNzYWdlID8/IG51bGwsXG4gICAgICBzZXQ6IChsaXN0ZW5lcjogKChldmVudDogeyBkYXRhOiB1bmtub3duIH0pID0+IHZvaWQpIHwgbnVsbCkgPT4ge1xuICAgICAgICBwb3J0Lm9ubWVzc2FnZSA9XG4gICAgICAgICAgbGlzdGVuZXIgPT09IG51bGxcbiAgICAgICAgICAgID8gbnVsbFxuICAgICAgICAgICAgOiAoZXZlbnQpID0+IHtcbiAgICAgICAgICAgICAgICBsaXN0ZW5lcihkZWNvZGVFdmVudChldmVudCkpO1xuICAgICAgICAgICAgICB9O1xuICAgICAgfSxcbiAgICB9KTtcbiAgfVxuXG4gIHJldHVybiB3cmFwcGVyIGFzIFA7XG59XG4iLCIvKipcbiAqIOWGheWtmOWtmOWCqOmAgumFjeWZqCDigJTigJQgKirlj4LogIPlrp7njrAqKuOAglxuICpcbiAqIOWtmOWcqOeahOeQhueUseS4jeaYr1wi5rWL6K+V5pa55L6/XCLvvIzogIzmmK8gQURSLTAwMDMgwqcyLjIg55qE56Gs6KaB5rGC77yaXG4gKlxuICogPiBgRGJBZGFwdGVyYCAvIGBPcExvZ1N0b3JlYCDlj6rmmrTpnLLmnIDlsI/lv4XopoHmk43kvZzigKbigKZcbiAqID4gKirlkIzkuIDlpZflpZHnuqbmtYvor5Xot5HpgY3miYDmnInlrp7njrAqKiDigJTigJQg5o2i5ZCO56uv5pe25LiK5bGC5LiA6KGM5LiN55So5pS5XG4gKlxuICog5Y+q5pyJ5LiA5Liq5a6e546w5pe277yMXCLlrZjlgqjlj6/mm7/mjaJcIuWPquaYryoq5aOw5piOKirvvJrmjqXlj6PkuIrku7vkvZXooqsgSW5kZXhlZERCIOeahFxuICog5YW35L2T6KGM5Li65oKE5oKE5Yaz5a6a55qE5Lic6KW/77yI6ZSu55qE5q+U6L6D6aG65bqP44CB5ZSv5LiA57Si5byV5Yay56qB5pe25pW05p2h6K6w5b2V5LiN5YWl5bqT44CBXG4gKiDorr/pl67mnKrliJflhaXkuovliqHnmoQgc3RvcmUg6KaB5oql6ZSZ4oCm4oCm77yJ6YO95LiN5Lya5pyJ5Lq65Y+R546w77yM55u05Yiw56e75qSN5YiwIFNRTGl0ZVxuICog5pe25omN6ZuG5Lit54iG54K444CC56ys5LqM5Liq5a6e546wICsg5ZCM5LiA5aWX5aWR57qm77yM5piv5ZSv5LiA6IO95oqK5aOw5piO5Y+Y5oiQ5LqL5a6e55qE5Yqe5rOV44CCXG4gKlxuICog4pqg77iPIOWug+aYryoq5YaF5a2YKirlrp7njrDvvJrov5vnqIvnu5PmnZ/ljbPmtojlpLHjgILkuI3opoHmi7/lroPlvZPnlJ/kuqflrZjlgqjjgIJcbiAqL1xuXG5pbXBvcnQgeyBBZGFwdGVyRGVzdHJveWVkRXJyb3IgfSBmcm9tICcuLi9lcnJvcnMuanMnO1xuaW1wb3J0IHtcbiAgYXNzZXJ0SXRlcmF0ZUxpbWl0LFxuICBERUZBVUxUX0lURVJBVEVfTElNSVQsXG4gIHR5cGUgRGJBZGFwdGVyLFxuICB0eXBlIERiQ3Vyc29yQWN0aW9uLFxuICB0eXBlIERiQ3Vyc29yVmlzaXRvcixcbiAgdHlwZSBEYkRlc3Ryb3lSZXBvcnQsXG4gIHR5cGUgRGJJbmRleFF1ZXJ5LFxuICB0eXBlIERiSXRlcmF0ZU9wdGlvbnMsXG4gIHR5cGUgRGJLZXksXG4gIHR5cGUgRGJLZXlSYW5nZSxcbiAgdHlwZSBEYlR4LFxuICB0eXBlIERiVHhNb2RlLFxuICB0eXBlIFN0b3JlU2NoZW1hLFxufSBmcm9tICcuLi9kYi50eXBlcy5qcyc7XG5cbi8qKlxuICog8J+UtCDplK7nmoTmr5TovoPlv4XpobvkuI4gSW5kZXhlZERCICoq5LiA6Ie0KirvvIzlkKbliJlcIuWQjOS4gOWll+Wlkee6plwi5piv5YGH55qE44CCXG4gKlxuICogSW5kZXhlZERCIOeahOmUruW6j+aYr++8mm51bWJlciA8IGRhdGUgPCBzdHJpbmcgPCBiaW5hcnkgPCBhcnJheeOAglxuICog5pWw57uE5oyJ5YWD57Sg6YCQ5Liq5q+U6L6D77yM5YmN57yA55+t55qE5o6S5YmN6Z2i44CCXG4gKiDov5nkuKrpobrluo/lhrPlrprkuoYgYGdldEFsbChyYW5nZSlgIOWSjOa4uOagh+mBjeWOhueahOe7k+aenOmhuuW6jyDigJTigJQg5LiK5bGC5Luj56CBXG4gKiDvvIjkvovlpoJcIuW+heS4iuS8oOmYn+WIl+aMiSBzZXEg5Y2H5bqPXCLvvInkvp3otZblroPvvIzmiYDku6XkuI3og73pmo/miYvnlKjlrZfnrKbkuLLmr5TovoPns4rov4fljrvjgIJcbiAqL1xuZnVuY3Rpb24gY29tcGFyZUtleXMoYTogRGJLZXkgfCBEYktleVtdLCBiOiBEYktleSB8IERiS2V5W10pOiBudW1iZXIge1xuICBjb25zdCByYW5rID0gKGs6IHVua25vd24pOiBudW1iZXIgPT4ge1xuICAgIGlmICh0eXBlb2YgayA9PT0gJ251bWJlcicpIHJldHVybiAwO1xuICAgIGlmIChrIGluc3RhbmNlb2YgRGF0ZSkgcmV0dXJuIDE7XG4gICAgaWYgKHR5cGVvZiBrID09PSAnc3RyaW5nJykgcmV0dXJuIDI7XG4gICAgaWYgKEFycmF5LmlzQXJyYXkoaykpIHJldHVybiA0O1xuICAgIHJldHVybiAzO1xuICB9O1xuXG4gIGlmIChBcnJheS5pc0FycmF5KGEpIHx8IEFycmF5LmlzQXJyYXkoYikpIHtcbiAgICBjb25zdCBhcnJBID0gQXJyYXkuaXNBcnJheShhKSA/IGEgOiBbYV07XG4gICAgY29uc3QgYXJyQiA9IEFycmF5LmlzQXJyYXkoYikgPyBiIDogW2JdO1xuICAgIC8vIOexu+Wei+S4jeWQjOeahOS4pOS+p+S4jeivpeiiq+W9k+S9nOaVsOe7hOavlOi+g++8jOWFiOaMieexu+Wei+W6j+aOkuW8gFxuICAgIGlmIChBcnJheS5pc0FycmF5KGEpICE9PSBBcnJheS5pc0FycmF5KGIpKSB7XG4gICAgICByZXR1cm4gcmFuayhhKSAtIHJhbmsoYik7XG4gICAgfVxuICAgIGNvbnN0IGxlbiA9IE1hdGgubWluKGFyckEubGVuZ3RoLCBhcnJCLmxlbmd0aCk7XG4gICAgZm9yIChsZXQgaSA9IDA7IGkgPCBsZW47IGkrKykge1xuICAgICAgY29uc3QgZGlmZiA9IGNvbXBhcmVLZXlzKGFyckFbaV0gYXMgRGJLZXksIGFyckJbaV0gYXMgRGJLZXkpO1xuICAgICAgaWYgKGRpZmYgIT09IDApIHJldHVybiBkaWZmO1xuICAgIH1cbiAgICByZXR1cm4gYXJyQS5sZW5ndGggLSBhcnJCLmxlbmd0aDtcbiAgfVxuXG4gIGNvbnN0IHJhbmtEaWZmID0gcmFuayhhKSAtIHJhbmsoYik7XG4gIGlmIChyYW5rRGlmZiAhPT0gMCkgcmV0dXJuIHJhbmtEaWZmO1xuXG4gIGlmICh0eXBlb2YgYSA9PT0gJ251bWJlcicgJiYgdHlwZW9mIGIgPT09ICdudW1iZXInKSByZXR1cm4gYSAtIGI7XG4gIC8vIOazqOaEj++8mmBEYktleWAg5Y+q5pyJIHN0cmluZyB8IG51bWJlciDigJTigJQgRGF0ZSDkuI3lnKjlpZHnuqbph4zvvIxcbiAgLy8g5omA5Lul6L+Z6YeM5LiN6ZyA6KaB77yI5Lmf5LiN6K+l77yJ5pyJIERhdGUg5YiG5pSv44CCYHJhbmsoKWAg6YeM55WZIERhdGUg5Y+q5piv5Li65LqG6K6pXG4gIC8vIOmUruW6j+aOkuWcqCBzdHJpbmcg5LmL5YmN55qE6YKj5p2h6KeE5YiZ5Zyo5rOo6YeK5LiK5a6M5pW044CCXG4gIHJldHVybiBTdHJpbmcoYSkgPCBTdHJpbmcoYikgPyAtMSA6IFN0cmluZyhhKSA+IFN0cmluZyhiKSA/IDEgOiAwO1xufVxuXG4vKipcbiAqIOWUr+S4gOe6puadn+WGsueqgeeahOWGhemDqOS/oeWPt+OAglxuICpcbiAqIOWPquWcqOmAgumFjeWZqOWGhemDqOS9v+eUqO+8mmBhZGRgIOaKiuWug+W9k+S9nOecn+mUmeivr+aKm+WHuu+8jGBhZGRUb2xlcmF0aW5nRHVwbGljYXRlYFxuICog5oqK5a6D6L2s5oiQIGB7IG9rOiBmYWxzZSwgcmVhc29uOiAnZHVwbGljYXRlJyB9YOOAglxuICog5LiN5a+85Ye65Yiw5YWs5YWx57G75Z6LIOKAlOKAlCDkuIrlsYLkuI3or6XpnaAgaW5zdGFuY2VvZiDliKTmlq3ph43lpI3jgIJcbiAqL1xuY2xhc3MgRHVwbGljYXRlS2V5RXJyb3IgZXh0ZW5kcyBFcnJvciB7XG4gIGNvbnN0cnVjdG9yKHdoYXQ6IHN0cmluZykge1xuICAgIHN1cGVyKGDllK/kuIDplK7lhrLnqoHvvJoke3doYXR9YCk7XG4gICAgdGhpcy5uYW1lID0gJ0R1cGxpY2F0ZUtleUVycm9yJztcbiAgfVxufVxuXG4vKiog56iz5a6a55qEIE1hcCDplK7jgILmlbDnu4TopoHkv53luo/vvIzmiYDku6XkuI3og73lj6ogU3RyaW5nKCnjgIIgKi9cbmZ1bmN0aW9uIHNlcmlhbGl6ZUtleShrZXk6IERiS2V5IHwgRGJLZXlbXSk6IHN0cmluZyB7XG4gIHJldHVybiBKU09OLnN0cmluZ2lmeShrZXkpO1xufVxuXG4vKiog5rK/54K55YiG6Lev5b6E5Y+W5YC844CCYG9wLmlkYCDopoHog73lj5bliLDltYzlpZflrZfmrrXjgIIgKi9cbmZ1bmN0aW9uIHZhbHVlQXRQYXRoKHZhbHVlOiB1bmtub3duLCBwYXRoOiBzdHJpbmcpOiB1bmtub3duIHtcbiAgbGV0IGN1cnJlbnQ6IHVua25vd24gPSB2YWx1ZTtcbiAgZm9yIChjb25zdCBzZWdtZW50IG9mIHBhdGguc3BsaXQoJy4nKSkge1xuICAgIGlmIChjdXJyZW50ID09PSBudWxsIHx8IHR5cGVvZiBjdXJyZW50ICE9PSAnb2JqZWN0JykgcmV0dXJuIHVuZGVmaW5lZDtcbiAgICBjdXJyZW50ID0gKGN1cnJlbnQgYXMgUmVjb3JkPHN0cmluZywgdW5rbm93bj4pW3NlZ21lbnRdO1xuICB9XG4gIHJldHVybiBjdXJyZW50O1xufVxuXG4vKiog5oqKIGtleVBhdGjvvIjlrZfnrKbkuLLmiJbmlbDnu4TvvInop6PmnpDmiJDkuIDkuKrplK7vvJvku7vkuIDlrZfmrrXnvLrlpLHliJnov5Tlm54gdW5kZWZpbmVk44CCICovXG5mdW5jdGlvbiBrZXlGcm9tUGF0aCh2YWx1ZTogdW5rbm93biwga2V5UGF0aDogc3RyaW5nIHwgcmVhZG9ubHkgc3RyaW5nW10pOiBEYktleSB8IERiS2V5W10gfCB1bmRlZmluZWQge1xuICBpZiAodHlwZW9mIGtleVBhdGggPT09ICdzdHJpbmcnKSB7XG4gICAgY29uc3QgdiA9IHZhbHVlQXRQYXRoKHZhbHVlLCBrZXlQYXRoKTtcbiAgICByZXR1cm4gdHlwZW9mIHYgPT09ICdzdHJpbmcnIHx8IHR5cGVvZiB2ID09PSAnbnVtYmVyJyA/IHYgOiB1bmRlZmluZWQ7XG4gIH1cbiAgY29uc3QgcGFydHM6IERiS2V5W10gPSBbXTtcbiAgZm9yIChjb25zdCBwIG9mIGtleVBhdGgpIHtcbiAgICBjb25zdCB2ID0gdmFsdWVBdFBhdGgodmFsdWUsIHApO1xuICAgIGlmICh0eXBlb2YgdiAhPT0gJ3N0cmluZycgJiYgdHlwZW9mIHYgIT09ICdudW1iZXInKSByZXR1cm4gdW5kZWZpbmVkO1xuICAgIHBhcnRzLnB1c2godik7XG4gIH1cbiAgcmV0dXJuIHBhcnRzO1xufVxuXG4vKiog5Yik5a6a5LiA5Liq6ZSu5piv5ZCm6JC95Zyo5Yy66Ze05YaF44CCICovXG5mdW5jdGlvbiBpblJhbmdlKGtleTogRGJLZXkgfCBEYktleVtdLCByYW5nZT86IERiS2V5UmFuZ2UpOiBib29sZWFuIHtcbiAgaWYgKHJhbmdlID09PSB1bmRlZmluZWQpIHJldHVybiB0cnVlO1xuICBjb25zdCB7IGxvd2VyLCB1cHBlciwgbG93ZXJPcGVuLCB1cHBlck9wZW4gfSA9IHJhbmdlO1xuICBpZiAobG93ZXIgIT09IHVuZGVmaW5lZCkge1xuICAgIGNvbnN0IGRpZmYgPSBjb21wYXJlS2V5cyhrZXksIGxvd2VyKTtcbiAgICBpZiAoZGlmZiA8IDAgfHwgKGRpZmYgPT09IDAgJiYgbG93ZXJPcGVuID09PSB0cnVlKSkgcmV0dXJuIGZhbHNlO1xuICB9XG4gIGlmICh1cHBlciAhPT0gdW5kZWZpbmVkKSB7XG4gICAgY29uc3QgZGlmZiA9IGNvbXBhcmVLZXlzKGtleSwgdXBwZXIpO1xuICAgIGlmIChkaWZmID4gMCB8fCAoZGlmZiA9PT0gMCAmJiB1cHBlck9wZW4gPT09IHRydWUpKSByZXR1cm4gZmFsc2U7XG4gIH1cbiAgcmV0dXJuIHRydWU7XG59XG5cbi8qKiDliKTlrprkuIDkuKrntKLlvJXmnaHnm67mmK/lkKblkb3kuK3mn6Xor6LvvIjmoIfph48gPSDnsr7noa7jgIHmlbDnu4QgPSDlpI3lkIjnsr7noa7jgIHlr7nosaEgPSDljLrpl7TvvInjgIIgKi9cbmZ1bmN0aW9uIG1hdGNoZXNJbmRleFF1ZXJ5KGVudHJ5S2V5OiBEYktleSB8IERiS2V5W10sIHF1ZXJ5PzogRGJJbmRleFF1ZXJ5KTogYm9vbGVhbiB7XG4gIGlmIChxdWVyeSA9PT0gdW5kZWZpbmVkKSByZXR1cm4gdHJ1ZTtcbiAgaWYgKHR5cGVvZiBxdWVyeSA9PT0gJ3N0cmluZycgfHwgdHlwZW9mIHF1ZXJ5ID09PSAnbnVtYmVyJykge1xuICAgIHJldHVybiBjb21wYXJlS2V5cyhlbnRyeUtleSwgcXVlcnkpID09PSAwO1xuICB9XG4gIGlmIChBcnJheS5pc0FycmF5KHF1ZXJ5KSkge1xuICAgIHJldHVybiBzZXJpYWxpemVLZXkoZW50cnlLZXkpID09PSBzZXJpYWxpemVLZXkocXVlcnkpO1xuICB9XG4gIHJldHVybiBpblJhbmdlKGVudHJ5S2V5LCBxdWVyeSk7XG59XG5cbmludGVyZmFjZSBQaHlzaWNhbFJlY29yZCB7XG4gIGtleTogRGJLZXkgfCBEYktleVtdO1xuICB2YWx1ZTogUmVjb3JkPHN0cmluZywgdW5rbm93bj47XG59XG5cbmludGVyZmFjZSBQaHlzaWNhbFN0b3JlIHtcbiAgc2NoZW1hOiBTdG9yZVNjaGVtYTtcbiAgcmVjb3JkczogTWFwPHN0cmluZywgUGh5c2ljYWxSZWNvcmQ+O1xuICBhdXRvSW5jcmVtZW50OiBudW1iZXI7XG59XG5cbi8qKlxuICog5YaF5a2Y6YCC6YWN5Zmo44CCXG4gKlxuICog5bm25Y+R5aWR57qm5LiOIGBEYkFkYXB0ZXJgIOS4gOiHtO+8muaJgOacieaWueazlemDveWPr+WuieWFqOW5tuWPkeiwg+eUqOOAglxuICog6L+Z6YeM6Z2gKirlkIzmraXmiafooYwgKyDlvq7ku7vliqHovrnnlYwqKuWkqeeEtuS4suihjOWMlu+8jOS4jemcgOimgemineWkluWKoOmUgeOAglxuICovXG5leHBvcnQgY2xhc3MgTWVtb3J5RGJBZGFwdGVyIGltcGxlbWVudHMgRGJBZGFwdGVyIHtcbiAgcHJpdmF0ZSBzdG9yZXMgPSBuZXcgTWFwPHN0cmluZywgUGh5c2ljYWxTdG9yZT4oKTtcbiAgcHJpdmF0ZSBjbG9zaW5nID0gZmFsc2U7XG5cbiAgLyoqIOmUgOavgeWNs+atu+i3r++8iEUyIOWPo+W+hCBC77yM5LiO5Lik5Lu95oyB5LmF5a6e546w5ZCM5LiA5p2h5aWR57qm77yJ44CCICovXG4gIHByaXZhdGUgZGVzdHJveWVkID0gZmFsc2U7XG5cbiAgLyoqIOesrOS6jOasoSBgZGVzdHJveSgpYCDlpI3nlKjov5nku73miqXlkYrvvIzkuI3lho1cIua4heepuuS4gOmBjVwi77yI5riF56m66ZyA6KaB5YWI6K6p5a6e5L6L5Y+v55So77yJ44CCICovXG4gIHByaXZhdGUgZGVzdHJveWluZzogUHJvbWlzZTxEYkRlc3Ryb3lSZXBvcnQ+IHwgdW5kZWZpbmVkO1xuICBwcml2YXRlIHN5bmNEZXB0aCA9IDA7XG4gIHByaXZhdGUgdHhRdWV1ZTogUHJvbWlzZTx1bmtub3duPiA9IFByb21pc2UucmVzb2x2ZSgpO1xuXG4gIGNvbnN0cnVjdG9yKHNjaGVtYTogcmVhZG9ubHkgU3RvcmVTY2hlbWFbXSA9IFtdKSB7XG4gICAgZm9yIChjb25zdCBzIG9mIHNjaGVtYSkge1xuICAgICAgdGhpcy5zdG9yZXMuc2V0KHMubmFtZSwge1xuICAgICAgICBzY2hlbWE6IHMsXG4gICAgICAgIHJlY29yZHM6IG5ldyBNYXAoKSxcbiAgICAgICAgYXV0b0luY3JlbWVudDogMCxcbiAgICAgIH0pO1xuICAgIH1cbiAgfVxuXG4gIGFzeW5jIGluaXQoKTogUHJvbWlzZTx2b2lkPiB7XG4gICAgaWYgKHRoaXMuZGVzdHJveWVkKSB0aHJvdyBuZXcgQWRhcHRlckRlc3Ryb3llZEVycm9yKCdtZW1vcnknKTtcbiAgICB0aGlzLmNsb3NpbmcgPSBmYWxzZTtcbiAgfVxuXG4gIGNsb3NlKCk6IHZvaWQge1xuICAgIHRoaXMuY2xvc2luZyA9IHRydWU7XG4gIH1cblxuICAvKipcbiAgICog5riF56m65YWo6YOoIHN0b3JlIOeahOiusOW9leS4juiHquWinuiuoeaVsOWZqO+8jOW5tuaKiui/meS4quWunuS+iyoq5L2c5bqfKirjgIJcbiAgICpcbiAgICog4pqg77iPICoq5L+d55WZIHN0b3JlIOeahCBzY2hlbWEqKu+8muaKiiBgc3RvcmVzYCDmlbTlvKAgTWFwIOa4heepuuS8muiuqeS5i+WQjuS7u+S9leS4gOasoeivu1xuICAgKiDlj5jmiJBcIuayoeaciei/meS4qiBzdG9yZVwi55qE5byC5bi477yM6ICM6YKj5Lya6KKr6K+75oiQXCLplIDmr4HlpLHotKVcIuOAguS9nOW6n+i1sOeahOaYr+WPpuS4gOadoei3r++8mlxuICAgKiDmr4/mrKHmk43kvZzlnKgqKui/m+mXqOaXtioq5bCx6KKrIGBBZGFwdGVyRGVzdHJveWVkRXJyb3JgIOaLkuaOie+8iOWPo+W+hCBC77yM6KeB5LiL77yJ44CCXG4gICAqXG4gICAqIPCflLQg6L+Z5LiA54mI5LmL5YmN5a6D5pivXCLmuIXnqbrlkI7ku43lj6/nu6fnu63nlKhcIu+8jOiAjOmCo+adoeWPo+W+hOermeWcqOWlkee6pueahOWvueeri+mdou+8mlxuICAgKiBgRGJBZGFwdGVyLmRlc3Ryb3lgIOS5i+WQjuWunuS+i+i/mOiDveWGme+8jOaEj+WRs+edgCoq5piO5paH5Y+v5Lul6YeN5paw6L+b6L+Z5Z2X5YaF5a2YKirvvIxcbiAgICog6ICM5Zub5Lu95a6e546w6YeM5ZSv5LiA6IO95Yy65YiGXCLplIDmr4FcIuS4jlwi5riF56m6XCLnmoTliKTmja7lsLHmmK/lhbHkuqvlpZHnuqbpgqPkuIDmnaHohb/jgIJcbiAgICog5YaF5a2Y5a6e546w5rKh5pyJ5oyB5LmF5a655Zmo5Y+v5Yig77yM5omA5LulIGBjb250YWluZXJSZW1vdmVkYCDmiqUgdHJ1ZSDnmoTnkIbnlLHmmK9cbiAgICogKirov5vnqIvlhoXmsqHmnInku7vkvZXkuJzopb/nlZnkuIvmnaUqKu+8iOS4jeaYr1wi5paH5Lu25Yig5LqGXCLvvInigJTigJQgYHRhcmdldGAg5LiOIGByZWFzb25gIOWGmeaYjuWug+OAglxuICAgKi9cbiAgYXN5bmMgZGVzdHJveSgpOiBQcm9taXNlPERiRGVzdHJveVJlcG9ydD4ge1xuICAgIGlmICh0aGlzLmRlc3Ryb3lpbmcgIT09IHVuZGVmaW5lZCkgcmV0dXJuIHRoaXMuZGVzdHJveWluZztcbiAgICB0aGlzLmNsb3NpbmcgPSBmYWxzZTtcbiAgICBsZXQgc3RvcmVzQ2xlYXJlZCA9IDA7XG4gICAgZm9yIChjb25zdCBzdG9yZSBvZiB0aGlzLnN0b3Jlcy52YWx1ZXMoKSkge1xuICAgICAgc3RvcmUucmVjb3Jkcy5jbGVhcigpO1xuICAgICAgc3RvcmUuYXV0b0luY3JlbWVudCA9IDA7XG4gICAgICBzdG9yZXNDbGVhcmVkICs9IDE7XG4gICAgfVxuICAgIHRoaXMuZGVzdHJveWVkID0gdHJ1ZTtcbiAgICB0aGlzLmRlc3Ryb3lpbmcgPSBQcm9taXNlLnJlc29sdmUoe1xuICAgICAgdGFyZ2V0OiAnbWVtb3J5JyxcbiAgICAgIGNvbnRhaW5lclJlbW92ZWQ6IHRydWUsXG4gICAgICByZWFzb246ICflhoXlrZjlrp7njrDvvJrmsqHmnInmjIHkuYXlrrnlmajvvIzmuIXnqbrljbPkuI3nlZnku7vkvZXkuJzopb8nLFxuICAgICAgc3RvcmVzQ2xlYXJlZCxcbiAgICB9KTtcbiAgICByZXR1cm4gdGhpcy5kZXN0cm95aW5nO1xuICB9XG5cbiAgLyoqIOW7uuihqOOAguWPr+mHjeWkjeiwg+eUqO+8iOW5guetie+8ie+8jOeUqOS6jua1i+ivlemHjOWKqOaAgeWKoCBzdG9yZeOAgiAqL1xuICBkZWZpbmVTdG9yZShzY2hlbWE6IFN0b3JlU2NoZW1hKTogdm9pZCB7XG4gICAgaWYgKHRoaXMuc3RvcmVzLmhhcyhzY2hlbWEubmFtZSkpIHJldHVybjtcbiAgICB0aGlzLnN0b3Jlcy5zZXQoc2NoZW1hLm5hbWUsIHsgc2NoZW1hLCByZWNvcmRzOiBuZXcgTWFwKCksIGF1dG9JbmNyZW1lbnQ6IDAgfSk7XG4gIH1cblxuICAvLyDilIDilIAg5YWs5byAIEFQSe+8muavj+adoemDveW8gOS4gOS4quWNlSBzdG9yZSDkuovliqEg4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG5cbiAgYWRkKHN0b3JlOiBzdHJpbmcsIHZhbHVlOiB1bmtub3duKTogUHJvbWlzZTxudW1iZXI+IHtcbiAgICByZXR1cm4gdGhpcy50cmFuc2FjdGlvbihbc3RvcmVdLCAncmVhZHdyaXRlJywgYXN5bmMgKHR4KSA9PiB0eC5hZGQoc3RvcmUsIHZhbHVlKSk7XG4gIH1cblxuICBwdXQoc3RvcmU6IHN0cmluZywgdmFsdWU6IHVua25vd24sIGtleT86IERiS2V5KTogUHJvbWlzZTx2b2lkPiB7XG4gICAgcmV0dXJuIHRoaXMudHJhbnNhY3Rpb24oW3N0b3JlXSwgJ3JlYWR3cml0ZScsIGFzeW5jICh0eCkgPT4gdHgucHV0KHN0b3JlLCB2YWx1ZSwga2V5KSk7XG4gIH1cblxuICBnZXQ8VD4oc3RvcmU6IHN0cmluZywga2V5OiBEYktleSk6IFByb21pc2U8VCB8IHVuZGVmaW5lZD4ge1xuICAgIHJldHVybiB0aGlzLnRyYW5zYWN0aW9uKFtzdG9yZV0sICdyZWFkb25seScsIGFzeW5jICh0eCkgPT4gdHguZ2V0PFQ+KHN0b3JlLCBrZXkpKTtcbiAgfVxuXG4gIGdldEFsbDxUPihzdG9yZTogc3RyaW5nLCByYW5nZT86IERiS2V5UmFuZ2UsIGxpbWl0PzogbnVtYmVyKTogUHJvbWlzZTxUW10+IHtcbiAgICByZXR1cm4gdGhpcy50cmFuc2FjdGlvbihbc3RvcmVdLCAncmVhZG9ubHknLCBhc3luYyAodHgpID0+IHR4LmdldEFsbDxUPihzdG9yZSwgcmFuZ2UsIGxpbWl0KSk7XG4gIH1cblxuICBkZWxldGUoc3RvcmU6IHN0cmluZywga2V5OiBEYktleSk6IFByb21pc2U8dm9pZD4ge1xuICAgIHJldHVybiB0aGlzLnRyYW5zYWN0aW9uKFtzdG9yZV0sICdyZWFkd3JpdGUnLCBhc3luYyAodHgpID0+IHR4LmRlbGV0ZShzdG9yZSwga2V5KSk7XG4gIH1cblxuICBjbGVhcihzdG9yZTogc3RyaW5nKTogUHJvbWlzZTx2b2lkPiB7XG4gICAgcmV0dXJuIHRoaXMudHJhbnNhY3Rpb24oW3N0b3JlXSwgJ3JlYWR3cml0ZScsIGFzeW5jICh0eCkgPT4gdHguY2xlYXIoc3RvcmUpKTtcbiAgfVxuXG4gIGNvdW50KHN0b3JlOiBzdHJpbmcsIHJhbmdlPzogRGJLZXlSYW5nZSk6IFByb21pc2U8bnVtYmVyPiB7XG4gICAgcmV0dXJuIHRoaXMudHJhbnNhY3Rpb24oW3N0b3JlXSwgJ3JlYWRvbmx5JywgYXN5bmMgKHR4KSA9PiB0eC5jb3VudChzdG9yZSwgcmFuZ2UpKTtcbiAgfVxuXG4gIGdldEZyb21JbmRleDxUPihzdG9yZTogc3RyaW5nLCBpbmRleDogc3RyaW5nLCBrZXk6IERiS2V5IHwgRGJLZXlbXSk6IFByb21pc2U8VCB8IHVuZGVmaW5lZD4ge1xuICAgIHJldHVybiB0aGlzLnRyYW5zYWN0aW9uKFtzdG9yZV0sICdyZWFkb25seScsIGFzeW5jICh0eCkgPT4gdHguZ2V0RnJvbUluZGV4PFQ+KHN0b3JlLCBpbmRleCwga2V5KSk7XG4gIH1cblxuICBnZXRLZXlGcm9tSW5kZXgoc3RvcmU6IHN0cmluZywgaW5kZXg6IHN0cmluZywga2V5OiBEYktleSB8IERiS2V5W10pOiBQcm9taXNlPERiS2V5IHwgdW5kZWZpbmVkPiB7XG4gICAgcmV0dXJuIHRoaXMudHJhbnNhY3Rpb24oW3N0b3JlXSwgJ3JlYWRvbmx5JywgYXN5bmMgKHR4KSA9PiB0eC5nZXRLZXlGcm9tSW5kZXgoc3RvcmUsIGluZGV4LCBrZXkpKTtcbiAgfVxuXG4gIGdldEFsbEZyb21JbmRleDxUPihzdG9yZTogc3RyaW5nLCBpbmRleDogc3RyaW5nLCBxdWVyeT86IERiSW5kZXhRdWVyeSk6IFByb21pc2U8VFtdPiB7XG4gICAgcmV0dXJuIHRoaXMudHJhbnNhY3Rpb24oW3N0b3JlXSwgJ3JlYWRvbmx5JywgYXN5bmMgKHR4KSA9PiB0eC5nZXRBbGxGcm9tSW5kZXg8VD4oc3RvcmUsIGluZGV4LCBxdWVyeSkpO1xuICB9XG5cbiAgY291bnRGcm9tSW5kZXgoc3RvcmU6IHN0cmluZywgaW5kZXg6IHN0cmluZywgcXVlcnk/OiBEYkluZGV4UXVlcnkpOiBQcm9taXNlPG51bWJlcj4ge1xuICAgIHJldHVybiB0aGlzLnRyYW5zYWN0aW9uKFtzdG9yZV0sICdyZWFkb25seScsIGFzeW5jICh0eCkgPT4gdHguY291bnRGcm9tSW5kZXgoc3RvcmUsIGluZGV4LCBxdWVyeSkpO1xuICB9XG5cbiAgaXRlcmF0ZTxUPihzdG9yZTogc3RyaW5nLCBvcHRpb25zOiBEYkl0ZXJhdGVPcHRpb25zLCB2aXNpdDogRGJDdXJzb3JWaXNpdG9yPFQ+KTogUHJvbWlzZTx2b2lkPiB7XG4gICAgcmV0dXJuIHRoaXMudHJhbnNhY3Rpb24oW3N0b3JlXSwgJ3JlYWR3cml0ZScsIGFzeW5jICh0eCkgPT4gdHguaXRlcmF0ZTxUPihzdG9yZSwgb3B0aW9ucywgdmlzaXQpKTtcbiAgfVxuXG4gIC8qKlxuICAgKiDljZXkuovliqHjgIIqKuWksei0peaXtuaVtOS9k+Wbnua7mioq44CCXG4gICAqXG4gICAqIOWbnua7muaYr+ecn+eahOimgeWunueOsOeahO+8muS4iuWxgu+8iOS+i+WmgiBgYXBwZW5kTG9jYWxg77yJ5L6d6LWWXCLopoHkuYjlhajokL3nm5jopoHkuYjlhajkuI3okL1cIu+8jFxuICAgKiDkuIDkuKrlgYfnmoTkuovliqHkvJrorqnltKnmuoPmgaLlpI3pgLvovpHlu7rnq4vlnKjkuI3lrZjlnKjnmoTkv53or4HkuIrjgIJcbiAgICovXG4gIGFzeW5jIHRyYW5zYWN0aW9uPFQ+KHN0b3Jlczogc3RyaW5nW10sIF9tb2RlOiBEYlR4TW9kZSwgZm46ICh0eDogRGJUeCkgPT4gUHJvbWlzZTxUPik6IFByb21pc2U8VD4ge1xuICAgIC8qKlxuICAgICAqIPCflLQg5bWM5aWX5qOA5rWLKirlj6rog70qKuimhuebllwi5ZCM5q2l5YmN57yAXCLvvIzov5nmmK/liLvmhI/nmoTlj5boiI3jgIJcbiAgICAgKlxuICAgICAqIOS4uuS7gOS5iOS4jeiDveeUqOS4gOS4qlwi5pyJ5LqL5Yqh5Zyo6LeRXCLnmoTluIPlsJTmoIflv5fvvJrpgqPkvJrmiooqKuW5tuWPkSoq5Lmf5oum5LiL5p2l77yMXG4gICAgICog6ICMIGBEYkFkYXB0ZXJgIOeahOWlkee6puaYjuehruimgeaxglwi5omA5pyJ5pa55rOV6YO95Y+v5a6J5YWo5bm25Y+R6LCD55SoXCLjgIJcbiAgICAgKiDmiJHnrKzkuIDniYjlsLHmmK/ov5nkuYjlhpnnmoTvvIzlpZHnuqbmtYvor5Xnq4vliLvmiqVcIuW5tuWPkeS6i+WKoeS4jeiDveiQveebmFwiIOKAlOKAlFxuICAgICAqIOaKiuW5tuWPkeW9k+W1jOWll++8jOetieS6juiuqeS4gOS4quacrOadpeato+ehrueahOeUqOazleWPmOaIkOmUmeivr+OAglxuICAgICAqXG4gICAgICog5Li65LuA5LmI5LiN6IO95a6M5YWo5qOA5rWL77ya6LeoIGBhd2FpdGAg5LmL5ZCO77yMSlMg6YeM5rKh5pyJ5Y+v56e75qSN55qE5Yqe5rOV55+l6YGTXG4gICAgICogXCLlvZPliY3ov5nmrrXku6PnoIHmmK/kuI3mmK/mn5DkuKrkuovliqEgZm4g55qE5ZCO57unXCLvvIjmtY/op4jlmajmsqHmnIkgQXN5bmNMb2NhbFN0b3JhZ2XvvInjgIJcbiAgICAgKlxuICAgICAqIOaJgOS7pei/memHjOWPquaKkyoq5ZCM5q2l5YmN57yAKirph4znmoTltYzlpZfosIPnlKjvvJpgZm4odHgpYCDosIPnlKjliLDlroPnrKzkuIDkuKogYGF3YWl0YFxuICAgICAqIOS5i+mXtOaYr+WQjOatpeaJp+ihjOeahO+8jOi/meauteaXtumXtOmHjOWGjeiwgyBgdHJhbnNhY3Rpb24oKWAg5b+F54S25piv55yf5bWM5aWX44CCXG4gICAgICog6L+H5LqGIGF3YWl0IOaJjeiwg+eahOW1jOWll+S8mui1sOmYn+WIl+iAjOS4jeaYr+aKm+mUmSDigJTigJQg6YKj5piv5bey55+l55qE44CB5pyJ5paH5qGj55qE6L6555WM44CCXG4gICAgICovXG4gICAgaWYgKHRoaXMuc3luY0RlcHRoID4gMCkge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKCfkuI3mlK/mjIHltYzlpZfkuovliqHvvJrlnKjkuovliqHph4zlj4josIPnlKjkuoYgdHJhbnNhY3Rpb24oKScpO1xuICAgIH1cblxuICAgIC8vIPCflLQg6ZSA5q+B5Y2z5q276Lev77ya5omA5pyJ5YWs5byA5pa55rOV6YO96LWw6L+Z5LiA5p2hIGB0cmFuc2FjdGlvbmDvvIzmiYDku6XkuIDkuKrov5vpl6jliKTmja5cbiAgICAvLyDlsLHopobnm5ZcIuS5i+WQjuS7u+S9leS4gOasoeivu+WGmVwi77yM5YyF5ous55yL6LW35p2l5peg5a6z55qEIGBjb3VudGDjgIJcbiAgICBpZiAodGhpcy5kZXN0cm95ZWQpIHRocm93IG5ldyBBZGFwdGVyRGVzdHJveWVkRXJyb3IoJ21lbW9yeScpO1xuXG4gICAgZm9yIChjb25zdCBuYW1lIG9mIHN0b3Jlcykge1xuICAgICAgaWYgKCF0aGlzLnN0b3Jlcy5oYXMobmFtZSkpIHtcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKFxuICAgICAgICAgIGDkuovliqHorr/pl67kuobmnKrlrprkuYnnmoQgc3RvcmXvvJrjgIwke25hbWV944CN44CC5bey5a6a5LmJ77yaJHtbLi4udGhpcy5zdG9yZXMua2V5cygpXS5qb2luKCcsICcpfWAsXG4gICAgICAgICk7XG4gICAgICB9XG4gICAgfVxuXG4gICAgLy8g5b+r54Wn55So5LqO5Zue5rua44CC5rWF5ou36LSd6Laz5aSf77ya6K6w5b2V5a+56LGh5pys6Lqr5Zyo5LqL5Yqh6YeM5LiN5Lya6KKr5bCx5Zyw5pS55YaZ44CCXG4gICAgY29uc3Qgc25hcHNob3QgPSBuZXcgTWFwPHN0cmluZywgeyByZWNvcmRzOiBNYXA8c3RyaW5nLCBQaHlzaWNhbFJlY29yZD47IGF1dG9JbmNyZW1lbnQ6IG51bWJlciB9PigpO1xuICAgIGZvciAoY29uc3QgbmFtZSBvZiBzdG9yZXMpIHtcbiAgICAgIGNvbnN0IHMgPSB0aGlzLnN0b3Jlcy5nZXQobmFtZSkhO1xuICAgICAgc25hcHNob3Quc2V0KG5hbWUsIHsgcmVjb3JkczogbmV3IE1hcChzLnJlY29yZHMpLCBhdXRvSW5jcmVtZW50OiBzLmF1dG9JbmNyZW1lbnQgfSk7XG4gICAgfVxuXG4gICAgY29uc3QgcnVuID0gYXN5bmMgKCk6IFByb21pc2U8VD4gPT4ge1xuICAgICAgdGhpcy5zeW5jRGVwdGgrKztcbiAgICAgIGxldCBwZW5kaW5nOiBQcm9taXNlPFQ+O1xuICAgICAgdHJ5IHtcbiAgICAgICAgcGVuZGluZyA9IGZuKHRoaXMubWFrZVR4KHN0b3JlcykpO1xuICAgICAgfSBmaW5hbGx5IHtcbiAgICAgICAgLy8g5Y+q6KaG55uWIGZuIOeahOWQjOatpeWJjee8gCDigJTigJQg6KeB5LiK6Z2i5YWz5LqO5bWM5aWX5qOA5rWL55qE6K+05piOXG4gICAgICAgIHRoaXMuc3luY0RlcHRoLS07XG4gICAgICB9XG4gICAgICB0cnkge1xuICAgICAgICByZXR1cm4gYXdhaXQgcGVuZGluZztcbiAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgIC8vIPCflLQg5Zue5rua5b+F6aG75piv55yf55qE44CC5LiK5bGC77yI5aaCIGFwcGVuZExvY2Fs77yJ5L6d6LWWXCLopoHkuYjlhajokL3nm5jopoHkuYjlhajkuI3okL1cIu+8jFxuICAgICAgICAvLyDkuIDkuKrlgYfnmoTkuovliqHkvJrorqnltKnmuoPmgaLlpI3lu7rnq4vlnKjkuI3lrZjlnKjnmoTkv53or4HkuIrjgIJcbiAgICAgICAgZm9yIChjb25zdCBbbmFtZSwgc25hcF0gb2Ygc25hcHNob3QpIHtcbiAgICAgICAgICBjb25zdCBzID0gdGhpcy5zdG9yZXMuZ2V0KG5hbWUpITtcbiAgICAgICAgICBzLnJlY29yZHMgPSBzbmFwLnJlY29yZHM7XG4gICAgICAgICAgcy5hdXRvSW5jcmVtZW50ID0gc25hcC5hdXRvSW5jcmVtZW50O1xuICAgICAgICB9XG4gICAgICAgIHRocm93IGVycm9yO1xuICAgICAgfVxuICAgIH07XG5cbiAgICAvLyBGSUZPIOS4suihjOWMlu+8muWNlei/nuaOpe+8iOWGheWtmCAvIFNRTGl0Ze+8ieW/hemhu+iHquW3seaOkumYn++8jOiwg+eUqOaWueS4jeWKoOmUgeOAglxuICAgIC8vIOS4jiBJbmRleGVkREIg55qEXCLph43lj6DkvZznlKjln5/kuovliqHooqvkuLLooYzljJZcIuWcqOWPr+inguWvn+ihjOS4uuS4iuS4gOiHtOOAglxuICAgIGNvbnN0IHJlc3VsdCA9IHRoaXMudHhRdWV1ZS50aGVuKHJ1biwgcnVuKTtcbiAgICAvLyDpmJ/liJfmnKzouqvkuI3og73lm6DkuLrmn5DmrKHkuovliqHlpLHotKXogIzkuK3mlq1cbiAgICB0aGlzLnR4UXVldWUgPSByZXN1bHQudGhlbihcbiAgICAgICgpID0+IHVuZGVmaW5lZCxcbiAgICAgICgpID0+IHVuZGVmaW5lZCxcbiAgICApO1xuICAgIHJldHVybiByZXN1bHQ7XG4gIH1cblxuICAvKiog5p6E6YCg5LqL5Yqh5Y+l5p+E44CCYGFsbG93ZWRgIOmHjOeahCBzdG9yZSDmiY3lj6/orr/pl64g4oCU4oCUIOiuv+mXruWIq+eahOebtOaOpeaKpemUme+8jOS4jemdmem7mOmZjee6p+OAgiAqL1xuICBwcml2YXRlIG1ha2VUeChhbGxvd2VkOiBzdHJpbmdbXSk6IERiVHgge1xuICAgIGNvbnN0IGFzc2VydCA9IChzdG9yZTogc3RyaW5nKTogUGh5c2ljYWxTdG9yZSA9PiB7XG4gICAgICBpZiAoIWFsbG93ZWQuaW5jbHVkZXMoc3RvcmUpKSB7XG4gICAgICAgIHRocm93IG5ldyBFcnJvcihgc3RvcmXjgIwke3N0b3JlfeOAjeS4jeWcqOacrOasoeS6i+WKoeeahOiMg+WbtOWGhe+8miR7YWxsb3dlZC5qb2luKCcsICcpfWApO1xuICAgICAgfVxuICAgICAgY29uc3QgcyA9IHRoaXMuc3RvcmVzLmdldChzdG9yZSk7XG4gICAgICBpZiAoIXMpIHtcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKGDmnKrlrprkuYnnmoQgc3RvcmXvvJrjgIwke3N0b3JlfeOAjWApO1xuICAgICAgfVxuICAgICAgcmV0dXJuIHM7XG4gICAgfTtcblxuICAgIGNvbnN0IGZpbmRJbmRleCA9IChzdG9yZTogUGh5c2ljYWxTdG9yZSwgaW5kZXhOYW1lOiBzdHJpbmcpID0+IHtcbiAgICAgIGNvbnN0IGlkeCA9IHN0b3JlLnNjaGVtYS5pbmRleGVzPy5maW5kKChpKSA9PiBpLm5hbWUgPT09IGluZGV4TmFtZSk7XG4gICAgICBpZiAoIWlkeCkge1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoYHN0b3Jl44CMJHtzdG9yZS5zY2hlbWEubmFtZX3jgI3kuIrmsqHmnInntKLlvJXjgIwke2luZGV4TmFtZX3jgI1gKTtcbiAgICAgIH1cbiAgICAgIHJldHVybiBpZHg7XG4gICAgfTtcblxuICAgIC8qKiDmlLbpm4bmn5DorrDlvZXlnKjkuIDkuKrntKLlvJXkuIrnmoTlhajpg6jmnaHnm67vvIhtdWx0aUVudHJ5IOS8muWxleW8gOaIkOWkmuS4qu+8ieOAgiAqL1xuICAgIGNvbnN0IGluZGV4RW50cmllcyA9IChcbiAgICAgIHN0b3JlOiBQaHlzaWNhbFN0b3JlLFxuICAgICAgaWR4OiBOb25OdWxsYWJsZTxTdG9yZVNjaGVtYVsnaW5kZXhlcyddPltudW1iZXJdLFxuICAgICAgdmFsdWU6IFJlY29yZDxzdHJpbmcsIHVua25vd24+LFxuICAgICk6IChEYktleSB8IERiS2V5W10pW10gPT4ge1xuICAgICAgLyoqXG4gICAgICAgKiDimqDvuI8g6L+Z6YeMKirkuI3og70qKuebtOaOpeeUqCBga2V5RnJvbVBhdGgoKWDjgIJcbiAgICAgICAqXG4gICAgICAgKiBga2V5RnJvbVBhdGhgIOaYr+e7mSoq5Li76ZSuKirnlKjnmoTvvIzlroPmiormlbDnu4TlgLzliKTkuLrpnZ7ms5XvvIjkuLvplK7lj6rog73mmK9cbiAgICAgICAqIHN0cmluZyB8IG51bWJlcu+8ieOAguiAjCBtdWx0aUVudHJ5IOe0ouW8leaBsOaBsOaMh+WQkeS4gOS4qioq5pWw57uE5a2X5q61KipcbiAgICAgICAqIO+8iOe6v+S4iiBgb3AuZW50aXR5SWRzYCDlsLHmmK/vvInvvIzkuo7mmK/lroPov5Tlm54gYHVuZGVmaW5lZGAg4oCU4oCUXG4gICAgICAgKiDntKLlvJXmgZLkuI3lkb3kuK3vvIzkuJQqKuS4jeaKpemUmSoq44CC5aWR57qm5rWL6K+V56ys5LiA5qyh6LeR5bCx5oqK6L+Z5Liq5oqT5Ye65p2l5LqG44CCXG4gICAgICAgKi9cbiAgICAgIGlmICh0eXBlb2YgaWR4LmtleVBhdGggPT09ICdzdHJpbmcnKSB7XG4gICAgICAgIGNvbnN0IHJhdyA9IHZhbHVlQXRQYXRoKHZhbHVlLCBpZHgua2V5UGF0aCk7XG4gICAgICAgIGlmIChyYXcgPT09IHVuZGVmaW5lZCkgcmV0dXJuIFtdO1xuICAgICAgICBpZiAoaWR4Lm11bHRpRW50cnkgPT09IHRydWUpIHtcbiAgICAgICAgICBpZiAoIUFycmF5LmlzQXJyYXkocmF3KSkgcmV0dXJuIFtdO1xuICAgICAgICAgIHJldHVybiByYXcuZmlsdGVyKCh2KSA9PiB0eXBlb2YgdiA9PT0gJ3N0cmluZycgfHwgdHlwZW9mIHYgPT09ICdudW1iZXInKSBhcyBEYktleVtdO1xuICAgICAgICB9XG4gICAgICAgIGlmICh0eXBlb2YgcmF3ICE9PSAnc3RyaW5nJyAmJiB0eXBlb2YgcmF3ICE9PSAnbnVtYmVyJykgcmV0dXJuIFtdO1xuICAgICAgICByZXR1cm4gW3Jhd107XG4gICAgICB9XG5cbiAgICAgIGNvbnN0IGNvbXBvc2l0ZSA9IGtleUZyb21QYXRoKHZhbHVlLCBpZHgua2V5UGF0aCk7XG4gICAgICBpZiAoY29tcG9zaXRlID09PSB1bmRlZmluZWQpIHJldHVybiBbXTtcbiAgICAgIGlmIChpZHgubXVsdGlFbnRyeSA9PT0gdHJ1ZSAmJiBBcnJheS5pc0FycmF5KGNvbXBvc2l0ZSkpIHtcbiAgICAgICAgcmV0dXJuIGNvbXBvc2l0ZS5tYXAoKHYpID0+IHYgYXMgRGJLZXkpO1xuICAgICAgfVxuICAgICAgcmV0dXJuIFtjb21wb3NpdGVdO1xuICAgIH07XG5cbiAgICBjb25zdCBhcHBseUFjdGlvbiA9IChhY3Rpb246IERiQ3Vyc29yQWN0aW9uLCByZWNvcmQ6IFBoeXNpY2FsUmVjb3JkLCBzdG9yZTogUGh5c2ljYWxTdG9yZSk6ICdjb250aW51ZScgfCAnc3RvcCcgPT4ge1xuICAgICAgc3dpdGNoIChhY3Rpb24pIHtcbiAgICAgICAgY2FzZSAnY29udGludWUnOlxuICAgICAgICAgIHJldHVybiAnY29udGludWUnO1xuICAgICAgICBjYXNlICdzdG9wJzpcbiAgICAgICAgICByZXR1cm4gJ3N0b3AnO1xuICAgICAgICBjYXNlICdkZWxldGUnOlxuICAgICAgICAgIHN0b3JlLnJlY29yZHMuZGVsZXRlKHNlcmlhbGl6ZUtleShyZWNvcmQua2V5KSk7XG4gICAgICAgICAgcmV0dXJuICdjb250aW51ZSc7XG4gICAgICAgIGNhc2UgJ2RlbGV0ZS1zdG9wJzpcbiAgICAgICAgICBzdG9yZS5yZWNvcmRzLmRlbGV0ZShzZXJpYWxpemVLZXkocmVjb3JkLmtleSkpO1xuICAgICAgICAgIHJldHVybiAnc3RvcCc7XG4gICAgICB9XG4gICAgfTtcblxuICAgIGNvbnN0IHNvcnRlZFJlY29yZHMgPSAoc3RvcmU6IFBoeXNpY2FsU3RvcmUpOiBQaHlzaWNhbFJlY29yZFtdID0+XG4gICAgICBbLi4uc3RvcmUucmVjb3Jkcy52YWx1ZXMoKV0uc29ydCgoYSwgYikgPT4gY29tcGFyZUtleXMoYS5rZXksIGIua2V5KSk7XG5cbiAgICAvKipcbiAgICAgKiDmj5LlhaXkuIDmnaHorrDlvZXjgILllK/kuIDlhrLnqoHml7bmipsgYER1cGxpY2F0ZUtleUVycm9yYO+8iOWGhemDqOWei+WIq++8ie+8jFxuICAgICAqIOeUsSBgYWRkYCDnm7TmjqXmipvlh7rjgIHnlLEgYGFkZFRvbGVyYXRpbmdEdXBsaWNhdGVgIOi9rOaIkOe7k+aenOWvueixoeOAglxuICAgICAqXG4gICAgICog5oq95Ye65p2l5piv5Li65LqG6K6p5Lik5Liq5YWl5Y+jKirlhbHnlKjlkIzkuIDlpZfllK/kuIDmgKfliKTlrpoqKiDigJTigJRcbiAgICAgKiDlkITlhpnkuIDku73lv4XnhLbmvILnp7vvvIzogIxcIuWuueW/jemHjeWkjVwi5LiOXCLkuI3lrrnlv43ph43lpI1cIuWvueWUr+S4gOaAp+eahOeQhuino1xuICAgICAqIOS4gOaXpuS4jeS4gOiHtO+8jOWOu+mHjeWwseS8muWPmOaIkOeisOi/kOawlOOAglxuICAgICAqL1xuICAgIGNvbnN0IGluc2VydCA9IChzdG9yZU5hbWU6IHN0cmluZywgdmFsdWU6IHVua25vd24pOiB7IGtleTogbnVtYmVyIH0gPT4ge1xuICAgICAgY29uc3Qgc3RvcmUgPSBhc3NlcnQoc3RvcmVOYW1lKTtcbiAgICAgIGNvbnN0IHJlY29yZCA9IHZhbHVlIGFzIFJlY29yZDxzdHJpbmcsIHVua25vd24+O1xuICAgICAgY29uc3Qga2V5UGF0aCA9IHN0b3JlLnNjaGVtYS5rZXlQYXRoO1xuICAgICAgbGV0IGtleSA9IGtleVBhdGggPT09IHVuZGVmaW5lZCA/IHVuZGVmaW5lZCA6IGtleUZyb21QYXRoKHJlY29yZCwga2V5UGF0aCk7XG5cbiAgICAgIGlmIChrZXkgPT09IHVuZGVmaW5lZCkge1xuICAgICAgICBpZiAoa2V5UGF0aCAhPT0gdW5kZWZpbmVkICYmIHN0b3JlLnNjaGVtYS5hdXRvSW5jcmVtZW50ICE9PSB0cnVlKSB7XG4gICAgICAgICAgdGhyb3cgbmV3IEVycm9yKGBzdG9yZeOAjCR7c3RvcmVOYW1lfeOAjeeahOiusOW9lee8uuWwkeS4u+mUruWtl+auteOAjCR7U3RyaW5nKGtleVBhdGgpfeOAjWApO1xuICAgICAgICB9XG4gICAgICAgIGtleSA9ICsrc3RvcmUuYXV0b0luY3JlbWVudDtcbiAgICAgICAgLy8g6Ieq5aKe5pe25oqK6ZSu5YaZ5Zue6K6w5b2V77yM5LiOIEluZGV4ZWREQiDnmoQgaW4tbGluZSBrZXkg6KGM5Li65LiA6Ie0XG4gICAgICAgIGlmIChrZXlQYXRoICE9PSB1bmRlZmluZWQpIHtcbiAgICAgICAgICBjb25zdCBwYXRoID0gdHlwZW9mIGtleVBhdGggPT09ICdzdHJpbmcnID8ga2V5UGF0aCA6IGtleVBhdGhbMF07XG4gICAgICAgICAgaWYgKHBhdGggIT09IHVuZGVmaW5lZCkgcmVjb3JkW3BhdGhdID0ga2V5O1xuICAgICAgICB9XG4gICAgICB9IGVsc2UgaWYgKHR5cGVvZiBrZXkgPT09ICdudW1iZXInICYmIGtleSA+IHN0b3JlLmF1dG9JbmNyZW1lbnQpIHtcbiAgICAgICAgc3RvcmUuYXV0b0luY3JlbWVudCA9IGtleTtcbiAgICAgIH1cblxuICAgICAgLy8g8J+UtCDllK/kuIDntKLlvJXlhrLnqoHopoEqKumYu+atouaVtOadoeiusOW9leWFpeW6kyoq77yM5LiN5pivXCLot7Pov4fntKLlvJXkvYbnlZnkuIvorrDlvZVcIuOAglxuICAgICAgLy8gYGFkZFRvbGVyYXRpbmdEdXBsaWNhdGVgIOS+nei1lui/meS4quihjOS4uuWBmuW5guetieWOu+mHjeOAglxuICAgICAgZm9yIChjb25zdCBpZHggb2Ygc3RvcmUuc2NoZW1hLmluZGV4ZXMgPz8gW10pIHtcbiAgICAgICAgaWYgKGlkeC51bmlxdWUgIT09IHRydWUpIGNvbnRpbnVlO1xuICAgICAgICBmb3IgKGNvbnN0IGVudHJ5IG9mIGluZGV4RW50cmllcyhzdG9yZSwgaWR4LCByZWNvcmQpKSB7XG4gICAgICAgICAgZm9yIChjb25zdCBleGlzdGluZyBvZiBzdG9yZS5yZWNvcmRzLnZhbHVlcygpKSB7XG4gICAgICAgICAgICBpZiAoZXhpc3Rpbmcua2V5ID09PSBrZXkpIGNvbnRpbnVlO1xuICAgICAgICAgICAgZm9yIChjb25zdCBvdGhlckVudHJ5IG9mIGluZGV4RW50cmllcyhzdG9yZSwgaWR4LCBleGlzdGluZy52YWx1ZSkpIHtcbiAgICAgICAgICAgICAgaWYgKGNvbXBhcmVLZXlzKGVudHJ5LCBvdGhlckVudHJ5KSA9PT0gMCkge1xuICAgICAgICAgICAgICAgIHRocm93IG5ldyBEdXBsaWNhdGVLZXlFcnJvcihpZHgubmFtZSk7XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgIH1cblxuICAgICAgaWYgKHN0b3JlLnJlY29yZHMuaGFzKHNlcmlhbGl6ZUtleShrZXkpKSkge1xuICAgICAgICB0aHJvdyBuZXcgRHVwbGljYXRlS2V5RXJyb3IoU3RyaW5nKGtleVBhdGggPz8gJ+S4u+mUricpKTtcbiAgICAgIH1cbiAgICAgIHN0b3JlLnJlY29yZHMuc2V0KHNlcmlhbGl6ZUtleShrZXkpLCB7IGtleSwgdmFsdWU6IHJlY29yZCB9KTtcbiAgICAgIHJldHVybiB7IGtleTogdHlwZW9mIGtleSA9PT0gJ251bWJlcicgPyBrZXkgOiAwIH07XG4gICAgfTtcblxuICAgIHJldHVybiB7XG4gICAgICBhZGQ6IGFzeW5jIChzdG9yZU5hbWUsIHZhbHVlKSA9PiB7XG4gICAgICAgIGNvbnN0IHsga2V5IH0gPSBpbnNlcnQoc3RvcmVOYW1lLCB2YWx1ZSk7XG4gICAgICAgIHJldHVybiBrZXk7XG4gICAgICB9LFxuXG4gICAgICAvKipcbiAgICAgICAqIOWuueW/jeWUr+S4gOWGsueqgeeahOaPkuWFpeOAglxuICAgICAgICpcbiAgICAgICAqIOivreS5ieS4jiBJbmRleGVkREIg5a6e546w5LiA6Ie077ya5Yay56qB5pe2KirkuI3mipvplJkqKu+8jOiAjOaYr+aKpeWRiiBgZHVwbGljYXRlYO+8jFxuICAgICAgICog5LiUKirorrDlvZXkuI3lhaXlupMqKuOAgeS6i+WKoee7p+e7reOAgm9wLWxvZyDnmoTluYLnrYnljrvph43lrozlhajpnaDov5nkuKrooYzkuLog4oCU4oCUXG4gICAgICAgKiDlkIzkuIDkuKogb3BJZCDooqvph43lpI3mipXpgJLmmK/mraPluLjot6/lvoTvvIjlkIzmraXkvJrph43mlL7vvInvvIzkuI3mmK/lvILluLjjgIJcbiAgICAgICAqL1xuICAgICAgYWRkVG9sZXJhdGluZ0R1cGxpY2F0ZTogYXN5bmMgKHN0b3JlTmFtZSwgdmFsdWUpID0+IHtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICBjb25zdCB7IGtleSB9ID0gaW5zZXJ0KHN0b3JlTmFtZSwgdmFsdWUpO1xuICAgICAgICAgIHJldHVybiB7IG9rOiB0cnVlIGFzIGNvbnN0LCBrZXkgfTtcbiAgICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgICBpZiAoZXJyb3IgaW5zdGFuY2VvZiBEdXBsaWNhdGVLZXlFcnJvcikge1xuICAgICAgICAgICAgcmV0dXJuIHsgb2s6IGZhbHNlIGFzIGNvbnN0LCByZWFzb246ICdkdXBsaWNhdGUnIGFzIGNvbnN0IH07XG4gICAgICAgICAgfVxuICAgICAgICAgIHRocm93IGVycm9yO1xuICAgICAgICB9XG4gICAgICB9LFxuICAgICAgcHV0OiBhc3luYyAoc3RvcmVOYW1lLCB2YWx1ZSwgZXhwbGljaXRLZXkpID0+IHtcbiAgICAgICAgY29uc3Qgc3RvcmUgPSBhc3NlcnQoc3RvcmVOYW1lKTtcbiAgICAgICAgY29uc3QgcmVjb3JkID0gdmFsdWUgYXMgUmVjb3JkPHN0cmluZywgdW5rbm93bj47XG4gICAgICAgIGNvbnN0IGtleVBhdGggPSBzdG9yZS5zY2hlbWEua2V5UGF0aDtcbiAgICAgICAgY29uc3Qga2V5ID0gZXhwbGljaXRLZXkgPz8gKGtleVBhdGggPT09IHVuZGVmaW5lZCA/IHVuZGVmaW5lZCA6IGtleUZyb21QYXRoKHJlY29yZCwga2V5UGF0aCkpO1xuICAgICAgICBpZiAoa2V5ID09PSB1bmRlZmluZWQpIHtcbiAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoYHN0b3Jl44CMJHtzdG9yZU5hbWV944CN55qEIHB1dCDnvLrlsJHkuLvplK5gKTtcbiAgICAgICAgfVxuICAgICAgICBzdG9yZS5yZWNvcmRzLnNldChzZXJpYWxpemVLZXkoa2V5KSwgeyBrZXksIHZhbHVlOiByZWNvcmQgfSk7XG4gICAgICB9LFxuXG4gICAgICBnZXQ6IGFzeW5jIDxULD4oc3RvcmVOYW1lOiBzdHJpbmcsIGtleTogRGJLZXkpID0+IHtcbiAgICAgICAgY29uc3Qgc3RvcmUgPSBhc3NlcnQoc3RvcmVOYW1lKTtcbiAgICAgICAgcmV0dXJuIHN0b3JlLnJlY29yZHMuZ2V0KHNlcmlhbGl6ZUtleShrZXkpKT8udmFsdWUgYXMgVCB8IHVuZGVmaW5lZDtcbiAgICAgIH0sXG5cbiAgICAgIGdldEFsbDogYXN5bmMgPFQsPihzdG9yZU5hbWU6IHN0cmluZywgcmFuZ2U/OiBEYktleVJhbmdlLCBsaW1pdD86IG51bWJlcikgPT4ge1xuICAgICAgICBhc3NlcnRJdGVyYXRlTGltaXQobGltaXQpO1xuICAgICAgICBjb25zdCBzdG9yZSA9IGFzc2VydChzdG9yZU5hbWUpO1xuICAgICAgICByZXR1cm4gc29ydGVkUmVjb3JkcyhzdG9yZSlcbiAgICAgICAgICAuZmlsdGVyKChyKSA9PiBpblJhbmdlKHIua2V5LCByYW5nZSkpXG4gICAgICAgICAgLnNsaWNlKDAsIGxpbWl0KVxuICAgICAgICAgIC5tYXAoKHIpID0+IHIudmFsdWUgYXMgVCk7XG4gICAgICB9LFxuXG4gICAgICBkZWxldGU6IGFzeW5jIChzdG9yZU5hbWUsIGtleSkgPT4ge1xuICAgICAgICBjb25zdCBzdG9yZSA9IGFzc2VydChzdG9yZU5hbWUpO1xuICAgICAgICBzdG9yZS5yZWNvcmRzLmRlbGV0ZShzZXJpYWxpemVLZXkoa2V5KSk7XG4gICAgICB9LFxuXG4gICAgICBjbGVhcjogYXN5bmMgKHN0b3JlTmFtZSkgPT4ge1xuICAgICAgICBjb25zdCBzdG9yZSA9IGFzc2VydChzdG9yZU5hbWUpO1xuICAgICAgICBzdG9yZS5yZWNvcmRzLmNsZWFyKCk7XG4gICAgICB9LFxuXG4gICAgICBjb3VudDogYXN5bmMgKHN0b3JlTmFtZSwgcmFuZ2U/OiBEYktleVJhbmdlKSA9PiB7XG4gICAgICAgIGNvbnN0IHN0b3JlID0gYXNzZXJ0KHN0b3JlTmFtZSk7XG4gICAgICAgIHJldHVybiBbLi4uc3RvcmUucmVjb3Jkcy52YWx1ZXMoKV0uZmlsdGVyKChyKSA9PiBpblJhbmdlKHIua2V5LCByYW5nZSkpLmxlbmd0aDtcbiAgICAgIH0sXG5cbiAgICAgIGdldEZyb21JbmRleDogYXN5bmMgPFQsPihzdG9yZU5hbWU6IHN0cmluZywgaW5kZXhOYW1lOiBzdHJpbmcsIGtleTogRGJLZXkgfCBEYktleVtdKSA9PiB7XG4gICAgICAgIGNvbnN0IHN0b3JlID0gYXNzZXJ0KHN0b3JlTmFtZSk7XG4gICAgICAgIGNvbnN0IGlkeCA9IGZpbmRJbmRleChzdG9yZSwgaW5kZXhOYW1lKTtcbiAgICAgICAgZm9yIChjb25zdCByIG9mIHNvcnRlZFJlY29yZHMoc3RvcmUpKSB7XG4gICAgICAgICAgZm9yIChjb25zdCBlbnRyeSBvZiBpbmRleEVudHJpZXMoc3RvcmUsIGlkeCwgci52YWx1ZSkpIHtcbiAgICAgICAgICAgIGlmIChjb21wYXJlS2V5cyhlbnRyeSwga2V5KSA9PT0gMCkgcmV0dXJuIHIudmFsdWUgYXMgVDtcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHVuZGVmaW5lZDtcbiAgICAgIH0sXG5cbiAgICAgIGdldEtleUZyb21JbmRleDogYXN5bmMgKHN0b3JlTmFtZSwgaW5kZXhOYW1lLCBrZXkpID0+IHtcbiAgICAgICAgY29uc3Qgc3RvcmUgPSBhc3NlcnQoc3RvcmVOYW1lKTtcbiAgICAgICAgY29uc3QgaWR4ID0gZmluZEluZGV4KHN0b3JlLCBpbmRleE5hbWUpO1xuICAgICAgICBmb3IgKGNvbnN0IHIgb2Ygc29ydGVkUmVjb3JkcyhzdG9yZSkpIHtcbiAgICAgICAgICBmb3IgKGNvbnN0IGVudHJ5IG9mIGluZGV4RW50cmllcyhzdG9yZSwgaWR4LCByLnZhbHVlKSkge1xuICAgICAgICAgICAgaWYgKGNvbXBhcmVLZXlzKGVudHJ5LCBrZXkpID09PSAwKSB7XG4gICAgICAgICAgICAgIC8vIOKaoO+4jyDlpI3lkIjkuLvplK7nmoQgc3RvcmUg6L+Z6YeM5a6e6ZmF5piv5pWw57uE77yM6ICMIGBEYkFkYXB0ZXJgIOWPquWjsOaYjuS6hlxuICAgICAgICAgICAgICAvLyBgRGJLZXlg44CC5o6l5Y+j5Zyo6L+Z5LiA5aSE5q+UIEluZGV4ZWREQiDnmoTnnJ/lrp7ooYzkuLrnqoQg4oCU4oCUIOS4jeaJqeWkp+Wug++8jFxuICAgICAgICAgICAgICAvLyDlm6DkuLrnjrDmnInosIPnlKjmlrnvvIhtZXRhL29wc++8iemDveeUqOWNlemUru+8m+WcqOi/memHjOaYvuW8j+agh+azqOi/meS4quW3suefpeiQveW3ruOAglxuICAgICAgICAgICAgICByZXR1cm4gci5rZXkgYXMgRGJLZXk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIHJldHVybiB1bmRlZmluZWQ7XG4gICAgICB9LFxuXG4gICAgICBnZXRBbGxGcm9tSW5kZXg6IGFzeW5jIDxULD4oc3RvcmVOYW1lOiBzdHJpbmcsIGluZGV4TmFtZTogc3RyaW5nLCBxdWVyeT86IERiSW5kZXhRdWVyeSkgPT4ge1xuICAgICAgICBjb25zdCBzdG9yZSA9IGFzc2VydChzdG9yZU5hbWUpO1xuICAgICAgICBjb25zdCBpZHggPSBmaW5kSW5kZXgoc3RvcmUsIGluZGV4TmFtZSk7XG4gICAgICAgIGNvbnN0IG91dDogVFtdID0gW107XG4gICAgICAgIGZvciAoY29uc3QgciBvZiBzb3J0ZWRSZWNvcmRzKHN0b3JlKSkge1xuICAgICAgICAgIGZvciAoY29uc3QgZW50cnkgb2YgaW5kZXhFbnRyaWVzKHN0b3JlLCBpZHgsIHIudmFsdWUpKSB7XG4gICAgICAgICAgICBpZiAobWF0Y2hlc0luZGV4UXVlcnkoZW50cnksIHF1ZXJ5KSkge1xuICAgICAgICAgICAgICBvdXQucHVzaChyLnZhbHVlIGFzIFQpO1xuICAgICAgICAgICAgICBicmVhazsgLy8gbXVsdGlFbnRyeSDlkIzkuIDmnaHorrDlvZXlj6rlupTlh7rnjrDkuIDmrKFcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIG91dDtcbiAgICAgIH0sXG5cbiAgICAgIGNvdW50RnJvbUluZGV4OiBhc3luYyAoc3RvcmVOYW1lLCBpbmRleE5hbWUsIHF1ZXJ5PzogRGJJbmRleFF1ZXJ5KSA9PiB7XG4gICAgICAgIGNvbnN0IHN0b3JlID0gYXNzZXJ0KHN0b3JlTmFtZSk7XG4gICAgICAgIGNvbnN0IGlkeCA9IGZpbmRJbmRleChzdG9yZSwgaW5kZXhOYW1lKTtcbiAgICAgICAgbGV0IG4gPSAwO1xuICAgICAgICBmb3IgKGNvbnN0IHIgb2Ygc29ydGVkUmVjb3JkcyhzdG9yZSkpIHtcbiAgICAgICAgICBmb3IgKGNvbnN0IGVudHJ5IG9mIGluZGV4RW50cmllcyhzdG9yZSwgaWR4LCByLnZhbHVlKSkge1xuICAgICAgICAgICAgaWYgKG1hdGNoZXNJbmRleFF1ZXJ5KGVudHJ5LCBxdWVyeSkpIHtcbiAgICAgICAgICAgICAgbisrO1xuICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIG47XG4gICAgICB9LFxuXG4gICAgICBpdGVyYXRlOiBhc3luYyA8VCw+KHN0b3JlTmFtZTogc3RyaW5nLCBvcHRpb25zOiBEYkl0ZXJhdGVPcHRpb25zLCB2aXNpdDogRGJDdXJzb3JWaXNpdG9yPFQ+KSA9PiB7XG4gICAgICAgIGNvbnN0IHN0b3JlID0gYXNzZXJ0KHN0b3JlTmFtZSk7XG5cbiAgICAgICAgLy8g5LiOIEluZGV4ZWREQiDlrp7njrDkuIDoh7TvvJrpnZ7ms5UgbGltaXQg56uL5Yi754K477yM5LiN6KaB562J5a6D5omr5YWo6KGo5oqK56e75Yqo56uv5Y2h5q27XG4gICAgICAgIGFzc2VydEl0ZXJhdGVMaW1pdChvcHRpb25zLmxpbWl0KTtcblxuICAgICAgICBjb25zdCB7IGRpcmVjdGlvbiA9ICduZXh0JywgbG93ZXIsIHVwcGVyLCBsaW1pdCwgaW5kZXggfSA9IG9wdGlvbnM7XG4gICAgICAgIGxldCBjYW5kaWRhdGVzOiBQaHlzaWNhbFJlY29yZFtdO1xuXG4gICAgICAgIGlmIChpbmRleCA9PT0gdW5kZWZpbmVkKSB7XG4gICAgICAgICAgY2FuZGlkYXRlcyA9IHNvcnRlZFJlY29yZHMoc3RvcmUpLmZpbHRlcigocikgPT4gaW5SYW5nZShyLmtleSwgeyBsb3dlciwgdXBwZXIgfSkpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIGNvbnN0IGlkeCA9IGZpbmRJbmRleChzdG9yZSwgaW5kZXgpO1xuICAgICAgICAgIGNhbmRpZGF0ZXMgPSBzb3J0ZWRSZWNvcmRzKHN0b3JlKS5maWx0ZXIoKHIpID0+XG4gICAgICAgICAgICBpbmRleEVudHJpZXMoc3RvcmUsIGlkeCwgci52YWx1ZSkuc29tZSgoZW50cnkpID0+IGluUmFuZ2UoZW50cnksIHsgbG93ZXIsIHVwcGVyIH0pKSxcbiAgICAgICAgICApO1xuICAgICAgICB9XG5cbiAgICAgICAgaWYgKGRpcmVjdGlvbiA9PT0gJ3ByZXYnKSBjYW5kaWRhdGVzLnJldmVyc2UoKTtcblxuICAgICAgICBjb25zdCBjYXAgPSBsaW1pdCA/PyBERUZBVUxUX0lURVJBVEVfTElNSVQ7XG4gICAgICAgIGxldCB2aXNpdGVkID0gMDtcbiAgICAgICAgZm9yIChjb25zdCByZWNvcmQgb2YgY2FuZGlkYXRlcykge1xuICAgICAgICAgIGlmICh2aXNpdGVkID49IGNhcCkgYnJlYWs7XG4gICAgICAgICAgdmlzaXRlZCsrO1xuICAgICAgICAgIGNvbnN0IGFjdGlvbiA9IHZpc2l0KHJlY29yZC52YWx1ZSBhcyBULCByZWNvcmQua2V5IGFzIERiS2V5KTtcbiAgICAgICAgICBpZiAoYXBwbHlBY3Rpb24oYWN0aW9uLCByZWNvcmQsIHN0b3JlKSA9PT0gJ3N0b3AnKSBicmVhaztcbiAgICAgICAgfVxuICAgICAgfSxcbiAgICB9O1xuICB9XG59XG4iLCIvKipcbiAqIOaTjeS9nOaXpeW/l+WtmOWCqO+8iCoq6YCC6YWN5Zmo5peg5YWzKirvvIlcbiAqID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxuICpcbiAqIOWunueOsCB7QGxpbmsgT3BMb2dTdG9yZX3jgILov5nmmK/lkIzmraXns7vnu5/nmoTmnKzlnLDkuovlrp7mnaXmupDjgIJcbiAqXG4gKiDwn5S0ICoq5a6D5LiN5bGe5LqOIEluZGV4ZWREQuOAgioqXG4gKlxuICog5a6D5Y6f5pys5Y+rIGBJbmRleGVkRGJPcExvZ1N0b3JlYCDlubbmlL7lnKggYGluZGV4ZWRkYi9gIOS4iyDigJTigJQg5L2G5a6e5rWL5a6DXG4gKiAqKuS4gOihjCBJbmRleGVkREIgQVBJIOmDveayoeeUqCoq77yM5Y+q5L6d6LWWIGBEYkFkYXB0ZXJgIC8gYERiVHhgIC8gYERiS2V5UmFuZ2Vg44CCXG4gKiDlkI3lrZflkoznm67lvZXlnKjmkpLosI7vvIzogIzku6Pku7fmmK/lrp7otKjnmoTvvJrku7vkvZXnnIvku6PnoIHnmoTkurrpg73kvJrku6XkuLrmjaLliLAgU1FMaXRlXG4gKiDpnIDopoEqKuWGjeWGmeS4gOS4qiBvcC1sb2cgc3RvcmUqKu+8jOS6juaYr+ecn+eahOWOu+WGmeesrOS6jOS4quWunueOsCDigJTigJRcbiAqIOiAjOS4pOS7veWQjOatpemAu+i+keWunueOsOS4jeWPr+iDveS/neaMgeS4gOiHtO+8jOmCo+etieS6juaVsOaNruaNn+Wdj++8iEFEUi0wMDAzIMKnMy4z77yJ44CCXG4gKlxuICog546w5Zyo5a6D5oyJ55yf5a6e6IO95Yqb5ZG95ZCN5LiO5L2N572u5pS+572u77yaKirmjaLku7vkvZUgYERiQWRhcHRlcmAg5a6e546w77yMb3AtbG9nIOWxgumbtuaUueWKqOOAgioqXG4gKiDov5nmmK8gQURSLTAwMDPjgIzlkIzkuIDlpZfmjqXlj6PjgIHlkIzkuIDlpZfmtYvor5XjgI3mnIDnm7TmjqXnmoTkvZPnjrDjgIJcbiAqXG4gKiDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcbiAqIOS4pOS4quS4jeiDveWmpeWNj+eahOato+ehruaAp+imgeaxgu+8mlxuICpcbiAqIDEuICoqYGFwcGVuZEJhdGNoU2tpcER1cGxpY2F0ZXNgIOW/hemhu+WOn+WtkOS4lOW5guetieOAgioqXG4gKiAgICDlkIzkuIDmibnph4zph43lpI3nmoQgb3BJZCDlkoxcIuW6k+mHjOW3suWtmOWcqOeahCBvcElkXCLpg73lv4Xpobvooqvot7Pov4fjgIJcbiAqICAgIOWunueOsOaWueW8j++8mumdoCBvcElkIOeahCoq5ZSv5LiA57Si5byVKiogKyDmjZXojrcgQ29uc3RyYWludEVycm9y77yMXG4gKiAgICAqKuS4jeaYryoq5YWIIGdldEFsbCDlho3liKTmlq0g4oCU4oCUIOmCo+aciSBUT0NUT1Ug56ue5oCB77ya5Lik5Liq5bm25Y+R5om55qyhXG4gKiAgICDpg73kvJrmn6XliLBcIuS4jeWtmOWcqFwi77yM54S25ZCO6YO95bCd6K+V5YaZ5YWl44CCXG4gKlxuICogMi4gKipzZXEg5b+F6aG75peg56m65rSe44CCKipcbiAqICAgIHNlcSDmmK/lkIzmraXmuLjmoIfnmoTln7rnoYDjgILoi6XmnInnqbrmtJ7vvIjmr5TlpoLlpLHotKXlm57mu5rnlZnkuIsgNSDljbTlhpnkuoYgNu+8ie+8jFxuICogICAg5aKe6YeP5ZCM5q2l5Lya5rC45LmF5ryP5o6J5Lit6Ze055qE5pON5L2cIOKAlOKAlCAqKumdmem7mOS4ouaVsOaNrioq44CCXG4gKiAgICDlm6DmraTlhpkgb3BzIOS4juabtOaWsCBgbGFzdExvY2FsU2VxYCDlv4XpobvlnKgqKuWQjOS4gOS4quS6i+WKoSoq6YeM44CCXG4gKiDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcbiAqL1xuXG5pbXBvcnQgdHlwZSB7XG4gIE9wZXJhdGlvbixcbiAgUmVtb3RlT3BlcmF0aW9uQXBwbHlTdG9yZVBvcnQsXG59IGZyb20gJ0BoZXl0YS9zeW5jLWNvcmUnO1xuaW1wb3J0IHR5cGUgeyBFbnRpdHlUeXBlIH0gZnJvbSAnQGhleXRhL3NoYXJlZC1zY2hlbWEnO1xuXG5pbXBvcnQgdHlwZSB7IERiQWRhcHRlciwgRGJLZXlSYW5nZSwgRGJUeCB9IGZyb20gJy4vZGIudHlwZXMuanMnO1xuaW1wb3J0IHtcbiAgT3BMb2dTdG9yZUVycm9yLFxuICBPcExvZ1N0b3JlRXJyb3JDb2RlLFxuICB0eXBlIEltcG9ydGVkQXBwZW5kUmVzdWx0LFxuICB0eXBlIE1hdGVyaWFsaXplZENoZWNrcG9pbnQsXG4gIHR5cGUgT3BMb2dTdG9yZSxcbiAgdHlwZSBPcGVyYXRpb25Tb3VyY2UsXG4gIHR5cGUgU3RvcmVkT3BlcmF0aW9uLFxufSBmcm9tICcuL29wLWxvZy1zdG9yZS5qcyc7XG5pbXBvcnQgeyBpc1ZhbGlkQ2hlY2twb2ludCB9IGZyb20gJy4vY2hlY2twb2ludC5qcyc7XG5pbXBvcnQge1xuICBNRVRBX0ZJRUxEUyxcbiAgTUVUQV9LRVlTLFxuICBPUF9GSUVMRFMsXG4gIE9QX0lOREVYRVMsXG4gIFNUT1JFUyxcbn0gZnJvbSAnLi9zdG9yZXMuanMnO1xuXG5jb25zdCBNQVRFUklBTElaRURfQ0hFQ0tQT0lOVF9LRVkgPSAnbWF0ZXJpYWxpemVkQ2hlY2twb2ludCc7XG5cbi8qKlxuICogYGFwcGVuZEJhdGNoU2tpcER1cGxpY2F0ZXNgIOeahOe7k+aenOexu+Wei+OAglxuICpcbiAqIOKaoO+4jyAqKuS7juerr+WPo+a0vueUn++8jOiAjOS4jeaYr+S7jiBzeW5jLWNvcmUg55u05o6lIGltcG9ydOOAgioqXG4gKiBgUmVtb3RlT3BlcmF0aW9uQXBwZW5kUmVzdWx0YCDlnKggc3luYy1jb3JlIOmHjOaYr+aooeWdl+WGheWjsOaYjuOAgeacquS7juWFpeWPo+WvvOWHulxuICog77yI55u05o6lIGltcG9ydCDkvJrmiqUgVFMyNDU577yJ44CC55SoIFJldHVyblR5cGUg5rS+55Sf6L+Y5pyJ5Liq5aW95aSE77yaXG4gKiDkuIrmuLjmlLnkuobnu5PmnpzlvaLnirbmiJHku6zkvJoqKuiHquWKqOi3n+S4iioq77yM5LiN5Lya5ZCE5YaZ5LiA5Lu96ICM5ryC56e744CCXG4gKi9cbnR5cGUgUmVtb3RlQXBwZW5kUmVzdWx0PFRPcGVyYXRpb24gZXh0ZW5kcyBPcGVyYXRpb248c3RyaW5nPj4gPSBBd2FpdGVkPFxuICBSZXR1cm5UeXBlPFxuICAgIFJlbW90ZU9wZXJhdGlvbkFwcGx5U3RvcmVQb3J0PFRPcGVyYXRpb24+WydhcHBlbmRCYXRjaFNraXBEdXBsaWNhdGVzJ11cbiAgPlxuPjtcblxuLyoqIOS4gOasoSBhcHBlbmRCYXRjaCDnmoTmnKzlnLDnu5PmnpzjgIIgKi9cbmV4cG9ydCBpbnRlcmZhY2UgQXBwZW5kQmF0Y2hSZXN1bHQ8VE9wZXJhdGlvbiBleHRlbmRzIE9wZXJhdGlvbjxzdHJpbmc+PiB7XG4gIGFwcGVuZGVkOiBUT3BlcmF0aW9uW107XG4gIHNraXBwZWQ6IFRPcGVyYXRpb25bXTtcbiAgc2VxczogbnVtYmVyW107XG59XG5cbmV4cG9ydCBjbGFzcyBEYk9wTG9nU3RvcmU8VE9wZXJhdGlvbiBleHRlbmRzIE9wZXJhdGlvbjxzdHJpbmc+ID0gT3BlcmF0aW9uPlxuICBpbXBsZW1lbnRzIE9wTG9nU3RvcmU8VE9wZXJhdGlvbj5cbntcbiAgY29uc3RydWN0b3IoXG4gICAgcHJpdmF0ZSByZWFkb25seSBkYjogRGJBZGFwdGVyLFxuICAgIC8qKiDljovnvKnpmIjlgLzvvJrlvZLmoaPml7bkv53nlZnlpJrlsJHkuKrmnIDov5Egb3Ag5Zyo54Ot5Yy644CCICovXG4gICAgcHJpdmF0ZSByZWFkb25seSBhcmNoaXZlS2VlcFJlY2VudCA9IDUwMCxcbiAgKSB7fVxuXG4gIC8vIOKUgOKUgCDlhpnlhaUg4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG5cbiAgYXN5bmMgYXBwZW5kTG9jYWwob3BzOiBUT3BlcmF0aW9uW10pOiBQcm9taXNlPG51bWJlcltdPiB7XG4gICAgY29uc3QgcmVzdWx0ID0gYXdhaXQgdGhpcy5hcHBlbmRCYXRjaChvcHMsICdsb2NhbCcsIHt9KTtcbiAgICByZXR1cm4gcmVzdWx0LnNlcXM7XG4gIH1cblxuICAvKipcbiAgICog6L+95Yqg5a+85YWl55qEIG9w44CCXG4gICAqXG4gICAqIGBhcHBlbmRCYXRjaGAg6YeMIGB1cGxvYWRTdGF0dXNgIOeahOinhOWImeaYryBgc291cmNlID09PSAnbG9jYWwnID8gJ3BlbmRpbmcnIDogJ3VwbG9hZGVkJ2DvvIxcbiAgICog5omA5Lul6L+Z6YeM5aSp54S25b6X5YiwXCLkuI3ov5vkuIrkvKDpmJ/liJdcIuKAlOKAlCoq6L+Z5q2j5piv5oOz6KaB55qEKirvvIznkIbnlLHop4HmjqXlj6Pms6jph4pcbiAgICog77yI5a+85YWl55qEIG9wIOW4puedgOWIq+eahOiuvuWkh+eahCBgY2xpZW50SWRg77yM5LiK5Lyg5Lya6KKr5pyN5Yqh56uv6YCQ5p2hIGBJTlZBTElEX0NMSUVOVF9JRGAg5ouS57ud77yJ44CCXG4gICAqIOS4jeimgeS4uuS6hlwi6K6p5a6D5Lmf6IO95LiK5LygXCLmioogc291cmNlIOaUueaIkCAnbG9jYWwn44CCXG4gICAqL1xuICBhc3luYyBhcHBlbmRJbXBvcnRlZChvcHM6IFRPcGVyYXRpb25bXSk6IFByb21pc2U8SW1wb3J0ZWRBcHBlbmRSZXN1bHQ8VE9wZXJhdGlvbj4+IHtcbiAgICBjb25zdCByZXN1bHQgPSBhd2FpdCB0aGlzLmFwcGVuZEJhdGNoKG9wcywgJ2ltcG9ydCcsIHt9KTtcbiAgICByZXR1cm4geyBhcHBlbmRlZDogcmVzdWx0LmFwcGVuZGVkLCBza2lwcGVkOiByZXN1bHQuc2tpcHBlZCwgc2VxczogcmVzdWx0LnNlcXMgfTtcbiAgfVxuXG4gIGFzeW5jIGFwcGVuZEJhdGNoU2tpcER1cGxpY2F0ZXMoXG4gICAgb3BzOiBUT3BlcmF0aW9uW10sXG4gICAgc291cmNlOiAncmVtb3RlJyxcbiAgICBvcHRpb25zOiB7IHBlbmRpbmdBcHBseTogdHJ1ZSB9LFxuICApOiBQcm9taXNlPFJlbW90ZUFwcGVuZFJlc3VsdDxUT3BlcmF0aW9uPj4ge1xuICAgIGNvbnN0IHJlc3VsdCA9IGF3YWl0IHRoaXMuYXBwZW5kQmF0Y2gob3BzLCBzb3VyY2UsIHtcbiAgICAgIHBlbmRpbmdBcHBseTogb3B0aW9ucy5wZW5kaW5nQXBwbHksXG4gICAgfSk7XG4gICAgLy8g4pqg77iPIOWtl+auteWQjeW/hemhu+aYryB3cml0dGVuT3Bz77yM5LiN5pivIGFwcGVuZGVkT3BzIOKAlOKAlFxuICAgIC8vIOi/meaYryBzeW5jLWNvcmUg5a6a5LmJ55qE57uT5p6c5aWR57qm77yM5YaZ6ZSZ57yW6K+R5bCx6L+H5LiN5Y6744CCXG4gICAgcmV0dXJuIHtcbiAgICAgIHdyaXR0ZW5PcHM6IHJlc3VsdC5hcHBlbmRlZCxcbiAgICAgIHNraXBwZWRDb3VudDogcmVzdWx0LnNraXBwZWQubGVuZ3RoLFxuICAgICAgc2VxczogcmVzdWx0LnNlcXMsXG4gICAgfTtcbiAgfVxuXG4gIC8qKlxuICAgKiDnu5/kuIDlhpnlhaXot6/lvoTjgIJcbiAgICpcbiAgICog4pqg77iPIOaVtOaJueWcqCoq5LiA5Liq5LqL5YqhKirph4zlrozmiJDvvJropoHkuYjlhajlhpnvvIzopoHkuYjlhajkuI3lhpnjgIJcbiAgICog5YiG5om55YaZ5Lya5Zyo5Lit6YCU5aSx6LSl5pe255WZ5LiLXCLlj6rlhpnkuobkuIDljYpcIueahOeKtuaAge+8jOiAjOW0qea6g+aBouWkjeaXoOazleWMuuWIhlxuICAgKiBcIui/meaJueacrOadpeWwseWPquaciei/meS6m1wi6L+Y5pivXCLlhpnliLDkuIDljYrngrjkuoZcIuOAglxuICAgKi9cbiAgcHJpdmF0ZSBhc3luYyBhcHBlbmRCYXRjaChcbiAgICBvcHM6IFRPcGVyYXRpb25bXSxcbiAgICBzb3VyY2U6IE9wZXJhdGlvblNvdXJjZSxcbiAgICBmbGFnczogeyBwZW5kaW5nQXBwbHk/OiBib29sZWFuIH0sXG4gICk6IFByb21pc2U8QXBwZW5kQmF0Y2hSZXN1bHQ8VE9wZXJhdGlvbj4+IHtcbiAgICBpZiAob3BzLmxlbmd0aCA9PT0gMCkgcmV0dXJuIHsgYXBwZW5kZWQ6IFtdLCBza2lwcGVkOiBbXSwgc2VxczogW10gfTtcblxuICAgIHJldHVybiB0aGlzLmRiLnRyYW5zYWN0aW9uKFxuICAgICAgW1NUT1JFUy5PUFMsIFNUT1JFUy5BUkNISVZFLCBTVE9SRVMuTUVUQV0sXG4gICAgICAncmVhZHdyaXRlJyxcbiAgICAgIGFzeW5jICh0eCkgPT4ge1xuICAgICAgICBjb25zdCBhcHBlbmRlZDogVE9wZXJhdGlvbltdID0gW107XG4gICAgICAgIGNvbnN0IHNraXBwZWQ6IFRPcGVyYXRpb25bXSA9IFtdO1xuICAgICAgICBjb25zdCBzZXFzOiBudW1iZXJbXSA9IFtdO1xuICAgICAgICAvLyDmibnlhoXljrvph43vvJrlkIzkuIDmibnph4zlh7rnjrDkuKTmrKHnmoQgb3BJZCDlj6rnrpfkuIDmrKFcbiAgICAgICAgY29uc3Qgc2VlbkluQmF0Y2ggPSBuZXcgU2V0PHN0cmluZz4oKTtcblxuICAgICAgICBmb3IgKGNvbnN0IG9wIG9mIG9wcykge1xuICAgICAgICAgIGlmIChzZWVuSW5CYXRjaC5oYXMob3AuaWQpKSB7XG4gICAgICAgICAgICBza2lwcGVkLnB1c2gob3ApO1xuICAgICAgICAgICAgY29udGludWU7XG4gICAgICAgICAgfVxuICAgICAgICAgIHNlZW5JbkJhdGNoLmFkZChvcC5pZCk7XG4gICAgICAgICAgLy8gQm90aCBzdG9yZXMgc2hhcmUgb25lIGxvZ2ljYWwgb3BJZCBuYW1lc3BhY2UuIExvY2tpbmcgdGhlbSBpbiB0aGVcbiAgICAgICAgICAvLyBzYW1lIHRyYW5zYWN0aW9uIG1ha2VzIHRoaXMgY2hlY2sgYXRvbWljIHdpdGggY29uY3VycmVudCBhcmNoaXZpbmcuXG4gICAgICAgICAgaWYgKGF3YWl0IHR4LmdldEtleUZyb21JbmRleChTVE9SRVMuQVJDSElWRSwgT1BfSU5ERVhFUy5PUF9JRCwgb3AuaWQpICE9PSB1bmRlZmluZWQpIHtcbiAgICAgICAgICAgIHNraXBwZWQucHVzaChvcCk7XG4gICAgICAgICAgICBjb250aW51ZTtcbiAgICAgICAgICB9XG5cbiAgICAgICAgICBjb25zdCByZWNvcmQ6IE9taXQ8U3RvcmVkT3BlcmF0aW9uPFRPcGVyYXRpb24+LCAnc2VxJz4gPSB7XG4gICAgICAgICAgICBvcCxcbiAgICAgICAgICAgIHNvdXJjZSxcbiAgICAgICAgICAgIC8vIOWtl+espuS4suiAjOS4jeaYr+W4g+WwlCDigJTigJQgSW5kZXhlZERCIOS4jeiDvee0ouW8leW4g+WwlO+8iOingSBzdG9yZXMudHPvvIlcbiAgICAgICAgICAgIGFwcGx5U3RhdHVzOiBmbGFncy5wZW5kaW5nQXBwbHkgPT09IHRydWUgPyAncGVuZGluZycgOiAnYXBwbGllZCcsXG4gICAgICAgICAgICAvLyDmnKzlnLAgb3Ag562J5b6F5LiK5Lyg77yb6L+c56iLIG9wIOaIkeS7rOacrOadpeWwseaUtuWIsOS6hu+8jOaXoOmcgOS4iuS8oOOAglxuICAgICAgICAgICAgLy8g5a+85YWl55qEIG9wIOWQjOeQhuS4jei/m+mYn+WIlyDigJTigJQg5a6D55qEIGNsaWVudElkIOWxnuS6juWIq+eahOiuvuWkh++8jOS4iuS8oOW/heiiq+aLku+8iOingSBhcHBlbmRJbXBvcnRlZO+8ieOAglxuICAgICAgICAgICAgdXBsb2FkU3RhdHVzOiBzb3VyY2UgPT09ICdsb2NhbCcgPyAncGVuZGluZycgOiAndXBsb2FkZWQnLFxuICAgICAgICAgIH07XG5cbiAgICAgICAgICAvLyDnlKggYWRkVG9sZXJhdGluZ0R1cGxpY2F0ZSDogIzkuI3mmK8gdHJ5L2NhdGNoIGFkZO+8mlxuICAgICAgICAgIC8vIOWUr+S4gOe0ouW8leWGsueqgeW/hemhu+WcqCoq6YCC6YWN5Zmo5YaF6YOoKiogcHJldmVudERlZmF1bHTvvIxcbiAgICAgICAgICAvLyDlkKbliJnplJnor6/lhpLms6HkvJrkuK3mraLmlbTkuKrkuovliqHvvIzmiormlbTmibnlhpnlhaXpg73lm57mu5rmjonjgIJcbiAgICAgICAgICAvLyDnjrDlnKjov5nmmK/mjqXlj6PkuIrnmoTmraPlvI/og73lipsg4oCU4oCUIOS4jeWGjemcgOimgSBgYXNgIOW8uui9rOOAglxuICAgICAgICAgIC8vIOmCo+S4quW8uui9rOabvue7j+aOqeebluS6hlwi5o6l5Y+j5rKh5pyJ6KGo6L6+5L2/55So6ICF55yf5a6e6ZyA5rGCXCLov5nkuKrkuovlrp7vvJpcbiAgICAgICAgICAvLyDmlrDpgILphY3lmajmjInmjqXlj6Plrp7njrDvvIzlsLHkvJrlnKjov5DooYzml7bmiqUgXCJub3QgYSBmdW5jdGlvblwi44CCXG4gICAgICAgICAgY29uc3Qgb3V0Y29tZSA9IGF3YWl0IHR4LmFkZFRvbGVyYXRpbmdEdXBsaWNhdGUoU1RPUkVTLk9QUywgcmVjb3JkKTtcblxuICAgICAgICAgIGlmICghb3V0Y29tZS5vaykge1xuICAgICAgICAgICAgLy8g5ZSv5LiA57Si5byV5Yay56qBID0g6L+Z5LiqIG9wSWQg5bey57uP5a2Y5Zyo44CC6L+Z5pivKirmraPluLjot6/lvoQqKu+8iOWQjOatpeS8mumHjeWkjeaKlemAku+8iVxuICAgICAgICAgICAgc2tpcHBlZC5wdXNoKG9wKTtcbiAgICAgICAgICAgIGNvbnRpbnVlO1xuICAgICAgICAgIH1cbiAgICAgICAgICBhcHBlbmRlZC5wdXNoKG9wKTtcbiAgICAgICAgICBzZXFzLnB1c2gob3V0Y29tZS5rZXkpO1xuICAgICAgICB9XG5cbiAgICAgICAgLy8g5LiO5YaZIG9wcyDlkIzkuIDkuovliqHmm7TmlrAgbGFzdExvY2FsU2VxIOKAlOKAlCDkv53or4Egc2VxIOS4jua4uOagh+S4jeS8muiEseiKglxuICAgICAgICBpZiAoc2Vxcy5sZW5ndGggPiAwKSB7XG4gICAgICAgICAgY29uc3QgbWF4U2VxID0gTWF0aC5tYXgoLi4uc2Vxcyk7XG4gICAgICAgICAgY29uc3QgY3VycmVudCA9IGF3YWl0IHJlYWRNZXRhTnVtYmVyKHR4LCBNRVRBX0tFWVMuTEFTVF9MT0NBTF9TRVEpO1xuICAgICAgICAgIGlmIChtYXhTZXEgPiBjdXJyZW50KSB7XG4gICAgICAgICAgICBhd2FpdCB3cml0ZU1ldGEodHgsIE1FVEFfS0VZUy5MQVNUX0xPQ0FMX1NFUSwgbWF4U2VxKTtcbiAgICAgICAgICB9XG4gICAgICAgIH1cblxuICAgICAgICByZXR1cm4geyBhcHBlbmRlZCwgc2tpcHBlZCwgc2VxcyB9O1xuICAgICAgfSxcbiAgICApO1xuICB9XG5cbiAgLyoqIOaKiuacrOWcsCBvcCDmoIforrDmiJBcIuW3suW6lOeUqFwi77yI5pys5ZywIG9wIOWGmeWFpeaXtuWwseebtOaOpeagh+S6hu+8jOi/memHjOeUqOS6jumHjeivle+8ieOAgiAqL1xuICBhc3luYyBtYXJrQXBwbGllZChzZXFzOiBudW1iZXJbXSk6IFByb21pc2U8dm9pZD4ge1xuICAgIGlmIChzZXFzLmxlbmd0aCA9PT0gMCkgcmV0dXJuO1xuICAgIGF3YWl0IHRoaXMuZGIudHJhbnNhY3Rpb24oW1NUT1JFUy5PUFNdLCAncmVhZHdyaXRlJywgYXN5bmMgKHR4KSA9PiB7XG4gICAgICBmb3IgKGNvbnN0IHNlcSBvZiBzZXFzKSB7XG4gICAgICAgIGNvbnN0IHJlYyA9IGF3YWl0IHR4LmdldDxTdG9yZWRPcGVyYXRpb248VE9wZXJhdGlvbj4+KFNUT1JFUy5PUFMsIHNlcSk7XG4gICAgICAgIGlmIChyZWMgPT09IHVuZGVmaW5lZCkgY29udGludWU7XG4gICAgICAgIC8vIOKaoO+4jyDkuI3kvKDnrKzkuInkuKrlj4LmlbDvvIjmmL7lvI8ga2V577yJ77yac3RvcmUg55So5LqGIGtleVBhdGggJ3NlcSfvvIxcbiAgICAgICAgLy8g6ICMIHJlYy5zZXEg5bey57uP5Zyo5a+56LGh6YeM44CCcHV0KHZhbHVlLCBrZXkpIOWcqCBrZXlQYXRoIOWtmOWcqOaXtuS8muaKmyBEYXRhRXJyb3LjgIJcbiAgICAgICAgYXdhaXQgdHgucHV0KFNUT1JFUy5PUFMsIHsgLi4ucmVjLCBhcHBseVN0YXR1czogJ2FwcGxpZWQnIH0pO1xuICAgICAgfVxuICAgIH0pO1xuICB9XG5cbiAgYXN5bmMgbWFya0ZhaWxlZChvcElkczogc3RyaW5nW10pOiBQcm9taXNlPHZvaWQ+IHtcbiAgICBpZiAob3BJZHMubGVuZ3RoID09PSAwKSByZXR1cm47XG4gICAgYXdhaXQgdGhpcy5kYi50cmFuc2FjdGlvbihbU1RPUkVTLk9QU10sICdyZWFkd3JpdGUnLCBhc3luYyAodHgpID0+IHtcbiAgICAgIGZvciAoY29uc3Qgb3BJZCBvZiBvcElkcykge1xuICAgICAgICBjb25zdCByZWMgPSBhd2FpdCB0eC5nZXRGcm9tSW5kZXg8U3RvcmVkT3BlcmF0aW9uPFRPcGVyYXRpb24+PihcbiAgICAgICAgICBTVE9SRVMuT1BTLFxuICAgICAgICAgIE9QX0lOREVYRVMuT1BfSUQsXG4gICAgICAgICAgb3BJZCxcbiAgICAgICAgKTtcbiAgICAgICAgaWYgKHJlYyA9PT0gdW5kZWZpbmVkKSBjb250aW51ZTtcbiAgICAgICAgYXdhaXQgdHgucHV0KFNUT1JFUy5PUFMsIHsgLi4ucmVjLCBhcHBseVN0YXR1czogJ2ZhaWxlZCcgfSk7XG4gICAgICB9XG4gICAgfSk7XG4gIH1cblxuICAvKipcbiAgICog5ZCI5bm26L+c56iLIG9wIOeahOWQkemHj+aXtumSn+OAglxuICAgKlxuICAgKiDimqDvuI8g6L+Z6YeMKirkuI3lgZrlhrLnqoHliKTlrpoqKiDigJTigJQg6YKj5pivIHN5bmMtY29yZSDnmoTogYzotKPjgIJcbiAgICog5a2Y5YKo5bGC5Y+q6LSf6LSj5oqK5pe26ZKf5oyB5LmF5YyW77yM5L+d6K+BXCLmlLbliLDkvYbov5jmsqHlupTnlKhcIueahCBvcCDnmoTml7bpkp9cbiAgICog5Zyo5bSp5rqD5ZCO5LuN54S25a2Y5Zyo77yI5ZCm5YiZ6YeN5ZCv5ZCO5Lya6K+v5Yik5bm25Y+R6ICM5Lii5pu05paw77yJ44CCXG4gICAqL1xuICBhc3luYyBtZXJnZVJlbW90ZU9wQ2xvY2tzKG9wczogVE9wZXJhdGlvbltdKTogUHJvbWlzZTx2b2lkPiB7XG4gICAgaWYgKG9wcy5sZW5ndGggPT09IDApIHJldHVybjtcbiAgICBhd2FpdCB0aGlzLmRiLnRyYW5zYWN0aW9uKFtTVE9SRVMuTUVUQV0sICdyZWFkd3JpdGUnLCBhc3luYyAodHgpID0+IHtcbiAgICAgIGF3YWl0IHdyaXRlTWV0YShcbiAgICAgICAgdHgsXG4gICAgICAgICdwZW5kaW5nUmVtb3RlQ2xvY2tzJyxcbiAgICAgICAgb3BzLm1hcCgob3ApID0+IG9wLnZlY3RvckNsb2NrID8/IHt9KSxcbiAgICAgICk7XG4gICAgfSk7XG4gIH1cblxuICBhc3luYyBtYXJrUmVkdWNlcnNDb21taXR0ZWRBbmRNZXJnZUNsb2NrcyhcbiAgICBzZXFzOiBudW1iZXJbXSxcbiAgICBfb3BzOiBUT3BlcmF0aW9uW10sXG4gICAgcmVqZWN0ZWRPcElkcz86IHN0cmluZ1tdLFxuICApOiBQcm9taXNlPHZvaWQ+IHtcbiAgICBhd2FpdCB0aGlzLm1hcmtBcHBsaWVkKHNlcXMpO1xuICAgIGlmIChyZWplY3RlZE9wSWRzICE9PSB1bmRlZmluZWQgJiYgcmVqZWN0ZWRPcElkcy5sZW5ndGggPiAwKSB7XG4gICAgICBhd2FpdCB0aGlzLm1hcmtGYWlsZWQocmVqZWN0ZWRPcElkcyk7XG4gICAgfVxuICB9XG5cbiAgLyoqIOa4heeQhlwi5YWo6YeP54q25oCBXCLmk43kvZzvvIzlj6rkv53nlZnmnIDmlrDnmoTjgILov5Tlm57ooqvmuIXpmaTnmoTmnaHmlbDjgIIgKi9cbiAgYXN5bmMgY2xlYXJGdWxsU3RhdGVPcHNFeGNlcHQoZXhjbHVkZUlkczogc3RyaW5nW10pOiBQcm9taXNlPG51bWJlcj4ge1xuICAgIGNvbnN0IGV4Y2x1ZGUgPSBuZXcgU2V0KGV4Y2x1ZGVJZHMpO1xuICAgIGxldCBjbGVhcmVkID0gMDtcblxuICAgIGF3YWl0IHRoaXMuZGIudHJhbnNhY3Rpb24oW1NUT1JFUy5PUFMsIFNUT1JFUy5BUkNISVZFLCBTVE9SRVMuTUVUQV0sICdyZWFkd3JpdGUnLCBhc3luYyAodHgpID0+IHtcbiAgICAgIGZvciAoY29uc3Qgc3RvcmUgb2YgW1NUT1JFUy5PUFMsIFNUT1JFUy5BUkNISVZFXSkge1xuICAgICAgICBjb25zdCBhbGwgPSBhd2FpdCB0eC5nZXRBbGw8U3RvcmVkT3BlcmF0aW9uPFRPcGVyYXRpb24+PihzdG9yZSk7XG4gICAgICAgIGZvciAoY29uc3QgcmVjIG9mIGFsbCkge1xuICAgICAgICAgIGlmIChpc0Z1bGxTdGF0ZU9wKHJlYy5vcCkgJiYgIWV4Y2x1ZGUuaGFzKHJlYy5vcC5pZCkpIHtcbiAgICAgICAgICAgIGF3YWl0IHR4LmRlbGV0ZShzdG9yZSwgcmVjLnNlcSk7XG4gICAgICAgICAgICBjbGVhcmVkICs9IDE7XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICB9XG4gICAgICAvLyBBIGNhY2hlZCBtYXRlcmlhbGl6YXRpb24gbWF5IHJlZmVyIHRvIG9uZSBvZiB0aGUgcmVtb3ZlZCByZWNvcmRzLlxuICAgICAgaWYgKGNsZWFyZWQgPiAwKSBhd2FpdCB0eC5kZWxldGUoU1RPUkVTLk1FVEEsIE1BVEVSSUFMSVpFRF9DSEVDS1BPSU5UX0tFWSk7XG4gICAgfSk7XG5cbiAgICByZXR1cm4gY2xlYXJlZDtcbiAgfVxuXG4gIC8vIOKUgOKUgCDor7vlj5Yg4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG5cbiAgYXN5bmMgZ2V0T3BzU2luY2UoXG4gICAgc2luY2VTZXE6IG51bWJlcixcbiAgICBsaW1pdD86IG51bWJlcixcbiAgICBleGNsdWRlQ2xpZW50Pzogc3RyaW5nLFxuICApOiBQcm9taXNlPFN0b3JlZE9wZXJhdGlvbjxUT3BlcmF0aW9uPltdPiB7XG4gICAgY29uc3QgYWxsID0gYXdhaXQgdGhpcy5nZXRBbGxPcHMoeyBsb3dlcjogc2luY2VTZXEsIGxvd2VyT3BlbjogdHJ1ZSB9LCBleGNsdWRlQ2xpZW50ID09PSB1bmRlZmluZWQgPyBsaW1pdCA6IHVuZGVmaW5lZCk7XG4gICAgY29uc3QgZmlsdGVyZWQgPSBleGNsdWRlQ2xpZW50ID09PSB1bmRlZmluZWQgPyBhbGwgOiBhbGwuZmlsdGVyKChyKSA9PiByLm9wLmNsaWVudElkICE9PSBleGNsdWRlQ2xpZW50KTtcbiAgICByZXR1cm4gbGltaXQgPT09IHVuZGVmaW5lZCA/IGZpbHRlcmVkIDogZmlsdGVyZWQuc2xpY2UoMCwgbGltaXQpO1xuICB9XG5cbiAgYXN5bmMgZ2V0T3BzRm9yRW50aXR5KFxuICAgIGVudGl0eVR5cGU6IEVudGl0eVR5cGUsXG4gICAgZW50aXR5SWQ6IHN0cmluZyxcbiAgKTogUHJvbWlzZTxTdG9yZWRPcGVyYXRpb248VE9wZXJhdGlvbj5bXT4ge1xuICAgIHJldHVybiB0aGlzLmRiLnRyYW5zYWN0aW9uKFtTVE9SRVMuT1BTLCBTVE9SRVMuQVJDSElWRV0sICdyZWFkb25seScsIGFzeW5jICh0eCkgPT4ge1xuICAgICAgY29uc3Qgc2NhbGFyID0gYXdhaXQgdHguZ2V0QWxsRnJvbUluZGV4PFN0b3JlZE9wZXJhdGlvbjxUT3BlcmF0aW9uPj4oXG4gICAgICAgIFNUT1JFUy5PUFMsIE9QX0lOREVYRVMuRU5USVRZLCBbZW50aXR5VHlwZSwgZW50aXR5SWRdLFxuICAgICAgKTtcbiAgICAgIGNvbnN0IGJhdGNoID0gYXdhaXQgdHguZ2V0QWxsRnJvbUluZGV4PFN0b3JlZE9wZXJhdGlvbjxUT3BlcmF0aW9uPj4oXG4gICAgICAgIFNUT1JFUy5PUFMsIE9QX0lOREVYRVMuRU5USVRZX0lEUywgZW50aXR5SWQsXG4gICAgICApO1xuICAgICAgLy8gVGhlIGV4aXN0aW5nIGFyY2hpdmUgc2NoZW1hIGhhcyBvbmx5IGFuIG9wSWQgaW5kZXguIENvbGQtaGlzdG9yeVxuICAgICAgLy8gcXVlcmllcyBkZWxpYmVyYXRlbHkgc2NhbiBpdCBpbnN0ZWFkIG9mIHJlcXVpcmluZyBhIHNjaGVtYSBtaWdyYXRpb24uXG4gICAgICBjb25zdCBhcmNoaXZlZCA9IGF3YWl0IHR4LmdldEFsbDxTdG9yZWRPcGVyYXRpb248VE9wZXJhdGlvbj4+KFNUT1JFUy5BUkNISVZFKTtcbiAgICAgIHJldHVybiBbLi4ubmV3IE1hcChbLi4uc2NhbGFyLCAuLi5iYXRjaCwgLi4uYXJjaGl2ZWRdXG4gICAgICAgIC5maWx0ZXIoKHIpID0+IHIub3AuZW50aXR5VHlwZSA9PT0gZW50aXR5VHlwZSAmJlxuICAgICAgICAgIChyLm9wLmVudGl0eUlkID09PSBlbnRpdHlJZCB8fCByLm9wLmVudGl0eUlkcz8uaW5jbHVkZXMoZW50aXR5SWQpKSlcbiAgICAgICAgLm1hcCgocikgPT4gW3Iuc2VxLCByXSkpLnZhbHVlcygpXS5zb3J0KChhLCBiKSA9PiBhLnNlcSAtIGIuc2VxKTtcbiAgICB9KTtcbiAgfVxuXG4gIGFzeW5jIGdldE9wQnlJZChvcElkOiBzdHJpbmcpOiBQcm9taXNlPFN0b3JlZE9wZXJhdGlvbjxUT3BlcmF0aW9uPiB8IHVuZGVmaW5lZD4ge1xuICAgIHJldHVybiB0aGlzLmRiLnRyYW5zYWN0aW9uKFtTVE9SRVMuT1BTLCBTVE9SRVMuQVJDSElWRV0sICdyZWFkb25seScsIGFzeW5jICh0eCkgPT4ge1xuICAgICAgZm9yIChjb25zdCBuYW1lIG9mIFtTVE9SRVMuT1BTLCBTVE9SRVMuQVJDSElWRV0pIHtcbiAgICAgICAgY29uc3Qga2V5ID0gYXdhaXQgdHguZ2V0S2V5RnJvbUluZGV4KG5hbWUsIE9QX0lOREVYRVMuT1BfSUQsIG9wSWQpO1xuICAgICAgICBpZiAoa2V5ICE9PSB1bmRlZmluZWQpIHJldHVybiB0eC5nZXQ8U3RvcmVkT3BlcmF0aW9uPFRPcGVyYXRpb24+PihuYW1lLCBrZXkpO1xuICAgICAgfVxuICAgICAgcmV0dXJuIHVuZGVmaW5lZDtcbiAgICB9KTtcbiAgfVxuXG4gIGFzeW5jIGdldExhc3RMb2NhbFNlcSgpOiBQcm9taXNlPG51bWJlcj4ge1xuICAgIGNvbnN0IHZhbHVlID0gYXdhaXQgdGhpcy5kYi5nZXQ8eyBrZXk6IHN0cmluZzsgdmFsdWU6IG51bWJlciB9PihcbiAgICAgIFNUT1JFUy5NRVRBLFxuICAgICAgTUVUQV9LRVlTLkxBU1RfTE9DQUxfU0VRLFxuICAgICk7XG4gICAgcmV0dXJuIHZhbHVlPy52YWx1ZSA/PyAwO1xuICB9XG5cbiAgYXN5bmMgZ2V0QWxsT3BzKHJhbmdlPzogRGJLZXlSYW5nZSwgbGltaXQ/OiBudW1iZXIpOiBQcm9taXNlPFN0b3JlZE9wZXJhdGlvbjxUT3BlcmF0aW9uPltdPiB7XG4gICAgLy8gQSBzaGFyZWQgcmVhZCB0cmFuc2FjdGlvbiBjYW5ub3Qgb2JzZXJ2ZSBhbiBvcCBib3RoIGJlZm9yZSBhbmQgYWZ0ZXJcbiAgICAvLyBhbiBhcmNoaXZlIG1vdmUsIG9yIG1pc3MgaXQgYmV0d2VlbiBzZXBhcmF0ZSBob3QvY29sZCByZWFkcy5cbiAgICByZXR1cm4gdGhpcy5kYi50cmFuc2FjdGlvbihbU1RPUkVTLk9QUywgU1RPUkVTLkFSQ0hJVkVdLCAncmVhZG9ubHknLCBhc3luYyAodHgpID0+IHtcbiAgICAgIGNvbnN0IGhvdCA9IGF3YWl0IHR4LmdldEFsbDxTdG9yZWRPcGVyYXRpb248VE9wZXJhdGlvbj4+KFNUT1JFUy5PUFMsIHJhbmdlLCBsaW1pdCk7XG4gICAgICBjb25zdCBhcmNoaXZlZCA9IGF3YWl0IHR4LmdldEFsbDxTdG9yZWRPcGVyYXRpb248VE9wZXJhdGlvbj4+KFNUT1JFUy5BUkNISVZFLCByYW5nZSwgbGltaXQpO1xuICAgICAgY29uc3Qgc29ydGVkID0gWy4uLmhvdCwgLi4uYXJjaGl2ZWRdLnNvcnQoKGEsIGIpID0+IGEuc2VxIC0gYi5zZXEpO1xuICAgICAgcmV0dXJuIGxpbWl0ID09PSB1bmRlZmluZWQgPyBzb3J0ZWQgOiBzb3J0ZWQuc2xpY2UoMCwgbGltaXQpO1xuICAgIH0pO1xuICB9XG5cbiAgYXN5bmMgY291bnRBbGxPcHMoKTogUHJvbWlzZTxudW1iZXI+IHtcbiAgICAvLyDwn5S0IOS4pOS4qiBzdG9yZSDpg73opoHmlbDjgIJBUkNISVZFIOmHjOeahCBvcCDku43nhLbmmK/ov5nlj7Dorr7lpIfnmoTml6Xlv5cg4oCU4oCUXG4gICAgLy8g5Y+q5pWw54Ot5Yy65Lya6K6p44CM6L+Y5Y6f5Y+q5YWB6K6456m65bqT44CN6YKj5p2h5a6I5Y2r5Zyo5pyJ5b2S5qGj5Y6G5Y+y55qE6K6+5aSH5LiK5pS+6KGM44CCXG4gICAgLy8g5LiOIGdldEFsbE9wcyDlkIzkuIDkuKrlj6ror7vkuovliqEg4oeSIOS4jeS8mueci+WIsFwi56e75Yqo5YmN5ZCO5ZCE5pWw5LiA5qyhXCLmiJbkuKTmrKHkuYvpl7TmvI/mjonjgIJcbiAgICByZXR1cm4gdGhpcy5kYi50cmFuc2FjdGlvbihbU1RPUkVTLk9QUywgU1RPUkVTLkFSQ0hJVkVdLCAncmVhZG9ubHknLCBhc3luYyAodHgpID0+XG4gICAgICAoYXdhaXQgdHguY291bnQoU1RPUkVTLk9QUykpICsgKGF3YWl0IHR4LmNvdW50KFNUT1JFUy5BUkNISVZFKSkpO1xuICB9XG5cbiAgLy8g4pSA4pSAIOW0qea6g+aBouWkjSDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcblxuICAvKipcbiAgICog5om+5Ye65omA5pyJXCLlt7LokL3nm5jkvYbmnKrlupTnlKhcIueahCBvcOOAglxuICAgKlxuICAgKiDlkK/liqjml7blv4XpobvlhYjph43mlL7lroPku6zvvIwqKuWGjSoq5o6l5Y+X5paw55qE5ZCM5q2l44CCXG4gICAqIOWQpuWImemCo+S4qiBvcCDnmoTnirbmgIHmsLjov5zkuI3kvJrnlJ/mlYjvvIzogIzlroPlt7LljaDnlKjkuoYgc2VxIOKAlOKAlCDnrYnkuo7pnZnpu5jkuKLmlbDmja7jgIJcbiAgICovXG4gIGFzeW5jIGZpbmRQZW5kaW5nQXBwbHkoKTogUHJvbWlzZTxTdG9yZWRPcGVyYXRpb248VE9wZXJhdGlvbj5bXT4ge1xuICAgIGNvbnN0IHJvd3MgPSBhd2FpdCB0aGlzLmRiLmdldEFsbEZyb21JbmRleDxTdG9yZWRPcGVyYXRpb248VE9wZXJhdGlvbj4+KFxuICAgICAgU1RPUkVTLk9QUyxcbiAgICAgIE9QX0lOREVYRVMuUEVORElOR19BUFBMWSxcbiAgICAgIC8vIOafpeWtl+espuS4siAncGVuZGluZyfjgIIqKuS4jeiDveafpeW4g+WwlCB0cnVlKiog4oCU4oCUIEluZGV4ZWREQiDkuI3ntKLlvJXluIPlsJTlgLzvvIxcbiAgICAgIC8vIOe0ouW8leadoeebruS8muiiq+mdmem7mOi3s+i/h++8jOafpeivouaBkuS4uuepuu+8iOi4qei/h+eahOWdke+8ieOAglxuICAgICAgJ3BlbmRpbmcnLFxuICAgICk7XG4gICAgcmV0dXJuIHJvd3Muc29ydCgoYSwgYikgPT4gYS5zZXEgLSBiLnNlcSk7XG4gIH1cblxuICAvKipcbiAgICog44CM6Zif5YiX56m65LiN56m644CN55qE5L6/5a6c54mI5pys77ya6LWw57Si5byV6K6h5pWw77yM5LiN5oqK5pW05p2h6Zif5YiX77yI5ZCr5a+G5paH5q2j5paH77yJ5pCs6L+b5YaF5a2Y44CCXG4gICAqXG4gICAqIOKaoO+4jyDmn6Xor6LmnaHku7bkuI4ge0BsaW5rIGZpbmRQZW5kaW5nQXBwbHl9IOmAkOWtl+ebuOWQjO+8iOafpeWtl+espuS4siBgJ3BlbmRpbmcnYO+8jFxuICAgKiAqKuS4jeiDveafpeW4g+WwlCBgdHJ1ZWAqKiDigJTigJQgSW5kZXhlZERCIOS4jee0ouW8leW4g+WwlOWAvO+8jOe0ouW8leadoeebruS8muiiq+mdmem7mOi3s+i/h++8ieOAglxuICAgKi9cbiAgYXN5bmMgY291bnRQZW5kaW5nQXBwbHkoKTogUHJvbWlzZTxudW1iZXI+IHtcbiAgICByZXR1cm4gdGhpcy5kYi5jb3VudEZyb21JbmRleChTVE9SRVMuT1BTLCBPUF9JTkRFWEVTLlBFTkRJTkdfQVBQTFksICdwZW5kaW5nJyk7XG4gIH1cblxuICAvLyDilIDilIAg5Y6L57ypIC8g5b2S5qGjIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuXG4gIC8qKlxuICAgKiDmioogYHVwVG9TZXFgIOS5i+WJjeeahCBvcCDnp7vlhaXlvZLmoaPjgIJcbiAgICpcbiAgICog5qOA5p+lIGNoZWNrcG9pbnQg5qCh6aqM5ZKM5LiO5a6e6ZmF5b2S5qGj5LiK55WM77yIZXhjbHVzaXZlIGN1dG9mZiAtIDHvvInjgIJcbiAgICog5pyq5LiK5LygL+acquW6lOeUqC/ooqvmi5Lnu53nmoTorrDlvZXku43nlZnlnKjng63ljLrvvJvlvZLmoaPljoblj7Lku43lsZ7kuo7ml6Xlv5fjgIJcbiAgICovXG4gIGFzeW5jIGFyY2hpdmVVcFRvKHVwVG9TZXE6IG51bWJlcik6IFByb21pc2U8bnVtYmVyPiB7XG4gICAgY29uc3QgY3V0b2ZmID0gdXBUb1NlcSAtIHRoaXMuYXJjaGl2ZUtlZXBSZWNlbnQ7XG4gICAgaWYgKGN1dG9mZiA8PSAwKSByZXR1cm4gMDtcblxuICAgIHJldHVybiB0aGlzLmRiLnRyYW5zYWN0aW9uKFxuICAgICAgW1NUT1JFUy5PUFMsIFNUT1JFUy5BUkNISVZFLCBTVE9SRVMuTUVUQV0sXG4gICAgICAncmVhZHdyaXRlJyxcbiAgICAgIGFzeW5jICh0eCkgPT4ge1xuICAgICAgICBjb25zdCBjaGVja3BvaW50UmVjb3JkID0gYXdhaXQgdHguZ2V0PHtcbiAgICAgICAgICBrZXk6IHN0cmluZztcbiAgICAgICAgICB2YWx1ZTogTWF0ZXJpYWxpemVkQ2hlY2twb2ludDtcbiAgICAgICAgfT4oU1RPUkVTLk1FVEEsIE1BVEVSSUFMSVpFRF9DSEVDS1BPSU5UX0tFWSk7XG4gICAgICAgIGNvbnN0IGxhc3RMb2NhbFNlcSA9IGF3YWl0IHJlYWRNZXRhTnVtYmVyKHR4LCBNRVRBX0tFWVMuTEFTVF9MT0NBTF9TRVEpO1xuICAgICAgICBpZiAoIWlzVmFsaWRDaGVja3BvaW50KGNoZWNrcG9pbnRSZWNvcmQ/LnZhbHVlLCBsYXN0TG9jYWxTZXEpIHx8IGNoZWNrcG9pbnRSZWNvcmQhLnZhbHVlLmNvdmVyZWRTZXEgPCBjdXRvZmYgLSAxKSB7XG4gICAgICAgICAgdGhyb3cgbmV3IE9wTG9nU3RvcmVFcnJvcihcbiAgICAgICAgICAgIE9wTG9nU3RvcmVFcnJvckNvZGUuQVJDSElWRV9SRVFVSVJFU19DSEVDS1BPSU5ULFxuICAgICAgICAgICAgYOW9kuahoyBzZXEgPCAke2N1dG9mZn0g6ZyA6KaB5LiA5Liq6KaG55uW6Iez5bCRICR7Y3V0b2ZmIC0gMX0g55qE5pyJ5pWIIGNoZWNrcG9pbnRgLFxuICAgICAgICAgICk7XG4gICAgICAgIH1cbiAgICAgICAgY29uc3Qgcm93cyA9IGF3YWl0IHR4LmdldEFsbDxTdG9yZWRPcGVyYXRpb248VE9wZXJhdGlvbj4+KFNUT1JFUy5PUFMsIHtcbiAgICAgICAgICB1cHBlcjogY3V0b2ZmLFxuICAgICAgICAgIHVwcGVyT3BlbjogdHJ1ZSxcbiAgICAgICAgfSk7XG4gICAgICAgIGNvbnN0IGVsaWdpYmxlID0gcm93cy5maWx0ZXIoKHJlYykgPT4gcmVjLmFwcGx5U3RhdHVzID09PSAnYXBwbGllZCcgJiYgcmVjLnVwbG9hZFN0YXR1cyA9PT0gJ3VwbG9hZGVkJyk7XG4gICAgICAgIGZvciAoY29uc3QgcmVjIG9mIGVsaWdpYmxlKSB7XG4gICAgICAgICAgLy8gUGVuZGluZyB1cGxvYWRzLCB1bmFwcGxpZWQgcmVtb3RlIG9wZXJhdGlvbnMgYW5kIHJlamVjdGVkIHdyaXRlc1xuICAgICAgICAgIC8vIHJlbWFpbiBpbiB0aGUgaG90IHN0b3JlIHdoZXJlIHF1ZXVlcyBhbmQgZGlhZ25vc3RpY3MgY2FuIHNlZSB0aGVtLlxuICAgICAgICAgIC8vIEFSQ0hJVkUg5Lmf55SoIGtleVBhdGggJ3NlcSfvvIzlkIzmoLfkuI3og73kvKDmmL7lvI8ga2V5XG4gICAgICAgICAgYXdhaXQgdHgucHV0KFNUT1JFUy5BUkNISVZFLCByZWMpO1xuICAgICAgICAgIGF3YWl0IHR4LmRlbGV0ZShTVE9SRVMuT1BTLCByZWMuc2VxKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gZWxpZ2libGUubGVuZ3RoO1xuICAgICAgfSxcbiAgICApO1xuICB9XG5cbiAgLy8g4pSA4pSAIOewv+iusCDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcblxuICAvKipcbiAgICog5b6F5LiK5Lyg55qE5pys5ZywIG9w77yI56a757q/6Zif5YiX77yJ44CCXG4gICAqXG4gICAqIOaMiSBzZXEg5Y2H5bqPIOKAlOKAlCDkuIrkvKDpobrluo/lv4XpobvkuI7mnKzlnLDkuqflh7rpobrluo/kuIDoh7TvvIxcbiAgICog5ZCm5YiZ5pyN5Yqh56uv55qE5Zug5p6c5qCh6aqM5Lya55yL5YiwXCLlkI7lj5HnlJ/nmoTlhYjliLBcIuOAglxuICAgKi9cbiAgYXN5bmMgZmluZFBlbmRpbmdVcGxvYWQoKTogUHJvbWlzZTxTdG9yZWRPcGVyYXRpb248VE9wZXJhdGlvbj5bXT4ge1xuICAgIGNvbnN0IHJvd3MgPSBhd2FpdCB0aGlzLmRiLmdldEFsbEZyb21JbmRleDxTdG9yZWRPcGVyYXRpb248VE9wZXJhdGlvbj4+KFxuICAgICAgU1RPUkVTLk9QUyxcbiAgICAgIE9QX0lOREVYRVMuUEVORElOR19VUExPQUQsXG4gICAgICAncGVuZGluZycsXG4gICAgKTtcbiAgICByZXR1cm4gcm93cy5zb3J0KChhLCBiKSA9PiBhLnNlcSAtIGIuc2VxKTtcbiAgfVxuXG4gIC8qKlxuICAgKiDlvoXkuIrkvKDpmJ/liJfnmoTmnaHmlbDvvIzkuI3nianljJbooYzvvIjmn6Xor6LmnaHku7bkuI4ge0BsaW5rIGZpbmRQZW5kaW5nVXBsb2FkfSDpgJDlrZfnm7jlkIzvvInjgIJcbiAgICpcbiAgICog8J+UtCDlroMqKuayoeaciSoq5YaN5oyJIGBzb3VyY2UgPT09ICdsb2NhbCdgIOaUtueqhO+8jOiAjOiwg+eUqOaWue+8iOW8leaTjueahFxuICAgKiBgZ2V0UGVuZGluZ1VwbG9hZCgpYO+8ieaUtueqhOS6huOAguS4pOiAheetieS7t+eahOWJjeaPkOaYr+mCo+adoeWGmeWFpeS4jeWPmOmHj++8mlxuICAgKiBgdXBsb2FkU3RhdHVzID0gc291cmNlID09PSAnbG9jYWwnID8gJ3BlbmRpbmcnIDogJ3VwbG9hZGVkJ2Ag4oCU4oCUXG4gICAqIOWPquacieacrOWcsOWGmeWFpeS8mui/myBwZW5kaW5n44CC5a6D55SxIGBvcC1sb2ctc3RvcmVgIOWlkee6pua1i+ivlemSieS9j++8jFxuICAgKiDkuI3mmK/pnaDov5nmrrXms6jph4roh6rnp7DmiJDnq4vjgIJcbiAgICovXG4gIGFzeW5jIGNvdW50UGVuZGluZ1VwbG9hZCgpOiBQcm9taXNlPG51bWJlcj4ge1xuICAgIHJldHVybiB0aGlzLmRiLmNvdW50RnJvbUluZGV4KFNUT1JFUy5PUFMsIE9QX0lOREVYRVMuUEVORElOR19VUExPQUQsICdwZW5kaW5nJyk7XG4gIH1cblxuICAvKipcbiAgICog5qCH6K6wIG9wIOW3suS4iuS8oO+8jOW5tuiusOW9leacjeWKoeerr+WIhumFjeeahCBzZXHjgIJcbiAgICpcbiAgICog4pqg77iPIOW/hemhu+WQjOaXtuaKiiBgb3Auc2VxYCDlhpnmiJDmnI3liqHnq6/luo/lj7fvvJrkuIvmrKHkuIrkvKDml7ZcbiAgICogYGxhc3RLbm93blNlcnZlclNlcWAg5LiO5Yay56qB5Yik5a6a6YO95L6d6LWW5a6D44CCXG4gICAqL1xuICBhc3luYyBtYXJrVXBsb2FkZWQoXG4gICAgc2VydmVyU2Vxc0J5T3BJZDogUmVhZG9ubHlNYXA8c3RyaW5nLCBudW1iZXI+LFxuICApOiBQcm9taXNlPG51bWJlcj4ge1xuICAgIGlmIChzZXJ2ZXJTZXFzQnlPcElkLnNpemUgPT09IDApIHJldHVybiAwO1xuXG4gICAgcmV0dXJuIHRoaXMuZGIudHJhbnNhY3Rpb24oXG4gICAgICBbU1RPUkVTLk9QU10sXG4gICAgICAncmVhZHdyaXRlJyxcbiAgICAgIGFzeW5jICh0eCkgPT4ge1xuICAgICAgICBsZXQgdXBkYXRlZCA9IDA7XG4gICAgICAgIGZvciAoY29uc3QgW29wSWQsIHNlcnZlclNlcV0gb2Ygc2VydmVyU2Vxc0J5T3BJZCkge1xuICAgICAgICAgIC8vIOeUqOW3suacieeahCBnZXRLZXlGcm9tSW5kZXjvvIhEYkFkYXB0ZXIg5rKh5pyJIGdldEFsbEtleXNGcm9tSW5kZXjvvIlcbiAgICAgICAgICBjb25zdCBrZXkgPSBhd2FpdCB0eC5nZXRLZXlGcm9tSW5kZXgoU1RPUkVTLk9QUywgT1BfSU5ERVhFUy5PUF9JRCwgb3BJZCk7XG4gICAgICAgICAgaWYgKGtleSA9PT0gdW5kZWZpbmVkKSBjb250aW51ZTtcblxuICAgICAgICAgIGNvbnN0IHJlY29yZCA9IGF3YWl0IHR4LmdldDxTdG9yZWRPcGVyYXRpb248VE9wZXJhdGlvbj4+KFNUT1JFUy5PUFMsIGtleSk7XG4gICAgICAgICAgaWYgKHJlY29yZCA9PT0gdW5kZWZpbmVkKSBjb250aW51ZTtcblxuICAgICAgICAgIC8vIOWPquaUueacrOWcsOWFg+aVsOaNru+8jCoq5LiN56KwIG9wKiog4oCU4oCUIG9wIOaYr+imgeWPkee7meacjeWKoeerr+eahOS4nOilv1xuICAgICAgICAgIGF3YWl0IHR4LnB1dChTVE9SRVMuT1BTLCB7XG4gICAgICAgICAgICAuLi5yZWNvcmQsXG4gICAgICAgICAgICB1cGxvYWRTdGF0dXM6ICd1cGxvYWRlZCcsXG4gICAgICAgICAgICBzZXJ2ZXJTZXEsXG4gICAgICAgICAgfSk7XG4gICAgICAgICAgdXBkYXRlZCArPSAxO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiB1cGRhdGVkO1xuICAgICAgfSxcbiAgICApO1xuICB9XG5cbiAgYXN5bmMgZGlzY2FyZFBlbmRpbmdVcGxvYWQob3BJZHM6IHN0cmluZ1tdKTogUHJvbWlzZTxudW1iZXI+IHtcbiAgICBpZiAob3BJZHMubGVuZ3RoID09PSAwKSByZXR1cm4gMDtcblxuICAgIHJldHVybiB0aGlzLmRiLnRyYW5zYWN0aW9uKFtTVE9SRVMuT1BTXSwgJ3JlYWR3cml0ZScsIGFzeW5jICh0eCkgPT4ge1xuICAgICAgbGV0IHVwZGF0ZWQgPSAwO1xuICAgICAgZm9yIChjb25zdCBvcElkIG9mIG9wSWRzKSB7XG4gICAgICAgIGNvbnN0IGtleSA9IGF3YWl0IHR4LmdldEtleUZyb21JbmRleChTVE9SRVMuT1BTLCBPUF9JTkRFWEVTLk9QX0lELCBvcElkKTtcbiAgICAgICAgaWYgKGtleSA9PT0gdW5kZWZpbmVkKSBjb250aW51ZTtcbiAgICAgICAgY29uc3QgcmVjb3JkID0gYXdhaXQgdHguZ2V0PFN0b3JlZE9wZXJhdGlvbjxUT3BlcmF0aW9uPj4oU1RPUkVTLk9QUywga2V5KTtcbiAgICAgICAgaWYgKHJlY29yZCA9PT0gdW5kZWZpbmVkKSBjb250aW51ZTtcbiAgICAgICAgYXdhaXQgdHgucHV0KFNUT1JFUy5PUFMsIHsgLi4ucmVjb3JkLCB1cGxvYWRTdGF0dXM6ICd1cGxvYWRlZCcgfSk7XG4gICAgICAgIHVwZGF0ZWQgKz0gMTtcbiAgICAgIH1cbiAgICAgIHJldHVybiB1cGRhdGVkO1xuICAgIH0pO1xuICB9XG5cbiAgYXN5bmMgbWFya1JlamVjdGVkKG9wSWRzOiBzdHJpbmdbXSk6IFByb21pc2U8bnVtYmVyPiB7XG4gICAgaWYgKG9wSWRzLmxlbmd0aCA9PT0gMCkgcmV0dXJuIDA7XG5cbiAgICByZXR1cm4gdGhpcy5kYi50cmFuc2FjdGlvbihbU1RPUkVTLk9QU10sICdyZWFkd3JpdGUnLCBhc3luYyAodHgpID0+IHtcbiAgICAgIGxldCB1cGRhdGVkID0gMDtcbiAgICAgIGZvciAoY29uc3Qgb3BJZCBvZiBvcElkcykge1xuICAgICAgICBjb25zdCBrZXkgPSBhd2FpdCB0eC5nZXRLZXlGcm9tSW5kZXgoU1RPUkVTLk9QUywgT1BfSU5ERVhFUy5PUF9JRCwgb3BJZCk7XG4gICAgICAgIGlmIChrZXkgPT09IHVuZGVmaW5lZCkgY29udGludWU7XG4gICAgICAgIGNvbnN0IHJlY29yZCA9IGF3YWl0IHR4LmdldDxTdG9yZWRPcGVyYXRpb248VE9wZXJhdGlvbj4+KFNUT1JFUy5PUFMsIGtleSk7XG4gICAgICAgIGlmIChyZWNvcmQgPT09IHVuZGVmaW5lZCkgY29udGludWU7XG4gICAgICAgIC8vIOS4jiBkaXNjYXJkIOWPquW3rui/meS4gOS4quWAvCDigJTigJQg6ICM5q2j5piv6L+Z5Liq5YC86K6pXCLmnI3liqHnq6/msLjkuYXmi5Lnu51cIuWPr+ingua1i+OAglxuICAgICAgICAvLyBvcCDmnKzouqvnhafml6fkuI3liqjvvJrlroPmmK/kuovlrp7mnaXmupDvvIzliKDkuoblsLHop6Pph4rkuI3kuobmnKzmnLrmm77nu4/mmK/ku4DkuYjlgLzjgIJcbiAgICAgICAgYXdhaXQgdHgucHV0KFNUT1JFUy5PUFMsIHsgLi4ucmVjb3JkLCB1cGxvYWRTdGF0dXM6ICdyZWplY3RlZCcgfSk7XG4gICAgICAgIHVwZGF0ZWQgKz0gMTtcbiAgICAgIH1cbiAgICAgIHJldHVybiB1cGRhdGVkO1xuICAgIH0pO1xuICB9XG5cbiAgYXN5bmMgZ2V0TGFzdFNlcnZlclNlcSgpOiBQcm9taXNlPG51bWJlcj4ge1xuICAgIHJldHVybiByZWFkTWV0YU51bWJlcih0aGlzLmRiLCBNRVRBX0tFWVMuTEFTVF9TRVJWRVJfU0VRKTtcbiAgfVxuXG4gIGFzeW5jIHNldExhc3RTZXJ2ZXJTZXEoc2VxOiBudW1iZXIpOiBQcm9taXNlPHZvaWQ+IHtcbiAgICBhd2FpdCB0aGlzLmRiLnRyYW5zYWN0aW9uKFtTVE9SRVMuTUVUQV0sICdyZWFkd3JpdGUnLCBhc3luYyAodHgpID0+IHtcbiAgICAgIGF3YWl0IHdyaXRlTWV0YSh0eCwgTUVUQV9LRVlTLkxBU1RfU0VSVkVSX1NFUSwgc2VxKTtcbiAgICB9KTtcbiAgfVxuXG4gIGFzeW5jIHJlYWRDaGVja3BvaW50KCk6IFByb21pc2U8TWF0ZXJpYWxpemVkQ2hlY2twb2ludCB8IHVuZGVmaW5lZD4ge1xuICAgIGNvbnN0IHJlY29yZCA9IGF3YWl0IHRoaXMuZGIuZ2V0PHsga2V5OiBzdHJpbmc7IHZhbHVlOiBNYXRlcmlhbGl6ZWRDaGVja3BvaW50IH0+KFxuICAgICAgU1RPUkVTLk1FVEEsXG4gICAgICBNQVRFUklBTElaRURfQ0hFQ0tQT0lOVF9LRVksXG4gICAgKTtcbiAgICByZXR1cm4gcmVjb3JkPy52YWx1ZTtcbiAgfVxuXG4gIGFzeW5jIHdyaXRlQ2hlY2twb2ludChjaGVja3BvaW50OiBNYXRlcmlhbGl6ZWRDaGVja3BvaW50KTogUHJvbWlzZTx2b2lkPiB7XG4gICAgaWYgKCFpc1ZhbGlkQ2hlY2twb2ludChjaGVja3BvaW50LCBhd2FpdCB0aGlzLmdldExhc3RMb2NhbFNlcSgpKSkge1xuICAgICAgdGhyb3cgbmV3IE9wTG9nU3RvcmVFcnJvcihcbiAgICAgICAgT3BMb2dTdG9yZUVycm9yQ29kZS5TVE9SQUdFX1VOQVZBSUxBQkxFLFxuICAgICAgICAn5ouS57ud5YaZ5YWl5peg5pWIIG1hdGVyaWFsaXplZCBjaGVja3BvaW50JyxcbiAgICAgICk7XG4gICAgfVxuICAgIGF3YWl0IHRoaXMuZGIudHJhbnNhY3Rpb24oW1NUT1JFUy5NRVRBXSwgJ3JlYWR3cml0ZScsIGFzeW5jICh0eCkgPT4ge1xuICAgICAgYXdhaXQgdHgucHV0KFNUT1JFUy5NRVRBLCB7IGtleTogTUFURVJJQUxJWkVEX0NIRUNLUE9JTlRfS0VZLCB2YWx1ZTogY2hlY2twb2ludCB9KTtcbiAgICB9KTtcbiAgfVxuXG4gIC8qKiBSZWFkIHRoZSBkdXJhYmxlIHNlcnZlci1vYnNlcnZlZCBjYXVzYWwgZnJvbnRpZXIsIGluZGVwZW5kZW50IG9mIGNoZWNrcG9pbnRzLiAqL1xuICBhc3luYyByZWFkT2JzZXJ2ZWRDbG9jaygpOiBQcm9taXNlPFJlY29yZDxzdHJpbmcsIG51bWJlcj4+IHtcbiAgICByZXR1cm4gdGhpcy5kYi50cmFuc2FjdGlvbihbU1RPUkVTLk1FVEFdLCAncmVhZG9ubHknLCBhc3luYyAodHgpID0+IHtcbiAgICAgIGNvbnN0IHJlY29yZCA9IGF3YWl0IHR4LmdldDx7IGtleTogc3RyaW5nOyB2YWx1ZTogdW5rbm93biB9PihcbiAgICAgICAgU1RPUkVTLk1FVEEsXG4gICAgICAgIE1FVEFfS0VZUy5PQlNFUlZFRF9DTE9DSyxcbiAgICAgICk7XG4gICAgICBpZiAocmVjb3JkID09PSB1bmRlZmluZWQpIHJldHVybiB7fTtcbiAgICAgIHJldHVybiB2YWxpZGF0ZU9ic2VydmVkQ2xvY2socmVjb3JkLnZhbHVlKTtcbiAgICB9KTtcbiAgfVxuXG4gIC8qKlxuICAgKiBQZXJzaXN0IGEgY29tcG9uZW50LXdpc2UgbWF4IG1lcmdlIGluIG9uZSBNRVRBIHRyYW5zYWN0aW9uLlxuICAgKlxuICAgKiBUaGUgcmVhZCBhbmQgd3JpdGUgaW50ZW50aW9uYWxseSBzaGFyZSB0aGUgc2FtZSB0cmFuc2FjdGlvbjogY29uY3VycmVudFxuICAgKiBjYWxsZXJzIG11c3QgbmV2ZXIgbG9zZSBhIGRpbWVuc2lvbiBiZWNhdXNlIGJvdGggcmVhZCB0aGUgc2FtZSBvbGQgdmFsdWUuXG4gICAqL1xuICBhc3luYyBtZXJnZU9ic2VydmVkQ2xvY2soY2xvY2s6IFJlY29yZDxzdHJpbmcsIG51bWJlcj4pOiBQcm9taXNlPHZvaWQ+IHtcbiAgICBjb25zdCBpbmNvbWluZyA9IHZhbGlkYXRlT2JzZXJ2ZWRDbG9jayhjbG9jayk7XG4gICAgYXdhaXQgdGhpcy5kYi50cmFuc2FjdGlvbihbU1RPUkVTLk1FVEFdLCAncmVhZHdyaXRlJywgYXN5bmMgKHR4KSA9PiB7XG4gICAgICBjb25zdCByZWNvcmQgPSBhd2FpdCB0eC5nZXQ8eyBrZXk6IHN0cmluZzsgdmFsdWU6IHVua25vd24gfT4oXG4gICAgICAgIFNUT1JFUy5NRVRBLFxuICAgICAgICBNRVRBX0tFWVMuT0JTRVJWRURfQ0xPQ0ssXG4gICAgICApO1xuICAgICAgY29uc3QgY3VycmVudCA9IHJlY29yZCA9PT0gdW5kZWZpbmVkID8ge30gOiB2YWxpZGF0ZU9ic2VydmVkQ2xvY2socmVjb3JkLnZhbHVlKTtcbiAgICAgIGNvbnN0IG1lcmdlZDogUmVjb3JkPHN0cmluZywgbnVtYmVyPiA9IHsgLi4uY3VycmVudCB9O1xuICAgICAgZm9yIChjb25zdCBbY2xpZW50SWQsIGNvdW50ZXJdIG9mIE9iamVjdC5lbnRyaWVzKGluY29taW5nKSkge1xuICAgICAgICBpZiAoKG1lcmdlZFtjbGllbnRJZF0gPz8gMCkgPCBjb3VudGVyKSB7XG4gICAgICAgICAgT2JqZWN0LmRlZmluZVByb3BlcnR5KG1lcmdlZCwgY2xpZW50SWQsIHtcbiAgICAgICAgICAgIHZhbHVlOiBjb3VudGVyLFxuICAgICAgICAgICAgZW51bWVyYWJsZTogdHJ1ZSxcbiAgICAgICAgICAgIGNvbmZpZ3VyYWJsZTogdHJ1ZSxcbiAgICAgICAgICAgIHdyaXRhYmxlOiB0cnVlLFxuICAgICAgICAgIH0pO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgICBhd2FpdCB0eC5wdXQoU1RPUkVTLk1FVEEsIHtcbiAgICAgICAgW01FVEFfRklFTERTLktFWV06IE1FVEFfS0VZUy5PQlNFUlZFRF9DTE9DSyxcbiAgICAgICAgW01FVEFfRklFTERTLlZBTFVFXTogbWVyZ2VkLFxuICAgICAgfSk7XG4gICAgfSk7XG4gIH1cblxuICAvKiogUmVhZCB0aGUgb25lLXdheSBoaXN0b3J5LWludGVncml0eSBtYXJrZXI7IGFic2VudCBtZWFucyBjb21wbGV0ZS4gKi9cbiAgYXN5bmMgaGFzSW5jb21wbGV0ZUhpc3RvcnkoKTogUHJvbWlzZTxib29sZWFuPiB7XG4gICAgcmV0dXJuIHRoaXMuZGIudHJhbnNhY3Rpb24oW1NUT1JFUy5NRVRBXSwgJ3JlYWRvbmx5JywgYXN5bmMgKHR4KSA9PiB7XG4gICAgICBjb25zdCByZWNvcmQgPSBhd2FpdCB0eC5nZXQ8eyBrZXk6IHN0cmluZzsgdmFsdWU6IHVua25vd24gfT4oXG4gICAgICAgIFNUT1JFUy5NRVRBLFxuICAgICAgICBNRVRBX0tFWVMuSElTVE9SWV9JTkNPTVBMRVRFLFxuICAgICAgKTtcbiAgICAgIHJldHVybiByZWNvcmQ/LnZhbHVlID09PSB0cnVlO1xuICAgIH0pO1xuICB9XG5cbiAgLyoqIFNldCB0aGUgaGlzdG9yeS1pbnRlZ3JpdHkgbWFya2VyLiBEZWxpYmVyYXRlbHkgbm8gY2xlYXJpbmcgb3BlcmF0aW9uIGV4aXN0cy4gKi9cbiAgYXN5bmMgbWFya0hpc3RvcnlJbmNvbXBsZXRlKCk6IFByb21pc2U8dm9pZD4ge1xuICAgIGF3YWl0IHRoaXMuZGIudHJhbnNhY3Rpb24oW1NUT1JFUy5NRVRBXSwgJ3JlYWR3cml0ZScsIGFzeW5jICh0eCkgPT4ge1xuICAgICAgYXdhaXQgdHgucHV0KFNUT1JFUy5NRVRBLCB7XG4gICAgICAgIFtNRVRBX0ZJRUxEUy5LRVldOiBNRVRBX0tFWVMuSElTVE9SWV9JTkNPTVBMRVRFLFxuICAgICAgICBbTUVUQV9GSUVMRFMuVkFMVUVdOiB0cnVlLFxuICAgICAgfSk7XG4gICAgfSk7XG4gIH1cblxuICBhc3luYyBnZXRNZXRhVmFsdWUoa2V5OiBzdHJpbmcpOiBQcm9taXNlPHN0cmluZyB8IG51bWJlciB8IHVuZGVmaW5lZD4ge1xuICAgIGNvbnN0IHJlYyA9IGF3YWl0IHRoaXMuZGIuZ2V0PHsga2V5OiBzdHJpbmc7IHZhbHVlOiBzdHJpbmcgfCBudW1iZXIgfT4oU1RPUkVTLk1FVEEsIGtleSk7XG4gICAgcmV0dXJuIHJlYz8udmFsdWU7XG4gIH1cblxuICBhc3luYyBzZXRNZXRhVmFsdWUoa2V5OiBzdHJpbmcsIHZhbHVlOiBzdHJpbmcgfCBudW1iZXIpOiBQcm9taXNlPHZvaWQ+IHtcbiAgICBhd2FpdCB0aGlzLmRiLnRyYW5zYWN0aW9uKFtTVE9SRVMuTUVUQV0sICdyZWFkd3JpdGUnLCBhc3luYyAodHgpID0+IHtcbiAgICAgIGF3YWl0IHdyaXRlTWV0YSh0eCwga2V5LCB2YWx1ZSk7XG4gICAgfSk7XG4gIH1cbn1cblxuLy8g4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG4vLyDovoXliqlcbi8vIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuXG4vKiog5piv5ZCmXCLlhajph4/nirbmgIFcIuaTjeS9nO+8iOeUqOS6juWOi+e8qe+8ieOAguaMiSBwYXlsb2FkIOmHjOeahOagh+iusOWIpOaWreOAgiAqL1xuZnVuY3Rpb24gaXNGdWxsU3RhdGVPcChvcDogT3BlcmF0aW9uPHN0cmluZz4pOiBib29sZWFuIHtcbiAgY29uc3QgcGF5bG9hZCA9IG9wLnBheWxvYWQ7XG4gIHJldHVybiAoXG4gICAgdHlwZW9mIHBheWxvYWQgPT09ICdvYmplY3QnICYmXG4gICAgcGF5bG9hZCAhPT0gbnVsbCAmJlxuICAgICdpc0Z1bGxTdGF0ZScgaW4gcGF5bG9hZCAmJlxuICAgIChwYXlsb2FkIGFzIHsgaXNGdWxsU3RhdGU/OiB1bmtub3duIH0pLmlzRnVsbFN0YXRlID09PSB0cnVlXG4gICk7XG59XG5cbi8qKlxuICog6K+75LiA5LiqIG1ldGEg5pWw5a2X44CCXG4gKlxuICog4pqg77iPIOWPguaVsOexu+Wei+aYryBgRGJBZGFwdGVyIHwgRGJUeGAg4oCU4oCUIOWboOS4uioq5ZCM5LiA5Liq6YC76L6R5pei6KaB5Zyo5LqL5Yqh5aSW6LCD55SoXG4gKiDvvIhnZXRMYXN0U2VydmVyU2Vx77yJ77yM5Lmf6KaB5Zyo5LqL5Yqh5YaF6LCD55SoKirvvIhhcHBlbmRCYXRjaCDph4zmm7TmlrDmuLjmoIfvvInjgIJcbiAqIOWPquaOpeWPlyBEYkFkYXB0ZXIg55qE6K+d77yM5LqL5Yqh5YaF6LCD55So5Lya57yW6K+R5aSx6LSl77yI5oiR56ys5LiA54mI5bCx5piv6L+Z5qC377yJ44CCXG4gKi9cbmFzeW5jIGZ1bmN0aW9uIHJlYWRNZXRhTnVtYmVyKFxuICBkYjogUGljazxEYkFkYXB0ZXIsICdnZXQnPiB8IFBpY2s8RGJUeCwgJ2dldCc+LFxuICBrZXk6IHN0cmluZyxcbik6IFByb21pc2U8bnVtYmVyPiB7XG4gIGNvbnN0IHJlYyA9IGF3YWl0IGRiLmdldDx7IGtleTogc3RyaW5nOyB2YWx1ZTogbnVtYmVyIH0+KFNUT1JFUy5NRVRBLCBrZXkpO1xuICByZXR1cm4gcmVjPy52YWx1ZSA/PyAwO1xufVxuXG5hc3luYyBmdW5jdGlvbiB3cml0ZU1ldGEodHg6IERiVHgsIGtleTogc3RyaW5nLCB2YWx1ZTogdW5rbm93bik6IFByb21pc2U8dm9pZD4ge1xuICBhd2FpdCB0eC5wdXQoU1RPUkVTLk1FVEEsIHsgW01FVEFfRklFTERTLktFWV06IGtleSwgW01FVEFfRklFTERTLlZBTFVFXTogdmFsdWUgfSk7XG59XG5cbi8qKiBWYWxpZGF0ZSBhIHBlcnNpc3RlZCBvciBpbmNvbWluZyBjYXVzYWwgZnJvbnRpZXIgYmVmb3JlIGl0IGNhbiBhZmZlY3Qgc3RhdGUuICovXG5mdW5jdGlvbiB2YWxpZGF0ZU9ic2VydmVkQ2xvY2sodmFsdWU6IHVua25vd24pOiBSZWNvcmQ8c3RyaW5nLCBudW1iZXI+IHtcbiAgaWYgKHZhbHVlID09PSBudWxsIHx8IHR5cGVvZiB2YWx1ZSAhPT0gJ29iamVjdCcgfHwgQXJyYXkuaXNBcnJheSh2YWx1ZSkpIHtcbiAgICB0aHJvdyBuZXcgVHlwZUVycm9yKCdvYnNlcnZlZCBjbG9jayDlv4XpobvmmK/lr7nosaEnKTtcbiAgfVxuICBjb25zdCBwcm90b3R5cGUgPSBPYmplY3QuZ2V0UHJvdG90eXBlT2YodmFsdWUpO1xuICBpZiAocHJvdG90eXBlICE9PSBPYmplY3QucHJvdG90eXBlICYmIHByb3RvdHlwZSAhPT0gbnVsbCkge1xuICAgIHRocm93IG5ldyBUeXBlRXJyb3IoJ29ic2VydmVkIGNsb2NrIOW/hemhu+aYr+aZrumAmuWvueixoScpO1xuICB9XG4gIGlmIChSZWZsZWN0Lm93bktleXModmFsdWUpLnNvbWUoKGtleSkgPT4gdHlwZW9mIGtleSAhPT0gJ3N0cmluZycpKSB7XG4gICAgdGhyb3cgbmV3IFR5cGVFcnJvcignb2JzZXJ2ZWQgY2xvY2sg55qE6ZSu5b+F6aG75piv5a2X56ym5LiyJyk7XG4gIH1cbiAgY29uc3QgY2xvY2s6IFJlY29yZDxzdHJpbmcsIG51bWJlcj4gPSB7fTtcbiAgZm9yIChjb25zdCBbY2xpZW50SWQsIGNvdW50ZXJdIG9mIE9iamVjdC5lbnRyaWVzKHZhbHVlKSkge1xuICAgIGlmICghTnVtYmVyLmlzU2FmZUludGVnZXIoY291bnRlcikgfHwgY291bnRlciA8IDApIHtcbiAgICAgIHRocm93IG5ldyBSYW5nZUVycm9yKFxuICAgICAgICBgb2JzZXJ2ZWQgY2xvY2vjgIwke2NsaWVudElkfeOAjeW/hemhu+aYr+mdnui0n+WuieWFqOaVtOaVsO+8jOaUtuWIsO+8miR7U3RyaW5nKGNvdW50ZXIpfWAsXG4gICAgICApO1xuICAgIH1cbiAgICBPYmplY3QuZGVmaW5lUHJvcGVydHkoY2xvY2ssIGNsaWVudElkLCB7XG4gICAgICB2YWx1ZTogY291bnRlcixcbiAgICAgIGVudW1lcmFibGU6IHRydWUsXG4gICAgICBjb25maWd1cmFibGU6IHRydWUsXG4gICAgICB3cml0YWJsZTogdHJ1ZSxcbiAgICB9KTtcbiAgfVxuICByZXR1cm4gY2xvY2s7XG59XG5cbmV4cG9ydCB7IE9wTG9nU3RvcmVFcnJvciwgT3BMb2dTdG9yZUVycm9yQ29kZSB9O1xuZXhwb3J0IHR5cGUgeyBTdG9yZWRPcGVyYXRpb24sIE9wZXJhdGlvblNvdXJjZSB9O1xuXG4vKipcbiAqIEBkZXByZWNhdGVkIOeUqCB7QGxpbmsgRGJPcExvZ1N0b3JlfeOAglxuICpcbiAqIOS/neeVmeWIq+WQjeWPquS4uuS4jeaUueWKqOaXouacieiwg+eUqOeCue+8m+Wug+eahOWQjeWtl+S8muiuqeS6uuS7peS4uui/meS4jiBJbmRleGVkREIg57uR5a6a77yMXG4gKiDogIzkuovlrp7lubbpnZ7lpoLmraTjgILmlrDku6PnoIHor7fnlKggYERiT3BMb2dTdG9yZWDjgIJcbiAqL1xuLy8g4pqg77iPIOW/hemhu+eUqCBgZXhwb3J0IHsgWCBhcyBZIH1gIOiAjOS4jeaYryBgZXhwb3J0IGNvbnN0IFkgPSBYYO+8mlxuLy8g57G75pei5piv5YC85Lmf5pivKirnsbvlnosqKu+8jOiAjCBgY29uc3RgIOWjsOaYjuWPquaPkOS+m+WAvCDigJTigJRcbi8vIOeUqCBgY29uc3RgIOS8muiuqSBgbGV0IHN0b3JlOiBJbmRleGVkRGJPcExvZ1N0b3JlPFQ+YCDnm7TmjqXnvJbor5HlpLHotKXjgIJcbi8vIOaIkeWcqOesrOS4gOasoeaUueWQjeaXtuWwseaYr+i/meS5iOWGmeeahO+8jGBwYWNrYWdlcy9vcC1sb2dgIOeahCB0eXBlY2hlY2sg56uL5Yi75oqlXG4vLyBcIidJbmRleGVkRGJPcExvZ1N0b3JlJyByZWZlcnMgdG8gYSB2YWx1ZSwgYnV0IGlzIGJlaW5nIHVzZWQgYXMgYSB0eXBlIGhlcmVcIuOAglxuZXhwb3J0IHsgRGJPcExvZ1N0b3JlIGFzIEluZGV4ZWREYk9wTG9nU3RvcmUgfTtcbiJdLCJtYXBwaW5ncyI6IjtBQXlSTyxJQUFNLHFCQUFxQixDQUFDLFVBQXlCO0FBQzFELE1BQUksVUFBVSxPQUFXO0FBQ3pCLE1BQUksQ0FBQyxPQUFPLFVBQVUsS0FBSyxLQUFLLFNBQVMsR0FBRztBQUMxQyxVQUFNLElBQUksTUFBTSw2RUFBMkIsT0FBTyxLQUFLLENBQUMsRUFBRTtBQUFBLEVBQzVEO0FBQ0Y7QUFHTyxJQUFNLHdCQUF3Qjs7O0FDbE85QixJQUFNLGVBQU4sY0FBMkIsTUFBTTtBQUFBLEVBQzdCO0FBQUEsRUFFVCxZQUFZLFNBQWlCLFNBQXlCLE9BQWlCO0FBQ3JFLFVBQU0sT0FBTztBQUNiLFNBQUssT0FBTztBQUNaLFNBQUssVUFBVTtBQUNmLFNBQUssUUFBUTtBQUFBLEVBQ2Y7QUFDRjtBQVlPLFNBQVMsYUFDZCxPQUNBLGlCQUNBLFNBQ2M7QUFDZCxNQUFJLGlCQUFpQixNQUFPLFFBQU8sSUFBSSxhQUFhLE1BQU0sU0FBUyxTQUFTLEtBQUs7QUFDakYsTUFBSSxVQUFVLFVBQWEsVUFBVSxLQUFNLFFBQU8sSUFBSSxhQUFhLGlCQUFpQixPQUFPO0FBQzNGLFNBQU8sSUFBSSxhQUFhLE9BQU8sS0FBSyxHQUFHLFNBQVMsS0FBSztBQUN2RDtBQVlPLFNBQVMsZUFDZCxPQUNBLGlCQUNBLFNBQ2M7QUFDZCxNQUFJLGlCQUFpQixhQUFjLFFBQU87QUFDMUMsU0FBTyxhQUFhLE9BQU8saUJBQWlCLE9BQU87QUFDckQ7QUFtQk8sSUFBTSx3QkFBTixjQUFvQyxhQUFhO0FBQUEsRUFDdEQsWUFBWSxRQUFnQjtBQUMxQjtBQUFBLE1BQ0UseURBQVksTUFBTTtBQUFBLE1BRWxCLEVBQUUsTUFBTSxvQkFBb0I7QUFBQSxJQUM5QjtBQUNBLFNBQUssT0FBTztBQUFBLEVBQ2Q7QUFDRjs7O0FDaklPLElBQU0sU0FBUztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBT3BCLEtBQUs7QUFBQTtBQUFBLEVBR0wsT0FBTztBQUFBO0FBQUEsRUFHUCxNQUFNO0FBQUE7QUFBQSxFQUdOLFNBQVM7QUFDWDtBQUtPLElBQU0sYUFBMEI7QUFBQSxFQUNyQyxPQUFPO0FBQUEsRUFDUCxPQUFPO0FBQUEsRUFDUCxPQUFPO0FBQUEsRUFDUCxPQUFPO0FBQ1Q7QUFnQk8sSUFBTSxZQUFZO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQVF2QixLQUFLO0FBQUE7QUFBQSxFQUVMLE9BQU87QUFBQSxFQUNQLGFBQWE7QUFBQSxFQUNiLFdBQVc7QUFBQTtBQUFBLEVBRVgsWUFBWTtBQUFBLEVBQ1osU0FBUztBQUFBLEVBQ1QsY0FBYztBQUFBLEVBQ2QsV0FBVztBQUFBLEVBQ1gsa0JBQWtCO0FBQUEsRUFDbEIsZ0JBQWdCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFPaEIsZUFBZTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFXZixjQUFjO0FBQ2hCO0FBbUNPLElBQU0sa0JBQTJDLENBQUMsV0FBVyxZQUFZLFVBQVU7QUFVMUYsSUFBTSxnQkFBZ0I7QUFBQSxFQUNwQixPQUFPLFVBQVU7QUFBQSxFQUNqQixhQUFhLFVBQVU7QUFBQSxFQUN2QixXQUFXLFVBQVU7QUFBQSxFQUNyQixZQUFZLFVBQVU7QUFBQSxFQUN0QixTQUFTLFVBQVU7QUFBQSxFQUNuQixjQUFjLFVBQVU7QUFBQSxFQUN4QixXQUFXLFVBQVU7QUFBQSxFQUNyQixrQkFBa0IsVUFBVTtBQUFBLEVBQzVCLGdCQUFnQixVQUFVO0FBQzVCO0FBSU8sSUFBTSxhQUFhO0FBQUE7QUFBQSxFQUV4QixPQUFPO0FBQUE7QUFBQSxFQUVQLFFBQVE7QUFBQTtBQUFBLEVBRVIsWUFBWTtBQUFBO0FBQUEsRUFFWixlQUFlO0FBQUE7QUFBQSxFQUVmLGdCQUFnQjtBQUNsQjtBQUdPLElBQU0sZUFBZTtBQUFBLEVBQzFCLGFBQWE7QUFBQSxFQUNiLFdBQVc7QUFBQSxFQUNYLE1BQU07QUFBQTtBQUFBLEVBRU4sVUFBVTtBQUNaO0FBR08sSUFBTSxpQkFBaUIsQ0FBQyxhQUFhLGFBQWEsYUFBYSxTQUFTO0FBR3hFLElBQU0sY0FBYztBQUFBLEVBQ3pCLEtBQUs7QUFBQSxFQUNMLE9BQU87QUFDVDtBQWlCTyxJQUFNLFlBQVk7QUFBQTtBQUFBLEVBRXZCLFdBQVc7QUFBQTtBQUFBLEVBRVgsaUJBQWlCO0FBQUE7QUFBQSxFQUVqQixnQkFBZ0I7QUFBQTtBQUFBLEVBRWhCLG9CQUFvQjtBQUFBO0FBQUEsRUFFcEIsZ0JBQWdCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFPaEIsZ0JBQWdCO0FBQUE7QUFBQSxFQUVoQixvQkFBb0I7QUFBQTtBQUFBLEVBRXBCLG1CQUFtQjtBQUFBO0FBQUEsRUFFbkIsaUJBQWlCO0FBQUE7QUFBQSxFQUVqQix5QkFBeUI7QUFBQTtBQUFBLEVBRXpCLG1CQUFtQjtBQUFBO0FBQUEsRUFFbkIsbUJBQW1CO0FBQUE7QUFBQSxFQUVuQix5QkFBeUI7QUFBQTtBQUFBLEVBRXpCLDJCQUEyQjtBQUFBO0FBQUEsRUFFM0IsNkJBQTZCO0FBQUE7QUFBQSxFQUU3Qix1QkFBdUI7QUFBQTtBQUFBLEVBRXZCLDJCQUEyQjtBQUFBO0FBQUEsRUFFM0Isd0JBQXdCO0FBQzFCOzs7QUNrRE8sSUFBSyxzQkFBTCxrQkFBS0EseUJBQUw7QUFFTCxFQUFBQSxxQkFBQSxxQkFBa0I7QUFFbEIsRUFBQUEscUJBQUEsYUFBVTtBQUVWLEVBQUFBLHFCQUFBLHdCQUFxQjtBQUVyQixFQUFBQSxxQkFBQSx5QkFBc0I7QUFFdEIsRUFBQUEscUJBQUEsaUNBQThCO0FBVnBCLFNBQUFBO0FBQUEsR0FBQTtBQWFMLElBQU0sa0JBQU4sY0FBOEIsTUFBTTtBQUFBLEVBQ3pDLFlBQ2tCLE1BQ2hCLFNBQ0E7QUFDQSxVQUFNLE9BQU87QUFIRztBQUloQixTQUFLLE9BQU87QUFBQSxFQUNkO0FBQUEsRUFMa0I7QUFNcEI7OztBQzNTTyxTQUFTLG1CQUNkLFlBQ1E7QUFDUixRQUFNLFFBQVEsS0FBSyxVQUFVLFVBQVU7QUFDdkMsTUFBSSxPQUFPO0FBQ1gsV0FBUyxRQUFRLEdBQUcsUUFBUSxNQUFNLFFBQVEsU0FBUyxHQUFHO0FBQ3BELFlBQVEsTUFBTSxXQUFXLEtBQUs7QUFDOUIsV0FBTyxLQUFLLEtBQUssTUFBTSxRQUFVO0FBQUEsRUFDbkM7QUFDQSxVQUFRLFNBQVMsR0FBRyxTQUFTLEVBQUUsRUFBRSxTQUFTLEdBQUcsR0FBRztBQUNsRDtBQUdPLFNBQVMsa0JBQ2QsWUFDQSxjQUNzQztBQUN0QyxNQUFJLENBQUMsY0FBYyxPQUFPLGVBQWUsWUFBWSxNQUFNLFFBQVEsVUFBVSxFQUFHLFFBQU87QUFDdkYsUUFBTSxZQUFZO0FBQ2xCLE1BQUksVUFBVSxrQkFBa0IsRUFBRyxRQUFPO0FBQzFDLE1BQUksQ0FBQyxPQUFPLFVBQVUsVUFBVSxVQUFVLEtBQUssVUFBVSxhQUFhLEVBQUcsUUFBTztBQUNoRixNQUFJLFVBQVUsYUFBYSxhQUFjLFFBQU87QUFDaEQsTUFBSSxVQUFVLFVBQVUsVUFBYSxVQUFVLFVBQVUsS0FBTSxRQUFPO0FBQ3RFLE1BQUksVUFBVSxVQUFVLFFBQVEsT0FBTyxVQUFVLFVBQVUsU0FBVSxRQUFPO0FBQzVFLE1BQUksTUFBTSxRQUFRLFVBQVUsS0FBSyxLQUFLLE9BQU8sT0FBTyxVQUFVLEtBQUssRUFBRTtBQUFBLElBQ25FLENBQUMsWUFBWSxDQUFDLE9BQU8sY0FBYyxPQUFPLEtBQUssVUFBVTtBQUFBLEVBQUMsRUFBRyxRQUFPO0FBQ3RFLE1BQUksQ0FBQyxNQUFNLFFBQVEsVUFBVSxZQUFZLEtBQUssVUFBVSxhQUFhLEtBQUssQ0FBQyxPQUFPLE9BQU8sT0FBTyxRQUFRLEVBQUcsUUFBTztBQUNsSCxNQUFJLE9BQU8sVUFBVSxhQUFhLFlBQVksVUFBVSxTQUFTLFdBQVcsRUFBRyxRQUFPO0FBRXRGLFFBQU0sRUFBRSxVQUFVLEdBQUcsS0FBSyxJQUFJO0FBQzlCLFNBQU8sYUFBYSxtQkFBbUIsSUFBSTtBQUM3Qzs7O0FDd0JBLElBQU0sb0JBQW9CO0FBRW5CLElBQU0sbUJBQWtDO0FBQUEsRUFDN0M7QUFBQSxJQUNFLE1BQU0sT0FBTztBQUFBLElBQ2IsU0FBUyxVQUFVO0FBQUEsSUFDbkIsZUFBZTtBQUFBLElBQ2YsU0FBUztBQUFBO0FBQUE7QUFBQTtBQUFBLE1BSVAsRUFBRSxNQUFNLFdBQVcsT0FBTyxTQUFTLE1BQU0sVUFBVSxLQUFLLElBQUksUUFBUSxLQUFLO0FBQUEsTUFDekUsRUFBRSxNQUFNLFdBQVcsZ0JBQWdCLFNBQVMsVUFBVSxjQUFjO0FBQUEsTUFDcEU7QUFBQSxRQUNFLE1BQU0sV0FBVztBQUFBLFFBQ2pCLFNBQVMsQ0FBQyxNQUFNLFVBQVUsV0FBVyxJQUFJLE1BQU0sVUFBVSxTQUFTLEVBQUU7QUFBQSxNQUN0RTtBQUFBLE1BQ0E7QUFBQSxRQUNFLE1BQU0sV0FBVztBQUFBLFFBQ2pCLFNBQVMsTUFBTSxVQUFVLFVBQVU7QUFBQSxRQUNuQyxZQUFZO0FBQUEsTUFDZDtBQUFBO0FBQUEsTUFFQSxFQUFFLE1BQU0sV0FBVyxlQUFlLFNBQVMsVUFBVSxhQUFhO0FBQUEsSUFDcEU7QUFBQSxFQUNGO0FBQUEsRUFDQTtBQUFBLElBQ0UsTUFBTSxPQUFPO0FBQUEsSUFDYixTQUFTLENBQUMsY0FBYyxVQUFVO0FBQUEsRUFDcEM7QUFBQSxFQUNBO0FBQUEsSUFDRSxNQUFNLE9BQU87QUFBQSxJQUNiLFNBQVM7QUFBQSxFQUNYO0FBQUEsRUFDQTtBQUFBLElBQ0UsTUFBTSxPQUFPO0FBQUEsSUFDYixTQUFTLFVBQVU7QUFBQSxJQUNuQixTQUFTO0FBQUEsTUFDUCxFQUFFLE1BQU0sV0FBVyxPQUFPLFNBQVMsTUFBTSxVQUFVLEtBQUssSUFBSSxRQUFRLEtBQUs7QUFBQSxJQUMzRTtBQUFBLEVBQ0Y7QUFDRjtBQWFBLFNBQVMsV0FDUCxPQUN1RDtBQUN2RCxNQUFJLFVBQVUsT0FBVyxRQUFPO0FBQ2hDLE1BQUksTUFBTSxRQUFRLEtBQUssRUFBRyxRQUFPO0FBQ2pDLE1BQUksT0FBTyxVQUFVLFlBQVksT0FBTyxVQUFVLFNBQVUsUUFBTztBQUNuRSxTQUFPLFdBQVcsS0FBSztBQUN6QjtBQUdBLFNBQVMsV0FBVyxPQUE2QztBQUMvRCxNQUFJLFVBQVUsT0FBVyxRQUFPO0FBQ2hDLFFBQU0sRUFBRSxPQUFPLE9BQU8sV0FBVyxVQUFVLElBQUk7QUFFL0MsTUFBSSxVQUFVLFVBQWEsVUFBVSxRQUFXO0FBQzlDLFdBQU8sWUFBWSxNQUFNLE9BQU8sT0FBTyxhQUFhLE9BQU8sYUFBYSxLQUFLO0FBQUEsRUFDL0U7QUFDQSxNQUFJLFVBQVUsT0FBVyxRQUFPLFlBQVksV0FBVyxPQUFPLGFBQWEsS0FBSztBQUNoRixNQUFJLFVBQVUsT0FBVyxRQUFPLFlBQVksV0FBVyxPQUFPLGFBQWEsS0FBSztBQUNoRixTQUFPO0FBQ1Q7QUFHQSxTQUFTLGtCQUFrQixRQUE0QixRQUFpQztBQUN0RixVQUFRLFFBQVE7QUFBQSxJQUNkLEtBQUs7QUFDSCxhQUFPLFNBQVM7QUFDaEIsYUFBTztBQUFBLElBQ1QsS0FBSztBQUNILGFBQU87QUFBQSxJQUNULEtBQUs7QUFDSCxhQUFPLE9BQU87QUFDZCxhQUFPLFNBQVM7QUFDaEIsYUFBTztBQUFBLElBQ1QsS0FBSztBQUNILGFBQU8sT0FBTztBQUNkLGFBQU87QUFBQSxFQUNYO0FBQ0Y7QUFlQSxTQUFTLElBQU8sU0FBd0IsZ0JBQWdCLE9BQW1CO0FBQ3pFLFNBQU8sSUFBSSxRQUFXLENBQUMsU0FBUyxXQUFXO0FBQ3pDLFlBQVEsWUFBWSxNQUFNLFFBQVEsUUFBUSxNQUFNO0FBQ2hELFlBQVEsVUFBVSxDQUFDLFVBQVU7QUFDM0IsVUFBSSxlQUFlO0FBRWpCLGNBQU0sZUFBZTtBQUNyQixjQUFNLGdCQUFnQjtBQUFBLE1BQ3hCO0FBQ0EsYUFBTyxhQUFhLFFBQVEsT0FBTyxzQ0FBa0IsRUFBRSxNQUFNLGlCQUFpQixDQUFDLENBQUM7QUFBQSxJQUNsRjtBQUFBLEVBQ0YsQ0FBQztBQUNIO0FBYU8sSUFBTSxtQkFBTixNQUE0QztBQUFBLEVBVWpELFlBQTZCLFNBQWlCLFNBQVM7QUFBMUI7QUFBQSxFQUEyQjtBQUFBLEVBQTNCO0FBQUEsRUFUckI7QUFBQSxFQUNBO0FBQUE7QUFBQSxFQUdBLFlBQVk7QUFBQTtBQUFBLEVBR1o7QUFBQSxFQUlSLE9BQXNCO0FBQ3BCLFdBQU8sS0FBSyxLQUFLLEVBQUUsS0FBSyxNQUFNLE1BQVM7QUFBQSxFQUN6QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBUVEsT0FBNkI7QUFJbkMsUUFBSSxLQUFLLFVBQVcsUUFBTyxRQUFRLE9BQU8sSUFBSSxzQkFBc0IsS0FBSyxNQUFNLENBQUM7QUFDaEYsUUFBSSxLQUFLLE9BQU8sT0FBVyxRQUFPLFFBQVEsUUFBUSxLQUFLLEVBQUU7QUFDekQsUUFBSSxLQUFLLFlBQVksT0FBVyxRQUFPLEtBQUs7QUFFNUMsU0FBSyxVQUFVLElBQUksUUFBcUIsQ0FBQyxTQUFTLFdBQVc7QUFDM0QsWUFBTSxVQUFVLFVBQVUsS0FBSyxLQUFLLFFBQVEsaUJBQWlCO0FBRTdELGNBQVEsa0JBQWtCLE1BQU07QUFDOUIsY0FBTSxLQUFLLFFBQVE7QUFDbkIsbUJBQVcsU0FBUyxrQkFBa0I7QUFDcEMsZ0JBQU0sY0FBYyxHQUFHLGlCQUFpQixTQUFTLE1BQU0sSUFBSSxJQUN2RCxRQUFRLFlBQWEsWUFBWSxNQUFNLElBQUksSUFDM0MsR0FBRyxrQkFBa0IsTUFBTSxNQUFNO0FBQUEsWUFDL0IsU0FBUyxNQUFNO0FBQUEsWUFDZixlQUFlLE1BQU0saUJBQWlCO0FBQUEsVUFDeEMsQ0FBQztBQUVMLHFCQUFXLFNBQVMsTUFBTSxXQUFXLENBQUMsR0FBRztBQUN2QyxnQkFBSSxZQUFZLFdBQVcsU0FBUyxNQUFNLElBQUksRUFBRztBQUNqRCx3QkFBWSxZQUFZLE1BQU0sTUFBTSxNQUFNLFNBQVM7QUFBQSxjQUNqRCxRQUFRLE1BQU0sVUFBVTtBQUFBLGNBQ3hCLFlBQVksTUFBTSxjQUFjO0FBQUEsWUFDbEMsQ0FBQztBQUFBLFVBQ0g7QUFBQSxRQUNGO0FBQUEsTUFDRjtBQUVBLGNBQVEsWUFBWSxNQUFNO0FBQ3hCLGFBQUssS0FBSyxRQUFRO0FBRWxCLGdCQUFRLE9BQU8sVUFBVSxNQUFNO0FBQzdCLGVBQUssS0FBSztBQUNWLGVBQUssVUFBVTtBQUFBLFFBQ2pCO0FBVUEsZ0JBQVEsT0FBTyxrQkFBa0IsTUFBTTtBQUNyQyxrQkFBUSxPQUFPLE1BQU07QUFDckIsZUFBSyxLQUFLO0FBQ1YsZUFBSyxVQUFVO0FBQUEsUUFDakI7QUFDQSxnQkFBUSxRQUFRLE1BQU07QUFBQSxNQUN4QjtBQUVBLGNBQVEsVUFBVSxNQUNoQixPQUFPLGFBQWEsUUFBUSxPQUFPLHNDQUFrQixFQUFFLE1BQU0sY0FBYyxDQUFDLENBQUM7QUFHL0UsY0FBUSxZQUFZLE1BQ2xCO0FBQUEsUUFDRSxJQUFJO0FBQUEsVUFDRjtBQUFBLFVBQ0EsRUFBRSxNQUFNLGtCQUFrQjtBQUFBLFFBQzVCO0FBQUEsTUFDRjtBQUFBLElBQ0osQ0FBQztBQUVELFdBQU8sS0FBSztBQUFBLEVBQ2Q7QUFBQSxFQUVBLFFBQWM7QUFDWixTQUFLLElBQUksTUFBTTtBQUNmLFNBQUssS0FBSztBQUNWLFNBQUssVUFBVTtBQUFBLEVBQ2pCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFTQSxNQUFNLFlBQ0osUUFDQSxNQUNBLElBQ1k7QUFDWixVQUFNLEtBQUssTUFBTSxLQUFLLEtBQUs7QUFFM0IsV0FBTyxJQUFJLFFBQVcsQ0FBQyxTQUFTLFdBQVc7QUFDekMsVUFBSTtBQUNKLFVBQUk7QUFDRixnQkFBUSxHQUFHLFlBQVksUUFBUSxJQUFJO0FBQUEsTUFDckMsU0FBUyxPQUFPO0FBRWQsZUFBTyxlQUFlLE9BQU8sd0NBQVUsRUFBRSxNQUFNLG9CQUFvQixDQUFDLENBQUM7QUFDckU7QUFBQSxNQUNGO0FBRUEsVUFBSTtBQUNKLFVBQUksVUFBVTtBQUVkLFlBQU0sYUFBYSxNQUFNO0FBQ3ZCLGtCQUFVO0FBQ1YsZ0JBQVEsTUFBTTtBQUFBLE1BQ2hCO0FBQ0EsWUFBTSxVQUFVLE1BQU07QUFDcEIsWUFBSSxRQUFTO0FBQ2Isa0JBQVU7QUFDVixlQUFPLGFBQWEsTUFBTSxPQUFPLDRDQUFtQixFQUFFLE1BQU0scUJBQXFCLENBQUMsQ0FBQztBQUFBLE1BQ3JGO0FBQ0EsWUFBTSxVQUFVLE1BQU07QUFDcEIsWUFBSSxRQUFTO0FBQ2Isa0JBQVU7QUFDVixlQUFPLGFBQWEsTUFBTSxPQUFPLHNDQUFrQixFQUFFLE1BQU0scUJBQXFCLENBQUMsQ0FBQztBQUFBLE1BQ3BGO0FBRUEsWUFBTSxLQUFLLEtBQUssT0FBTyxPQUFPLE1BQU07QUFFcEMsU0FBRyxFQUFFLEVBQUU7QUFBQSxRQUNMLENBQUMsVUFBVTtBQUNULG1CQUFTO0FBS1QsY0FBSTtBQUNGLGtCQUFNLFNBQVM7QUFBQSxVQUNqQixRQUFRO0FBQUEsVUFFUjtBQUFBLFFBQ0Y7QUFBQSxRQUNBLENBQUMsVUFBbUI7QUFDbEIsb0JBQVU7QUFDVixjQUFJO0FBQ0Ysa0JBQU0sTUFBTTtBQUFBLFVBQ2QsUUFBUTtBQUFBLFVBRVI7QUFDQSxpQkFBTyxlQUFlLE9BQU8sb0RBQVksRUFBRSxNQUFNLGlCQUFpQixDQUFDLENBQUM7QUFBQSxRQUN0RTtBQUFBLE1BQ0Y7QUFBQSxJQUNGLENBQUM7QUFBQSxFQUNIO0FBQUEsRUFFUSxPQUFPLE9BQXVCLFNBQXlCO0FBQzdELFVBQU0sYUFBYSxJQUFJLElBQUksT0FBTztBQUVsQyxVQUFNLFNBQVMsQ0FBQ0MsV0FBd0I7QUFDdEMsVUFBSSxDQUFDLFdBQVcsSUFBSUEsTUFBSyxHQUFHO0FBRTFCLGNBQU0sSUFBSTtBQUFBLFVBQ1IsNkNBQWVBLE1BQUsseUZBQWtDLFFBQVEsS0FBSyxJQUFJLENBQUM7QUFBQSxVQUN4RSxFQUFFLE1BQU0sb0JBQW9CO0FBQUEsUUFDOUI7QUFBQSxNQUNGO0FBQUEsSUFDRjtBQUVBLFVBQU0sUUFBUSxDQUFDLFNBQWlDO0FBQzlDLGFBQU8sSUFBSTtBQUNYLGFBQU8sTUFBTSxZQUFZLElBQUk7QUFBQSxJQUMvQjtBQUVBLFVBQU0sTUFFRjtBQUFBLE1BQ0YsS0FBSyxDQUFDLEdBQUcsVUFBVSxJQUFJLE1BQU0sQ0FBQyxFQUFFLElBQUksS0FBSyxDQUFDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFRMUMsd0JBQXdCLE9BQU8sV0FBVyxVQUFVO0FBQ2xELFlBQUk7QUFDRixnQkFBTSxNQUFNLE1BQU0sSUFBSSxNQUFNLFNBQVMsRUFBRSxJQUFJLEtBQUssR0FBRyxJQUFJO0FBSXZELGlCQUFPLEVBQUUsSUFBSSxNQUFNLEtBQUssT0FBTyxRQUFRLFdBQVcsTUFBTSxPQUFPLEdBQUcsRUFBRTtBQUFBLFFBQ3RFLFNBQVMsT0FBTztBQUlkLGdCQUFNLGNBQWMsaUJBQWlCLGVBQWUsTUFBTSxRQUFRO0FBQ2xFLGNBQ0UsT0FBTyxnQkFBZ0IsWUFDdkIsZ0JBQWdCLFFBQ2hCLFVBQVUsZUFDVCxZQUFpQyxTQUFTLG1CQUMzQztBQUNBLG1CQUFPLEVBQUUsSUFBSSxPQUFPLFFBQVEsWUFBWTtBQUFBLFVBQzFDO0FBQ0EsZ0JBQU07QUFBQSxRQUNSO0FBQUEsTUFDRjtBQUFBLE1BQ0EsS0FBSyxDQUFDLEdBQUcsT0FBTyxRQUNkLFFBQVEsU0FDSixJQUFJLE1BQU0sQ0FBQyxFQUFFLElBQUksS0FBSyxDQUFDLEVBQUUsS0FBSyxNQUFNLE1BQVMsSUFDN0MsSUFBSSxNQUFNLENBQUMsRUFBRSxJQUFJLE9BQU8sR0FBRyxDQUFDLEVBQUUsS0FBSyxNQUFNLE1BQVM7QUFBQSxNQUN4RCxLQUFLLENBQUssR0FBVyxRQUNuQixJQUFJLE1BQU0sQ0FBQyxFQUFFLElBQUksR0FBRyxDQUFDO0FBQUEsTUFDdkIsUUFBUSxDQUFLLEdBQVcsT0FBb0IsVUFBbUI7QUFDN0QsMkJBQW1CLEtBQUs7QUFDeEIsZUFBTyxJQUFJLE1BQU0sQ0FBQyxFQUFFLE9BQU8sV0FBVyxLQUFLLEdBQUcsS0FBSyxDQUFDO0FBQUEsTUFDdEQ7QUFBQSxNQUNBLFFBQVEsQ0FBQyxHQUFHLFFBQVEsSUFBSSxNQUFNLENBQUMsRUFBRSxPQUFPLEdBQUcsQ0FBQyxFQUFFLEtBQUssTUFBTSxNQUFTO0FBQUEsTUFDbEUsT0FBTyxDQUFDLE1BQU0sSUFBSSxNQUFNLENBQUMsRUFBRSxNQUFNLENBQUMsRUFBRSxLQUFLLE1BQU0sTUFBUztBQUFBLE1BQ3hELE9BQU8sQ0FBQyxHQUFHLFVBQXVCLElBQUksTUFBTSxDQUFDLEVBQUUsTUFBTSxXQUFXLEtBQUssQ0FBQyxDQUFDO0FBQUEsTUFFdkUsY0FBYyxDQUFLLEdBQVcsT0FBZSxRQUMzQyxJQUFJLE1BQU0sQ0FBQyxFQUFFLE1BQU0sS0FBSyxFQUFFLElBQUksR0FBRyxDQUFDO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFJcEMsaUJBQWlCLENBQUMsR0FBRyxPQUFPLFFBQzFCLElBQUksTUFBTSxDQUFDLEVBQUUsTUFBTSxLQUFLLEVBQUUsT0FBTyxHQUFHLENBQUM7QUFBQSxNQUN2QyxpQkFBaUIsQ0FBSyxHQUFXLE9BQWUsVUFBeUI7QUFDdkUsZUFBTyxJQUFJLE1BQU0sQ0FBQyxFQUFFLE1BQU0sS0FBSyxFQUFFLE9BQU8sV0FBVyxLQUFLLENBQUMsQ0FBQztBQUFBLE1BQzVEO0FBQUEsTUFDQSxnQkFBZ0IsQ0FBQyxHQUFHLE9BQU8sVUFBeUI7QUFDbEQsZUFBTyxJQUFJLE1BQU0sQ0FBQyxFQUFFLE1BQU0sS0FBSyxFQUFFLE1BQU0sV0FBVyxLQUFLLENBQUMsQ0FBQztBQUFBLE1BQzNEO0FBQUEsTUFFQSxTQUFTLENBQ1AsR0FDQSxTQUNBLFVBQ0csS0FBSyxVQUFVLE1BQU0sQ0FBQyxHQUFHLFNBQVMsS0FBSztBQUFBLElBQzlDO0FBQ0EsV0FBTztBQUFBLEVBQ1Q7QUFBQTtBQUFBLEVBR1EsVUFDTixRQUNBLFNBQ0EsT0FDZTtBQUNmLHVCQUFtQixRQUFRLEtBQUs7QUFFaEMsV0FBTyxJQUFJLFFBQWMsQ0FBQyxTQUFTLFdBQVc7QUFDNUMsVUFBSSxVQUFVO0FBQ2QsWUFBTSxRQUFRLFFBQVE7QUFDdEIsWUFBTSxRQUFRLFdBQVcsRUFBRSxPQUFPLFFBQVEsT0FBTyxPQUFPLFFBQVEsTUFBTSxDQUFDO0FBQ3ZFLFlBQU0sWUFBZ0MsUUFBUSxhQUFhO0FBRTNELFlBQU0sVUFBVSxPQUFPLFdBQVcsT0FBTyxTQUFTO0FBRWxELGNBQVEsWUFBWSxNQUFNO0FBQ3hCLGNBQU0sU0FBUyxRQUFRO0FBQ3ZCLFlBQUksV0FBVyxNQUFNO0FBQ25CLGtCQUFRO0FBQ1I7QUFBQSxRQUNGO0FBQ0EsWUFBSSxVQUFVLFVBQWEsV0FBVyxPQUFPO0FBQzNDLGtCQUFRO0FBQ1I7QUFBQSxRQUNGO0FBRUEsbUJBQVc7QUFHWCxjQUFNLFNBQVMsTUFBTSxPQUFPLE9BQVksT0FBTyxHQUFZO0FBQzNELFlBQUksQ0FBQyxrQkFBa0IsUUFBUSxNQUFNLEdBQUc7QUFDdEMsa0JBQVE7QUFBQSxRQUNWO0FBQUEsTUFDRjtBQUVBLGNBQVEsVUFBVSxNQUNoQixPQUFPLGFBQWEsUUFBUSxPQUFPLHNDQUFrQixFQUFFLE1BQU0saUJBQWlCLENBQUMsQ0FBQztBQUFBLElBQ3BGLENBQUM7QUFBQSxFQUNIO0FBQUE7QUFBQSxFQUlBLE1BQU0sSUFBSSxPQUFlLE9BQWlDO0FBQ3hELFdBQU8sS0FBSyxZQUFZLENBQUMsS0FBSyxHQUFHLGFBQWEsQ0FBQyxPQUFPLEdBQUcsSUFBSSxPQUFPLEtBQUssQ0FBQztBQUFBLEVBQzVFO0FBQUEsRUFFQSxNQUFNLElBQUksT0FBZSxPQUFnQixLQUE0QjtBQUNuRSxXQUFPLEtBQUssWUFBWSxDQUFDLEtBQUssR0FBRyxhQUFhLENBQUMsT0FBTyxHQUFHLElBQUksT0FBTyxPQUFPLEdBQUcsQ0FBQztBQUFBLEVBQ2pGO0FBQUEsRUFFQSxNQUFNLElBQU8sT0FBZSxLQUFvQztBQUM5RCxXQUFPLEtBQUssWUFBWSxDQUFDLEtBQUssR0FBRyxZQUFZLENBQUMsT0FBTyxHQUFHLElBQU8sT0FBTyxHQUFHLENBQUM7QUFBQSxFQUM1RTtBQUFBLEVBRUEsTUFBTSxPQUFVLE9BQWUsT0FBb0IsT0FBOEI7QUFDL0UsV0FBTyxLQUFLLFlBQVksQ0FBQyxLQUFLLEdBQUcsWUFBWSxDQUFDLE9BQU8sR0FBRyxPQUFVLE9BQU8sT0FBTyxLQUFLLENBQUM7QUFBQSxFQUN4RjtBQUFBLEVBRUEsTUFBTSxPQUFPLE9BQWUsS0FBMkI7QUFDckQsV0FBTyxLQUFLLFlBQVksQ0FBQyxLQUFLLEdBQUcsYUFBYSxDQUFDLE9BQU8sR0FBRyxPQUFPLE9BQU8sR0FBRyxDQUFDO0FBQUEsRUFDN0U7QUFBQSxFQUVBLE1BQU0sTUFBTSxPQUE4QjtBQUN4QyxXQUFPLEtBQUssWUFBWSxDQUFDLEtBQUssR0FBRyxhQUFhLENBQUMsT0FBTyxHQUFHLE1BQU0sS0FBSyxDQUFDO0FBQUEsRUFDdkU7QUFBQSxFQUVBLE1BQU0sTUFBTSxPQUFlLE9BQXFDO0FBQzlELFdBQU8sS0FBSyxZQUFZLENBQUMsS0FBSyxHQUFHLFlBQVksQ0FBQyxPQUFPLEdBQUcsTUFBTSxPQUFPLEtBQUssQ0FBQztBQUFBLEVBQzdFO0FBQUEsRUFFQSxNQUFNLGFBQ0osT0FDQSxPQUNBLEtBQ3dCO0FBQ3hCLFdBQU8sS0FBSztBQUFBLE1BQVksQ0FBQyxLQUFLO0FBQUEsTUFBRztBQUFBLE1BQVksQ0FBQyxPQUM1QyxHQUFHLGFBQWdCLE9BQU8sT0FBTyxHQUFHO0FBQUEsSUFDdEM7QUFBQSxFQUNGO0FBQUEsRUFFQSxNQUFNLGdCQUNKLE9BQ0EsT0FDQSxLQUM0QjtBQUM1QixXQUFPLEtBQUs7QUFBQSxNQUFZLENBQUMsS0FBSztBQUFBLE1BQUc7QUFBQSxNQUFZLENBQUMsT0FDNUMsR0FBRyxnQkFBZ0IsT0FBTyxPQUFPLEdBQUc7QUFBQSxJQUN0QztBQUFBLEVBQ0Y7QUFBQSxFQUVBLE1BQU0sZ0JBQ0osT0FDQSxPQUNBLE9BQ2M7QUFDZCxXQUFPLEtBQUs7QUFBQSxNQUFZLENBQUMsS0FBSztBQUFBLE1BQUc7QUFBQSxNQUFZLENBQUMsT0FDNUMsR0FBRyxnQkFBbUIsT0FBTyxPQUFPLEtBQUs7QUFBQSxJQUMzQztBQUFBLEVBQ0Y7QUFBQSxFQUVBLE1BQU0sZUFDSixPQUNBLE9BQ0EsT0FDaUI7QUFDakIsV0FBTyxLQUFLO0FBQUEsTUFBWSxDQUFDLEtBQUs7QUFBQSxNQUFHO0FBQUEsTUFBWSxDQUFDLE9BQzVDLEdBQUcsZUFBZSxPQUFPLE9BQU8sS0FBSztBQUFBLElBQ3ZDO0FBQUEsRUFDRjtBQUFBLEVBRUEsTUFBTSxRQUNKLE9BQ0EsU0FDQSxPQUNlO0FBSWYsV0FBTyxLQUFLLFlBQVksQ0FBQyxLQUFLLEdBQUcsYUFBYSxPQUFPLE9BQU87QUFDMUQsWUFBTSxHQUFHLFFBQVcsT0FBTyxTQUFTLEtBQUs7QUFBQSxJQUMzQyxDQUFDO0FBQUEsRUFDSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQWdCQSxNQUFNLFVBQW9DO0FBQ3hDLFFBQUksS0FBSyxlQUFlLE9BQVcsUUFBTyxLQUFLO0FBQy9DLFNBQUssWUFBWTtBQUNqQixVQUFNLFdBQVcsWUFBc0M7QUFDckQsV0FBSyxNQUFNO0FBQ1gsWUFBTSxJQUFJLFFBQWMsQ0FBQyxTQUFTLFdBQVc7QUFDM0MsY0FBTSxVQUFVLFVBQVUsZUFBZSxLQUFLLE1BQU07QUFDcEQsZ0JBQVEsWUFBWSxNQUFNLFFBQVE7QUFDbEMsZ0JBQVEsVUFBVSxNQUNoQixPQUFPLGFBQWEsUUFBUSxPQUFPLDhDQUFXLEVBQUUsTUFBTSxpQkFBaUIsQ0FBQyxDQUFDO0FBQzNFLGdCQUFRLFlBQVksTUFBTTtBQUFBLFFBRTFCO0FBQUEsTUFDRixDQUFDO0FBQ0QsYUFBTyxFQUFFLFFBQVEsS0FBSyxRQUFRLGtCQUFrQixNQUFNLGVBQWUsV0FBVyxPQUFPO0FBQUEsSUFDekYsR0FBRztBQUlILFNBQUssYUFBYSxRQUFRLE1BQU0sQ0FBQyxVQUFtQjtBQUNsRCxXQUFLLFlBQVk7QUFDakIsV0FBSyxhQUFhO0FBQ2xCLFlBQU07QUFBQSxJQUNSLENBQUM7QUFDRCxXQUFPLEtBQUs7QUFBQSxFQUNkO0FBQ0Y7QUFHTyxJQUFNLGtCQUErQjs7O0FDdmpCNUMsSUFBTSxJQUFJLENBQUMsZUFBK0IsSUFBSSxXQUFXLFFBQVEsTUFBTSxJQUFJLENBQUM7QUFHNUUsSUFBTSxZQUFZO0FBUWxCLFNBQVMsUUFBUSxHQUFvQjtBQUNuQyxNQUFJLE9BQU8sTUFBTSxTQUFVLFFBQU87QUFDbEMsTUFBSSxPQUFPLE1BQU0sU0FBVSxRQUFPO0FBQ2xDLE1BQUksTUFBTSxRQUFRLENBQUMsRUFBRyxRQUFPO0FBQzdCLFNBQU87QUFDVDtBQUVBLFNBQVMsWUFBWSxHQUEwQixHQUFrQztBQUMvRSxNQUFJLE1BQU0sUUFBUSxDQUFDLEtBQUssTUFBTSxRQUFRLENBQUMsR0FBRztBQUV4QyxRQUFJLE1BQU0sUUFBUSxDQUFDLE1BQU0sTUFBTSxRQUFRLENBQUMsRUFBRyxRQUFPLFFBQVEsQ0FBQyxJQUFJLFFBQVEsQ0FBQztBQUN4RSxVQUFNLE9BQU87QUFDYixVQUFNLE9BQU87QUFDYixVQUFNLE1BQU0sS0FBSyxJQUFJLEtBQUssUUFBUSxLQUFLLE1BQU07QUFDN0MsYUFBUyxJQUFJLEdBQUcsSUFBSSxLQUFLLEtBQUs7QUFDNUIsWUFBTSxPQUFPLFlBQVksS0FBSyxDQUFDLEdBQUksS0FBSyxDQUFDLENBQUU7QUFDM0MsVUFBSSxTQUFTLEVBQUcsUUFBTztBQUFBLElBQ3pCO0FBQ0EsV0FBTyxLQUFLLFNBQVMsS0FBSztBQUFBLEVBQzVCO0FBRUEsUUFBTSxXQUFXLFFBQVEsQ0FBQyxJQUFJLFFBQVEsQ0FBQztBQUN2QyxNQUFJLGFBQWEsRUFBRyxRQUFPO0FBQzNCLE1BQUksT0FBTyxNQUFNLFlBQVksT0FBTyxNQUFNLFNBQVUsUUFBTyxJQUFJO0FBQy9ELFFBQU0sS0FBSyxPQUFPLENBQUM7QUFDbkIsUUFBTSxLQUFLLE9BQU8sQ0FBQztBQUNuQixTQUFPLEtBQUssS0FBSyxLQUFLLEtBQUssS0FBSyxJQUFJO0FBQ3RDO0FBRUEsU0FBUyxXQUFXLEtBQTRCLE9BQTZCO0FBQzNFLE1BQUksVUFBVSxPQUFXLFFBQU87QUFDaEMsUUFBTSxFQUFFLE9BQU8sT0FBTyxXQUFXLFVBQVUsSUFBSTtBQUMvQyxNQUFJLFVBQVUsUUFBVztBQUN2QixVQUFNLE9BQU8sWUFBWSxLQUFLLEtBQUs7QUFDbkMsUUFBSSxPQUFPLEtBQU0sU0FBUyxLQUFLLGNBQWMsS0FBTyxRQUFPO0FBQUEsRUFDN0Q7QUFDQSxNQUFJLFVBQVUsUUFBVztBQUN2QixVQUFNLE9BQU8sWUFBWSxLQUFLLEtBQUs7QUFDbkMsUUFBSSxPQUFPLEtBQU0sU0FBUyxLQUFLLGNBQWMsS0FBTyxRQUFPO0FBQUEsRUFDN0Q7QUFDQSxTQUFPO0FBQ1Q7QUFHQSxTQUFTLFlBQVksT0FBZ0IsTUFBdUI7QUFDMUQsTUFBSSxVQUFtQjtBQUN2QixhQUFXLFdBQVcsS0FBSyxNQUFNLEdBQUcsR0FBRztBQUNyQyxRQUFJLFlBQVksUUFBUSxPQUFPLFlBQVksU0FBVSxRQUFPO0FBQzVELGNBQVcsUUFBb0MsT0FBTztBQUFBLEVBQ3hEO0FBQ0EsU0FBTztBQUNUO0FBR0EsU0FBUyxVQUFVLFFBQWlDLE1BQWMsT0FBc0I7QUFDdEYsUUFBTSxXQUFXLEtBQUssTUFBTSxHQUFHO0FBQy9CLE1BQUksVUFBbUM7QUFDdkMsV0FBUyxJQUFJLEdBQUcsSUFBSSxTQUFTLFNBQVMsR0FBRyxLQUFLO0FBQzVDLFVBQU0sVUFBVSxTQUFTLENBQUM7QUFDMUIsVUFBTSxPQUFPLFFBQVEsT0FBTztBQUM1QixRQUFJLFNBQVMsUUFBUSxPQUFPLFNBQVMsU0FBVSxTQUFRLE9BQU8sSUFBSSxDQUFDO0FBQ25FLGNBQVUsUUFBUSxPQUFPO0FBQUEsRUFDM0I7QUFDQSxVQUFRLFNBQVMsU0FBUyxTQUFTLENBQUMsQ0FBRSxJQUFJO0FBQzVDO0FBRUEsU0FBUyxXQUFXLEdBQTJCO0FBQzdDLFNBQU8sT0FBTyxNQUFNLFlBQVksT0FBTyxNQUFNO0FBQy9DO0FBNkJBLFNBQVMsZUFBZSxRQUFnQztBQUN0RCxRQUFNLFFBQVEsT0FBTztBQUNyQixRQUFNLFVBQVUsT0FBTyxPQUFPLFlBQVksV0FBVyxDQUFDLE9BQU8sT0FBTyxJQUFJLENBQUMsR0FBRyxPQUFPLE9BQU87QUFDMUYsUUFBTSxZQUFZLFFBQVEsSUFBSSxDQUFDLElBQUksTUFBTSxLQUFLLENBQUMsRUFBRTtBQUVqRCxRQUFNLFVBQXVCLENBQUM7QUFDOUIsUUFBTSxTQUFTLG9CQUFJLElBQXVCO0FBRTFDLEdBQUMsT0FBTyxXQUFXLENBQUMsR0FBRyxRQUFRLENBQUMsT0FBTyxZQUFZO0FBQ2pELFVBQU0sUUFBUSxPQUFPLE1BQU0sWUFBWSxXQUFXLENBQUMsTUFBTSxPQUFPLElBQUksQ0FBQyxHQUFHLE1BQU0sT0FBTztBQUNyRixRQUFJLE1BQU0sZUFBZSxRQUFRLE1BQU0sV0FBVyxHQUFHO0FBR25ELFlBQU0sSUFBSTtBQUFBLFFBQ1IscUJBQU0sTUFBTSxJQUFJLG1GQUFpQyxLQUFLLFVBQVUsTUFBTSxPQUFPLENBQUM7QUFBQSxNQUNoRjtBQUFBLElBQ0Y7QUFDQSxVQUFNLE9BQWtCO0FBQUEsTUFDdEIsTUFBTSxNQUFNO0FBQUEsTUFDWixZQUFZLE1BQU0sZUFBZTtBQUFBLE1BQ2pDLFFBQVEsTUFBTSxXQUFXO0FBQUEsTUFDekI7QUFBQSxNQUNBLFNBQVMsTUFBTSxlQUFlLE9BQU8sQ0FBQyxJQUFJLE1BQU0sSUFBSSxDQUFDLElBQUksTUFBTSxLQUFLLE9BQU8sSUFBSSxDQUFDLEVBQUU7QUFBQSxNQUNsRixZQUFZLE1BQU0sZUFBZSxPQUFPLEdBQUcsS0FBSyxPQUFPLE9BQU8sS0FBSztBQUFBLE1BQ25FLFlBQVksTUFBTSxlQUFlLE9BQU8sR0FBRyxLQUFLLE9BQU8sT0FBTyxVQUFVO0FBQUEsSUFDMUU7QUFDQSxZQUFRLEtBQUssSUFBSTtBQUNqQixXQUFPLElBQUksS0FBSyxNQUFNLElBQUk7QUFBQSxFQUM1QixDQUFDO0FBRUQsU0FBTyxFQUFFLFFBQVEsT0FBTyxXQUFXLFNBQVMsWUFBWSxRQUFRLFNBQVMsT0FBTztBQUNsRjtBQUVBLElBQU0sZ0JBQU4sTUFBeUM7QUFBQSxFQUN0QixRQUFxQixDQUFDO0FBQUEsRUFDdEIsYUFBYSxvQkFBSSxJQUF1QjtBQUFBLEVBQ2pEO0FBQUEsRUFDQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBV0EsWUFBWTtBQUFBO0FBQUEsRUFHWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFNQSxRQUEwQixRQUFRLFFBQVE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBTTFDLFlBQVk7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFPSDtBQUFBLEVBRWpCLFlBQVksU0FBK0I7QUFDekMsU0FBSyxnQkFBZ0IsUUFBUTtBQUM3QixlQUFXLFVBQVUsUUFBUSxRQUFRO0FBQ25DLFlBQU0sT0FBTyxlQUFlLE1BQU07QUFDbEMsV0FBSyxNQUFNLEtBQUssSUFBSTtBQUNwQixXQUFLLFdBQVcsSUFBSSxLQUFLLE9BQU8sSUFBSTtBQUFBLElBQ3RDO0FBQUEsRUFDRjtBQUFBO0FBQUEsRUFJQSxPQUFzQjtBQUNwQixXQUFPLEtBQUssV0FBVyxFQUFFLEtBQUssTUFBTSxNQUFTO0FBQUEsRUFDL0M7QUFBQSxFQUVBLFFBQWM7QUFDWixTQUFLLFFBQVEsTUFBTTtBQUNuQixTQUFLLFNBQVM7QUFDZCxTQUFLLFVBQVU7QUFBQSxFQUNqQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFlQSxNQUFNLFVBQW9DO0FBR3hDLFFBQUksS0FBSyxlQUFlLE9BQVcsUUFBTyxLQUFLO0FBRS9DLFVBQU0sTUFBTSxZQUFzQztBQUdoRCxZQUFNLFNBQVMsTUFBTSxLQUFLLFdBQVc7QUFFckMsVUFBSSxnQkFBZ0I7QUFDcEIsaUJBQVcsUUFBUSxLQUFLLE9BQU87QUFDN0IsZUFBTyxLQUFLLHdCQUF3QixFQUFFLEtBQUssS0FBSyxDQUFDLEVBQUU7QUFDbkQseUJBQWlCO0FBQ2pCLG1CQUFXLFNBQVMsS0FBSyxTQUFTO0FBQ2hDLGNBQUksTUFBTSxlQUFlLEtBQU07QUFDL0IsaUJBQU8sS0FBSyx3QkFBd0IsRUFBRSxNQUFNLFVBQVcsQ0FBQyxFQUFFO0FBQzFELDJCQUFpQjtBQUFBLFFBQ25CO0FBQUEsTUFDRjtBQUNBLGFBQU8sS0FBSyx3QkFBd0IsRUFBRSxTQUFTLENBQUMsRUFBRTtBQUNsRCx1QkFBaUI7QUFFakIsYUFBTyxLQUFLLFFBQVE7QUFFcEIsV0FBSyxNQUFNO0FBR1gsV0FBSyxZQUFZO0FBRWpCLFVBQUksT0FBTyxtQkFBbUIsUUFBVztBQUN2QyxlQUFPO0FBQUEsVUFDTCxRQUFRO0FBQUEsVUFDUixrQkFBa0I7QUFBQSxVQUNsQixRQUFRO0FBQUEsVUFDUjtBQUFBLFFBQ0Y7QUFBQSxNQUNGO0FBQ0EsWUFBTSxVQUFVLE1BQU0sT0FBTyxlQUFlO0FBQzVDLGFBQU8sRUFBRSxHQUFHLFNBQVMsY0FBYztBQUFBLElBQ3JDO0FBRUEsVUFBTSxTQUFTLEtBQUssTUFBTSxLQUFLLEtBQUssR0FBRztBQUl2QyxTQUFLLGFBQWEsT0FBTyxNQUFNLENBQUMsVUFBbUI7QUFDakQsV0FBSyxhQUFhO0FBQ2xCLFdBQUssWUFBWTtBQUNqQixZQUFNO0FBQUEsSUFDUixDQUFDO0FBQ0QsU0FBSyxRQUFRLE9BQU87QUFBQSxNQUNsQixNQUFNO0FBQUEsTUFDTixNQUFNO0FBQUEsSUFDUjtBQUNBLFdBQU8sS0FBSztBQUFBLEVBQ2Q7QUFBQTtBQUFBLEVBR1EsYUFBb0M7QUFJMUMsUUFBSSxLQUFLLFVBQVcsUUFBTyxRQUFRLE9BQU8sSUFBSSxzQkFBc0IsUUFBUSxDQUFDO0FBQzdFLFFBQUksS0FBSyxXQUFXLE9BQVcsUUFBTyxRQUFRLFFBQVEsS0FBSyxNQUFNO0FBQ2pFLFFBQUksS0FBSyxZQUFZLE9BQVcsUUFBTyxLQUFLO0FBQzVDLFNBQUssVUFBVSxRQUFRLFFBQVEsRUFBRSxLQUFLLE1BQU07QUFDMUMsWUFBTSxTQUFTLEtBQUssY0FBYztBQUNsQyxVQUFJO0FBQ0YsYUFBSyxhQUFhLE1BQU07QUFBQSxNQUMxQixTQUFTLE9BQU87QUFDZCxlQUFPLE1BQU07QUFDYixhQUFLLFVBQVU7QUFDZixjQUFNO0FBQUEsTUFDUjtBQUNBLFdBQUssU0FBUztBQUNkLGFBQU87QUFBQSxJQUNULENBQUM7QUFDRCxXQUFPLEtBQUs7QUFBQSxFQUNkO0FBQUEsRUFFUSxhQUFhLFFBQTRCO0FBQy9DLGVBQVcsUUFBUSxLQUFLLE9BQU87QUFDN0IsWUFBTSxjQUFjO0FBQUE7QUFBQSxRQUVsQixHQUFHLEtBQUssVUFBVSxJQUFJLENBQUMsTUFBTSxFQUFFLENBQUMsQ0FBQztBQUFBLFFBQ2pDLEdBQUcsS0FBSyxRQUNMLE9BQU8sQ0FBQyxNQUFNLENBQUMsRUFBRSxVQUFVLEVBQzNCLFFBQVEsQ0FBQyxNQUFNLEVBQUUsUUFBUSxJQUFJLENBQUMsTUFBTSxFQUFFLENBQUMsQ0FBQyxDQUFDO0FBQUEsUUFDNUMsR0FBRyxFQUFFLEtBQUssVUFBVSxDQUFDO0FBQUEsUUFDckIsZ0JBQWdCLEtBQUssVUFBVSxJQUFJLENBQUMsRUFBRSxLQUFLLElBQUksQ0FBQztBQUFBLE1BQ2xEO0FBQ0EsYUFBTztBQUFBLFFBQ0wsOEJBQThCLEVBQUUsS0FBSyxLQUFLLENBQUMsS0FBSyxZQUFZLEtBQUssSUFBSSxDQUFDO0FBQUEsTUFDeEU7QUFFQSxpQkFBVyxTQUFTLEtBQUssU0FBUztBQUNoQyxZQUFJLE1BQU0sWUFBWTtBQUNwQixpQkFBTztBQUFBLFlBQ0wsOEJBQThCLEVBQUUsTUFBTSxVQUFXLENBQUMsS0FBSztBQUFBLGNBQ3JELEdBQUcsS0FBSyxVQUFVLElBQUksQ0FBQyxNQUFNLEVBQUUsQ0FBQyxDQUFDO0FBQUEsY0FDakM7QUFBQSxZQUNGLEVBQUUsS0FBSyxJQUFJLENBQUM7QUFBQSxVQUNkO0FBQ0EsaUJBQU87QUFBQSxZQUNMLDhCQUE4QixFQUFFLE1BQU0sVUFBVyxDQUFDLE9BQU8sRUFBRSxNQUFNLFVBQVcsQ0FBQztBQUFBLFVBQy9FO0FBQ0E7QUFBQSxRQUNGO0FBQ0EsY0FBTSxTQUFTLE1BQU0sU0FBUyxZQUFZO0FBQzFDLGVBQU87QUFBQSxVQUNMLFVBQVUsTUFBTSx1QkFBdUIsRUFBRSxHQUFHLEtBQUssS0FBSyxNQUFNLE1BQU0sUUFBUSxDQUFDLENBQUMsRUFBRSxDQUFDLE9BQ3ZFLEVBQUUsS0FBSyxLQUFLLENBQUMsS0FBSyxNQUFNLFFBQVEsSUFBSSxDQUFDLEVBQUUsS0FBSyxJQUFJLENBQUM7QUFBQSxRQUMzRDtBQUFBLE1BQ0Y7QUFBQSxJQUNGO0FBRUEsV0FBTztBQUFBLE1BQ0wsOEJBQThCLEVBQUUsU0FBUyxDQUFDO0FBQUEsSUFDNUM7QUFBQSxFQUNGO0FBQUE7QUFBQSxFQUlBLFlBQ0UsUUFDQSxPQUNBLElBQ1k7QUFDWixRQUFJLEtBQUssWUFBWSxHQUFHO0FBQ3RCLFlBQU0sSUFBSSxNQUFNLGdIQUFnQztBQUFBLElBQ2xEO0FBRUEsZUFBVyxRQUFRLFFBQVE7QUFDekIsVUFBSSxDQUFDLEtBQUssV0FBVyxJQUFJLElBQUksR0FBRztBQUM5QixjQUFNLElBQUk7QUFBQSxVQUNSLDJFQUFvQixJQUFJLHVDQUFTLENBQUMsR0FBRyxLQUFLLFdBQVcsS0FBSyxDQUFDLEVBQUUsS0FBSyxJQUFJLENBQUM7QUFBQSxRQUN6RTtBQUFBLE1BQ0Y7QUFBQSxJQUNGO0FBRUEsVUFBTSxNQUFNLFlBQXdCO0FBQ2xDLFlBQU0sU0FBUyxNQUFNLEtBQUssV0FBVztBQUNyQyxhQUFPLEtBQUssaUJBQWlCO0FBQzdCLFVBQUk7QUFDSixXQUFLO0FBQ0wsVUFBSTtBQUNGLGtCQUFVLEdBQUcsS0FBSyxPQUFPLFFBQVEsTUFBTSxDQUFDO0FBQUEsTUFDMUMsU0FBUyxPQUFPO0FBRWQsYUFBSztBQUNMLFlBQUk7QUFDRixpQkFBTyxLQUFLLFVBQVU7QUFBQSxRQUN4QixRQUFRO0FBQUEsUUFFUjtBQUNBLGNBQU07QUFBQSxNQUNSO0FBQ0EsV0FBSztBQUNMLFVBQUk7QUFDRixjQUFNQyxVQUFTLE1BQU07QUFDckIsZUFBTyxLQUFLLFFBQVE7QUFDcEIsZUFBT0E7QUFBQSxNQUNULFNBQVMsT0FBTztBQUdkLFlBQUk7QUFDRixpQkFBTyxLQUFLLFVBQVU7QUFBQSxRQUN4QixRQUFRO0FBQUEsUUFFUjtBQUNBLGNBQU07QUFBQSxNQUNSO0FBQUEsSUFDRjtBQUVBLFVBQU0sU0FBUyxLQUFLLE1BQU0sS0FBSyxLQUFLLEdBQUc7QUFFdkMsU0FBSyxRQUFRLE9BQU87QUFBQSxNQUNsQixNQUFNO0FBQUEsTUFDTixNQUFNO0FBQUEsSUFDUjtBQUNBLFdBQU87QUFBQSxFQUNUO0FBQUE7QUFBQSxFQUlBLElBQUksT0FBZSxPQUFpQztBQUNsRCxXQUFPLEtBQUssWUFBWSxDQUFDLEtBQUssR0FBRyxhQUFhLENBQUMsT0FBTyxHQUFHLElBQUksT0FBTyxLQUFLLENBQUM7QUFBQSxFQUM1RTtBQUFBLEVBRUEsSUFBSSxPQUFlLE9BQWdCLEtBQTRCO0FBQzdELFdBQU8sS0FBSyxZQUFZLENBQUMsS0FBSyxHQUFHLGFBQWEsQ0FBQyxPQUFPLEdBQUcsSUFBSSxPQUFPLE9BQU8sR0FBRyxDQUFDO0FBQUEsRUFDakY7QUFBQSxFQUVBLElBQU8sT0FBZSxLQUFvQztBQUN4RCxXQUFPLEtBQUssWUFBWSxDQUFDLEtBQUssR0FBRyxZQUFZLENBQUMsT0FBTyxHQUFHLElBQU8sT0FBTyxHQUFHLENBQUM7QUFBQSxFQUM1RTtBQUFBLEVBRUEsT0FBVSxPQUFlLE9BQW9CLE9BQThCO0FBQ3pFLFdBQU8sS0FBSyxZQUFZLENBQUMsS0FBSyxHQUFHLFlBQVksQ0FBQyxPQUFPLEdBQUcsT0FBVSxPQUFPLE9BQU8sS0FBSyxDQUFDO0FBQUEsRUFDeEY7QUFBQSxFQUVBLE9BQU8sT0FBZSxLQUEyQjtBQUMvQyxXQUFPLEtBQUssWUFBWSxDQUFDLEtBQUssR0FBRyxhQUFhLENBQUMsT0FBTyxHQUFHLE9BQU8sT0FBTyxHQUFHLENBQUM7QUFBQSxFQUM3RTtBQUFBLEVBRUEsTUFBTSxPQUE4QjtBQUNsQyxXQUFPLEtBQUssWUFBWSxDQUFDLEtBQUssR0FBRyxhQUFhLENBQUMsT0FBTyxHQUFHLE1BQU0sS0FBSyxDQUFDO0FBQUEsRUFDdkU7QUFBQSxFQUVBLE1BQU0sT0FBZSxPQUFxQztBQUN4RCxXQUFPLEtBQUssWUFBWSxDQUFDLEtBQUssR0FBRyxZQUFZLENBQUMsT0FBTyxHQUFHLE1BQU0sT0FBTyxLQUFLLENBQUM7QUFBQSxFQUM3RTtBQUFBLEVBRUEsYUFBZ0IsT0FBZSxPQUFlLEtBQThDO0FBQzFGLFdBQU8sS0FBSyxZQUFZLENBQUMsS0FBSyxHQUFHLFlBQVksQ0FBQyxPQUFPLEdBQUcsYUFBZ0IsT0FBTyxPQUFPLEdBQUcsQ0FBQztBQUFBLEVBQzVGO0FBQUEsRUFFQSxnQkFBZ0IsT0FBZSxPQUFlLEtBQWtEO0FBQzlGLFdBQU8sS0FBSyxZQUFZLENBQUMsS0FBSyxHQUFHLFlBQVksQ0FBQyxPQUFPLEdBQUcsZ0JBQWdCLE9BQU8sT0FBTyxHQUFHLENBQUM7QUFBQSxFQUM1RjtBQUFBLEVBRUEsZ0JBQW1CLE9BQWUsT0FBZSxPQUFvQztBQUNuRixXQUFPLEtBQUs7QUFBQSxNQUFZLENBQUMsS0FBSztBQUFBLE1BQUc7QUFBQSxNQUFZLENBQUMsT0FDNUMsR0FBRyxnQkFBbUIsT0FBTyxPQUFPLEtBQUs7QUFBQSxJQUMzQztBQUFBLEVBQ0Y7QUFBQSxFQUVBLGVBQWUsT0FBZSxPQUFlLE9BQXVDO0FBQ2xGLFdBQU8sS0FBSyxZQUFZLENBQUMsS0FBSyxHQUFHLFlBQVksQ0FBQyxPQUFPLEdBQUcsZUFBZSxPQUFPLE9BQU8sS0FBSyxDQUFDO0FBQUEsRUFDN0Y7QUFBQSxFQUVBLFFBQ0UsT0FDQSxTQUNBLE9BQ2U7QUFFZixXQUFPLEtBQUssWUFBWSxDQUFDLEtBQUssR0FBRyxhQUFhLENBQUMsT0FBTyxHQUFHLFFBQVcsT0FBTyxTQUFTLEtBQUssQ0FBQztBQUFBLEVBQzVGO0FBQUEsRUFFUSxPQUFPLFNBQW1CLFFBQTRCO0FBQzVELFVBQU0sU0FBUyxDQUFDLFVBQTZCO0FBQzNDLFVBQUksQ0FBQyxRQUFRLFNBQVMsS0FBSyxHQUFHO0FBQzVCLGNBQU0sSUFBSTtBQUFBLFVBQ1IsY0FBUyxLQUFLLDJFQUFlLFFBQVEsS0FBSyxJQUFJLENBQUM7QUFBQSxRQUNqRDtBQUFBLE1BQ0Y7QUFDQSxZQUFNLE9BQU8sS0FBSyxXQUFXLElBQUksS0FBSztBQUN0QyxVQUFJLFNBQVMsT0FBVyxPQUFNLElBQUksTUFBTSw2Q0FBZSxLQUFLLFFBQUc7QUFDL0QsYUFBTztBQUFBLElBQ1Q7QUFFQSxVQUFNLFlBQVksQ0FBQyxNQUFpQixjQUFpQztBQUNuRSxZQUFNLFFBQVEsS0FBSyxPQUFPLElBQUksU0FBUztBQUN2QyxVQUFJLFVBQVUsUUFBVztBQUN2QixjQUFNLElBQUksTUFBTSxjQUFTLEtBQUssS0FBSyw2Q0FBVSxTQUFTLFFBQUc7QUFBQSxNQUMzRDtBQUNBLGFBQU87QUFBQSxJQUNUO0FBU0EsVUFBTSxlQUFlLENBQUMsV0FBbUIsVUFBb0Q7QUFDM0YsWUFBTSxPQUFPLE9BQU8sU0FBUztBQUM3QixZQUFNLFNBQVM7QUFDZixZQUFNLFlBQVksS0FBSyxjQUFjLE1BQU0sTUFBTTtBQUNqRCxVQUFJO0FBQ0osVUFBSTtBQUVKLFVBQUksY0FBYyxRQUFXO0FBQzNCLFlBQUksS0FBSyxPQUFPLGtCQUFrQixNQUFNO0FBQ3RDLGdCQUFNLElBQUk7QUFBQSxZQUNSLGNBQVMsU0FBUyxxRUFBYyxLQUFLLFFBQVEsS0FBSyxJQUFJLENBQUM7QUFBQSxVQUN6RDtBQUFBLFFBQ0Y7QUFDQSxvQkFBWSxLQUFLLGtCQUFrQixRQUFRLElBQUk7QUFDL0MsYUFBSyxDQUFDLFNBQVM7QUFFZixrQkFBVSxRQUFRLEtBQUssUUFBUSxDQUFDLEdBQUksU0FBUztBQUFBLE1BQy9DLE9BQU87QUFDTCxhQUFLO0FBQUEsTUFDUDtBQUdBLFdBQUssVUFBVSxRQUFRLE1BQU0sSUFBSSxNQUFNO0FBRXZDLFVBQUksY0FBYyxRQUFXO0FBQzNCLGFBQUssU0FBUyxRQUFRLE1BQU0sU0FBUztBQUFBLE1BQ3ZDLFdBQVcsS0FBSyxPQUFPLGtCQUFrQixRQUFRLE9BQU8sR0FBRyxDQUFDLE1BQU0sVUFBVTtBQUMxRSxhQUFLLGtCQUFrQixRQUFRLE1BQU0sR0FBRyxDQUFDLENBQUM7QUFBQSxNQUM1QztBQUNBLGFBQU8sRUFBRSxLQUFLLE9BQU8sR0FBRyxDQUFDLE1BQU0sV0FBVyxHQUFHLENBQUMsSUFBSSxHQUFHLEdBQUc7QUFBQSxJQUMxRDtBQUVBLFdBQU87QUFBQSxNQUNMLEtBQUssT0FBTyxXQUFXLFVBQVUsYUFBYSxXQUFXLEtBQUssRUFBRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFTaEUsd0JBQXdCLE9BQU8sV0FBVyxVQUFVO0FBQ2xELFlBQUk7QUFDRixnQkFBTSxFQUFFLElBQUksSUFBSSxhQUFhLFdBQVcsS0FBSztBQUM3QyxpQkFBTyxFQUFFLElBQUksTUFBZSxJQUFJO0FBQUEsUUFDbEMsU0FBUyxPQUFPO0FBQ2QsY0FBSSxLQUFLLGtCQUFrQixRQUFRLEtBQUssR0FBRztBQUN6QyxtQkFBTyxFQUFFLElBQUksT0FBZ0IsUUFBUSxZQUFxQjtBQUFBLFVBQzVEO0FBQ0EsZ0JBQU07QUFBQSxRQUNSO0FBQUEsTUFDRjtBQUFBLE1BRUEsS0FBSyxPQUFPLFdBQVcsT0FBTyxnQkFBZ0I7QUFDNUMsY0FBTSxPQUFPLE9BQU8sU0FBUztBQUM3QixjQUFNLFNBQVM7QUFDZixjQUFNLEtBQUssS0FBSyxxQkFBcUIsTUFBTSxXQUFXLEtBQUssS0FBSyxjQUFjLE1BQU0sTUFBTTtBQUMxRixZQUFJLE9BQU8sUUFBVztBQUNwQixnQkFBTSxJQUFJLE1BQU0sY0FBUyxTQUFTLDJDQUFhO0FBQUEsUUFDakQ7QUFHQSxhQUFLLFVBQVUsUUFBUSxNQUFNLEVBQUU7QUFDL0IsYUFBSyxVQUFVLFFBQVEsTUFBTSxJQUFJLE1BQU07QUFBQSxNQUN6QztBQUFBLE1BRUEsS0FBSyxPQUFXLFdBQW1CLFFBQWU7QUFDaEQsY0FBTSxPQUFPLE9BQU8sU0FBUztBQUM3QixjQUFNLEtBQUssS0FBSyxxQkFBcUIsTUFBTSxHQUFHO0FBQzlDLFlBQUksT0FBTyxPQUFXLFFBQU87QUFDN0IsY0FBTSxPQUFPLE9BQU87QUFBQSxVQUNsQixVQUFVLEVBQUUsS0FBSyxVQUFVLENBQUMsU0FBUyxFQUFFLEtBQUssS0FBSyxDQUFDLFVBQVUsUUFBUSxJQUFJLENBQUM7QUFBQSxVQUN6RTtBQUFBLFFBQ0Y7QUFDQSxlQUFPLEtBQUssV0FBVyxJQUFJLFNBQWEsS0FBSyxNQUFNLE9BQU8sS0FBSyxDQUFDLEVBQUcsS0FBSyxVQUFVLENBQUMsQ0FBQztBQUFBLE1BQ3RGO0FBQUEsTUFFQSxRQUFRLE9BQVcsV0FBbUIsT0FBb0IsVUFBbUI7QUFDM0UsMkJBQW1CLEtBQUs7QUFDeEIsY0FBTSxPQUFPLE9BQU8sU0FBUztBQUM3QixlQUFPLEtBQUssYUFBYSxRQUFRLE1BQU0sT0FBTyxLQUFLLEVBQUUsSUFBSSxDQUFDLE1BQU0sRUFBRSxJQUFTO0FBQUEsTUFDN0U7QUFBQSxNQUVBLFFBQVEsT0FBTyxXQUFXLFFBQVE7QUFDaEMsY0FBTSxPQUFPLE9BQU8sU0FBUztBQUM3QixjQUFNLEtBQUssS0FBSyxxQkFBcUIsTUFBTSxHQUFHO0FBQzlDLFlBQUksT0FBTyxPQUFXO0FBQ3RCLGFBQUssVUFBVSxRQUFRLE1BQU0sRUFBRTtBQUFBLE1BQ2pDO0FBQUEsTUFFQSxPQUFPLE9BQU8sY0FBYztBQUMxQixjQUFNLE9BQU8sT0FBTyxTQUFTO0FBQzdCLGVBQU8sSUFBSSxlQUFlLEVBQUUsS0FBSyxLQUFLLENBQUMsRUFBRTtBQUN6QyxtQkFBVyxTQUFTLEtBQUssU0FBUztBQUNoQyxjQUFJLE1BQU0sV0FBWSxRQUFPLElBQUksZUFBZSxFQUFFLE1BQU0sVUFBVyxDQUFDLEVBQUU7QUFBQSxRQUN4RTtBQUFBLE1BQ0Y7QUFBQSxNQUVBLE9BQU8sT0FBTyxXQUFXLFVBQXVCO0FBQzlDLGNBQU0sT0FBTyxPQUFPLFNBQVM7QUFFN0IsWUFBSSxLQUFLLFVBQVUsV0FBVyxLQUFLLFVBQVUsUUFBVztBQUN0RCxnQkFBTSxTQUFxQixDQUFDO0FBQzVCLGdCQUFNLFFBQVEsZ0JBQWdCLEVBQUUsS0FBSyxVQUFVLENBQUMsQ0FBRSxHQUFHLE9BQU8sTUFBTTtBQUNsRSxnQkFBTSxPQUFPLE9BQU87QUFBQSxZQUNsQiw2QkFBNkIsRUFBRSxLQUFLLEtBQUssQ0FBQyxHQUFHLE1BQU0sU0FBUyxVQUFVLE1BQU0sS0FBSyxPQUFPLENBQUMsS0FBSyxFQUFFO0FBQUEsWUFDaEc7QUFBQSxVQUNGO0FBQ0EsaUJBQU8sT0FBTyxLQUFLLENBQUMsSUFBSSxHQUFHLEtBQUssQ0FBQztBQUFBLFFBQ25DO0FBQ0EsZUFBTyxLQUFLLGFBQWEsUUFBUSxNQUFNLEtBQUssRUFBRTtBQUFBLE1BQ2hEO0FBQUEsTUFFQSxjQUFjLE9BQVcsV0FBbUIsV0FBbUIsUUFBeUI7QUFDdEYsY0FBTSxPQUFPLE9BQU8sU0FBUztBQUM3QixjQUFNLFFBQVEsVUFBVSxNQUFNLFNBQVM7QUFDdkMsY0FBTSxVQUFVLEtBQUssa0JBQWtCLFFBQVEsTUFBTSxPQUFPLEdBQUc7QUFDL0QsZUFBTyxRQUFRLFdBQVcsSUFBSSxTQUFhLFFBQVEsQ0FBQyxFQUFHO0FBQUEsTUFDekQ7QUFBQSxNQUVBLGlCQUFpQixPQUFPLFdBQVcsV0FBVyxRQUFRO0FBQ3BELGNBQU0sT0FBTyxPQUFPLFNBQVM7QUFDN0IsY0FBTSxRQUFRLFVBQVUsTUFBTSxTQUFTO0FBQ3ZDLGNBQU0sVUFBVSxLQUFLLGtCQUFrQixRQUFRLE1BQU0sT0FBTyxHQUFHO0FBQy9ELGVBQU8sUUFBUSxXQUFXLElBQUksU0FBWSxRQUFRLE1BQU0sUUFBUSxDQUFDLEVBQUcsRUFBRTtBQUFBLE1BQ3hFO0FBQUEsTUFFQSxpQkFBaUIsT0FBVyxXQUFtQixXQUFtQixVQUF5QjtBQUN6RixjQUFNLE9BQU8sT0FBTyxTQUFTO0FBQzdCLGNBQU0sUUFBUSxVQUFVLE1BQU0sU0FBUztBQUN2QyxlQUFPLEtBQUssa0JBQWtCLFFBQVEsTUFBTSxPQUFPLEtBQUssRUFBRSxJQUFJLENBQUMsTUFBTSxFQUFFLElBQVM7QUFBQSxNQUNsRjtBQUFBLE1BRUEsZ0JBQWdCLE9BQU8sV0FBVyxXQUFXLFVBQXlCO0FBQ3BFLGNBQU0sT0FBTyxPQUFPLFNBQVM7QUFDN0IsY0FBTSxRQUFRLFVBQVUsTUFBTSxTQUFTO0FBQ3ZDLGVBQU8sS0FBSyxrQkFBa0IsUUFBUSxNQUFNLE9BQU8sS0FBSyxFQUFFO0FBQUEsTUFDNUQ7QUFBQSxNQUVBLFNBQVMsT0FDUCxXQUNBLFNBQ0EsVUFDRztBQUNILGNBQU0sT0FBTyxPQUFPLFNBQVM7QUFDN0IsMkJBQW1CLFFBQVEsS0FBSztBQUVoQyxjQUFNLEVBQUUsWUFBWSxRQUFRLE9BQU8sT0FBTyxPQUFPLE1BQU0sSUFBSTtBQUMzRCxZQUFJO0FBQ0osWUFBSSxVQUFVLFFBQVc7QUFDdkIsb0JBQVUsS0FBSyxhQUFhLFFBQVEsTUFBTSxFQUFFLE9BQU8sTUFBTSxDQUFDO0FBQUEsUUFDNUQsT0FBTztBQUNMLGdCQUFNLFlBQVksVUFBVSxNQUFNLEtBQUs7QUFDdkMsb0JBQVUsS0FBSyxrQkFBa0IsUUFBUSxNQUFNLFdBQVcsRUFBRSxPQUFPLE1BQU0sQ0FBQztBQUFBLFFBQzVFO0FBQ0EsWUFBSSxjQUFjLE9BQVEsU0FBUSxRQUFRO0FBRTFDLGNBQU0sTUFBTSxTQUFTO0FBQ3JCLFlBQUksVUFBVTtBQUNkLG1CQUFXLFVBQVUsU0FBUztBQUM1QixjQUFJLFdBQVcsSUFBSztBQUNwQjtBQUNBLGdCQUFNLFNBQXlCLE1BQU0sT0FBTyxNQUFXLFFBQVEsTUFBTSxPQUFPLEVBQUUsQ0FBQztBQUMvRSxjQUFJLFdBQVcsWUFBWSxXQUFXLGVBQWU7QUFDbkQsaUJBQUssVUFBVSxRQUFRLE1BQU0sT0FBTyxFQUFFO0FBQUEsVUFDeEM7QUFDQSxjQUFJLFdBQVcsVUFBVSxXQUFXLGNBQWU7QUFBQSxRQUNyRDtBQUFBLE1BQ0Y7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQUFBO0FBQUEsRUFJUSxjQUFjLE1BQWlCLFFBQXlEO0FBQzlGLFVBQU0sTUFBa0IsQ0FBQztBQUN6QixlQUFXLFFBQVEsS0FBSyxTQUFTO0FBQy9CLFlBQU0sSUFBSSxZQUFZLFFBQVEsSUFBSTtBQUNsQyxVQUFJLENBQUMsV0FBVyxDQUFDLEVBQUcsUUFBTztBQUMzQixVQUFJLEtBQUssQ0FBQztBQUFBLElBQ1o7QUFDQSxXQUFPO0FBQUEsRUFDVDtBQUFBLEVBRVEscUJBQXFCLE1BQWlCLEtBQTBEO0FBQ3RHLFFBQUksUUFBUSxPQUFXLFFBQU87QUFDOUIsVUFBTSxRQUFRLE1BQU0sUUFBUSxHQUFHLElBQUksTUFBTSxDQUFDLEdBQUc7QUFDN0MsUUFBSSxNQUFNLFdBQVcsS0FBSyxVQUFVLE9BQVEsUUFBTztBQUNuRCxRQUFJLENBQUMsTUFBTSxNQUFNLFVBQVUsRUFBRyxRQUFPO0FBQ3JDLFdBQU87QUFBQSxFQUNUO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQU1RLGtCQUFrQixRQUFzQixNQUF5QjtBQUN2RSxVQUFNLFNBQVMsT0FBTztBQUFBLE1BQ3BCLHNCQUFzQixFQUFFLFNBQVMsQ0FBQztBQUFBLE1BQ2xDLENBQUMsS0FBSyxLQUFLO0FBQUEsSUFDYixFQUFFLENBQUM7QUFDSCxVQUFNLFNBQVMsV0FBVyxTQUFZLElBQUksT0FBTyxPQUFPLE1BQU0sQ0FBQztBQUMvRCxVQUFNLFNBQVMsT0FBTztBQUFBLE1BQ3BCLGNBQWMsRUFBRSxLQUFLLFVBQVUsQ0FBQyxDQUFFLENBQUMsaUJBQWlCLEVBQUUsS0FBSyxLQUFLLENBQUM7QUFBQSxJQUNuRSxFQUFFLENBQUM7QUFDSCxVQUFNLFFBQVEsV0FBVyxVQUFhLE9BQU8sT0FBTyxHQUFHLE1BQU0sV0FBVyxPQUFPLEdBQUcsSUFBSTtBQUN0RixXQUFPLEtBQUssSUFBSSxRQUFRLEtBQUssSUFBSTtBQUFBLEVBQ25DO0FBQUE7QUFBQSxFQUdRLGtCQUFrQixRQUFzQixPQUF5QjtBQUN2RSxRQUFJLE9BQU8sc0JBQXNCLE9BQVcsUUFBTyxPQUFPLGtCQUFrQixLQUFLO0FBQ2pGLFdBQU8seUJBQXlCLEtBQUs7QUFBQSxFQUN2QztBQUFBLEVBRVEsa0JBQWtCLFFBQXNCLE1BQWlCLEtBQW1CO0FBQ2xGLFVBQU0sU0FBUyxPQUFPO0FBQUEsTUFDcEIsc0JBQXNCLEVBQUUsU0FBUyxDQUFDO0FBQUEsTUFDbEMsQ0FBQyxLQUFLLEtBQUs7QUFBQSxJQUNiLEVBQUUsQ0FBQztBQUNILFVBQU0sU0FBUyxXQUFXLFNBQVksSUFBSSxPQUFPLE9BQU8sTUFBTSxDQUFDO0FBQy9ELFFBQUksTUFBTSxPQUFRLE1BQUssU0FBUyxRQUFRLE1BQU0sR0FBRztBQUFBLEVBQ25EO0FBQUEsRUFFUSxTQUFTLFFBQXNCLE1BQWlCLE1BQW9CO0FBQzFFLFdBQU87QUFBQSxNQUNMLDBCQUEwQixFQUFFLFNBQVMsQ0FBQztBQUFBLE1BQ3RDLENBQUMsS0FBSyxPQUFPLElBQUk7QUFBQSxJQUNuQjtBQUFBLEVBQ0Y7QUFBQSxFQUVRLFVBQ04sUUFDQSxNQUNBLElBQ0EsUUFDTTtBQUNOLFVBQU0sVUFBVSxDQUFDLEdBQUcsS0FBSyxTQUFTO0FBQ2xDLFVBQU0sU0FBcUIsQ0FBQyxHQUFHLEVBQUU7QUFFakMsZUFBVyxTQUFTLEtBQUssU0FBUztBQUNoQyxVQUFJLE1BQU0sV0FBWTtBQUN0QixZQUFNLFFBQVEsa0JBQWtCLE9BQU8sTUFBTTtBQUM3QyxlQUFTLElBQUksR0FBRyxJQUFJLE1BQU0sUUFBUSxRQUFRLEtBQUs7QUFDN0MsZ0JBQVEsS0FBSyxNQUFNLFFBQVEsQ0FBQyxDQUFFO0FBQzlCLGVBQU8sS0FBSyxVQUFVLFNBQVksT0FBTyxNQUFNLENBQUMsQ0FBRTtBQUFBLE1BQ3BEO0FBQUEsSUFDRjtBQUVBLFlBQVEsS0FBSyxLQUFLLFVBQVU7QUFDNUIsV0FBTyxLQUFLLEtBQUssVUFBVSxNQUFNLENBQUM7QUFFbEMsV0FBTztBQUFBLE1BQ0wsZUFBZSxFQUFFLEtBQUssS0FBSyxDQUFDLEtBQUssUUFBUSxJQUFJLENBQUMsRUFBRSxLQUFLLElBQUksQ0FBQyxhQUFhLFFBQVEsSUFBSSxNQUFNLEdBQUcsRUFBRSxLQUFLLElBQUksQ0FBQztBQUFBLE1BQ3hHO0FBQUEsSUFDRjtBQUVBLGVBQVcsU0FBUyxLQUFLLFNBQVM7QUFDaEMsVUFBSSxDQUFDLE1BQU0sV0FBWTtBQUN2QixpQkFBVyxXQUFXLGlCQUFpQixPQUFPLE1BQU0sR0FBRztBQUNyRCxlQUFPO0FBQUEsVUFDTCxlQUFlLEVBQUUsTUFBTSxVQUFXLENBQUMsS0FBSztBQUFBLFlBQ3RDLEdBQUcsS0FBSyxVQUFVLElBQUksQ0FBQztBQUFBLFlBQ3ZCO0FBQUEsVUFDRixFQUFFLEtBQUssSUFBSSxDQUFDLGFBQWEsQ0FBQyxHQUFHLEtBQUssVUFBVSxJQUFJLE1BQU0sR0FBRyxHQUFHLEdBQUcsRUFBRSxLQUFLLElBQUksQ0FBQztBQUFBLFVBQzNFLENBQUMsR0FBRyxJQUFJLE9BQU87QUFBQSxRQUNqQjtBQUFBLE1BQ0Y7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQUFBLEVBRVEsVUFBVSxRQUFzQixNQUFpQixJQUFzQjtBQUM3RSxXQUFPLElBQUksZUFBZSxFQUFFLEtBQUssS0FBSyxDQUFDLFVBQVUsUUFBUSxJQUFJLENBQUMsSUFBSSxFQUFFO0FBQ3BFLGVBQVcsU0FBUyxLQUFLLFNBQVM7QUFDaEMsVUFBSSxNQUFNLFlBQVk7QUFDcEIsZUFBTyxJQUFJLGVBQWUsRUFBRSxNQUFNLFVBQVcsQ0FBQyxVQUFVLFFBQVEsSUFBSSxDQUFDLElBQUksRUFBRTtBQUFBLE1BQzdFO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFBQSxFQUVRLGFBQ04sUUFDQSxNQUNBLE9BQ0EsT0FDa0I7QUFDbEIsVUFBTSxTQUFxQixDQUFDO0FBQzVCLFFBQUksUUFBUTtBQUlaLFVBQU0sV0FBVyxLQUFLLFVBQVUsV0FBVyxLQUFLLFVBQVU7QUFDMUQsUUFBSSxVQUFVO0FBQ1osWUFBTSxhQUFhLGdCQUFnQixFQUFFLEtBQUssVUFBVSxDQUFDLENBQUUsR0FBRyxPQUFRLE1BQU07QUFDeEUsVUFBSSxXQUFXLFNBQVMsRUFBRyxTQUFRLFVBQVUsV0FBVyxLQUFLLE9BQU8sQ0FBQztBQUFBLElBQ3ZFO0FBRUEsVUFBTSxXQUFXLFVBQVUsV0FBYyxZQUFZLFVBQVU7QUFDL0QsUUFBSSxTQUFVLFFBQU8sS0FBSyxLQUFLO0FBQy9CLFVBQU0sT0FBTyxPQUFPO0FBQUEsTUFDbEIsaUJBQWlCLEVBQUUsS0FBSyxLQUFLLENBQUMsR0FBRyxLQUFLLGFBQWEsVUFBVSxJQUFJLENBQUMsR0FBRyxXQUFXLGFBQWEsRUFBRTtBQUFBLE1BQy9GO0FBQUEsSUFDRjtBQUVBLFVBQU0sWUFBWSxLQUFLLElBQUksQ0FBQyxRQUFRLEtBQUssaUJBQWlCLE1BQU0sR0FBRyxDQUFDO0FBQ3BFLFlBQVEsV0FBVyxZQUFZLFVBQVUsT0FBTyxDQUFDLE1BQU0sV0FBVyxFQUFFLElBQUksS0FBSyxDQUFDLEdBQUcsTUFBTSxHQUFHLEtBQUs7QUFBQSxFQUNqRztBQUFBLEVBRVEsa0JBQ04sUUFDQSxNQUNBLE9BQ0EsT0FDa0I7QUFDbEIsUUFBSSxNQUFNLFlBQVk7QUFDcEIsWUFBTUMsVUFBcUIsQ0FBQztBQUM1QixZQUFNQyxjQUF1QixDQUFDO0FBQzlCLFVBQUksVUFBVSxRQUFXO0FBQ3ZCLFlBQUksV0FBVyxLQUFLLEdBQUc7QUFDckIsVUFBQUEsWUFBVyxLQUFLLGNBQWM7QUFDOUIsVUFBQUQsUUFBTyxLQUFLLEtBQUs7QUFBQSxRQUVuQixXQUFXLE1BQU0sUUFBUSxLQUFLLEdBQUc7QUFDL0IsaUJBQU8sQ0FBQztBQUFBLFFBQ1YsT0FBTztBQUNMLFVBQUFDLFlBQVcsS0FBSyxHQUFHLGdCQUFnQixZQUFZLE9BQU9ELE9BQU0sQ0FBQztBQUFBLFFBQy9EO0FBQUEsTUFDRjtBQUNBLFlBQU0sUUFBUUMsWUFBVyxTQUFTLElBQUksUUFBUUEsWUFBVyxLQUFLLE9BQU8sQ0FBQyxLQUFLO0FBQzNFLFlBQU1DLFFBQU8sT0FBTztBQUFBLFFBQ2xCLG1CQUFtQixFQUFFLEtBQUssS0FBSyxDQUFDLGtDQUNDLEVBQUUsTUFBTSxVQUFXLENBQUMsWUFDMUMsU0FBUyxLQUFLLEtBQUssSUFBSSxDQUFDLEdBQUcsS0FBSyxjQUM3QixVQUFVLE1BQU0sR0FBRyxDQUFDO0FBQUEsUUFDbENGO0FBQUEsTUFDRjtBQUNBLGFBQU9FLE1BQUssSUFBSSxDQUFDLFFBQVEsS0FBSyxpQkFBaUIsTUFBTSxHQUFHLENBQUM7QUFBQSxJQUMzRDtBQUVBLFVBQU0sU0FBcUIsQ0FBQztBQUM1QixVQUFNLGFBQXVCLENBQUM7QUFFOUIsUUFBSSxVQUFVLFFBQVc7QUFFdkIsaUJBQVcsVUFBVSxNQUFNLFFBQVMsWUFBVyxLQUFLLEdBQUcsRUFBRSxNQUFNLENBQUMsY0FBYztBQUFBLElBQ2hGLFdBQVcsV0FBVyxLQUFLLEdBQUc7QUFDNUIsVUFBSSxNQUFNLFFBQVEsV0FBVyxFQUFHLFFBQU8sQ0FBQztBQUN4QyxpQkFBVyxLQUFLLEdBQUcsRUFBRSxNQUFNLFFBQVEsQ0FBQyxDQUFFLENBQUMsTUFBTTtBQUM3QyxhQUFPLEtBQUssS0FBSztBQUFBLElBQ25CLFdBQVcsTUFBTSxRQUFRLEtBQUssR0FBRztBQUMvQixVQUFJLE1BQU0sV0FBVyxNQUFNLFFBQVEsT0FBUSxRQUFPLENBQUM7QUFDbkQsWUFBTSxRQUFRLFFBQVEsQ0FBQyxRQUFRLE1BQU07QUFDbkMsbUJBQVcsS0FBSyxHQUFHLEVBQUUsTUFBTSxDQUFDLE1BQU07QUFDbEMsZUFBTyxLQUFLLE1BQU0sQ0FBQyxDQUFFO0FBQUEsTUFDdkIsQ0FBQztBQUFBLElBQ0gsV0FBVyxNQUFNLFFBQVEsV0FBVyxHQUFHO0FBQ3JDLGlCQUFXLEtBQUssR0FBRyxnQkFBZ0IsRUFBRSxNQUFNLFFBQVEsQ0FBQyxDQUFFLEdBQUcsT0FBTyxNQUFNLENBQUM7QUFBQSxJQUN6RSxPQUFPO0FBR0wsaUJBQVcsVUFBVSxNQUFNLFFBQVMsWUFBVyxLQUFLLEdBQUcsRUFBRSxNQUFNLENBQUMsY0FBYztBQUFBLElBQ2hGO0FBRUEsVUFBTSxRQUFRLFdBQVcsU0FBUyxJQUFJLFVBQVUsV0FBVyxLQUFLLE9BQU8sQ0FBQyxLQUFLO0FBQzdFLFVBQU0sT0FBTyxPQUFPO0FBQUEsTUFDbEIsaUJBQWlCLEVBQUUsS0FBSyxLQUFLLENBQUMsR0FBRyxLQUFLLGFBQWEsVUFBVSxJQUFJLENBQUM7QUFBQSxNQUNsRTtBQUFBLElBQ0Y7QUFFQSxRQUFJLFlBQVksS0FBSyxJQUFJLENBQUMsUUFBUSxLQUFLLGlCQUFpQixNQUFNLEdBQUcsQ0FBQztBQUNsRSxRQUNFLFVBQVUsVUFDVixDQUFDLFdBQVcsS0FBSyxLQUNqQixDQUFDLE1BQU0sUUFBUSxLQUFLLEtBQ3BCLE1BQU0sUUFBUSxTQUFTLEdBQ3ZCO0FBQ0Esa0JBQVksVUFBVTtBQUFBLFFBQU8sQ0FBQyxNQUM1QjtBQUFBLFVBQ0UsTUFBTSxRQUFRLElBQUksQ0FBQyxNQUFNLEVBQUUsSUFBSSxDQUFDLENBQWE7QUFBQSxVQUM3QztBQUFBLFFBQ0Y7QUFBQSxNQUNGO0FBQUEsSUFDRjtBQUNBLFdBQU87QUFBQSxFQUNUO0FBQUEsRUFFUSxpQkFBaUIsTUFBaUIsS0FBNkI7QUFDckUsV0FBTztBQUFBLE1BQ0wsTUFBTSxLQUFLLE1BQU0sT0FBTyxJQUFJLEtBQUssVUFBVSxDQUFDLENBQUM7QUFBQSxNQUM3QyxJQUFJLEtBQUssVUFBVSxJQUFJLENBQUMsTUFBTSxJQUFJLENBQUMsQ0FBYTtBQUFBLE1BQ2hEO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFDRjtBQW9CQSxTQUFTLHlCQUF5QixPQUF5QjtBQUN6RCxNQUFJLE9BQU8sVUFBVSxZQUFZLFVBQVUsS0FBTSxRQUFPO0FBQ3hELFFBQU0sWUFBWTtBQUNsQixhQUFXLFFBQVEsQ0FBQyxVQUFVLFNBQVMsVUFBVSxJQUFJLEdBQUc7QUFDdEQsUUFBSSxPQUFPLFNBQVMsYUFBYSxTQUFTLFFBQVEsU0FBUyxNQUFPLFFBQU87QUFBQSxFQUMzRTtBQUNBLFNBQ0UsT0FBTyxVQUFVLFlBQVksWUFDN0IsNEJBQTRCLEtBQUssVUFBVSxPQUFPO0FBRXREO0FBRUEsU0FBUyxRQUFRLE1BQWlCLE9BQXdCO0FBQ3hELFFBQU0sU0FBUyxVQUFVLFNBQVksS0FBSyxHQUFHLEtBQUs7QUFDbEQsU0FBTyxLQUFLLFVBQVUsSUFBSSxDQUFDLE1BQU0sR0FBRyxNQUFNLEdBQUcsRUFBRSxDQUFDLENBQUMsTUFBTSxFQUFFLEtBQUssT0FBTztBQUN2RTtBQUVBLFNBQVMsU0FBUyxNQUFjLE9BQWUsTUFBeUI7QUFDdEUsU0FBTyxLQUFLLFVBQVUsSUFBSSxDQUFDLE1BQU0sR0FBRyxJQUFJLElBQUksRUFBRSxDQUFDLENBQUMsTUFBTSxLQUFLLElBQUksRUFBRSxDQUFDLENBQUMsRUFBRSxFQUFFLEtBQUssT0FBTztBQUNyRjtBQUVBLFNBQVMsVUFBVSxNQUFpQixPQUF3QjtBQUMxRCxRQUFNLFNBQVMsVUFBVSxTQUFZLEtBQUssR0FBRyxLQUFLO0FBQ2xELFNBQU8sS0FBSyxVQUFVLElBQUksQ0FBQyxNQUFNLEdBQUcsTUFBTSxHQUFHLEVBQUUsQ0FBQyxDQUFDLEVBQUUsRUFBRSxLQUFLLElBQUk7QUFDaEU7QUFFQSxTQUFTLGdCQUFnQixRQUFnQixPQUFtQixRQUE4QjtBQUN4RixRQUFNLGFBQXVCLENBQUM7QUFDOUIsTUFBSSxNQUFNLFVBQVUsUUFBVztBQUM3QixlQUFXLEtBQUssR0FBRyxNQUFNLElBQUksTUFBTSxjQUFjLE9BQU8sTUFBTSxJQUFJLElBQUk7QUFDdEUsV0FBTyxLQUFLLE1BQU0sS0FBSztBQUFBLEVBQ3pCO0FBQ0EsTUFBSSxNQUFNLFVBQVUsUUFBVztBQUM3QixlQUFXLEtBQUssR0FBRyxNQUFNLElBQUksTUFBTSxjQUFjLE9BQU8sTUFBTSxJQUFJLElBQUk7QUFDdEUsV0FBTyxLQUFLLE1BQU0sS0FBSztBQUFBLEVBQ3pCO0FBQ0EsU0FBTztBQUNUO0FBR0EsU0FBUyxrQkFDUCxPQUNBLFFBQ3dCO0FBQ3hCLFFBQU0sTUFBa0IsQ0FBQztBQUN6QixhQUFXLFFBQVEsTUFBTSxPQUFPO0FBQzlCLFVBQU0sSUFBSSxZQUFZLFFBQVEsSUFBSTtBQUNsQyxRQUFJLENBQUMsV0FBVyxDQUFDLEVBQUcsUUFBTztBQUMzQixRQUFJLEtBQUssQ0FBQztBQUFBLEVBQ1o7QUFDQSxTQUFPO0FBQ1Q7QUFHQSxTQUFTLGlCQUFpQixPQUFrQixRQUE2QztBQUN2RixRQUFNLE1BQU0sWUFBWSxRQUFRLE1BQU0sTUFBTSxDQUFDLENBQUU7QUFDL0MsTUFBSSxDQUFDLE1BQU0sUUFBUSxHQUFHLEVBQUcsUUFBTyxDQUFDO0FBQ2pDLFFBQU0sTUFBa0IsQ0FBQztBQUN6QixhQUFXLEtBQUssS0FBSztBQUNuQixRQUFJLFdBQVcsQ0FBQyxLQUFLLENBQUMsSUFBSSxLQUFLLENBQUMsYUFBYSxZQUFZLFVBQVUsQ0FBQyxNQUFNLENBQUMsRUFBRyxLQUFJLEtBQUssQ0FBQztBQUFBLEVBQzFGO0FBQ0EsU0FBTztBQUNUO0FBRUEsU0FBUyxRQUFRLE1BQWlCLElBQXVCO0FBR3ZELFNBQVEsS0FBSyxVQUFVLFdBQVcsSUFBSSxHQUFHLENBQUMsSUFBTTtBQUNsRDs7O0FDaDZCTyxTQUFTLGVBQWUsT0FBaUM7QUFDOUQsTUFBSSxpQkFBaUIsT0FBTztBQUMxQixXQUFPO0FBQUEsTUFDTCxNQUFNLE1BQU07QUFBQSxNQUNaLFNBQVMsTUFBTTtBQUFBO0FBQUEsTUFFZixHQUFJLE1BQU0sVUFBVSxTQUFZLENBQUMsSUFBSSxFQUFFLE9BQU8sTUFBTSxNQUFNO0FBQUEsSUFDNUQ7QUFBQSxFQUNGO0FBQ0EsU0FBTyxFQUFFLE1BQU0sU0FBUyxTQUFTLE9BQU8sS0FBSyxFQUFFO0FBQ2pEO0FBR0EsU0FBUyxpQkFBaUIsT0FBK0I7QUFDdkQsUUFBTSxVQUFVLElBQUksTUFBTSxNQUFNLE9BQU87QUFDdkMsVUFBUSxPQUFPLE1BQU07QUFDckIsTUFBSSxNQUFNLFVBQVUsT0FBVyxTQUFRLFFBQVEsTUFBTTtBQUNyRCxTQUFPO0FBQ1Q7QUFRQSxlQUFzQix5QkFDcEIsT0FDQSxTQUM4QjtBQUM5QixRQUFNLEtBQU0sTUFBNkMsUUFBUSxNQUFNO0FBQ3ZFLE1BQUksT0FBTyxPQUFPLFlBQVk7QUFPNUIsV0FBTztBQUFBLE1BQ0wsSUFBSSxRQUFRO0FBQUEsTUFDWixJQUFJO0FBQUEsTUFDSixPQUFPO0FBQUEsUUFDTCxNQUFNO0FBQUEsUUFDTixTQUFTLDhDQUFxQixRQUFRLE1BQU07QUFBQSxNQUM5QztBQUFBLElBQ0Y7QUFBQSxFQUNGO0FBRUEsTUFBSTtBQUNGLFVBQU0sUUFBUSxNQUFPLEdBQTZDLE1BQU0sT0FBTyxRQUFRLElBQUk7QUFDM0YsV0FBTyxFQUFFLElBQUksUUFBUSxJQUFJLElBQUksTUFBTSxNQUFNO0FBQUEsRUFDM0MsU0FBUyxPQUFPO0FBQ2QsV0FBTyxFQUFFLElBQUksUUFBUSxJQUFJLElBQUksT0FBTyxPQUFPLGVBQWUsS0FBSyxFQUFFO0FBQUEsRUFDbkU7QUFDRjtBQW9CTyxTQUFTLGlCQUNkLE1BSUEsT0FDTTtBQUVOLFFBQU0sVUFBZ0MsQ0FBQztBQUN2QyxNQUFJLFFBQWlDO0FBRXJDLFFBQU0sV0FBVyxPQUFPLFlBQStDO0FBQ3JFLFFBQUksVUFBVSxNQUFNO0FBQ2xCLGNBQVEsS0FBSyxPQUFPO0FBQ3BCO0FBQUEsSUFDRjtBQUNBLFVBQU0sV0FBVyxNQUFNLHlCQUF5QixPQUFPLE9BQU87QUFDOUQsU0FBSyxZQUFZLFFBQVE7QUFBQSxFQUMzQjtBQUdBLE9BQUssWUFBWSxDQUFDLFVBQVU7QUFDMUIsU0FBSyxTQUFTLE1BQU0sSUFBMEI7QUFBQSxFQUNoRDtBQUVBLFFBQU07QUFBQSxJQUNKLENBQUMsV0FBVztBQUNWLGNBQVEsT0FBTztBQUVmLFdBQUssWUFBWSxFQUFFLE1BQU0sU0FBUyxVQUFVLE9BQU8sU0FBUyxDQUE0QjtBQUt4RixZQUFNLGtCQUFrQixRQUFRLE9BQU8sR0FBRyxRQUFRLE1BQU07QUFDeEQsWUFBTSxZQUFZO0FBQ2hCLG1CQUFXLFdBQVcsaUJBQWlCO0FBQ3JDLGdCQUFNLFdBQVcsTUFBTSx5QkFBeUIsT0FBTyxPQUFPLE9BQU87QUFDckUsZUFBSyxZQUFZLFFBQVE7QUFBQSxRQUMzQjtBQUFBLE1BQ0YsR0FBRztBQUFBLElBQ0w7QUFBQSxJQUNBLENBQUMsVUFBbUI7QUFFbEIsV0FBSyxZQUFZLEVBQUUsTUFBTSxTQUFTLE9BQU8sZUFBZSxLQUFLLEVBQUUsQ0FBNEI7QUFDM0YsWUFBTSxVQUFVLGVBQWUsS0FBSztBQUNwQyxZQUFNLGtCQUFrQixRQUFRLE9BQU8sR0FBRyxRQUFRLE1BQU07QUFDeEQsaUJBQVcsV0FBVyxpQkFBaUI7QUFDckMsYUFBSyxZQUFZLEVBQUUsSUFBSSxRQUFRLElBQUksSUFBSSxPQUFPLE9BQU8sUUFBUSxDQUFDO0FBQUEsTUFDaEU7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQUNGO0FBcUJPLFNBQVMseUJBQ2QsUUFDZ0M7QUFDaEMsTUFBSSxTQUFTO0FBQ2IsUUFBTSxVQUFVLG9CQUFJLElBR2xCO0FBRUYsTUFBSSxlQUErRCxNQUFNO0FBQ3pFLE1BQUksY0FBd0MsTUFBTTtBQUNsRCxRQUFNLFFBQVEsSUFBSSxRQUF1QyxDQUFDLFNBQVMsV0FBVztBQUM1RSxtQkFBZTtBQUNmLGtCQUFjO0FBQUEsRUFDaEIsQ0FBQztBQUVELFFBQU0sTUFBTSxNQUFNLE1BQVM7QUFPM0IsUUFBTSxXQUFXO0FBS2pCLFFBQU0sWUFBWSxDQUFDLFVBQW1DO0FBQ3BELFVBQU0sT0FBTyxNQUFNO0FBT25CLFFBQUksVUFBVSxRQUFRLEtBQUssU0FBUyxTQUFTO0FBQzNDLFVBQUksY0FBYyxLQUFNLGNBQWEsRUFBRSxVQUFVLEtBQUssU0FBUyxDQUFDO0FBQUEsVUFDM0QsYUFBWSxpQkFBaUIsS0FBSyxLQUFLLENBQUM7QUFDN0M7QUFBQSxJQUNGO0FBRUEsVUFBTSxXQUFXO0FBQ2pCLFVBQU0sU0FBUyxRQUFRLElBQUksU0FBUyxFQUFFO0FBQ3RDLFFBQUksV0FBVyxPQUFXO0FBQzFCLFlBQVEsT0FBTyxTQUFTLEVBQUU7QUFDMUIsUUFBSSxTQUFTLEdBQUksUUFBTyxRQUFRLFNBQVMsS0FBSztBQUFBLFFBQ3pDLFFBQU8sT0FBTyxpQkFBaUIsU0FBUyxLQUFLLENBQUM7QUFBQSxFQUNyRDtBQUdBLE1BQUksT0FBTyxTQUFTLHFCQUFxQixZQUFZO0FBQ25ELGFBQVMsaUJBQWlCLFdBQVcsU0FBUztBQUFBLEVBQ2hELE9BQU87QUFDTCxhQUFTLFlBQVk7QUFBQSxFQUN2QjtBQUVBLFFBQU0sT0FBTyxDQUFDLFFBQWdCLFNBQXNDO0FBQ2xFLFVBQU0sS0FBSyxFQUFFO0FBQ2IsV0FBTyxJQUFJLFFBQVEsQ0FBQyxTQUFTLFdBQVc7QUFDdEMsY0FBUSxJQUFJLElBQUksRUFBRSxTQUFTLE9BQU8sQ0FBQztBQUNuQyxhQUFPLFlBQVksRUFBRSxJQUFJLFFBQVEsS0FBSyxDQUE4QjtBQUFBLElBQ3RFLENBQUM7QUFBQSxFQUNIO0FBU0EsUUFBTSxRQUFnQztBQUFBLElBQ3BDLGFBQWEsQ0FBQyxRQUFRLEtBQUssZUFBZSxDQUFDLEdBQUcsQ0FBQztBQUFBLElBQy9DLGdCQUFnQixDQUFDLFFBQVEsS0FBSyxrQkFBa0IsQ0FBQyxHQUFHLENBQUM7QUFBQSxJQUdyRCxhQUFhLENBQUMsVUFBVSxPQUFPLGtCQUM3QixLQUFLLGVBQWUsQ0FBQyxVQUFVLE9BQU8sYUFBYSxDQUFDO0FBQUEsSUFHdEQsV0FBVyxDQUFDLFNBQVMsS0FBSyxhQUFhLENBQUMsSUFBSSxDQUFDO0FBQUEsSUFDN0MsaUJBQWlCLENBQUMsWUFBWSxhQUM1QixLQUFLLG1CQUFtQixDQUFDLFlBQVksUUFBUSxDQUFDO0FBQUEsSUFHaEQsaUJBQWlCLE1BQU0sS0FBSyxtQkFBbUIsQ0FBQyxDQUFDO0FBQUEsSUFDakQsV0FBVyxDQUFDLE9BQU8sVUFDakIsS0FBSyxhQUFhLENBQUMsT0FBTyxLQUFLLENBQUM7QUFBQSxJQUNsQyxhQUFhLE1BQU0sS0FBSyxlQUFlLENBQUMsQ0FBQztBQUFBLElBQ3pDLGtCQUFrQixNQUNoQixLQUFLLG9CQUFvQixDQUFDLENBQUM7QUFBQSxJQUM3QixtQkFBbUIsTUFBTSxLQUFLLHFCQUFxQixDQUFDLENBQUM7QUFBQSxJQUNyRCxtQkFBbUIsTUFDakIsS0FBSyxxQkFBcUIsQ0FBQyxDQUFDO0FBQUEsSUFDOUIsb0JBQW9CLE1BQU0sS0FBSyxzQkFBc0IsQ0FBQyxDQUFDO0FBQUEsSUFDdkQsY0FBYyxDQUFDLHFCQUNiLEtBQUssZ0JBQWdCLENBQUMsZ0JBQWdCLENBQUM7QUFBQSxJQUN6QyxzQkFBc0IsQ0FBQyxVQUFVLEtBQUssd0JBQXdCLENBQUMsS0FBSyxDQUFDO0FBQUEsSUFDckUsY0FBYyxDQUFDLFVBQVUsS0FBSyxnQkFBZ0IsQ0FBQyxLQUFLLENBQUM7QUFBQSxJQUNyRCxhQUFhLENBQUMsWUFBWSxLQUFLLGVBQWUsQ0FBQyxPQUFPLENBQUM7QUFBQSxJQUN2RCxnQkFBZ0IsTUFBTSxLQUFLLGtCQUFrQixDQUFDLENBQUM7QUFBQSxJQUcvQyxpQkFBaUIsQ0FBQyxlQUFlLEtBQUssbUJBQW1CLENBQUMsVUFBVSxDQUFDO0FBQUEsSUFHckUsbUJBQW1CLE1BQU0sS0FBSyxxQkFBcUIsQ0FBQyxDQUFDO0FBQUEsSUFHckQsb0JBQW9CLENBQUMsVUFBVSxLQUFLLHNCQUFzQixDQUFDLEtBQUssQ0FBQztBQUFBLElBR2pFLHNCQUFzQixNQUFNLEtBQUssd0JBQXdCLENBQUMsQ0FBQztBQUFBLElBRzNELHVCQUF1QixNQUFNLEtBQUsseUJBQXlCLENBQUMsQ0FBQztBQUFBO0FBQUEsSUFLN0Qsa0JBQWtCLE1BQU0sS0FBSyxvQkFBb0IsQ0FBQyxDQUFDO0FBQUEsSUFDbkQsa0JBQWtCLENBQUMsUUFBUSxLQUFLLG9CQUFvQixDQUFDLEdBQUcsQ0FBQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFNekQsY0FBYyxDQUFDLFFBQVEsS0FBSyxnQkFBZ0IsQ0FBQyxHQUFHLENBQUM7QUFBQSxJQUNqRCxjQUFjLENBQUMsS0FBSyxVQUFVLEtBQUssZ0JBQWdCLENBQUMsS0FBSyxLQUFLLENBQUM7QUFBQTtBQUFBLElBRy9ELDJCQUEyQixDQUFDLEtBQUssUUFBUSxZQUN2QyxLQUFLLDZCQUE2QixDQUFDLEtBQUssUUFBUSxPQUFPLENBQUM7QUFBQSxJQUcxRCxxQkFBcUIsQ0FBQyxRQUFRLEtBQUssdUJBQXVCLENBQUMsR0FBRyxDQUFDO0FBQUEsSUFDL0QscUNBQXFDLENBQUMsTUFBTSxLQUFLLGtCQUMvQyxLQUFLLHVDQUF1QyxDQUFDLE1BQU0sS0FBSyxhQUFhLENBQUM7QUFBQSxJQUN4RSxhQUFhLENBQUMsU0FBUyxLQUFLLGVBQWUsQ0FBQyxJQUFJLENBQUM7QUFBQSxJQUNqRCxZQUFZLENBQUMsVUFBVSxLQUFLLGNBQWMsQ0FBQyxLQUFLLENBQUM7QUFBQSxJQUNqRCx5QkFBeUIsQ0FBQyxlQUN4QixLQUFLLDJCQUEyQixDQUFDLFVBQVUsQ0FBQztBQUFBLEVBQ2hEO0FBRUEsU0FBTyxFQUFFLE9BQU8sTUFBTTtBQUN4QjtBQVNPLFNBQVMsdUJBQ2QsUUFDd0I7QUFDeEIsU0FBTyx5QkFBcUMsTUFBTSxFQUFFO0FBQ3REOzs7QUNyV0EsSUFBTSxNQUFNO0FBR1osU0FBUyxNQUFNLE9BQXdEO0FBQ3JFLE1BQUksT0FBTyxVQUFVLFlBQVksVUFBVSxRQUFRLE1BQU0sUUFBUSxLQUFLLEVBQUcsUUFBTztBQUNoRixRQUFNLE9BQU8sT0FBTyxLQUFLLEtBQUs7QUFDOUIsU0FBTyxLQUFLLFdBQVcsS0FBSyxLQUFLLFNBQVMsR0FBRztBQUMvQztBQVdPLFNBQVMsZ0JBQWdCLE9BQXlCO0FBV3ZELE1BQUksVUFBVSxPQUFXLFFBQU8sRUFBRSxDQUFDLEdBQUcsR0FBRyxhQUFhLEdBQUcsS0FBSztBQUM5RCxNQUFJLFVBQVUsS0FBTSxRQUFPO0FBRTNCLE1BQUksaUJBQWlCLEtBQUs7QUFDeEIsV0FBTyxFQUFFLENBQUMsR0FBRyxHQUFHLE9BQU8sR0FBRyxDQUFDLEdBQUcsTUFBTSxRQUFRLENBQUMsRUFBRSxJQUFJLENBQUMsQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLGdCQUFnQixDQUFDLEdBQUcsZ0JBQWdCLENBQUMsQ0FBQyxDQUFDLEVBQUU7QUFBQSxFQUMzRztBQUNBLE1BQUksaUJBQWlCLEtBQUs7QUFDeEIsV0FBTyxFQUFFLENBQUMsR0FBRyxHQUFHLE9BQU8sR0FBRyxDQUFDLEdBQUcsTUFBTSxPQUFPLENBQUMsRUFBRSxJQUFJLGVBQWUsRUFBRTtBQUFBLEVBQ3JFO0FBQ0EsTUFBSSxNQUFNLFFBQVEsS0FBSyxFQUFHLFFBQU8sTUFBTSxJQUFJLGVBQWU7QUFFMUQsTUFBSSxPQUFPLFVBQVUsVUFBVTtBQUM3QixVQUFNLE1BQStCLENBQUM7QUFDdEMsZUFBVyxDQUFDLEdBQUcsQ0FBQyxLQUFLLE9BQU8sUUFBUSxLQUFLLEVBQUcsS0FBSSxDQUFDLElBQUksZ0JBQWdCLENBQUM7QUFDdEUsV0FBTztBQUFBLEVBQ1Q7QUFFQSxNQUFJLE9BQU8sVUFBVSxjQUFjLE9BQU8sVUFBVSxZQUFZLE9BQU8sVUFBVSxVQUFVO0FBQ3pGLFVBQU0sSUFBSTtBQUFBLE1BQ1IsNEJBQWEsT0FBTyxLQUFLO0FBQUEsSUFHM0I7QUFBQSxFQUNGO0FBS0EsU0FBTztBQUNUO0FBR08sU0FBUyxnQkFBZ0IsT0FBeUI7QUFDdkQsTUFBSSxVQUFVLFFBQVEsT0FBTyxVQUFVLFNBQVUsUUFBTztBQUV4RCxNQUFJLE1BQU0sS0FBSyxHQUFHO0FBQ2hCLFVBQU0sT0FBUSxNQUFrQyxHQUFHO0FBQ25ELFVBQU0sVUFBVyxNQUFrQyxHQUFHO0FBQ3RELFFBQUksU0FBUyxZQUFhLFFBQU87QUFDakMsUUFBSSxTQUFTLE9BQU87QUFDbEIsWUFBTSxVQUFVO0FBQ2hCLGFBQU8sSUFBSSxJQUFJLFFBQVEsSUFBSSxDQUFDLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQyxnQkFBZ0IsQ0FBQyxHQUFHLGdCQUFnQixDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQUEsSUFDbEY7QUFDQSxRQUFJLFNBQVMsT0FBTztBQUNsQixZQUFNLFNBQVM7QUFDZixhQUFPLElBQUksSUFBSSxPQUFPLElBQUksZUFBZSxDQUFDO0FBQUEsSUFDNUM7QUFDQSxVQUFNLElBQUksTUFBTSxpRUFBb0IsT0FBTyxJQUFJLENBQUMsNEVBQWdCO0FBQUEsRUFDbEU7QUFFQSxNQUFJLE1BQU0sUUFBUSxLQUFLLEVBQUcsUUFBTyxNQUFNLElBQUksZUFBZTtBQUUxRCxRQUFNLE1BQStCLENBQUM7QUFDdEMsYUFBVyxDQUFDLEdBQUcsQ0FBQyxLQUFLLE9BQU8sUUFBUSxLQUFLLEVBQUcsS0FBSSxDQUFDLElBQUksZ0JBQWdCLENBQUM7QUFDdEUsU0FBTztBQUNUO0FBNkJPLFNBQVMsb0JBQTZDLE1BQVk7QUFDdkUsUUFBTSxjQUFjLENBQUMsV0FBaUQ7QUFBQSxJQUNwRSxNQUFNLGdCQUFnQixNQUFNLElBQUk7QUFBQSxFQUNsQztBQUVBLFFBQU0sVUFBeUI7QUFBQSxJQUM3QixZQUFZLFNBQXdCO0FBQ2xDLFdBQUssWUFBWSxnQkFBZ0IsT0FBTyxDQUFDO0FBQUEsSUFDM0M7QUFBQSxFQUNGO0FBT0EsTUFBSSxPQUFPLEtBQUsscUJBQXFCLFlBQVk7QUFDL0MsWUFBUSxtQkFBbUIsQ0FBQyxNQUFNLGFBQWE7QUFDN0MsV0FBSyxtQkFBbUIsTUFBTSxDQUFDLFVBQVU7QUFDdkMsaUJBQVMsWUFBWSxLQUFLLENBQUM7QUFBQSxNQUM3QixDQUFDO0FBQUEsSUFDSDtBQUFBLEVBQ0YsT0FBTztBQUNMLFdBQU8sZUFBZSxTQUFTLGFBQWE7QUFBQSxNQUMxQyxLQUFLLE1BQU0sS0FBSyxhQUFhO0FBQUEsTUFDN0IsS0FBSyxDQUFDLGFBQTBEO0FBQzlELGFBQUssWUFDSCxhQUFhLE9BQ1QsT0FDQSxDQUFDLFVBQVU7QUFDVCxtQkFBUyxZQUFZLEtBQUssQ0FBQztBQUFBLFFBQzdCO0FBQUEsTUFDUjtBQUFBLElBQ0YsQ0FBQztBQUFBLEVBQ0g7QUFFQSxTQUFPO0FBQ1Q7OztBQ3JKQSxTQUFTQyxhQUFZLEdBQW9CLEdBQTRCO0FBQ25FLFFBQU0sT0FBTyxDQUFDLE1BQXVCO0FBQ25DLFFBQUksT0FBTyxNQUFNLFNBQVUsUUFBTztBQUNsQyxRQUFJLGFBQWEsS0FBTSxRQUFPO0FBQzlCLFFBQUksT0FBTyxNQUFNLFNBQVUsUUFBTztBQUNsQyxRQUFJLE1BQU0sUUFBUSxDQUFDLEVBQUcsUUFBTztBQUM3QixXQUFPO0FBQUEsRUFDVDtBQUVBLE1BQUksTUFBTSxRQUFRLENBQUMsS0FBSyxNQUFNLFFBQVEsQ0FBQyxHQUFHO0FBQ3hDLFVBQU0sT0FBTyxNQUFNLFFBQVEsQ0FBQyxJQUFJLElBQUksQ0FBQyxDQUFDO0FBQ3RDLFVBQU0sT0FBTyxNQUFNLFFBQVEsQ0FBQyxJQUFJLElBQUksQ0FBQyxDQUFDO0FBRXRDLFFBQUksTUFBTSxRQUFRLENBQUMsTUFBTSxNQUFNLFFBQVEsQ0FBQyxHQUFHO0FBQ3pDLGFBQU8sS0FBSyxDQUFDLElBQUksS0FBSyxDQUFDO0FBQUEsSUFDekI7QUFDQSxVQUFNLE1BQU0sS0FBSyxJQUFJLEtBQUssUUFBUSxLQUFLLE1BQU07QUFDN0MsYUFBUyxJQUFJLEdBQUcsSUFBSSxLQUFLLEtBQUs7QUFDNUIsWUFBTSxPQUFPQSxhQUFZLEtBQUssQ0FBQyxHQUFZLEtBQUssQ0FBQyxDQUFVO0FBQzNELFVBQUksU0FBUyxFQUFHLFFBQU87QUFBQSxJQUN6QjtBQUNBLFdBQU8sS0FBSyxTQUFTLEtBQUs7QUFBQSxFQUM1QjtBQUVBLFFBQU0sV0FBVyxLQUFLLENBQUMsSUFBSSxLQUFLLENBQUM7QUFDakMsTUFBSSxhQUFhLEVBQUcsUUFBTztBQUUzQixNQUFJLE9BQU8sTUFBTSxZQUFZLE9BQU8sTUFBTSxTQUFVLFFBQU8sSUFBSTtBQUkvRCxTQUFPLE9BQU8sQ0FBQyxJQUFJLE9BQU8sQ0FBQyxJQUFJLEtBQUssT0FBTyxDQUFDLElBQUksT0FBTyxDQUFDLElBQUksSUFBSTtBQUNsRTtBQVNBLElBQU0sb0JBQU4sY0FBZ0MsTUFBTTtBQUFBLEVBQ3BDLFlBQVksTUFBYztBQUN4QixVQUFNLHVDQUFTLElBQUksRUFBRTtBQUNyQixTQUFLLE9BQU87QUFBQSxFQUNkO0FBQ0Y7QUFHQSxTQUFTLGFBQWEsS0FBOEI7QUFDbEQsU0FBTyxLQUFLLFVBQVUsR0FBRztBQUMzQjtBQUdBLFNBQVNDLGFBQVksT0FBZ0IsTUFBdUI7QUFDMUQsTUFBSSxVQUFtQjtBQUN2QixhQUFXLFdBQVcsS0FBSyxNQUFNLEdBQUcsR0FBRztBQUNyQyxRQUFJLFlBQVksUUFBUSxPQUFPLFlBQVksU0FBVSxRQUFPO0FBQzVELGNBQVcsUUFBb0MsT0FBTztBQUFBLEVBQ3hEO0FBQ0EsU0FBTztBQUNUO0FBR0EsU0FBUyxZQUFZLE9BQWdCLFNBQWtFO0FBQ3JHLE1BQUksT0FBTyxZQUFZLFVBQVU7QUFDL0IsVUFBTSxJQUFJQSxhQUFZLE9BQU8sT0FBTztBQUNwQyxXQUFPLE9BQU8sTUFBTSxZQUFZLE9BQU8sTUFBTSxXQUFXLElBQUk7QUFBQSxFQUM5RDtBQUNBLFFBQU0sUUFBaUIsQ0FBQztBQUN4QixhQUFXLEtBQUssU0FBUztBQUN2QixVQUFNLElBQUlBLGFBQVksT0FBTyxDQUFDO0FBQzlCLFFBQUksT0FBTyxNQUFNLFlBQVksT0FBTyxNQUFNLFNBQVUsUUFBTztBQUMzRCxVQUFNLEtBQUssQ0FBQztBQUFBLEVBQ2Q7QUFDQSxTQUFPO0FBQ1Q7QUFHQSxTQUFTLFFBQVEsS0FBc0IsT0FBNkI7QUFDbEUsTUFBSSxVQUFVLE9BQVcsUUFBTztBQUNoQyxRQUFNLEVBQUUsT0FBTyxPQUFPLFdBQVcsVUFBVSxJQUFJO0FBQy9DLE1BQUksVUFBVSxRQUFXO0FBQ3ZCLFVBQU0sT0FBT0QsYUFBWSxLQUFLLEtBQUs7QUFDbkMsUUFBSSxPQUFPLEtBQU0sU0FBUyxLQUFLLGNBQWMsS0FBTyxRQUFPO0FBQUEsRUFDN0Q7QUFDQSxNQUFJLFVBQVUsUUFBVztBQUN2QixVQUFNLE9BQU9BLGFBQVksS0FBSyxLQUFLO0FBQ25DLFFBQUksT0FBTyxLQUFNLFNBQVMsS0FBSyxjQUFjLEtBQU8sUUFBTztBQUFBLEVBQzdEO0FBQ0EsU0FBTztBQUNUO0FBR0EsU0FBUyxrQkFBa0IsVUFBMkIsT0FBK0I7QUFDbkYsTUFBSSxVQUFVLE9BQVcsUUFBTztBQUNoQyxNQUFJLE9BQU8sVUFBVSxZQUFZLE9BQU8sVUFBVSxVQUFVO0FBQzFELFdBQU9BLGFBQVksVUFBVSxLQUFLLE1BQU07QUFBQSxFQUMxQztBQUNBLE1BQUksTUFBTSxRQUFRLEtBQUssR0FBRztBQUN4QixXQUFPLGFBQWEsUUFBUSxNQUFNLGFBQWEsS0FBSztBQUFBLEVBQ3REO0FBQ0EsU0FBTyxRQUFRLFVBQVUsS0FBSztBQUNoQztBQW1CTyxJQUFNLGtCQUFOLE1BQTJDO0FBQUEsRUFDeEMsU0FBUyxvQkFBSSxJQUEyQjtBQUFBLEVBQ3hDLFVBQVU7QUFBQTtBQUFBLEVBR1YsWUFBWTtBQUFBO0FBQUEsRUFHWjtBQUFBLEVBQ0EsWUFBWTtBQUFBLEVBQ1osVUFBNEIsUUFBUSxRQUFRO0FBQUEsRUFFcEQsWUFBWSxTQUFpQyxDQUFDLEdBQUc7QUFDL0MsZUFBVyxLQUFLLFFBQVE7QUFDdEIsV0FBSyxPQUFPLElBQUksRUFBRSxNQUFNO0FBQUEsUUFDdEIsUUFBUTtBQUFBLFFBQ1IsU0FBUyxvQkFBSSxJQUFJO0FBQUEsUUFDakIsZUFBZTtBQUFBLE1BQ2pCLENBQUM7QUFBQSxJQUNIO0FBQUEsRUFDRjtBQUFBLEVBRUEsTUFBTSxPQUFzQjtBQUMxQixRQUFJLEtBQUssVUFBVyxPQUFNLElBQUksc0JBQXNCLFFBQVE7QUFDNUQsU0FBSyxVQUFVO0FBQUEsRUFDakI7QUFBQSxFQUVBLFFBQWM7QUFDWixTQUFLLFVBQVU7QUFBQSxFQUNqQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFlQSxNQUFNLFVBQW9DO0FBQ3hDLFFBQUksS0FBSyxlQUFlLE9BQVcsUUFBTyxLQUFLO0FBQy9DLFNBQUssVUFBVTtBQUNmLFFBQUksZ0JBQWdCO0FBQ3BCLGVBQVcsU0FBUyxLQUFLLE9BQU8sT0FBTyxHQUFHO0FBQ3hDLFlBQU0sUUFBUSxNQUFNO0FBQ3BCLFlBQU0sZ0JBQWdCO0FBQ3RCLHVCQUFpQjtBQUFBLElBQ25CO0FBQ0EsU0FBSyxZQUFZO0FBQ2pCLFNBQUssYUFBYSxRQUFRLFFBQVE7QUFBQSxNQUNoQyxRQUFRO0FBQUEsTUFDUixrQkFBa0I7QUFBQSxNQUNsQixRQUFRO0FBQUEsTUFDUjtBQUFBLElBQ0YsQ0FBQztBQUNELFdBQU8sS0FBSztBQUFBLEVBQ2Q7QUFBQTtBQUFBLEVBR0EsWUFBWSxRQUEyQjtBQUNyQyxRQUFJLEtBQUssT0FBTyxJQUFJLE9BQU8sSUFBSSxFQUFHO0FBQ2xDLFNBQUssT0FBTyxJQUFJLE9BQU8sTUFBTSxFQUFFLFFBQVEsU0FBUyxvQkFBSSxJQUFJLEdBQUcsZUFBZSxFQUFFLENBQUM7QUFBQSxFQUMvRTtBQUFBO0FBQUEsRUFJQSxJQUFJLE9BQWUsT0FBaUM7QUFDbEQsV0FBTyxLQUFLLFlBQVksQ0FBQyxLQUFLLEdBQUcsYUFBYSxPQUFPLE9BQU8sR0FBRyxJQUFJLE9BQU8sS0FBSyxDQUFDO0FBQUEsRUFDbEY7QUFBQSxFQUVBLElBQUksT0FBZSxPQUFnQixLQUE0QjtBQUM3RCxXQUFPLEtBQUssWUFBWSxDQUFDLEtBQUssR0FBRyxhQUFhLE9BQU8sT0FBTyxHQUFHLElBQUksT0FBTyxPQUFPLEdBQUcsQ0FBQztBQUFBLEVBQ3ZGO0FBQUEsRUFFQSxJQUFPLE9BQWUsS0FBb0M7QUFDeEQsV0FBTyxLQUFLLFlBQVksQ0FBQyxLQUFLLEdBQUcsWUFBWSxPQUFPLE9BQU8sR0FBRyxJQUFPLE9BQU8sR0FBRyxDQUFDO0FBQUEsRUFDbEY7QUFBQSxFQUVBLE9BQVUsT0FBZSxPQUFvQixPQUE4QjtBQUN6RSxXQUFPLEtBQUssWUFBWSxDQUFDLEtBQUssR0FBRyxZQUFZLE9BQU8sT0FBTyxHQUFHLE9BQVUsT0FBTyxPQUFPLEtBQUssQ0FBQztBQUFBLEVBQzlGO0FBQUEsRUFFQSxPQUFPLE9BQWUsS0FBMkI7QUFDL0MsV0FBTyxLQUFLLFlBQVksQ0FBQyxLQUFLLEdBQUcsYUFBYSxPQUFPLE9BQU8sR0FBRyxPQUFPLE9BQU8sR0FBRyxDQUFDO0FBQUEsRUFDbkY7QUFBQSxFQUVBLE1BQU0sT0FBOEI7QUFDbEMsV0FBTyxLQUFLLFlBQVksQ0FBQyxLQUFLLEdBQUcsYUFBYSxPQUFPLE9BQU8sR0FBRyxNQUFNLEtBQUssQ0FBQztBQUFBLEVBQzdFO0FBQUEsRUFFQSxNQUFNLE9BQWUsT0FBcUM7QUFDeEQsV0FBTyxLQUFLLFlBQVksQ0FBQyxLQUFLLEdBQUcsWUFBWSxPQUFPLE9BQU8sR0FBRyxNQUFNLE9BQU8sS0FBSyxDQUFDO0FBQUEsRUFDbkY7QUFBQSxFQUVBLGFBQWdCLE9BQWUsT0FBZSxLQUE4QztBQUMxRixXQUFPLEtBQUssWUFBWSxDQUFDLEtBQUssR0FBRyxZQUFZLE9BQU8sT0FBTyxHQUFHLGFBQWdCLE9BQU8sT0FBTyxHQUFHLENBQUM7QUFBQSxFQUNsRztBQUFBLEVBRUEsZ0JBQWdCLE9BQWUsT0FBZSxLQUFrRDtBQUM5RixXQUFPLEtBQUssWUFBWSxDQUFDLEtBQUssR0FBRyxZQUFZLE9BQU8sT0FBTyxHQUFHLGdCQUFnQixPQUFPLE9BQU8sR0FBRyxDQUFDO0FBQUEsRUFDbEc7QUFBQSxFQUVBLGdCQUFtQixPQUFlLE9BQWUsT0FBb0M7QUFDbkYsV0FBTyxLQUFLLFlBQVksQ0FBQyxLQUFLLEdBQUcsWUFBWSxPQUFPLE9BQU8sR0FBRyxnQkFBbUIsT0FBTyxPQUFPLEtBQUssQ0FBQztBQUFBLEVBQ3ZHO0FBQUEsRUFFQSxlQUFlLE9BQWUsT0FBZSxPQUF1QztBQUNsRixXQUFPLEtBQUssWUFBWSxDQUFDLEtBQUssR0FBRyxZQUFZLE9BQU8sT0FBTyxHQUFHLGVBQWUsT0FBTyxPQUFPLEtBQUssQ0FBQztBQUFBLEVBQ25HO0FBQUEsRUFFQSxRQUFXLE9BQWUsU0FBMkIsT0FBMEM7QUFDN0YsV0FBTyxLQUFLLFlBQVksQ0FBQyxLQUFLLEdBQUcsYUFBYSxPQUFPLE9BQU8sR0FBRyxRQUFXLE9BQU8sU0FBUyxLQUFLLENBQUM7QUFBQSxFQUNsRztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBUUEsTUFBTSxZQUFlLFFBQWtCLE9BQWlCLElBQTBDO0FBZ0JoRyxRQUFJLEtBQUssWUFBWSxHQUFHO0FBQ3RCLFlBQU0sSUFBSSxNQUFNLGdIQUFnQztBQUFBLElBQ2xEO0FBSUEsUUFBSSxLQUFLLFVBQVcsT0FBTSxJQUFJLHNCQUFzQixRQUFRO0FBRTVELGVBQVcsUUFBUSxRQUFRO0FBQ3pCLFVBQUksQ0FBQyxLQUFLLE9BQU8sSUFBSSxJQUFJLEdBQUc7QUFDMUIsY0FBTSxJQUFJO0FBQUEsVUFDUiwyRUFBb0IsSUFBSSx1Q0FBUyxDQUFDLEdBQUcsS0FBSyxPQUFPLEtBQUssQ0FBQyxFQUFFLEtBQUssSUFBSSxDQUFDO0FBQUEsUUFDckU7QUFBQSxNQUNGO0FBQUEsSUFDRjtBQUdBLFVBQU0sV0FBVyxvQkFBSSxJQUE2RTtBQUNsRyxlQUFXLFFBQVEsUUFBUTtBQUN6QixZQUFNLElBQUksS0FBSyxPQUFPLElBQUksSUFBSTtBQUM5QixlQUFTLElBQUksTUFBTSxFQUFFLFNBQVMsSUFBSSxJQUFJLEVBQUUsT0FBTyxHQUFHLGVBQWUsRUFBRSxjQUFjLENBQUM7QUFBQSxJQUNwRjtBQUVBLFVBQU0sTUFBTSxZQUF3QjtBQUNsQyxXQUFLO0FBQ0wsVUFBSTtBQUNKLFVBQUk7QUFDRixrQkFBVSxHQUFHLEtBQUssT0FBTyxNQUFNLENBQUM7QUFBQSxNQUNsQyxVQUFFO0FBRUEsYUFBSztBQUFBLE1BQ1A7QUFDQSxVQUFJO0FBQ0YsZUFBTyxNQUFNO0FBQUEsTUFDZixTQUFTLE9BQU87QUFHZCxtQkFBVyxDQUFDLE1BQU0sSUFBSSxLQUFLLFVBQVU7QUFDbkMsZ0JBQU0sSUFBSSxLQUFLLE9BQU8sSUFBSSxJQUFJO0FBQzlCLFlBQUUsVUFBVSxLQUFLO0FBQ2pCLFlBQUUsZ0JBQWdCLEtBQUs7QUFBQSxRQUN6QjtBQUNBLGNBQU07QUFBQSxNQUNSO0FBQUEsSUFDRjtBQUlBLFVBQU0sU0FBUyxLQUFLLFFBQVEsS0FBSyxLQUFLLEdBQUc7QUFFekMsU0FBSyxVQUFVLE9BQU87QUFBQSxNQUNwQixNQUFNO0FBQUEsTUFDTixNQUFNO0FBQUEsSUFDUjtBQUNBLFdBQU87QUFBQSxFQUNUO0FBQUE7QUFBQSxFQUdRLE9BQU8sU0FBeUI7QUFDdEMsVUFBTSxTQUFTLENBQUMsVUFBaUM7QUFDL0MsVUFBSSxDQUFDLFFBQVEsU0FBUyxLQUFLLEdBQUc7QUFDNUIsY0FBTSxJQUFJLE1BQU0sY0FBUyxLQUFLLDJFQUFlLFFBQVEsS0FBSyxJQUFJLENBQUMsRUFBRTtBQUFBLE1BQ25FO0FBQ0EsWUFBTSxJQUFJLEtBQUssT0FBTyxJQUFJLEtBQUs7QUFDL0IsVUFBSSxDQUFDLEdBQUc7QUFDTixjQUFNLElBQUksTUFBTSw2Q0FBZSxLQUFLLFFBQUc7QUFBQSxNQUN6QztBQUNBLGFBQU87QUFBQSxJQUNUO0FBRUEsVUFBTSxZQUFZLENBQUMsT0FBc0IsY0FBc0I7QUFDN0QsWUFBTSxNQUFNLE1BQU0sT0FBTyxTQUFTLEtBQUssQ0FBQyxNQUFNLEVBQUUsU0FBUyxTQUFTO0FBQ2xFLFVBQUksQ0FBQyxLQUFLO0FBQ1IsY0FBTSxJQUFJLE1BQU0sY0FBUyxNQUFNLE9BQU8sSUFBSSw2Q0FBVSxTQUFTLFFBQUc7QUFBQSxNQUNsRTtBQUNBLGFBQU87QUFBQSxJQUNUO0FBR0EsVUFBTSxlQUFlLENBQ25CLE9BQ0EsS0FDQSxVQUN3QjtBQVN4QixVQUFJLE9BQU8sSUFBSSxZQUFZLFVBQVU7QUFDbkMsY0FBTSxNQUFNQyxhQUFZLE9BQU8sSUFBSSxPQUFPO0FBQzFDLFlBQUksUUFBUSxPQUFXLFFBQU8sQ0FBQztBQUMvQixZQUFJLElBQUksZUFBZSxNQUFNO0FBQzNCLGNBQUksQ0FBQyxNQUFNLFFBQVEsR0FBRyxFQUFHLFFBQU8sQ0FBQztBQUNqQyxpQkFBTyxJQUFJLE9BQU8sQ0FBQyxNQUFNLE9BQU8sTUFBTSxZQUFZLE9BQU8sTUFBTSxRQUFRO0FBQUEsUUFDekU7QUFDQSxZQUFJLE9BQU8sUUFBUSxZQUFZLE9BQU8sUUFBUSxTQUFVLFFBQU8sQ0FBQztBQUNoRSxlQUFPLENBQUMsR0FBRztBQUFBLE1BQ2I7QUFFQSxZQUFNLFlBQVksWUFBWSxPQUFPLElBQUksT0FBTztBQUNoRCxVQUFJLGNBQWMsT0FBVyxRQUFPLENBQUM7QUFDckMsVUFBSSxJQUFJLGVBQWUsUUFBUSxNQUFNLFFBQVEsU0FBUyxHQUFHO0FBQ3ZELGVBQU8sVUFBVSxJQUFJLENBQUMsTUFBTSxDQUFVO0FBQUEsTUFDeEM7QUFDQSxhQUFPLENBQUMsU0FBUztBQUFBLElBQ25CO0FBRUEsVUFBTSxjQUFjLENBQUMsUUFBd0IsUUFBd0IsVUFBOEM7QUFDakgsY0FBUSxRQUFRO0FBQUEsUUFDZCxLQUFLO0FBQ0gsaUJBQU87QUFBQSxRQUNULEtBQUs7QUFDSCxpQkFBTztBQUFBLFFBQ1QsS0FBSztBQUNILGdCQUFNLFFBQVEsT0FBTyxhQUFhLE9BQU8sR0FBRyxDQUFDO0FBQzdDLGlCQUFPO0FBQUEsUUFDVCxLQUFLO0FBQ0gsZ0JBQU0sUUFBUSxPQUFPLGFBQWEsT0FBTyxHQUFHLENBQUM7QUFDN0MsaUJBQU87QUFBQSxNQUNYO0FBQUEsSUFDRjtBQUVBLFVBQU0sZ0JBQWdCLENBQUMsVUFDckIsQ0FBQyxHQUFHLE1BQU0sUUFBUSxPQUFPLENBQUMsRUFBRSxLQUFLLENBQUMsR0FBRyxNQUFNRCxhQUFZLEVBQUUsS0FBSyxFQUFFLEdBQUcsQ0FBQztBQVV0RSxVQUFNLFNBQVMsQ0FBQyxXQUFtQixVQUFvQztBQUNyRSxZQUFNLFFBQVEsT0FBTyxTQUFTO0FBQzlCLFlBQU0sU0FBUztBQUNmLFlBQU0sVUFBVSxNQUFNLE9BQU87QUFDN0IsVUFBSSxNQUFNLFlBQVksU0FBWSxTQUFZLFlBQVksUUFBUSxPQUFPO0FBRXpFLFVBQUksUUFBUSxRQUFXO0FBQ3JCLFlBQUksWUFBWSxVQUFhLE1BQU0sT0FBTyxrQkFBa0IsTUFBTTtBQUNoRSxnQkFBTSxJQUFJLE1BQU0sY0FBUyxTQUFTLHFFQUFjLE9BQU8sT0FBTyxDQUFDLFFBQUc7QUFBQSxRQUNwRTtBQUNBLGNBQU0sRUFBRSxNQUFNO0FBRWQsWUFBSSxZQUFZLFFBQVc7QUFDekIsZ0JBQU0sT0FBTyxPQUFPLFlBQVksV0FBVyxVQUFVLFFBQVEsQ0FBQztBQUM5RCxjQUFJLFNBQVMsT0FBVyxRQUFPLElBQUksSUFBSTtBQUFBLFFBQ3pDO0FBQUEsTUFDRixXQUFXLE9BQU8sUUFBUSxZQUFZLE1BQU0sTUFBTSxlQUFlO0FBQy9ELGNBQU0sZ0JBQWdCO0FBQUEsTUFDeEI7QUFJQSxpQkFBVyxPQUFPLE1BQU0sT0FBTyxXQUFXLENBQUMsR0FBRztBQUM1QyxZQUFJLElBQUksV0FBVyxLQUFNO0FBQ3pCLG1CQUFXLFNBQVMsYUFBYSxPQUFPLEtBQUssTUFBTSxHQUFHO0FBQ3BELHFCQUFXLFlBQVksTUFBTSxRQUFRLE9BQU8sR0FBRztBQUM3QyxnQkFBSSxTQUFTLFFBQVEsSUFBSztBQUMxQix1QkFBVyxjQUFjLGFBQWEsT0FBTyxLQUFLLFNBQVMsS0FBSyxHQUFHO0FBQ2pFLGtCQUFJQSxhQUFZLE9BQU8sVUFBVSxNQUFNLEdBQUc7QUFDeEMsc0JBQU0sSUFBSSxrQkFBa0IsSUFBSSxJQUFJO0FBQUEsY0FDdEM7QUFBQSxZQUNGO0FBQUEsVUFDRjtBQUFBLFFBQ0Y7QUFBQSxNQUNGO0FBRUEsVUFBSSxNQUFNLFFBQVEsSUFBSSxhQUFhLEdBQUcsQ0FBQyxHQUFHO0FBQ3hDLGNBQU0sSUFBSSxrQkFBa0IsT0FBTyxXQUFXLGNBQUksQ0FBQztBQUFBLE1BQ3JEO0FBQ0EsWUFBTSxRQUFRLElBQUksYUFBYSxHQUFHLEdBQUcsRUFBRSxLQUFLLE9BQU8sT0FBTyxDQUFDO0FBQzNELGFBQU8sRUFBRSxLQUFLLE9BQU8sUUFBUSxXQUFXLE1BQU0sRUFBRTtBQUFBLElBQ2xEO0FBRUEsV0FBTztBQUFBLE1BQ0wsS0FBSyxPQUFPLFdBQVcsVUFBVTtBQUMvQixjQUFNLEVBQUUsSUFBSSxJQUFJLE9BQU8sV0FBVyxLQUFLO0FBQ3ZDLGVBQU87QUFBQSxNQUNUO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQVNBLHdCQUF3QixPQUFPLFdBQVcsVUFBVTtBQUNsRCxZQUFJO0FBQ0YsZ0JBQU0sRUFBRSxJQUFJLElBQUksT0FBTyxXQUFXLEtBQUs7QUFDdkMsaUJBQU8sRUFBRSxJQUFJLE1BQWUsSUFBSTtBQUFBLFFBQ2xDLFNBQVMsT0FBTztBQUNkLGNBQUksaUJBQWlCLG1CQUFtQjtBQUN0QyxtQkFBTyxFQUFFLElBQUksT0FBZ0IsUUFBUSxZQUFxQjtBQUFBLFVBQzVEO0FBQ0EsZ0JBQU07QUFBQSxRQUNSO0FBQUEsTUFDRjtBQUFBLE1BQ0EsS0FBSyxPQUFPLFdBQVcsT0FBTyxnQkFBZ0I7QUFDNUMsY0FBTSxRQUFRLE9BQU8sU0FBUztBQUM5QixjQUFNLFNBQVM7QUFDZixjQUFNLFVBQVUsTUFBTSxPQUFPO0FBQzdCLGNBQU0sTUFBTSxnQkFBZ0IsWUFBWSxTQUFZLFNBQVksWUFBWSxRQUFRLE9BQU87QUFDM0YsWUFBSSxRQUFRLFFBQVc7QUFDckIsZ0JBQU0sSUFBSSxNQUFNLGNBQVMsU0FBUywyQ0FBYTtBQUFBLFFBQ2pEO0FBQ0EsY0FBTSxRQUFRLElBQUksYUFBYSxHQUFHLEdBQUcsRUFBRSxLQUFLLE9BQU8sT0FBTyxDQUFDO0FBQUEsTUFDN0Q7QUFBQSxNQUVBLEtBQUssT0FBVyxXQUFtQixRQUFlO0FBQ2hELGNBQU0sUUFBUSxPQUFPLFNBQVM7QUFDOUIsZUFBTyxNQUFNLFFBQVEsSUFBSSxhQUFhLEdBQUcsQ0FBQyxHQUFHO0FBQUEsTUFDL0M7QUFBQSxNQUVBLFFBQVEsT0FBVyxXQUFtQixPQUFvQixVQUFtQjtBQUMzRSwyQkFBbUIsS0FBSztBQUN4QixjQUFNLFFBQVEsT0FBTyxTQUFTO0FBQzlCLGVBQU8sY0FBYyxLQUFLLEVBQ3ZCLE9BQU8sQ0FBQyxNQUFNLFFBQVEsRUFBRSxLQUFLLEtBQUssQ0FBQyxFQUNuQyxNQUFNLEdBQUcsS0FBSyxFQUNkLElBQUksQ0FBQyxNQUFNLEVBQUUsS0FBVTtBQUFBLE1BQzVCO0FBQUEsTUFFQSxRQUFRLE9BQU8sV0FBVyxRQUFRO0FBQ2hDLGNBQU0sUUFBUSxPQUFPLFNBQVM7QUFDOUIsY0FBTSxRQUFRLE9BQU8sYUFBYSxHQUFHLENBQUM7QUFBQSxNQUN4QztBQUFBLE1BRUEsT0FBTyxPQUFPLGNBQWM7QUFDMUIsY0FBTSxRQUFRLE9BQU8sU0FBUztBQUM5QixjQUFNLFFBQVEsTUFBTTtBQUFBLE1BQ3RCO0FBQUEsTUFFQSxPQUFPLE9BQU8sV0FBVyxVQUF1QjtBQUM5QyxjQUFNLFFBQVEsT0FBTyxTQUFTO0FBQzlCLGVBQU8sQ0FBQyxHQUFHLE1BQU0sUUFBUSxPQUFPLENBQUMsRUFBRSxPQUFPLENBQUMsTUFBTSxRQUFRLEVBQUUsS0FBSyxLQUFLLENBQUMsRUFBRTtBQUFBLE1BQzFFO0FBQUEsTUFFQSxjQUFjLE9BQVcsV0FBbUIsV0FBbUIsUUFBeUI7QUFDdEYsY0FBTSxRQUFRLE9BQU8sU0FBUztBQUM5QixjQUFNLE1BQU0sVUFBVSxPQUFPLFNBQVM7QUFDdEMsbUJBQVcsS0FBSyxjQUFjLEtBQUssR0FBRztBQUNwQyxxQkFBVyxTQUFTLGFBQWEsT0FBTyxLQUFLLEVBQUUsS0FBSyxHQUFHO0FBQ3JELGdCQUFJQSxhQUFZLE9BQU8sR0FBRyxNQUFNLEVBQUcsUUFBTyxFQUFFO0FBQUEsVUFDOUM7QUFBQSxRQUNGO0FBQ0EsZUFBTztBQUFBLE1BQ1Q7QUFBQSxNQUVBLGlCQUFpQixPQUFPLFdBQVcsV0FBVyxRQUFRO0FBQ3BELGNBQU0sUUFBUSxPQUFPLFNBQVM7QUFDOUIsY0FBTSxNQUFNLFVBQVUsT0FBTyxTQUFTO0FBQ3RDLG1CQUFXLEtBQUssY0FBYyxLQUFLLEdBQUc7QUFDcEMscUJBQVcsU0FBUyxhQUFhLE9BQU8sS0FBSyxFQUFFLEtBQUssR0FBRztBQUNyRCxnQkFBSUEsYUFBWSxPQUFPLEdBQUcsTUFBTSxHQUFHO0FBSWpDLHFCQUFPLEVBQUU7QUFBQSxZQUNYO0FBQUEsVUFDRjtBQUFBLFFBQ0Y7QUFDQSxlQUFPO0FBQUEsTUFDVDtBQUFBLE1BRUEsaUJBQWlCLE9BQVcsV0FBbUIsV0FBbUIsVUFBeUI7QUFDekYsY0FBTSxRQUFRLE9BQU8sU0FBUztBQUM5QixjQUFNLE1BQU0sVUFBVSxPQUFPLFNBQVM7QUFDdEMsY0FBTSxNQUFXLENBQUM7QUFDbEIsbUJBQVcsS0FBSyxjQUFjLEtBQUssR0FBRztBQUNwQyxxQkFBVyxTQUFTLGFBQWEsT0FBTyxLQUFLLEVBQUUsS0FBSyxHQUFHO0FBQ3JELGdCQUFJLGtCQUFrQixPQUFPLEtBQUssR0FBRztBQUNuQyxrQkFBSSxLQUFLLEVBQUUsS0FBVTtBQUNyQjtBQUFBLFlBQ0Y7QUFBQSxVQUNGO0FBQUEsUUFDRjtBQUNBLGVBQU87QUFBQSxNQUNUO0FBQUEsTUFFQSxnQkFBZ0IsT0FBTyxXQUFXLFdBQVcsVUFBeUI7QUFDcEUsY0FBTSxRQUFRLE9BQU8sU0FBUztBQUM5QixjQUFNLE1BQU0sVUFBVSxPQUFPLFNBQVM7QUFDdEMsWUFBSSxJQUFJO0FBQ1IsbUJBQVcsS0FBSyxjQUFjLEtBQUssR0FBRztBQUNwQyxxQkFBVyxTQUFTLGFBQWEsT0FBTyxLQUFLLEVBQUUsS0FBSyxHQUFHO0FBQ3JELGdCQUFJLGtCQUFrQixPQUFPLEtBQUssR0FBRztBQUNuQztBQUNBO0FBQUEsWUFDRjtBQUFBLFVBQ0Y7QUFBQSxRQUNGO0FBQ0EsZUFBTztBQUFBLE1BQ1Q7QUFBQSxNQUVBLFNBQVMsT0FBVyxXQUFtQixTQUEyQixVQUE4QjtBQUM5RixjQUFNLFFBQVEsT0FBTyxTQUFTO0FBRzlCLDJCQUFtQixRQUFRLEtBQUs7QUFFaEMsY0FBTSxFQUFFLFlBQVksUUFBUSxPQUFPLE9BQU8sT0FBTyxNQUFNLElBQUk7QUFDM0QsWUFBSTtBQUVKLFlBQUksVUFBVSxRQUFXO0FBQ3ZCLHVCQUFhLGNBQWMsS0FBSyxFQUFFLE9BQU8sQ0FBQyxNQUFNLFFBQVEsRUFBRSxLQUFLLEVBQUUsT0FBTyxNQUFNLENBQUMsQ0FBQztBQUFBLFFBQ2xGLE9BQU87QUFDTCxnQkFBTSxNQUFNLFVBQVUsT0FBTyxLQUFLO0FBQ2xDLHVCQUFhLGNBQWMsS0FBSyxFQUFFO0FBQUEsWUFBTyxDQUFDLE1BQ3hDLGFBQWEsT0FBTyxLQUFLLEVBQUUsS0FBSyxFQUFFLEtBQUssQ0FBQyxVQUFVLFFBQVEsT0FBTyxFQUFFLE9BQU8sTUFBTSxDQUFDLENBQUM7QUFBQSxVQUNwRjtBQUFBLFFBQ0Y7QUFFQSxZQUFJLGNBQWMsT0FBUSxZQUFXLFFBQVE7QUFFN0MsY0FBTSxNQUFNLFNBQVM7QUFDckIsWUFBSSxVQUFVO0FBQ2QsbUJBQVcsVUFBVSxZQUFZO0FBQy9CLGNBQUksV0FBVyxJQUFLO0FBQ3BCO0FBQ0EsZ0JBQU0sU0FBUyxNQUFNLE9BQU8sT0FBWSxPQUFPLEdBQVk7QUFDM0QsY0FBSSxZQUFZLFFBQVEsUUFBUSxLQUFLLE1BQU0sT0FBUTtBQUFBLFFBQ3JEO0FBQUEsTUFDRjtBQUFBLElBQ0Y7QUFBQSxFQUNGO0FBQ0Y7OztBQ2xrQkEsSUFBTSw4QkFBOEI7QUF1QjdCLElBQU0sZUFBTixNQUVQO0FBQUEsRUFDRSxZQUNtQixJQUVBLG9CQUFvQixLQUNyQztBQUhpQjtBQUVBO0FBQUEsRUFDaEI7QUFBQSxFQUhnQjtBQUFBLEVBRUE7QUFBQTtBQUFBLEVBS25CLE1BQU0sWUFBWSxLQUFzQztBQUN0RCxVQUFNLFNBQVMsTUFBTSxLQUFLLFlBQVksS0FBSyxTQUFTLENBQUMsQ0FBQztBQUN0RCxXQUFPLE9BQU87QUFBQSxFQUNoQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQVVBLE1BQU0sZUFBZSxLQUE4RDtBQUNqRixVQUFNLFNBQVMsTUFBTSxLQUFLLFlBQVksS0FBSyxVQUFVLENBQUMsQ0FBQztBQUN2RCxXQUFPLEVBQUUsVUFBVSxPQUFPLFVBQVUsU0FBUyxPQUFPLFNBQVMsTUFBTSxPQUFPLEtBQUs7QUFBQSxFQUNqRjtBQUFBLEVBRUEsTUFBTSwwQkFDSixLQUNBLFFBQ0EsU0FDeUM7QUFDekMsVUFBTSxTQUFTLE1BQU0sS0FBSyxZQUFZLEtBQUssUUFBUTtBQUFBLE1BQ2pELGNBQWMsUUFBUTtBQUFBLElBQ3hCLENBQUM7QUFHRCxXQUFPO0FBQUEsTUFDTCxZQUFZLE9BQU87QUFBQSxNQUNuQixjQUFjLE9BQU8sUUFBUTtBQUFBLE1BQzdCLE1BQU0sT0FBTztBQUFBLElBQ2Y7QUFBQSxFQUNGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQVNBLE1BQWMsWUFDWixLQUNBLFFBQ0EsT0FDd0M7QUFDeEMsUUFBSSxJQUFJLFdBQVcsRUFBRyxRQUFPLEVBQUUsVUFBVSxDQUFDLEdBQUcsU0FBUyxDQUFDLEdBQUcsTUFBTSxDQUFDLEVBQUU7QUFFbkUsV0FBTyxLQUFLLEdBQUc7QUFBQSxNQUNiLENBQUMsT0FBTyxLQUFLLE9BQU8sU0FBUyxPQUFPLElBQUk7QUFBQSxNQUN4QztBQUFBLE1BQ0EsT0FBTyxPQUFPO0FBQ1osY0FBTSxXQUF5QixDQUFDO0FBQ2hDLGNBQU0sVUFBd0IsQ0FBQztBQUMvQixjQUFNLE9BQWlCLENBQUM7QUFFeEIsY0FBTSxjQUFjLG9CQUFJLElBQVk7QUFFcEMsbUJBQVcsTUFBTSxLQUFLO0FBQ3BCLGNBQUksWUFBWSxJQUFJLEdBQUcsRUFBRSxHQUFHO0FBQzFCLG9CQUFRLEtBQUssRUFBRTtBQUNmO0FBQUEsVUFDRjtBQUNBLHNCQUFZLElBQUksR0FBRyxFQUFFO0FBR3JCLGNBQUksTUFBTSxHQUFHLGdCQUFnQixPQUFPLFNBQVMsV0FBVyxPQUFPLEdBQUcsRUFBRSxNQUFNLFFBQVc7QUFDbkYsb0JBQVEsS0FBSyxFQUFFO0FBQ2Y7QUFBQSxVQUNGO0FBRUEsZ0JBQU0sU0FBbUQ7QUFBQSxZQUN2RDtBQUFBLFlBQ0E7QUFBQTtBQUFBLFlBRUEsYUFBYSxNQUFNLGlCQUFpQixPQUFPLFlBQVk7QUFBQTtBQUFBO0FBQUEsWUFHdkQsY0FBYyxXQUFXLFVBQVUsWUFBWTtBQUFBLFVBQ2pEO0FBUUEsZ0JBQU0sVUFBVSxNQUFNLEdBQUcsdUJBQXVCLE9BQU8sS0FBSyxNQUFNO0FBRWxFLGNBQUksQ0FBQyxRQUFRLElBQUk7QUFFZixvQkFBUSxLQUFLLEVBQUU7QUFDZjtBQUFBLFVBQ0Y7QUFDQSxtQkFBUyxLQUFLLEVBQUU7QUFDaEIsZUFBSyxLQUFLLFFBQVEsR0FBRztBQUFBLFFBQ3ZCO0FBR0EsWUFBSSxLQUFLLFNBQVMsR0FBRztBQUNuQixnQkFBTSxTQUFTLEtBQUssSUFBSSxHQUFHLElBQUk7QUFDL0IsZ0JBQU0sVUFBVSxNQUFNLGVBQWUsSUFBSSxVQUFVLGNBQWM7QUFDakUsY0FBSSxTQUFTLFNBQVM7QUFDcEIsa0JBQU0sVUFBVSxJQUFJLFVBQVUsZ0JBQWdCLE1BQU07QUFBQSxVQUN0RDtBQUFBLFFBQ0Y7QUFFQSxlQUFPLEVBQUUsVUFBVSxTQUFTLEtBQUs7QUFBQSxNQUNuQztBQUFBLElBQ0Y7QUFBQSxFQUNGO0FBQUE7QUFBQSxFQUdBLE1BQU0sWUFBWSxNQUErQjtBQUMvQyxRQUFJLEtBQUssV0FBVyxFQUFHO0FBQ3ZCLFVBQU0sS0FBSyxHQUFHLFlBQVksQ0FBQyxPQUFPLEdBQUcsR0FBRyxhQUFhLE9BQU8sT0FBTztBQUNqRSxpQkFBVyxPQUFPLE1BQU07QUFDdEIsY0FBTSxNQUFNLE1BQU0sR0FBRyxJQUFpQyxPQUFPLEtBQUssR0FBRztBQUNyRSxZQUFJLFFBQVEsT0FBVztBQUd2QixjQUFNLEdBQUcsSUFBSSxPQUFPLEtBQUssRUFBRSxHQUFHLEtBQUssYUFBYSxVQUFVLENBQUM7QUFBQSxNQUM3RDtBQUFBLElBQ0YsQ0FBQztBQUFBLEVBQ0g7QUFBQSxFQUVBLE1BQU0sV0FBVyxPQUFnQztBQUMvQyxRQUFJLE1BQU0sV0FBVyxFQUFHO0FBQ3hCLFVBQU0sS0FBSyxHQUFHLFlBQVksQ0FBQyxPQUFPLEdBQUcsR0FBRyxhQUFhLE9BQU8sT0FBTztBQUNqRSxpQkFBVyxRQUFRLE9BQU87QUFDeEIsY0FBTSxNQUFNLE1BQU0sR0FBRztBQUFBLFVBQ25CLE9BQU87QUFBQSxVQUNQLFdBQVc7QUFBQSxVQUNYO0FBQUEsUUFDRjtBQUNBLFlBQUksUUFBUSxPQUFXO0FBQ3ZCLGNBQU0sR0FBRyxJQUFJLE9BQU8sS0FBSyxFQUFFLEdBQUcsS0FBSyxhQUFhLFNBQVMsQ0FBQztBQUFBLE1BQzVEO0FBQUEsSUFDRixDQUFDO0FBQUEsRUFDSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFTQSxNQUFNLG9CQUFvQixLQUFrQztBQUMxRCxRQUFJLElBQUksV0FBVyxFQUFHO0FBQ3RCLFVBQU0sS0FBSyxHQUFHLFlBQVksQ0FBQyxPQUFPLElBQUksR0FBRyxhQUFhLE9BQU8sT0FBTztBQUNsRSxZQUFNO0FBQUEsUUFDSjtBQUFBLFFBQ0E7QUFBQSxRQUNBLElBQUksSUFBSSxDQUFDLE9BQU8sR0FBRyxlQUFlLENBQUMsQ0FBQztBQUFBLE1BQ3RDO0FBQUEsSUFDRixDQUFDO0FBQUEsRUFDSDtBQUFBLEVBRUEsTUFBTSxvQ0FDSixNQUNBLE1BQ0EsZUFDZTtBQUNmLFVBQU0sS0FBSyxZQUFZLElBQUk7QUFDM0IsUUFBSSxrQkFBa0IsVUFBYSxjQUFjLFNBQVMsR0FBRztBQUMzRCxZQUFNLEtBQUssV0FBVyxhQUFhO0FBQUEsSUFDckM7QUFBQSxFQUNGO0FBQUE7QUFBQSxFQUdBLE1BQU0sd0JBQXdCLFlBQXVDO0FBQ25FLFVBQU0sVUFBVSxJQUFJLElBQUksVUFBVTtBQUNsQyxRQUFJLFVBQVU7QUFFZCxVQUFNLEtBQUssR0FBRyxZQUFZLENBQUMsT0FBTyxLQUFLLE9BQU8sU0FBUyxPQUFPLElBQUksR0FBRyxhQUFhLE9BQU8sT0FBTztBQUM5RixpQkFBVyxTQUFTLENBQUMsT0FBTyxLQUFLLE9BQU8sT0FBTyxHQUFHO0FBQ2hELGNBQU0sTUFBTSxNQUFNLEdBQUcsT0FBb0MsS0FBSztBQUM5RCxtQkFBVyxPQUFPLEtBQUs7QUFDckIsY0FBSSxjQUFjLElBQUksRUFBRSxLQUFLLENBQUMsUUFBUSxJQUFJLElBQUksR0FBRyxFQUFFLEdBQUc7QUFDcEQsa0JBQU0sR0FBRyxPQUFPLE9BQU8sSUFBSSxHQUFHO0FBQzlCLHVCQUFXO0FBQUEsVUFDYjtBQUFBLFFBQ0Y7QUFBQSxNQUNGO0FBRUEsVUFBSSxVQUFVLEVBQUcsT0FBTSxHQUFHLE9BQU8sT0FBTyxNQUFNLDJCQUEyQjtBQUFBLElBQzNFLENBQUM7QUFFRCxXQUFPO0FBQUEsRUFDVDtBQUFBO0FBQUEsRUFJQSxNQUFNLFlBQ0osVUFDQSxPQUNBLGVBQ3dDO0FBQ3hDLFVBQU0sTUFBTSxNQUFNLEtBQUssVUFBVSxFQUFFLE9BQU8sVUFBVSxXQUFXLEtBQUssR0FBRyxrQkFBa0IsU0FBWSxRQUFRLE1BQVM7QUFDdEgsVUFBTSxXQUFXLGtCQUFrQixTQUFZLE1BQU0sSUFBSSxPQUFPLENBQUMsTUFBTSxFQUFFLEdBQUcsYUFBYSxhQUFhO0FBQ3RHLFdBQU8sVUFBVSxTQUFZLFdBQVcsU0FBUyxNQUFNLEdBQUcsS0FBSztBQUFBLEVBQ2pFO0FBQUEsRUFFQSxNQUFNLGdCQUNKLFlBQ0EsVUFDd0M7QUFDeEMsV0FBTyxLQUFLLEdBQUcsWUFBWSxDQUFDLE9BQU8sS0FBSyxPQUFPLE9BQU8sR0FBRyxZQUFZLE9BQU8sT0FBTztBQUNqRixZQUFNLFNBQVMsTUFBTSxHQUFHO0FBQUEsUUFDdEIsT0FBTztBQUFBLFFBQUssV0FBVztBQUFBLFFBQVEsQ0FBQyxZQUFZLFFBQVE7QUFBQSxNQUN0RDtBQUNBLFlBQU0sUUFBUSxNQUFNLEdBQUc7QUFBQSxRQUNyQixPQUFPO0FBQUEsUUFBSyxXQUFXO0FBQUEsUUFBWTtBQUFBLE1BQ3JDO0FBR0EsWUFBTSxXQUFXLE1BQU0sR0FBRyxPQUFvQyxPQUFPLE9BQU87QUFDNUUsYUFBTyxDQUFDLEdBQUcsSUFBSSxJQUFJLENBQUMsR0FBRyxRQUFRLEdBQUcsT0FBTyxHQUFHLFFBQVEsRUFDakQsT0FBTyxDQUFDLE1BQU0sRUFBRSxHQUFHLGVBQWUsZUFDaEMsRUFBRSxHQUFHLGFBQWEsWUFBWSxFQUFFLEdBQUcsV0FBVyxTQUFTLFFBQVEsRUFBRSxFQUNuRSxJQUFJLENBQUMsTUFBTSxDQUFDLEVBQUUsS0FBSyxDQUFDLENBQUMsQ0FBQyxFQUFFLE9BQU8sQ0FBQyxFQUFFLEtBQUssQ0FBQyxHQUFHLE1BQU0sRUFBRSxNQUFNLEVBQUUsR0FBRztBQUFBLElBQ25FLENBQUM7QUFBQSxFQUNIO0FBQUEsRUFFQSxNQUFNLFVBQVUsTUFBZ0U7QUFDOUUsV0FBTyxLQUFLLEdBQUcsWUFBWSxDQUFDLE9BQU8sS0FBSyxPQUFPLE9BQU8sR0FBRyxZQUFZLE9BQU8sT0FBTztBQUNqRixpQkFBVyxRQUFRLENBQUMsT0FBTyxLQUFLLE9BQU8sT0FBTyxHQUFHO0FBQy9DLGNBQU0sTUFBTSxNQUFNLEdBQUcsZ0JBQWdCLE1BQU0sV0FBVyxPQUFPLElBQUk7QUFDakUsWUFBSSxRQUFRLE9BQVcsUUFBTyxHQUFHLElBQWlDLE1BQU0sR0FBRztBQUFBLE1BQzdFO0FBQ0EsYUFBTztBQUFBLElBQ1QsQ0FBQztBQUFBLEVBQ0g7QUFBQSxFQUVBLE1BQU0sa0JBQW1DO0FBQ3ZDLFVBQU0sUUFBUSxNQUFNLEtBQUssR0FBRztBQUFBLE1BQzFCLE9BQU87QUFBQSxNQUNQLFVBQVU7QUFBQSxJQUNaO0FBQ0EsV0FBTyxPQUFPLFNBQVM7QUFBQSxFQUN6QjtBQUFBLEVBRUEsTUFBTSxVQUFVLE9BQW9CLE9BQXdEO0FBRzFGLFdBQU8sS0FBSyxHQUFHLFlBQVksQ0FBQyxPQUFPLEtBQUssT0FBTyxPQUFPLEdBQUcsWUFBWSxPQUFPLE9BQU87QUFDakYsWUFBTSxNQUFNLE1BQU0sR0FBRyxPQUFvQyxPQUFPLEtBQUssT0FBTyxLQUFLO0FBQ2pGLFlBQU0sV0FBVyxNQUFNLEdBQUcsT0FBb0MsT0FBTyxTQUFTLE9BQU8sS0FBSztBQUMxRixZQUFNLFNBQVMsQ0FBQyxHQUFHLEtBQUssR0FBRyxRQUFRLEVBQUUsS0FBSyxDQUFDLEdBQUcsTUFBTSxFQUFFLE1BQU0sRUFBRSxHQUFHO0FBQ2pFLGFBQU8sVUFBVSxTQUFZLFNBQVMsT0FBTyxNQUFNLEdBQUcsS0FBSztBQUFBLElBQzdELENBQUM7QUFBQSxFQUNIO0FBQUEsRUFFQSxNQUFNLGNBQStCO0FBSW5DLFdBQU8sS0FBSyxHQUFHLFlBQVksQ0FBQyxPQUFPLEtBQUssT0FBTyxPQUFPLEdBQUcsWUFBWSxPQUFPLE9BQ3pFLE1BQU0sR0FBRyxNQUFNLE9BQU8sR0FBRyxJQUFNLE1BQU0sR0FBRyxNQUFNLE9BQU8sT0FBTyxDQUFFO0FBQUEsRUFDbkU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBVUEsTUFBTSxtQkFBMkQ7QUFDL0QsVUFBTSxPQUFPLE1BQU0sS0FBSyxHQUFHO0FBQUEsTUFDekIsT0FBTztBQUFBLE1BQ1AsV0FBVztBQUFBO0FBQUE7QUFBQSxNQUdYO0FBQUEsSUFDRjtBQUNBLFdBQU8sS0FBSyxLQUFLLENBQUMsR0FBRyxNQUFNLEVBQUUsTUFBTSxFQUFFLEdBQUc7QUFBQSxFQUMxQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBUUEsTUFBTSxvQkFBcUM7QUFDekMsV0FBTyxLQUFLLEdBQUcsZUFBZSxPQUFPLEtBQUssV0FBVyxlQUFlLFNBQVM7QUFBQSxFQUMvRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFVQSxNQUFNLFlBQVksU0FBa0M7QUFDbEQsVUFBTSxTQUFTLFVBQVUsS0FBSztBQUM5QixRQUFJLFVBQVUsRUFBRyxRQUFPO0FBRXhCLFdBQU8sS0FBSyxHQUFHO0FBQUEsTUFDYixDQUFDLE9BQU8sS0FBSyxPQUFPLFNBQVMsT0FBTyxJQUFJO0FBQUEsTUFDeEM7QUFBQSxNQUNBLE9BQU8sT0FBTztBQUNaLGNBQU0sbUJBQW1CLE1BQU0sR0FBRyxJQUcvQixPQUFPLE1BQU0sMkJBQTJCO0FBQzNDLGNBQU0sZUFBZSxNQUFNLGVBQWUsSUFBSSxVQUFVLGNBQWM7QUFDdEUsWUFBSSxDQUFDLGtCQUFrQixrQkFBa0IsT0FBTyxZQUFZLEtBQUssaUJBQWtCLE1BQU0sYUFBYSxTQUFTLEdBQUc7QUFDaEgsZ0JBQU0sSUFBSTtBQUFBO0FBQUEsWUFFUixzQkFBWSxNQUFNLHFEQUFhLFNBQVMsQ0FBQztBQUFBLFVBQzNDO0FBQUEsUUFDRjtBQUNBLGNBQU0sT0FBTyxNQUFNLEdBQUcsT0FBb0MsT0FBTyxLQUFLO0FBQUEsVUFDcEUsT0FBTztBQUFBLFVBQ1AsV0FBVztBQUFBLFFBQ2IsQ0FBQztBQUNELGNBQU0sV0FBVyxLQUFLLE9BQU8sQ0FBQyxRQUFRLElBQUksZ0JBQWdCLGFBQWEsSUFBSSxpQkFBaUIsVUFBVTtBQUN0RyxtQkFBVyxPQUFPLFVBQVU7QUFJMUIsZ0JBQU0sR0FBRyxJQUFJLE9BQU8sU0FBUyxHQUFHO0FBQ2hDLGdCQUFNLEdBQUcsT0FBTyxPQUFPLEtBQUssSUFBSSxHQUFHO0FBQUEsUUFDckM7QUFDQSxlQUFPLFNBQVM7QUFBQSxNQUNsQjtBQUFBLElBQ0Y7QUFBQSxFQUNGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQVVBLE1BQU0sb0JBQTREO0FBQ2hFLFVBQU0sT0FBTyxNQUFNLEtBQUssR0FBRztBQUFBLE1BQ3pCLE9BQU87QUFBQSxNQUNQLFdBQVc7QUFBQSxNQUNYO0FBQUEsSUFDRjtBQUNBLFdBQU8sS0FBSyxLQUFLLENBQUMsR0FBRyxNQUFNLEVBQUUsTUFBTSxFQUFFLEdBQUc7QUFBQSxFQUMxQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBV0EsTUFBTSxxQkFBc0M7QUFDMUMsV0FBTyxLQUFLLEdBQUcsZUFBZSxPQUFPLEtBQUssV0FBVyxnQkFBZ0IsU0FBUztBQUFBLEVBQ2hGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFRQSxNQUFNLGFBQ0osa0JBQ2lCO0FBQ2pCLFFBQUksaUJBQWlCLFNBQVMsRUFBRyxRQUFPO0FBRXhDLFdBQU8sS0FBSyxHQUFHO0FBQUEsTUFDYixDQUFDLE9BQU8sR0FBRztBQUFBLE1BQ1g7QUFBQSxNQUNBLE9BQU8sT0FBTztBQUNaLFlBQUksVUFBVTtBQUNkLG1CQUFXLENBQUMsTUFBTSxTQUFTLEtBQUssa0JBQWtCO0FBRWhELGdCQUFNLE1BQU0sTUFBTSxHQUFHLGdCQUFnQixPQUFPLEtBQUssV0FBVyxPQUFPLElBQUk7QUFDdkUsY0FBSSxRQUFRLE9BQVc7QUFFdkIsZ0JBQU0sU0FBUyxNQUFNLEdBQUcsSUFBaUMsT0FBTyxLQUFLLEdBQUc7QUFDeEUsY0FBSSxXQUFXLE9BQVc7QUFHMUIsZ0JBQU0sR0FBRyxJQUFJLE9BQU8sS0FBSztBQUFBLFlBQ3ZCLEdBQUc7QUFBQSxZQUNILGNBQWM7QUFBQSxZQUNkO0FBQUEsVUFDRixDQUFDO0FBQ0QscUJBQVc7QUFBQSxRQUNiO0FBQ0EsZUFBTztBQUFBLE1BQ1Q7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQUFBLEVBRUEsTUFBTSxxQkFBcUIsT0FBa0M7QUFDM0QsUUFBSSxNQUFNLFdBQVcsRUFBRyxRQUFPO0FBRS9CLFdBQU8sS0FBSyxHQUFHLFlBQVksQ0FBQyxPQUFPLEdBQUcsR0FBRyxhQUFhLE9BQU8sT0FBTztBQUNsRSxVQUFJLFVBQVU7QUFDZCxpQkFBVyxRQUFRLE9BQU87QUFDeEIsY0FBTSxNQUFNLE1BQU0sR0FBRyxnQkFBZ0IsT0FBTyxLQUFLLFdBQVcsT0FBTyxJQUFJO0FBQ3ZFLFlBQUksUUFBUSxPQUFXO0FBQ3ZCLGNBQU0sU0FBUyxNQUFNLEdBQUcsSUFBaUMsT0FBTyxLQUFLLEdBQUc7QUFDeEUsWUFBSSxXQUFXLE9BQVc7QUFDMUIsY0FBTSxHQUFHLElBQUksT0FBTyxLQUFLLEVBQUUsR0FBRyxRQUFRLGNBQWMsV0FBVyxDQUFDO0FBQ2hFLG1CQUFXO0FBQUEsTUFDYjtBQUNBLGFBQU87QUFBQSxJQUNULENBQUM7QUFBQSxFQUNIO0FBQUEsRUFFQSxNQUFNLGFBQWEsT0FBa0M7QUFDbkQsUUFBSSxNQUFNLFdBQVcsRUFBRyxRQUFPO0FBRS9CLFdBQU8sS0FBSyxHQUFHLFlBQVksQ0FBQyxPQUFPLEdBQUcsR0FBRyxhQUFhLE9BQU8sT0FBTztBQUNsRSxVQUFJLFVBQVU7QUFDZCxpQkFBVyxRQUFRLE9BQU87QUFDeEIsY0FBTSxNQUFNLE1BQU0sR0FBRyxnQkFBZ0IsT0FBTyxLQUFLLFdBQVcsT0FBTyxJQUFJO0FBQ3ZFLFlBQUksUUFBUSxPQUFXO0FBQ3ZCLGNBQU0sU0FBUyxNQUFNLEdBQUcsSUFBaUMsT0FBTyxLQUFLLEdBQUc7QUFDeEUsWUFBSSxXQUFXLE9BQVc7QUFHMUIsY0FBTSxHQUFHLElBQUksT0FBTyxLQUFLLEVBQUUsR0FBRyxRQUFRLGNBQWMsV0FBVyxDQUFDO0FBQ2hFLG1CQUFXO0FBQUEsTUFDYjtBQUNBLGFBQU87QUFBQSxJQUNULENBQUM7QUFBQSxFQUNIO0FBQUEsRUFFQSxNQUFNLG1CQUFvQztBQUN4QyxXQUFPLGVBQWUsS0FBSyxJQUFJLFVBQVUsZUFBZTtBQUFBLEVBQzFEO0FBQUEsRUFFQSxNQUFNLGlCQUFpQixLQUE0QjtBQUNqRCxVQUFNLEtBQUssR0FBRyxZQUFZLENBQUMsT0FBTyxJQUFJLEdBQUcsYUFBYSxPQUFPLE9BQU87QUFDbEUsWUFBTSxVQUFVLElBQUksVUFBVSxpQkFBaUIsR0FBRztBQUFBLElBQ3BELENBQUM7QUFBQSxFQUNIO0FBQUEsRUFFQSxNQUFNLGlCQUE4RDtBQUNsRSxVQUFNLFNBQVMsTUFBTSxLQUFLLEdBQUc7QUFBQSxNQUMzQixPQUFPO0FBQUEsTUFDUDtBQUFBLElBQ0Y7QUFDQSxXQUFPLFFBQVE7QUFBQSxFQUNqQjtBQUFBLEVBRUEsTUFBTSxnQkFBZ0IsWUFBbUQ7QUFDdkUsUUFBSSxDQUFDLGtCQUFrQixZQUFZLE1BQU0sS0FBSyxnQkFBZ0IsQ0FBQyxHQUFHO0FBQ2hFLFlBQU0sSUFBSTtBQUFBO0FBQUEsUUFFUjtBQUFBLE1BQ0Y7QUFBQSxJQUNGO0FBQ0EsVUFBTSxLQUFLLEdBQUcsWUFBWSxDQUFDLE9BQU8sSUFBSSxHQUFHLGFBQWEsT0FBTyxPQUFPO0FBQ2xFLFlBQU0sR0FBRyxJQUFJLE9BQU8sTUFBTSxFQUFFLEtBQUssNkJBQTZCLE9BQU8sV0FBVyxDQUFDO0FBQUEsSUFDbkYsQ0FBQztBQUFBLEVBQ0g7QUFBQTtBQUFBLEVBR0EsTUFBTSxvQkFBcUQ7QUFDekQsV0FBTyxLQUFLLEdBQUcsWUFBWSxDQUFDLE9BQU8sSUFBSSxHQUFHLFlBQVksT0FBTyxPQUFPO0FBQ2xFLFlBQU0sU0FBUyxNQUFNLEdBQUc7QUFBQSxRQUN0QixPQUFPO0FBQUEsUUFDUCxVQUFVO0FBQUEsTUFDWjtBQUNBLFVBQUksV0FBVyxPQUFXLFFBQU8sQ0FBQztBQUNsQyxhQUFPLHNCQUFzQixPQUFPLEtBQUs7QUFBQSxJQUMzQyxDQUFDO0FBQUEsRUFDSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBUUEsTUFBTSxtQkFBbUIsT0FBOEM7QUFDckUsVUFBTSxXQUFXLHNCQUFzQixLQUFLO0FBQzVDLFVBQU0sS0FBSyxHQUFHLFlBQVksQ0FBQyxPQUFPLElBQUksR0FBRyxhQUFhLE9BQU8sT0FBTztBQUNsRSxZQUFNLFNBQVMsTUFBTSxHQUFHO0FBQUEsUUFDdEIsT0FBTztBQUFBLFFBQ1AsVUFBVTtBQUFBLE1BQ1o7QUFDQSxZQUFNLFVBQVUsV0FBVyxTQUFZLENBQUMsSUFBSSxzQkFBc0IsT0FBTyxLQUFLO0FBQzlFLFlBQU0sU0FBaUMsRUFBRSxHQUFHLFFBQVE7QUFDcEQsaUJBQVcsQ0FBQyxVQUFVLE9BQU8sS0FBSyxPQUFPLFFBQVEsUUFBUSxHQUFHO0FBQzFELGFBQUssT0FBTyxRQUFRLEtBQUssS0FBSyxTQUFTO0FBQ3JDLGlCQUFPLGVBQWUsUUFBUSxVQUFVO0FBQUEsWUFDdEMsT0FBTztBQUFBLFlBQ1AsWUFBWTtBQUFBLFlBQ1osY0FBYztBQUFBLFlBQ2QsVUFBVTtBQUFBLFVBQ1osQ0FBQztBQUFBLFFBQ0g7QUFBQSxNQUNGO0FBQ0EsWUFBTSxHQUFHLElBQUksT0FBTyxNQUFNO0FBQUEsUUFDeEIsQ0FBQyxZQUFZLEdBQUcsR0FBRyxVQUFVO0FBQUEsUUFDN0IsQ0FBQyxZQUFZLEtBQUssR0FBRztBQUFBLE1BQ3ZCLENBQUM7QUFBQSxJQUNILENBQUM7QUFBQSxFQUNIO0FBQUE7QUFBQSxFQUdBLE1BQU0sdUJBQXlDO0FBQzdDLFdBQU8sS0FBSyxHQUFHLFlBQVksQ0FBQyxPQUFPLElBQUksR0FBRyxZQUFZLE9BQU8sT0FBTztBQUNsRSxZQUFNLFNBQVMsTUFBTSxHQUFHO0FBQUEsUUFDdEIsT0FBTztBQUFBLFFBQ1AsVUFBVTtBQUFBLE1BQ1o7QUFDQSxhQUFPLFFBQVEsVUFBVTtBQUFBLElBQzNCLENBQUM7QUFBQSxFQUNIO0FBQUE7QUFBQSxFQUdBLE1BQU0sd0JBQXVDO0FBQzNDLFVBQU0sS0FBSyxHQUFHLFlBQVksQ0FBQyxPQUFPLElBQUksR0FBRyxhQUFhLE9BQU8sT0FBTztBQUNsRSxZQUFNLEdBQUcsSUFBSSxPQUFPLE1BQU07QUFBQSxRQUN4QixDQUFDLFlBQVksR0FBRyxHQUFHLFVBQVU7QUFBQSxRQUM3QixDQUFDLFlBQVksS0FBSyxHQUFHO0FBQUEsTUFDdkIsQ0FBQztBQUFBLElBQ0gsQ0FBQztBQUFBLEVBQ0g7QUFBQSxFQUVBLE1BQU0sYUFBYSxLQUFtRDtBQUNwRSxVQUFNLE1BQU0sTUFBTSxLQUFLLEdBQUcsSUFBNkMsT0FBTyxNQUFNLEdBQUc7QUFDdkYsV0FBTyxLQUFLO0FBQUEsRUFDZDtBQUFBLEVBRUEsTUFBTSxhQUFhLEtBQWEsT0FBdUM7QUFDckUsVUFBTSxLQUFLLEdBQUcsWUFBWSxDQUFDLE9BQU8sSUFBSSxHQUFHLGFBQWEsT0FBTyxPQUFPO0FBQ2xFLFlBQU0sVUFBVSxJQUFJLEtBQUssS0FBSztBQUFBLElBQ2hDLENBQUM7QUFBQSxFQUNIO0FBQ0Y7QUFPQSxTQUFTLGNBQWMsSUFBZ0M7QUFDckQsUUFBTSxVQUFVLEdBQUc7QUFDbkIsU0FDRSxPQUFPLFlBQVksWUFDbkIsWUFBWSxRQUNaLGlCQUFpQixXQUNoQixRQUFzQyxnQkFBZ0I7QUFFM0Q7QUFTQSxlQUFlLGVBQ2IsSUFDQSxLQUNpQjtBQUNqQixRQUFNLE1BQU0sTUFBTSxHQUFHLElBQW9DLE9BQU8sTUFBTSxHQUFHO0FBQ3pFLFNBQU8sS0FBSyxTQUFTO0FBQ3ZCO0FBRUEsZUFBZSxVQUFVLElBQVUsS0FBYSxPQUErQjtBQUM3RSxRQUFNLEdBQUcsSUFBSSxPQUFPLE1BQU0sRUFBRSxDQUFDLFlBQVksR0FBRyxHQUFHLEtBQUssQ0FBQyxZQUFZLEtBQUssR0FBRyxNQUFNLENBQUM7QUFDbEY7QUFHQSxTQUFTLHNCQUFzQixPQUF3QztBQUNyRSxNQUFJLFVBQVUsUUFBUSxPQUFPLFVBQVUsWUFBWSxNQUFNLFFBQVEsS0FBSyxHQUFHO0FBQ3ZFLFVBQU0sSUFBSSxVQUFVLCtDQUFzQjtBQUFBLEVBQzVDO0FBQ0EsUUFBTSxZQUFZLE9BQU8sZUFBZSxLQUFLO0FBQzdDLE1BQUksY0FBYyxPQUFPLGFBQWEsY0FBYyxNQUFNO0FBQ3hELFVBQU0sSUFBSSxVQUFVLDJEQUF3QjtBQUFBLEVBQzlDO0FBQ0EsTUFBSSxRQUFRLFFBQVEsS0FBSyxFQUFFLEtBQUssQ0FBQyxRQUFRLE9BQU8sUUFBUSxRQUFRLEdBQUc7QUFDakUsVUFBTSxJQUFJLFVBQVUsaUVBQXlCO0FBQUEsRUFDL0M7QUFDQSxRQUFNLFFBQWdDLENBQUM7QUFDdkMsYUFBVyxDQUFDLFVBQVUsT0FBTyxLQUFLLE9BQU8sUUFBUSxLQUFLLEdBQUc7QUFDdkQsUUFBSSxDQUFDLE9BQU8sY0FBYyxPQUFPLEtBQUssVUFBVSxHQUFHO0FBQ2pELFlBQU0sSUFBSTtBQUFBLFFBQ1IsdUJBQWtCLFFBQVEsdUZBQWlCLE9BQU8sT0FBTyxDQUFDO0FBQUEsTUFDNUQ7QUFBQSxJQUNGO0FBQ0EsV0FBTyxlQUFlLE9BQU8sVUFBVTtBQUFBLE1BQ3JDLE9BQU87QUFBQSxNQUNQLFlBQVk7QUFBQSxNQUNaLGNBQWM7QUFBQSxNQUNkLFVBQVU7QUFBQSxJQUNaLENBQUM7QUFBQSxFQUNIO0FBQ0EsU0FBTztBQUNUOyIsIm5hbWVzIjpbIk9wTG9nU3RvcmVFcnJvckNvZGUiLCJzdG9yZSIsInJlc3VsdCIsInBhcmFtcyIsImNvbmRpdGlvbnMiLCJyb3dzIiwiY29tcGFyZUtleXMiLCJ2YWx1ZUF0UGF0aCJdfQ==